import copy
import io
import json
import math
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

import optuna

from src.configs import m2patch_profiles as profiles
from src.hpo import warm_start
from src.hpo.search_space import build_search_space


class WarmStartTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="m2patch-hpo-warm-test-")
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        directory_patch = mock.patch.object(warm_start, "_OUTPUT_DIR", str(self.directory))
        directory_patch.start()
        self.addCleanup(directory_patch.stop)
        output = redirect_stdout(io.StringIO())
        output.__enter__()
        self.addCleanup(output.__exit__, None, None, None)
        self.dataset = "ETTh1"
        self.pred_len = 96
        self.space = build_search_space(self.dataset, self.pred_len)
        self.fixed = {"dropout": 0.1, "pct_start": 0.2}

    def write_baseline(self, params, directory=None, dataset="ETTh1", pred_len=96, best_value=1e-12, best_trial_number=47):
        directory = self.directory if directory is None else Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"M2Patch_{dataset}_pl{pred_len}_best_params.json"
        payload = {
            "study_name": f"M2Patch_{dataset}_pl{pred_len}",
            "version": "historical",
            "best_value": best_value,
            "best_params": params,
            "best_trial_number": best_trial_number,
            "best_trial_user_attrs": {"mse": best_value},
        }
        path.write_text(json.dumps(payload), encoding="utf-8")
        return path

    def profile_params(self):
        profile = profiles.resolve(self.dataset, self.pred_len)
        return {key: profile[key] for key in self.space if key not in self.fixed}

    def new_study(self):
        return optuna.create_study(sampler=optuna.samplers.RandomSampler(seed=2023))

    def initialize(self, study, **kwargs):
        return warm_start.initialize_study(study, self.dataset, self.pred_len, self.space, self.fixed, optuna_dir=self.directory, **kwargs)

    def assert_waiting_records(self, study, records):
        self.assertEqual(len(study.trials), len(records))
        for trial, record in zip(study.trials, records):
            self.assertEqual(trial.state, optuna.trial.TrialState.WAITING)
            self.assertIsNone(trial.value)
            self.assertEqual(trial.system_attrs["fixed_params"], record["params"])
            self.assertEqual(trial.user_attrs["seed_source"], record["seed_source"])
            self.assertEqual(trial.user_attrs["warm_start"], record["warm_start"])
            self.assertNotIn("dropout", record["params"])
            self.assertNotIn("pct_start", record["params"])
            self.assertLessEqual(set(record["params"]), set(self.space))

    def assert_feasible_patch_completion(self, params, space, fixed):
        choices = {}
        for key in ("patch_len", "stride"):
            if key in fixed:
                choices[key] = [fixed[key]]
            elif key in params:
                choices[key] = [params[key]]
            else:
                choices[key] = space[key]["choices"]
        self.assertTrue(any(stride <= patch_len for patch_len in choices["patch_len"] for stride in choices["stride"]))

    def test_load_baseline_separates_provenance_without_filtering_parameters(self):
        params = {**self.profile_params(), "dropout": 0.19, "pct_start": 0.37, "unknown": "historical"}
        path = self.write_baseline(params)
        baseline = warm_start.load_baseline("ETTh1", 96, optuna_dir=self.directory)
        self.assertEqual(set(baseline), {"best_params", "source_file", "best_value", "best_trial_number"})
        self.assertEqual(baseline["best_params"], params)
        self.assertEqual(Path(baseline["source_file"]), path.resolve())
        self.assertEqual(baseline["best_value"], 1e-12)
        self.assertEqual(baseline["best_trial_number"], 47)
        self.assertNotIn("_source", baseline["best_params"])
        self.assertNotIn("_best_value", baseline["best_params"])

    def test_aliases_load_canonical_and_lowercase_filenames(self):
        cases = (("etth1", "ETTh1", 96), ("ili", "Illness", 24), ("Solar-Energy", "Solar", 96), ("pems03", "PEMS03", 12))
        for alias, canonical, pred_len in cases:
            for filename_dataset in (canonical, canonical.lower()):
                with self.subTest(alias=alias, filename_dataset=filename_dataset):
                    directory = self.directory / f"{alias}-{filename_dataset}"
                    path = self.write_baseline({"d_model": 128}, directory, filename_dataset, pred_len)
                    baseline = warm_start.load_baseline(alias, pred_len, optuna_dir=directory)
                    self.assertIsNotNone(baseline)
                    self.assertEqual(baseline["best_params"], {"d_model": 128})
                    self.assertEqual(Path(baseline["source_file"]), path.resolve())

    def test_load_baseline_uses_only_exact_horizon(self):
        self.write_baseline(self.profile_params(), pred_len=96)
        for pred_len in (95, 100, 192, 336, 720):
            with self.subTest(pred_len=pred_len):
                self.assertIsNone(warm_start.load_baseline("ETTh1", pred_len, optuna_dir=self.directory))

    def test_missing_or_malformed_json_falls_back_to_profile(self):
        contents = (
            None,
            b"{broken",
            b"\xff",
            b"null",
            b"[]",
            b"{}",
            b'{"best_params": null}',
            b'{"best_params": []}',
            b'{"best_params": "invalid"}',
            b'{"best_params": {}}',
        )
        for index, content in enumerate(contents):
            with self.subTest(content=content):
                directory = self.directory / str(index)
                directory.mkdir()
                if content is not None:
                    (directory / "M2Patch_ETTh1_pl96_best_params.json").write_bytes(content)
                self.assertIsNone(warm_start.load_baseline("ETTh1", 96, optuna_dir=directory))
                study = self.new_study()
                records = warm_start.initialize_study(study, "ETTh1", 96, self.space, self.fixed, optuna_dir=directory)
                self.assertEqual([record["seed_source"] for record in records], ["profile"])
                self.assertEqual(records[0]["params"], self.profile_params())
                self.assert_waiting_records(study, records)

    def test_malformed_canonical_file_does_not_hide_valid_lowercase_file(self):
        (self.directory / "M2Patch_ETTh1_pl96_best_params.json").write_text("{bad", encoding="utf-8")
        path = self.write_baseline({"d_model": 384}, dataset="etth1")
        baseline = warm_start.load_baseline("ETTH1", 96, optuna_dir=self.directory)
        self.assertEqual(baseline["best_params"], {"d_model": 384})
        self.assertEqual(Path(baseline["source_file"]), path.resolve())

    def test_validate_returns_only_searchable_values_and_does_not_mutate_inputs(self):
        baseline = {
            "d_model": 384,
            "learning_rate": 0.0005,
            "dropout": 0.19,
            "pct_start": 0.39,
            "_source": "legacy.json",
            "_best_value": 1e-12,
            "source_file": "legacy.json",
            "best_value": 1e-12,
            "best_trial_number": 47,
            "unknown": {"nested": [1, 2]},
        }
        space = {**self.space, "dropout": {"type": "uniform", "low": 0.0, "high": 0.5}}
        before = copy.deepcopy((baseline, space, self.fixed))
        result = warm_start.validate_baseline(baseline, space, self.fixed)
        self.assertEqual(result, {"d_model": 384, "learning_rate": 0.0005})
        self.assertEqual((baseline, space, self.fixed), before)
        result["d_model"] = 512
        self.assertEqual(baseline["d_model"], 384)

    def test_validation_rejects_invalid_scalar_types_ranges_and_categories(self):
        common_invalid = (True, False, None, "1", [], {}, float("nan"), float("inf"), float("-inf"))
        cases = (
            ({"type": "categorical", "choices": [1, 2]}, common_invalid + (0, 3, 1.5)),
            ({"type": "int", "low": 1, "high": 7, "step": 2}, common_invalid + (0, 2, 8, 3.0, 3.5)),
            ({"type": "uniform", "low": 0.1, "high": 0.5}, common_invalid + (-0.1, 0.0, 0.6)),
            ({"type": "loguniform", "low": 0.0001, "high": 0.001}, common_invalid + (-1, 0, 0.01)),
        )
        for spec, values in cases:
            for value in values:
                with self.subTest(spec=spec, value=value):
                    self.assertEqual(warm_start.validate_baseline({"value": value}, {"value": spec}), {})

    def test_valid_numeric_categories_are_normalized_to_choice_types(self):
        space = {
            "category": {"type": "categorical", "choices": [128, 256]},
            "integer": {"type": "int", "low": 1, "high": 7, "step": 2},
            "float": {"type": "uniform", "low": 0.0, "high": 2.0},
            "rate": {"type": "loguniform", "low": 0.0001, "high": 0.001},
        }
        baseline = {"category": 128.0, "integer": 3, "float": 1, "rate": 0.0001}
        result = warm_start.validate_baseline(baseline, space)
        self.assertEqual(result, {"category": 128, "integer": 3, "float": 1.0, "rate": 0.0001})
        self.assertIs(type(result["category"]), int)
        self.assertIs(type(result["integer"]), int)
        self.assertIs(type(result["float"]), float)
        self.assertTrue(all(math.isfinite(value) for value in result.values()))

    def test_stride_conflicts_are_filtered_without_inventing_parameter_values(self):
        space = {
            "patch_len": {"type": "categorical", "choices": [8, 16]},
            "stride": {"type": "categorical", "choices": [4, 8, 16, 32]},
            "learning_rate": {"type": "loguniform", "low": 0.0001, "high": 0.001},
        }
        cases = (
            ({"patch_len": 8, "stride": 16, "learning_rate": 0.0003}, {}),
            ({"stride": 32, "learning_rate": 0.0003}, {}),
            ({"stride": 16, "learning_rate": 0.0003}, {"patch_len": 8}),
            ({"patch_len": 8, "learning_rate": 0.0003}, {"stride": 16}),
        )
        for baseline, fixed in cases:
            with self.subTest(baseline=baseline, fixed=fixed):
                result = warm_start.validate_baseline(baseline, space, fixed)
                self.assertEqual(result.get("learning_rate"), 0.0003)
                self.assertTrue(all(key in baseline and value == baseline[key] for key, value in result.items()))
                self.assert_feasible_patch_completion(result, space, fixed)
        tight = {**space, "stride": {"type": "categorical", "choices": [16, 32]}}
        result = warm_start.validate_baseline({"patch_len": 8, "learning_rate": 0.0003}, tight)
        self.assertNotIn("patch_len", result)
        self.assert_feasible_patch_completion(result, tight, {})

    def test_new_study_enqueues_json_before_distinct_profile_with_provenance(self):
        params = self.profile_params()
        profile_rate = params["learning_rate"]
        params["learning_rate"] = next(value for value in (self.space["learning_rate"]["low"], self.space["learning_rate"]["high"]) if value != profile_rate)
        params.update({"dropout": 0.19, "pct_start": 0.37, "d_ff": 12345, "unknown": "ignored"})
        path = self.write_baseline(params)
        study = self.new_study()
        records = self.initialize(study)
        self.assertEqual([record["seed_source"] for record in records], ["json", "profile"])
        self.assertEqual(records[1]["params"], self.profile_params())
        self.assertNotEqual(records[0]["params"], records[1]["params"])
        self.assert_waiting_records(study, records)
        metadata = records[0]["warm_start"]
        self.assertEqual(Path(metadata["source_file"]), path.resolve())
        self.assertEqual(metadata["best_value"], 1e-12)
        self.assertEqual(metadata["best_trial_number"], 47)
        self.assertEqual(metadata["accepted"], records[0]["params"])
        for key in ("dropout", "pct_start", "d_ff", "unknown"):
            self.assertEqual(metadata["ignored"][key]["value"], params[key])
            self.assertTrue(metadata["ignored"][key]["reason"])
        with self.assertRaises(ValueError):
            _ = study.best_value

    def test_json_equal_to_profile_after_filtering_is_enqueued_only_once(self):
        params = {**self.profile_params(), "dropout": 0.19, "pct_start": 0.39, "seed": 7}
        self.write_baseline(params)
        study = self.new_study()
        records = self.initialize(study)
        self.assertEqual([record["seed_source"] for record in records], ["json"])
        self.assertEqual(records[0]["params"], self.profile_params())
        self.assert_waiting_records(study, records)

    def test_warm_start_opt_out_does_not_read_json_and_still_enqueues_profile(self):
        self.write_baseline({"learning_rate": 0.0005})
        study = self.new_study()
        with mock.patch.object(warm_start, "load_baseline", side_effect=AssertionError("JSON must not be read")) as loader:
            records = self.initialize(study, warm_start=False)
        loader.assert_not_called()
        self.assertEqual([record["seed_source"] for record in records], ["profile"])
        self.assertEqual(records[0]["params"], self.profile_params())
        self.assert_waiting_records(study, records)

    def test_all_existing_trial_states_prevent_reinitialization_and_source_reads(self):
        for state in optuna.trial.TrialState:
            for enabled in (True, False):
                with self.subTest(state=state.name, warm_start=enabled):
                    study = self.new_study()
                    value = 0.5 if state == optuna.trial.TrialState.COMPLETE else None
                    study.add_trial(optuna.trial.create_trial(state=state, value=value, user_attrs={"existing": state.name}))
                    before = study.get_trials(deepcopy=True)
                    with mock.patch.object(warm_start, "load_baseline", side_effect=AssertionError("JSON must not be read")) as loader:
                        with mock.patch.object(warm_start, "resolve", side_effect=AssertionError("Profile must not be read")) as resolver:
                            records = self.initialize(study, warm_start=enabled)
                    self.assertEqual(records, [])
                    self.assertEqual(study.trials, before)
                    loader.assert_not_called()
                    resolver.assert_not_called()

    def test_second_initialization_does_not_duplicate_waiting_candidates(self):
        study = self.new_study()
        first = self.initialize(study)
        before = study.get_trials(deepcopy=True)
        with mock.patch.object(warm_start, "load_baseline", side_effect=AssertionError("JSON must not be read")):
            self.assertEqual(self.initialize(study), [])
        self.assertEqual(study.trials, before)
        self.assert_waiting_records(study, first)

    def test_fully_invalid_json_candidate_falls_back_to_profile(self):
        self.write_baseline({"d_model": True, "patch_len": None, "stride": "8", "learning_rate": float("nan"), "dropout": 0.19, "pct_start": 0.39})
        study = self.new_study()
        records = self.initialize(study)
        self.assertEqual([record["seed_source"] for record in records], ["profile"])
        self.assertEqual(records[0]["params"], self.profile_params())
        self.assert_waiting_records(study, records)

    def test_nonfinite_provenance_and_ignored_values_are_json_safe(self):
        self.write_baseline({"learning_rate": 0.0005, "d_model": float("inf")}, best_value=float("nan"))
        study = self.new_study()
        records = self.initialize(study)
        self.assertEqual(records[0]["seed_source"], "json")
        self.assertEqual(records[0]["params"], {"learning_rate": 0.0005})
        self.assert_waiting_records(study, records)
        json.dumps(records, allow_nan=False)
        json.dumps(study.trials[0].user_attrs, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
