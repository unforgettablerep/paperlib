import copy
import io
import json
import subprocess
import sys
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from unittest import mock

import optuna

from src.configs import m2patch_cli
from src.configs import m2patch_profiles as profiles
from src.hpo import search_space, study_manager, warm_start

with mock.patch("subprocess.run", return_value=subprocess.CompletedProcess([], 1, stdout="", stderr="")):
    from src.hpo import objective


class HPOTestCase(unittest.TestCase):
    def setUp(self):
        self.directory = Path(self.enterContext(tempfile.TemporaryDirectory(prefix="m2patch-hpo-test-")))
        self.output_dir = self.directory / "output"
        self.storage = optuna.storages.InMemoryStorage()
        self.enterContext(mock.patch.object(study_manager, "TEMP_OPTUNA_DIR", str(self.directory / "storage")))
        self.enterContext(mock.patch.object(study_manager, "OUTPUT_OPTUNA_DIR", str(self.output_dir)))
        self.enterContext(mock.patch.object(study_manager, "STORAGE_TEMPLATE", f"sqlite:///{self.directory}/{{}}.db"))
        self.enterContext(mock.patch.object(study_manager, "_make_storage", return_value=self.storage))
        self.enterContext(mock.patch.object(warm_start, "_OUTPUT_DIR", str(self.output_dir)))
        self.enterContext(redirect_stdout(io.StringIO()))

    def fixed_params(self, dataset="ETTh1", pred_len=96, **overrides):
        params = {
            **profiles.resolve_meta(dataset, pred_len),
            "dataset": dataset,
            "dec_in": profiles.DATASET_META[dataset]["enc_in"],
            "model": "M2Patch",
            "des": "HPO_OPTUNA",
            "save_tmp": 0,
            "use_cuda_accel": 0,
            "use_amp": False,
            "num_workers": 0,
            "train_epochs": 7,
            "patience": 3,
            "seed": 2023,
        }
        params.update(overrides)
        return params

    def profile_params(self, dataset="ETTh1", pred_len=96):
        profile = profiles.resolve(dataset, pred_len)
        return {key: profile[key] for key in search_space.build_search_space(dataset, pred_len)}

    def create_study(self, dataset="ETTh1", pred_len=96, fixed=None):
        return study_manager.create_study(
            study_name=f"M2Patch_{dataset}_pl{pred_len}",
            search_space_spec=search_space.build_search_space(dataset, pred_len),
            fixed_params=self.fixed_params(dataset, pred_len) if fixed is None else fixed,
        )

    def export(self, study):
        study_manager.export_results(study.study_name)
        path = self.output_dir / f"{study.study_name}_best_params.json"
        return json.loads(path.read_text(encoding="utf-8"))


class FixedProfileTests(HPOTestCase):
    def test_all_56_profiles_fix_dropout_and_pct_start_outside_search(self):
        self.assertEqual(len(profiles.DATASET_META), 14)
        self.assertNotIn("dropout", search_space.PARAM_ORDER)
        self.assertNotIn("pct_start", search_space.PARAM_ORDER)
        for group in search_space.HPO_PARAM_GROUPS.values():
            self.assertNotIn("dropout", group)
            self.assertNotIn("pct_start", group)
        cells = 0
        for dataset, meta in profiles.DATASET_META.items():
            self.assertEqual(len(meta["pred_lens"]), 4)
            for pred_len in meta["pred_lens"]:
                with self.subTest(dataset=dataset, pred_len=pred_len):
                    cells += 1
                    dropout = 0.2 if dataset == "Illness" else 0.1
                    profile = profiles.resolve(dataset, pred_len)
                    fixed = search_space.get_fixed_params(dataset, pred_len)
                    space = search_space.build_search_space(dataset, pred_len)
                    self.assertEqual(profile["dropout"], dropout)
                    self.assertEqual(profile["pct_start"], 0.2)
                    self.assertEqual(fixed["dropout"], dropout)
                    self.assertEqual(fixed["pct_start"], 0.2)
                    self.assertNotIn("dropout", space)
                    self.assertNotIn("pct_start", space)
                    study = optuna.create_study(sampler=optuna.samplers.RandomSampler(seed=2023))
                    trial = study.ask()
                    suggested = objective._suggest_params(trial, space)
                    self.assertEqual(set(suggested), set(space))
                    self.assertEqual(trial.params, suggested)
                    self.assertNotIn("dropout", trial.params)
                    self.assertNotIn("pct_start", trial.params)
        self.assertEqual(cells, 56)
        self.assertEqual(profiles.CONSTANTS["pct_start"], 0.2)

    def test_resolve_fixed_params_ignores_stale_values_and_honors_runtime_overrides(self):
        for dataset, pred_len, dropout in (("ETTh1", 96, 0.1), ("Illness", 24, 0.2)):
            with self.subTest(dataset=dataset):
                supplied = self.fixed_params(dataset, pred_len, dropout=0.99, pct_start=0.99, batch_size=5, gpu=4, unknown="discarded", d_ff=12345)
                before = copy.deepcopy(supplied)
                fixed = objective.resolve_fixed_params(supplied)
                self.assertEqual(fixed["dropout"], dropout)
                self.assertEqual(fixed["pct_start"], 0.2)
                for key in ("train_epochs", "patience", "batch_size", "gpu", "save_tmp", "use_amp", "num_workers", "seed"):
                    self.assertEqual(fixed[key], supplied[key])
                self.assertNotIn("unknown", fixed)
                self.assertNotIn("d_ff", fixed)
                self.assertEqual(supplied, before)
                args = objective._build_args(fixed, {**self.profile_params(dataset, pred_len), "dropout": 0.98, "pct_start": 0.98})
                self.assertEqual(args.dropout, dropout)
                self.assertEqual(args.pct_start, 0.2)
                self.assertEqual(args.train_epochs, 7)
                self.assertEqual(args.patience, 3)
                self.assertEqual(args.d_ff, min(args.d_model * 2, profiles.D_FF_CAP))
        alias = objective.resolve_fixed_params({"dataset": "ili", "pred_len": 24, "dropout": 0.99, "pct_start": 0.99})
        self.assertEqual(alias["dataset"], "Illness")
        self.assertEqual((alias["dropout"], alias["pct_start"]), (0.2, 0.2))

    def test_historical_from_optuna_cli_preserves_json_dropout_and_pct_start(self):
        self.output_dir.mkdir()
        path = self.output_dir / "M2Patch_ETTh1_pl96_best_params.json"
        path.write_text(json.dumps({"best_params": {"d_model": 384, "dropout": 0.17, "pct_start": 0.37}}), encoding="utf-8")
        config = profiles.load_optuna_best_params("ETTh1", 96, optuna_dir=str(self.output_dir))
        self.assertEqual((config["dropout"], config["pct_start"]), (0.17, 0.37))
        command = ["m2patch_cli", "ETTh1", "96", "--from-optuna", "--optuna-dir", str(self.output_dir)]
        with mock.patch.object(sys, "argv", command), redirect_stdout(io.StringIO()) as output:
            m2patch_cli.main()
        flags = output.getvalue().split()
        self.assertEqual(flags[flags.index("--dropout") + 1], "0.17")
        self.assertEqual(flags[flags.index("--pct_start") + 1], "0.37")
        self.assertEqual(profiles.resolve("ETTh1", 96)["dropout"], 0.1)
        self.assertEqual(profiles.resolve("ETTh1", 96)["pct_start"], 0.2)


class StudyFingerprintTests(HPOTestCase):
    def test_identical_configuration_resumes_with_fixed_values_in_fingerprint(self):
        fixed = self.fixed_params(dropout=0.99, pct_start=0.99)
        study = self.create_study(fixed=fixed)
        fingerprint = study.user_attrs["hpo_config"]
        self.assertEqual(fingerprint["fixed_params"]["dropout"], 0.1)
        self.assertEqual(fingerprint["fixed_params"]["pct_start"], 0.2)
        self.assertEqual(fingerprint["fixed_params"]["train_epochs"], 7)
        self.assertEqual(fingerprint["fixed_params"]["patience"], 3)
        self.assertEqual(fingerprint["d_ff_cap"], profiles.D_FF_CAP)
        self.assertEqual(
            fingerprint["pruner"],
            {"name": "HyperbandPruner", "min_resource": 4, "max_resource": 7, "reduction_factor": 3},
        )
        self.assertEqual(study.pruner._min_resource, 4)
        self.assertEqual(study.pruner._reduction_factor, 3)
        self.assertEqual(study.pruner._max_resource, 7)
        study.enqueue_trial(self.profile_params())
        resumed = self.create_study(fixed=copy.deepcopy(fixed))
        self.assertEqual(resumed.user_attrs["hpo_config"], fingerprint)
        self.assertEqual(resumed.trials, study.trials)
        self.assertEqual(len(resumed.trials), 1)

    def test_changed_fixed_profile_values_reject_resume(self):
        study = self.create_study()
        original = study.user_attrs["hpo_config"]
        real_get_fixed = study_manager.get_fixed_params
        for key, value in (("dropout", 0.15), ("pct_start", 0.25)):
            with self.subTest(key=key):
                def changed_profile(*args, **kwargs):
                    return {**real_get_fixed(*args, **kwargs), key: value}

                with mock.patch.object(study_manager, "get_fixed_params", side_effect=changed_profile):
                    with self.assertRaisesRegex(RuntimeError, "different HPO configuration|mixed resume"):
                        self.create_study()
                self.assertEqual(study.user_attrs["hpo_config"], original)

    def test_changed_runtime_epochs_or_patience_reject_resume(self):
        self.create_study()
        for key, value in (("train_epochs", 8), ("patience", 4)):
            with self.subTest(key=key):
                with self.assertRaisesRegex(RuntimeError, "different HPO configuration|mixed resume"):
                    self.create_study(fixed=self.fixed_params(**{key: value}))

    def test_changed_pruner_configuration_rejects_resume(self):
        self.create_study()
        with mock.patch.object(study_manager, "PRUNER_MIN_RESOURCE", 5):
            with self.assertRaisesRegex(RuntimeError, "different HPO configuration|mixed resume"):
                self.create_study()

    def test_resume_uses_random_sampler_seed(self):
        recorded = []
        real_sampler = study_manager.TPESampler

        class RecordingSampler(real_sampler):
            def __init__(self, *args, **kwargs):
                recorded.append(kwargs.get("seed"))
                super().__init__(*args, **kwargs)

        with mock.patch.object(study_manager, "TPESampler", RecordingSampler):
            study = self.create_study()
            self.create_study()
            study.enqueue_trial(self.profile_params())
            resumed = self.create_study()

        self.assertEqual(recorded[:2], [2023, 2023])
        self.assertIsNone(recorded[2])
        self.assertEqual(resumed.user_attrs["hpo_config"]["seed"], 2023)

    def test_study_without_fingerprint_cannot_be_resumed(self):
        optuna.create_study(study_name="M2Patch_ETTh1_pl96", storage=self.storage)
        with self.assertRaisesRegex(RuntimeError, "predates config fingerprinting|missing user attr"):
            self.create_study()

    def test_fingerprint_excludes_library_versions(self):
        study = self.create_study()
        fingerprint = study.user_attrs["hpo_config"]
        for key in study_manager.LEGACY_ENV_INFO_KEYS:
            self.assertNotIn(key, fingerprint)

    def test_legacy_fingerprint_with_env_versions_allows_cross_host_resume(self):
        study = self.create_study()
        study.enqueue_trial(self.profile_params())
        fingerprint = study.user_attrs["hpo_config"]
        legacy = {
            **fingerprint,
            "torch_version": "2.8.0+cu129",
            "optuna_version": "3.0.0",
        }
        study.set_user_attr("hpo_config", legacy)
        resumed = self.create_study()
        self.assertEqual(resumed.trials, study.trials)
        self.assertEqual(len(resumed.trials), 1)
        self.assertEqual(resumed.user_attrs["hpo_config"], legacy)

    def test_legacy_fingerprint_with_mask_keys_allows_resume(self):
        study = self.create_study()
        study.enqueue_trial(self.profile_params())
        fingerprint = study.user_attrs["hpo_config"]
        legacy = {
            **fingerprint,
            "fixed_params": {
                **fingerprint["fixed_params"],
                "mask_ratio": 0.0,
                "mask_value": 0.0,
                "train_mask_ratio": 0.0,
            },
        }
        study.set_user_attr("hpo_config", legacy)
        resumed = self.create_study()
        self.assertEqual(resumed.trials, study.trials)
        self.assertEqual(len(resumed.trials), 1)
        self.assertEqual(resumed.user_attrs["hpo_config"], legacy)


class ObjectiveAndExportTests(HPOTestCase):
    def run_fake_objective(self, fixed, study):
        events = []
        instances = []

        class FakeExperiment:
            def __init__(self, args):
                self.args = args
                self.trained = False
                instances.append(self)
                events.append(("init", args.des))

            def train(self, setting):
                self.trained = True
                self.setting = setting
                events.append(("train", setting))

            def test(self, setting):
                if not self.trained or setting != self.setting:
                    raise AssertionError("Test must evaluate the newly trained candidate")
                events.append(("test", setting))
                errors = [prediction - target for prediction, target in zip((1.0, 3.0), (0.0, 1.0))]
                return {"mse": sum(error ** 2 for error in errors) / len(errors), "mae": sum(abs(error) for error in errors) / len(errors)}

        with ExitStack() as patches:
            budget_class = patches.enter_context(mock.patch.object(objective, "PerGPUBudget"))
            budget_class.return_value.acquire.return_value = True
            patches.enter_context(mock.patch.object(objective, "Exp_Long_Term_Forecast", FakeExperiment))
            patches.enter_context(mock.patch.object(objective, "_estimate", return_value=64.0))
            patches.enter_context(mock.patch.object(objective, "TOTAL_GPU_MEMORY_MB", 1024))
            patches.enter_context(mock.patch.object(objective, "_release_cuda_cache"))
            patches.enter_context(mock.patch.object(objective.torch, "manual_seed"))
            patches.enter_context(mock.patch.object(objective.random, "seed"))
            patches.enter_context(mock.patch.object(objective.np.random, "seed"))
            patches.enter_context(mock.patch("src.utils.checkpoint.cleanup_checkpoint", side_effect=AssertionError("No real checkpoint exists")))
            patches.enter_context(mock.patch("src.utils.checkpoint.save_checkpoint", side_effect=AssertionError("No real checkpoint may be saved")))
            patches.enter_context(mock.patch("src.utils.result_io.write_test_result", side_effect=AssertionError("No real result may be written")))
            trial_objective = objective.create_objective(fixed, physical_gpu=0)
            study.optimize(trial_objective, n_trials=1)
        budget_class.assert_called_once_with(0)
        budget_class.return_value.acquire.assert_called_once()
        budget_class.return_value.release.assert_called_once()
        acquired_key = budget_class.return_value.acquire.call_args.args[0]
        budget_class.return_value.release.assert_called_once_with(acquired_key)
        self.assertEqual([event[0] for event in events], ["init", "train", "test"])
        self.assertEqual(len(instances), 1)
        return instances[0].args

    def test_warm_candidate_is_trained_and_scored_with_actual_fixed_profile(self):
        for dataset, pred_len, dropout in (("ETTh1", 96, 0.1), ("Illness", 24, 0.2)):
            with self.subTest(dataset=dataset):
                self.output_dir.mkdir(exist_ok=True)
                old_params = {**self.profile_params(dataset, pred_len), "dropout": 0.19, "pct_start": 0.39}
                historical = {"best_params": old_params, "best_value": 1e-12, "best_trial_number": 99}
                path = self.output_dir / f"M2Patch_{dataset}_pl{pred_len}_best_params.json"
                path.write_text(json.dumps(historical), encoding="utf-8")
                supplied = self.fixed_params(dataset, pred_len, dropout=0.99, pct_start=0.99)
                fixed = objective.resolve_fixed_params(supplied)
                study = self.create_study(dataset, pred_len, fixed)
                records = warm_start.initialize_study(study, dataset, pred_len, search_space.build_search_space(dataset, pred_len), fixed, optuna_dir=self.output_dir)
                self.assertEqual([record["seed_source"] for record in records], ["json"])
                self.assertIsNone(study.trials[0].value)
                args = self.run_fake_objective(supplied, study)
                best = study.best_trial
                self.assertEqual(best.state, optuna.trial.TrialState.COMPLETE)
                self.assertEqual(best.value, 2.5)
                self.assertEqual(best.user_attrs["mse"], 2.5)
                self.assertEqual(best.user_attrs["mae"], 1.5)
                self.assertNotEqual(best.value, historical["best_value"])
                self.assertEqual(best.user_attrs["warm_start"]["best_value"], 1e-12)
                self.assertEqual((args.dropout, args.pct_start), (dropout, 0.2))
                self.assertEqual((args.train_epochs, args.patience), (7, 3))
                self.assertEqual(args.save_tmp, 0)
                self.assertEqual(args.use_cuda_accel, 0)
                self.assertNotIn("dropout", best.params)
                self.assertNotIn("pct_start", best.params)
                snapshot = best.user_attrs["effective_params"]
                for key in profiles.CLI_ORDER + ["seed", "use_amp", "use_cuda_accel", "dataset", "pred_len"]:
                    self.assertEqual(snapshot[key], getattr(args, key))
                self.assertEqual(snapshot["d_ff"], min(args.d_model * 2, profiles.D_FF_CAP))
                with mock.patch.object(study_manager, "get_fixed_params", side_effect=AssertionError("Export must use the stored snapshot")):
                    with mock.patch.object(profiles, "D_FF_CAP", 16), mock.patch.object(study_manager, "D_FF_CAP", 16):
                        with mock.patch.dict(profiles.CONSTANTS, {"dropout": 0.88, "pct_start": 0.88, "train_epochs": 88, "patience": 88}):
                            exported = self.export(study)
                self.assertEqual(set(exported), {"study_name", "version", "best_value", "best_params", "best_trial_number", "best_trial_user_attrs"})
                self.assertEqual(exported["study_name"], study.study_name)
                self.assertEqual(exported["best_value"], 2.5)
                self.assertEqual(exported["best_trial_number"], best.number)
                public_params = {key: snapshot[key] for key in profiles.CLI_ORDER + ["seed"] if key in snapshot}
                self.assertEqual(exported["best_params"], public_params)
                self.assertEqual(set(exported["best_trial_user_attrs"]), {"mse", "mae", "checkpoint", "arch_signature"})
                self.assertEqual(exported["best_trial_user_attrs"]["mse"], 2.5)
                self.assertNotIn("effective_params", exported["best_trial_user_attrs"])
                self.assertNotIn("seed_source", exported["best_trial_user_attrs"])
                self.assertNotIn("warm_start", exported["best_trial_user_attrs"])

    def test_export_allows_only_public_trial_attributes(self):
        study = self.create_study()
        snapshot = {**profiles.resolve("ETTh1", 96), "train_epochs": 7, "patience": 3, "seed": 2023, "unknown": "private"}
        allowed = {"mse": 0.4, "mae": 0.3, "checkpoint": None, "arch_signature": "architecture", "cuda_accel_auto_disabled": True, "cuda_accel_overhead_mb": 123.0}
        internal = {
            "seed_source": "json", "warm_start": {"best_value": 1e-12}, "setting": "private",
            "status": "ok", "est_mb": 64.0, "error_trace": "private", "unknown": "private",
        }
        trial = optuna.trial.create_trial(value=0.4, user_attrs={**allowed, **internal, "effective_params": snapshot})
        study.add_trial(trial)
        exported = self.export(study)
        self.assertEqual(exported["best_trial_user_attrs"], allowed)
        self.assertNotIn("unknown", exported["best_params"])
        self.assertEqual(exported["best_params"]["train_epochs"], 7)
        self.assertEqual(exported["best_params"]["patience"], 3)

    def test_legacy_export_uses_stored_fingerprint_without_filling_current_profile(self):
        study = self.create_study()
        fingerprint = study.user_attrs["hpo_config"]
        fingerprint["fixed_params"].update({"dropout": 0.17, "pct_start": 0.37, "train_epochs": 9, "patience": 4})
        fingerprint.update({"train_epochs": 9, "patience": 4, "d_ff_cap": 640})
        study.set_user_attr("hpo_config", fingerprint)
        distributions = {"d_model": optuna.distributions.CategoricalDistribution([384, 512])}
        study.add_trial(optuna.trial.create_trial(value=0.5, params={"d_model": 512}, distributions=distributions))
        with mock.patch.object(study_manager, "get_fixed_params", side_effect=AssertionError("Legacy export must not read current profiles")):
            exported = self.export(study)
        params = exported["best_params"]
        self.assertEqual((params["dropout"], params["pct_start"]), (0.17, 0.37))
        self.assertEqual((params["train_epochs"], params["patience"]), (9, 4))
        self.assertEqual(params["d_ff"], 640)
        self.assertNotIn("learning_rate", params)


class WidenedSearchSpaceTests(unittest.TestCase):
    def _space(self, dataset, pred_len):
        return search_space.build_search_space(dataset, pred_len)

    def test_high_variate_d_model_windows_allow_above_profile(self):
        self.assertEqual(self._space("ECL", 96)["d_model"]["choices"], [128, 256, 384])
        for pred_len in (192, 336, 720):
            self.assertEqual(self._space("ECL", pred_len)["d_model"]["choices"], [128, 256])
        for dataset in ("Traffic", "PEMS03", "PEMS04", "PEMS07"):
            self.assertEqual(self._space(dataset, 96)["d_model"]["choices"], [128, 256, 384])
        for pred_len in (12, 24, 96):
            self.assertEqual(self._space("PEMS08", pred_len)["d_model"]["choices"], [256, 384, 512])
        self.assertEqual(self._space("PEMS08", 48)["d_model"]["choices"], [384, 512])

    def test_tight_patch_and_stride_freeze_is_preserved(self):
        space = self._space("ECL", 192)
        self.assertEqual(space["patch_len"]["choices"], [16])
        self.assertEqual(space["stride"]["choices"], [8])

    def test_boundary_pinned_cells_get_wider_lambda_prior(self):
        cells = [("ECL", pred_len) for pred_len in (96, 192, 336, 720)] + [("ETTm1", 336), ("ETTm1", 720), ("ETTm2", 720)]
        for dataset, pred_len in cells:
            spec = self._space(dataset, pred_len)["lambda_prior"]
            self.assertEqual((spec["low"], spec["high"]), (0.03, 1.0))

    def test_manifold_c_and_d_hyp_overrides(self):
        manifold = self._space("ETTm2", 720)["manifold_c"]
        self.assertEqual((manifold["low"], manifold["high"]), (0.25, 2.0))
        self.assertEqual(self._space("ETTm2", 720)["d_hyp"]["choices"], [32, 64, 128])
        self.assertEqual(self._space("ECL", 720)["d_hyp"]["choices"], [32, 64, 128, 256])
        self.assertEqual(self._space("ETTm1", 336)["d_hyp"]["choices"], [64, 128, 256])
        self.assertEqual(self._space("ETTm1", 720)["d_hyp"]["choices"], [64, 128])

    def test_capacity_and_learning_rate_overrides(self):
        self.assertEqual(self._space("ETTm1", 336)["d_model"]["choices"], [256, 384, 512, 768])
        learning_rate = self._space("ETTm1", 336)["learning_rate"]
        self.assertEqual((learning_rate["low"], learning_rate["high"]), (1e-4, 1e-3))
        ecl192 = self._space("ECL", 192)["learning_rate"]
        self.assertEqual(ecl192["high"], 8e-3)
        self.assertGreater(ecl192["low"], 6e-4)
        self.assertLess(ecl192["low"], 7e-4)

    def test_untouched_datasets_keep_previous_spaces(self):
        self.assertEqual(self._space("Weather", 96)["lambda_prior"]["high"], 0.5)
        self.assertEqual(self._space("ETTh1", 96)["lambda_prior"]["low"], 0.05)
        self.assertEqual(self._space("ETTh1", 96)["lambda_prior"]["high"], 0.6)
        self.assertEqual(self._space("ETTh1", 96)["d_hyp"]["choices"], [32, 64, 128])
        self.assertEqual(self._space("ETTm1", 96)["lambda_prior"]["high"], 0.3)
        self.assertEqual(self._space("ETTm2", 96)["manifold_c"]["low"], 0.5)
        self.assertEqual(self._space("ETTm2", 96)["manifold_c"]["high"], 2.0)
        self.assertEqual(self._space("ETTm1", 720)["d_model"]["choices"], [128, 256, 384])

    def test_warm_start_marker_reaches_trial_user_attrs(self):
        study = optuna.create_study()
        study.enqueue_trial({"d_model": 256}, user_attrs={"warm_start": {"best_value": 0.2}})
        trial = study.ask()
        self.assertEqual(trial.suggest_categorical("d_model", [128, 256, 384]), 256)
        self.assertIn("warm_start", trial.user_attrs)


if __name__ == "__main__":
    unittest.main()
