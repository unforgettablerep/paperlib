# Mechanism Figure Captions (drafts)

Rendered by `scripts/mechanism/plot_m2patch_mechanism.py` from the checkpoints in
`temp/checkpoints/{Dataset}/` written by `scripts/mechanism/run_m2patch_mechanism.sh`
(pl = 96, 15 epochs, all five variants). Variant-level MSE/MAE and geodesic
columns come from `output/mechanism/m2patch_mechanism_summary.tsv`; panel (b)
window $r$/RMSE and the $K$ sweep are recomputed from the checkpoints by the plot
script.

## Fig. M1 — Mechanism panel, 2 x 2, single column (`m2patch_mechanism_analysis.png`)

**Caption draft.** M2Patch mechanism analysis on ETTh2 (96 -> 96), single-column
layout (5.35 in x 4.60 in, 600 dpi). **(a)** Causal history patches
$z^{\mathrm{hist}}$, bridge prior $z^{\mathrm{prior}}$, denoised future
$\hat{z}^{\mathrm{fut}}$ and orthogonal-DCT target $z^{\mathrm{fut}}_{\mathrm{tgt}}$
inside the constant-curvature Poincaré ball ($c$ = 1.01, $d_{\mathrm{hyp}}$ = 32),
projected through the origin log/exp map and PCA(2); the labels report the mean
geodesic distance to the target before and after denoising
($\bar d_{\mathrm{prior}}$ = 1.00 -> $\bar d_{\mathrm{fut}}$ = 0.97, i.e. 3.2%
closer). **(b)** Prior-bridge denoising on the variate with the largest
prior-to-denoised error reduction: target $Y$, causal prior $Y_{\mathrm{prior}}$
and single-step denoised $\hat Y_0$ in the standardized space (top), and the
correction $\Delta Y_{\mathrm{diff}} = \hat Y_0 - Y_{\mathrm{prior}}$ (bottom);
for this window $r$ rises 0.504 -> 0.510 while RMSE falls 0.237 -> 0.194.
**(c)** Training dynamics: EMA-smoothed per-iteration $\mathcal{L}_{\mathrm{total}}$,
$\mathcal{L}_{\mathrm{bridge}}$, $\lambda_p\mathcal{L}_{\mathrm{prior}}$ and
$\lambda_h\mathcal{L}_{\mathrm{hyp}}$ on a log axis (direct colored labels above
the traces, no legend box over the data), plus the residual burden
$\mathrm{RMSE}_\Delta$ at $K \in \{1,2,4\}$ diffusion steps evaluated on the
deployed weights (a what-if sweep, not retraining); the ring marks the deployed
$K$ (here 1) and the dashed line the prior level. **(d)** Mechanism interventions:
window-free test-set MSE/MAE (bars) and geodesic alignment $1/(1+\bar d)$ (right
strip) for Full / Euclid manifold / Zero prior bridge / No hyp. cond. / No prior
loss. The strip is marker-only: no line joins the points, because the Euclidean
variant sits on a different distance scale, and its numeric label is omitted for
the same reason; hollow markers flag that variant throughout.

## Fig. M2, M3 — Same panel for ETTm1 and Exchange

`m2patch_mechanism_ETTm1.png` and `m2patch_mechanism_Exchange.png` use the same
layout and the dataset's own Optuna configuration (ETTm1 $c$ = 1.91,
$d_{\mathrm{hyp}}$ = 128, deployed $K$ = 1; Exchange $c$ = 1.10,
$d_{\mathrm{hyp}}$ = 128, deployed $K$ = 2). Note that the deployed $K$ is
dataset-dependent: the ring in panel (c) marks it, and the $K \in \{1,2,4\}$ line
is a post-hoc what-if evaluation of the same weights.

## Fig. M4 — Cross-dataset summary (`m2patch_mechanism_cross_dataset.png`)

Grouped $\Delta$MSE against the full model (a) and $\Delta$ geodesic alignment
(b) for the five variants on ETTh2, ETTm1 and Exchange. Hollow markers again
flag the Euclidean variant, for which panel (b) is a Euclidean distance change
and not a hyperbolic one.

## Protocol and measured results

- **Configuration.** Every variant uses
  `mechanism_config.get_config`, which defaults to
  `load_optuna_best_params(dataset, pred_len)` as in the paper tables, with
  `optim=Adam`, `lradj=onecycle`, `pct_start=0.2` from `CONSTANTS`. A
  `lambda_hyp` optimum of 0 is lifted to `MECHANISM_LAMBDA_HYP_FLOOR` = 0.1 so
  the alignment term is active. All 15 result rows record `optim=Adam` and
  `pct_start=0.2`.
- **What the interventions say (MSE vs. Full, pl = 96).** Removing the prior
  anchor or the prior bridge consistently hurts: `zero_prior_bridge`
  +4.76% / +10.90% / +2.08% and `no_prior_loss` +2.03% / +12.94% / +6.05% on
  ETTh2 / ETTm1 / Exchange. In these settings the hyperbolic *conditioning* does not
  change pointwise error materially: `no_hyp_cond` is 2.13% / 0.14% / 12.00%
  *lower* than Full with essentially unchanged alignment
  (-0.0003 / 0.0000 / +0.0064), and `euclid_manifold` is -1.24% / +0.41% /
  -14.21% (i.e. it is not uniformly better or worse). The Poincaré geometry is
  supported by the *distance* behaviour in panel (a) and by the alignment
  column; the accuracy columns show no uniform gain for the hyperbolic
  components.
- **Alignment metric.** $1/(1+\bar d)$ for the Euclidean variant is computed
  from Euclidean distances, so its value (0.68 / 0.84 / 0.78) uses a different
  metric and is not comparable with the hyperbolic values.
- **Diffusion steps.** The deployed step count is the Optuna value per dataset
  (ETTh2 1, ETTm1 1, Exchange 2). The what-if sweep shows that extra steps
  beyond the deployed setting increase the residual burden
  (ETTh2 1.495 -> 1.608 from $K$=1 to 4; ETTm1 1.417 -> 1.481;
  Exchange 2.644 -> 2.684), while on Exchange $K$=1 is marginally below the
  deployed $K$=2 (2.644 vs 2.665) — a 0.8% difference; the data do not support a
  general K=1-is-best rule.
- **Typography.** 5.35 in x 4.60 in at 600 dpi for the 2 x 2 panels (5.35 in x
  4.35 in for the cross-dataset panel), Times/Nimbus/DejaVu serif, panel titles
  7.5 pt and every other label at or above 6.5 pt, ticks 6.5 pt, all colors from
  `scripts/color.py`.
