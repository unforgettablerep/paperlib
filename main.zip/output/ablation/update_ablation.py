"""Build m2p-ablation.xlsx (Main Table + Full Detail) from the OFAT ablation TSVs."""
import argparse
import json
import math
import os
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from src.ablation.registry import MAIN_ABLATION_LABELS, MAIN_ABLATION_VARIANTS, is_noop_ablation
from src.utils.result_io import canonical_dataset, is_valid_result, read_results

BASELINE_LABEL = "Full M2Patch"
BASELINE_VARIANT_ID = ""

MAIN_VARIANTS = [(BASELINE_LABEL, BASELINE_VARIANT_ID)] + [
    (MAIN_ABLATION_LABELS[variant_id], variant_id) for variant_id in MAIN_ABLATION_VARIANTS
]

VARIANT_DIRS = {vid: vid for _, vid in MAIN_VARIANTS if vid}

DES_TO_VARIANT = {f"ablation_{vid}": vid for _, vid in MAIN_VARIANTS if vid}

DATASETS = ["ETTh2", "ETTm1", "Exchange", "Weather", "ECL", "Illness"]
MAIN_DATASETS = list(DATASETS)

STANDARD_PRED_LENS = [96, 192, 336, 720]

DS_PRED_LENS = {ds: list(STANDARD_PRED_LENS) for ds in DATASETS}
DS_PRED_LENS["Illness"] = [24, 36, 48, 60]

DS_TO_COL = {ds: 3 + 2 * i for i, ds in enumerate(DATASETS)}
DS_COL_PAIRS = [(DS_TO_COL[ds], ds) for ds in DATASETS]

OPTUNA_DIR = os.path.join(REPO_ROOT, "output", "optuna")

N_PL = 4
ROWS_PER_VARIANT = 5

MAIN_HEADER_ROWS = 2
MAIN_DATA_START = MAIN_HEADER_ROWS + 1
MAIN_DATA_END = MAIN_DATA_START + len(MAIN_VARIANTS) - 1
MAIN_DS_TO_COL = {ds: 2 + 2 * i for i, ds in enumerate(MAIN_DATASETS)}
MAIN_DELTA_COL = 2 + 2 * len(MAIN_DATASETS)
MAIN_COMPLETED_COL = MAIN_DELTA_COL + 2
MAIN_LAST_COL = MAIN_COMPLETED_COL + 1
PENDING_TEXT = "PENDING"
PENDING_FILL = PatternFill(fill_type="solid", fgColor="FFF2F2F2")

DET_HEADER_ROWS = 2
DET_DATA_START = DET_HEADER_ROWS + 1
DET_ROWS = len(MAIN_VARIANTS) * ROWS_PER_VARIANT

FONT_NAME = "Aptos"
FONT_SIZE = 12
ROW_HEIGHT = 20
NUM_FMT = r"0.000_);[Red]\(0.000\)"
DELTA_FMT = "+0.00;-0.00;0.00"
HEADER_FILL = PatternFill(fill_type="solid", fgColor="FFFFC000")
SECTION_FILL = PatternFill(fill_type="solid", fgColor="FFD6E4F0")
BASELINE_FILL = PatternFill(fill_type="solid", fgColor="FFE2EFDA")
BEST_FONT = Font(name=FONT_NAME, bold=True, size=FONT_SIZE, color="FFCC0000")
SECOND_FONT = Font(name=FONT_NAME, bold=True, size=FONT_SIZE, color="FF000000", underline="single")
CELL_FONT = Font(name=FONT_NAME, bold=True, size=FONT_SIZE, color="FF000000")
PLAIN_FONT = Font(name=FONT_NAME, bold=False, size=FONT_SIZE, color="FF000000")
SECTION_FONT = Font(name=FONT_NAME, bold=True, size=FONT_SIZE, color="FF1F4E79")
NOOP_FILL = PatternFill(fill_type="solid", fgColor="FFFFFF99")
CENTER = Alignment(horizontal="center", vertical="center")
VCENTER = Alignment(vertical="center")
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)


def _is_numeric(v):
    return v is not None and v != "-" and isinstance(v, (int, float)) and math.isfinite(v)


def _fmt3(v):
    return math.floor(v * 1000 + 0.5) / 1000


def _display(v):
    return _fmt3(v) if _is_numeric(v) else None


def _baseline_tsv_paths(output_dir):
    paths = []
    measured = os.path.join(output_dir, "none.tsv")
    if os.path.isfile(measured):
        paths.append(measured)
    return paths


def _read_baseline_tsv(path, dataset):
    cells = {}
    for row in read_results(path):
        if not is_valid_result(row):
            continue
        if canonical_dataset(row.get("dataset", "")) != dataset:
            continue
        if str(row.get("model", "")) not in ("", "M2Patch"):
            continue
        des = str(row.get("des", ""))
        if des.startswith("ablation_") and des != "ablation_none":
            continue
        try:
            pred_len = int(float(row.get("pred_len", "")))
            mse = float(row.get("mse", ""))
            mae = float(row.get("mae", ""))
        except (TypeError, ValueError):
            continue
        cells[pred_len] = (mse, mae)
    return cells


def _optuna_json_path(dataset, pred_len):
    candidates = DS_PRED_LENS.get(dataset, STANDARD_PRED_LENS)
    shorter = [p for p in candidates if p < pred_len]
    actual_pl = pred_len if pred_len in candidates else max(shorter or [min(candidates)])
    for name in (f"M2Patch_{dataset}_pl{actual_pl}", f"M2Patch_{dataset.lower()}_pl{actual_pl}"):
        path = os.path.join(OPTUNA_DIR, f"{name}_best_params.json")
        if os.path.isfile(path):
            return path
    return None


def _optuna_baseline(dataset, pred_len):
    path = _optuna_json_path(dataset, pred_len)
    if path is None:
        return None, None
    try:
        with open(path) as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None, None
    attrs = data.get("best_trial_user_attrs") or {}
    mse = attrs.get("test_mse", attrs.get("mse"))
    mae = attrs.get("test_mae", attrs.get("mae"))
    if mse is None:
        mse = data.get("best_value")
    return mse, mae


def _baseline_table(output_dir):
    baseline = {}
    missing = []
    sources = {}
    for ds in DATASETS:
        merged = {}
        for path in _baseline_tsv_paths(output_dir):
            merged.update(_read_baseline_tsv(path, ds))
        for pl in DS_PRED_LENS[ds]:
            if pl in merged:
                baseline[(ds, pl)] = merged[pl]
                sources[(ds, pl)] = "none.tsv"
                continue
            mse, mae = _optuna_baseline(ds, pl)
            if _is_numeric(mse) and _is_numeric(mae):
                baseline[(ds, pl)] = (float(mse), float(mae))
                sources[(ds, pl)] = "optuna"
            else:
                missing.append(f"{ds}@{pl}")
    measured = sum(1 for v in sources.values() if v == "none.tsv")
    print(f"Baseline cells: {measured} measured (none.tsv), "
          f"{len(sources) - measured} from Optuna JSON, {len(missing)} missing")
    return baseline, missing


def _read_variant_tsvs(output_dir):
    file_map = {}
    missing_tsvs = []
    des_mismatches = []
    if not os.path.isdir(output_dir):
        return file_map, missing_tsvs, des_mismatches
    for variant_id in VARIANT_DIRS.values():
        des_key = f"ablation_{variant_id}"
        tsv_path = os.path.join(output_dir, f"{variant_id}.tsv")
        if not os.path.isfile(tsv_path):
            missing_tsvs.append(variant_id)
            continue
        for row in read_results(tsv_path):
            if not is_valid_result(row):
                continue
            parsed_des = row.get("des", "")
            if parsed_des and parsed_des != des_key:
                des_mismatches.append((variant_id, tsv_path, parsed_des, des_key))
            ds_name = canonical_dataset(row.get("dataset", ""))
            if ds_name not in DATASETS:
                continue
            try:
                pred_len = int(row.get("pred_len", ""))
                mse_val = float(row.get("mse", ""))
                mae_val = float(row.get("mae", ""))
            except (TypeError, ValueError):
                continue
            file_map[(variant_id, ds_name, pred_len)] = {"mse": mse_val, "mae": mae_val}
    return file_map, missing_tsvs, des_mismatches


_NOOP_CACHE = {}


def _is_noop_cell(variant_id, dataset, pred_len):
    key = (variant_id, dataset, pred_len)
    if key not in _NOOP_CACHE:
        _NOOP_CACHE[key] = is_noop_ablation(dataset, pred_len, variant_id, baseline="optuna")
    return _NOOP_CACHE[key]


def collect_results(output_dir):
    results = {}
    baseline, missing_baseline = _baseline_table(output_dir)
    for (ds, pl), (mse, mae) in baseline.items():
        results[(BASELINE_VARIANT_ID, ds, pl)] = {"mse": mse, "mae": mae, "noop": False}

    file_map, missing_tsvs, des_mismatches = _read_variant_tsvs(output_dir)
    filled_noop = 0
    for variant_id in VARIANT_DIRS.values():
        for ds in DATASETS:
            for pl in DS_PRED_LENS[ds]:
                if _is_noop_cell(variant_id, ds, pl):
                    if (ds, pl) in baseline:
                        mse, mae = baseline[(ds, pl)]
                        results[(variant_id, ds, pl)] = {"mse": mse, "mae": mae, "noop": True}
                        filled_noop += 1
                    continue
                record = file_map.get((variant_id, ds, pl))
                if record is not None:
                    results[(variant_id, ds, pl)] = {
                        "mse": record["mse"],
                        "mae": record["mae"],
                        "noop": False,
                    }
    return results, missing_tsvs, des_mismatches, missing_baseline, filled_noop


def _len_label(pi):
    if pi >= N_PL:
        return "Avg"
    std = STANDARD_PRED_LENS[pi]
    parts = [str(std)]
    for ds in ("Illness",):
        val = DS_PRED_LENS[ds][pi]
        if val != std and str(val) not in parts:
            parts.append(str(val))
    return "/".join(parts)


def _cell_pred_len(ds, pi):
    return DS_PRED_LENS.get(ds, STANDARD_PRED_LENS)[pi]


def _horizon_values(results, vid, ds, metric):
    vals = []
    for pl in DS_PRED_LENS[ds]:
        cell = results.get((vid, ds, pl))
        vals.append(_display(cell[metric]) if cell is not None else None)
    return vals


def _cross_horizon_mean(results, vid, ds, metric):
    vals = []
    for pl in DS_PRED_LENS[ds]:
        cell = results.get((vid, ds, pl))
        if cell is not None:
            vals.append(float(cell[metric]))
    if len(vals) < N_PL:
        return None
    return sum(vals) / N_PL


def _delta_pct(results, vid, metric, datasets=None):
    datasets = MAIN_DATASETS if datasets is None else datasets
    num = 0.0
    den = 0.0
    for ds in datasets:
        for pl in DS_PRED_LENS[ds]:
            v = results.get((vid, ds, pl))
            f = results.get((BASELINE_VARIANT_ID, ds, pl))
            if v is None or f is None:
                return None
            num += float(v[metric])
            den += float(f[metric])
    if den == 0:
        return None
    return round((num / den - 1.0) * 100.0, 2)


def _dataset_complete(results, ds):
    for metric in ("mse", "mae"):
        if _cross_horizon_mean(results, BASELINE_VARIANT_ID, ds, metric) is None:
            return False
        for vid in VARIANT_DIRS.values():
            if _cross_horizon_mean(results, vid, ds, metric) is None:
                return False
    return True


def _completed_datasets(results):
    return [ds for ds in MAIN_DATASETS if _dataset_complete(results, ds)]


def _style_cell(ws, row, col, value, font, fill, align=CENTER):
    c = ws.cell(row=row, column=col, value=value)
    c.font = font
    c.fill = fill
    c.alignment = align
    return c


def _merge_styled(ws, row1, col1, row2, col2, value, font, fill, align=CENTER):
    for row in range(row1, row2 + 1):
        for col in range(col1, col2 + 1):
            c = ws.cell(row=row, column=col)
            c.fill = fill
            c.border = THIN_BORDER
    ws.merge_cells(start_row=row1, start_column=col1, end_row=row2, end_column=col2)
    c = ws.cell(row=row1, column=col1, value=value)
    c.font = font
    c.alignment = align
    return c


def _apply_rank_fonts(ws, col, pairs):
    if not pairs:
        return
    vals = sorted(set(v for _, v in pairs))
    best = vals[0]
    second = vals[1] if len(vals) > 1 else None
    for row, v in pairs:
        cell = ws.cell(row=row, column=col)
        if v == best:
            cell.font = BEST_FONT
        elif second is not None and v == second:
            cell.font = SECOND_FONT
        else:
            cell.font = CELL_FONT


def _build_main_sheet(ws, results):
    completed = _completed_datasets(results)
    for row in range(1, MAIN_DATA_END + 1):
        for col in range(1, MAIN_LAST_COL + 1):
            c = ws.cell(row=row, column=col)
            c.border = THIN_BORDER
            c.font = PLAIN_FONT

    _merge_styled(ws, 1, 1, MAIN_HEADER_ROWS, 1, "Variant", SECTION_FONT, HEADER_FILL)
    for ds in MAIN_DATASETS:
        col = MAIN_DS_TO_COL[ds]
        _merge_styled(ws, 1, col, 1, col + 1, ds, SECTION_FONT, HEADER_FILL)
        for j, label in enumerate(("MSE", "MAE")):
            _style_cell(ws, 2, col + j, label, SECTION_FONT, SECTION_FILL)
    _merge_styled(ws, 1, MAIN_DELTA_COL, 1, MAIN_DELTA_COL + 1, "Δ vs Full (%)", SECTION_FONT, HEADER_FILL)
    for j, label in enumerate(("MSE", "MAE")):
        _style_cell(ws, 2, MAIN_DELTA_COL + j, label, SECTION_FONT, SECTION_FILL)
    _merge_styled(ws, 1, MAIN_COMPLETED_COL, 1, MAIN_COMPLETED_COL + 1, "Δ Completed (%)", SECTION_FONT, HEADER_FILL)
    for j, label in enumerate(("MSE", "MAE")):
        _style_cell(ws, 2, MAIN_COMPLETED_COL + j, label, SECTION_FONT, SECTION_FILL)

    for vi, (name, vid) in enumerate(MAIN_VARIANTS):
        row = MAIN_DATA_START + vi
        ws.row_dimensions[row].height = ROW_HEIGHT
        c = ws.cell(row=row, column=1, value=name)
        c.font = SECTION_FONT if not vid else PLAIN_FONT
        c.alignment = VCENTER
        if not vid:
            c.fill = BASELINE_FILL
        for ds in MAIN_DATASETS:
            for j, metric in enumerate(("mse", "mae")):
                col = MAIN_DS_TO_COL[ds] + j
                v = _cross_horizon_mean(results, vid, ds, metric)
                if v is not None:
                    c = ws.cell(row=row, column=col, value=v)
                    c.number_format = NUM_FMT
                elif ds not in completed:
                    c = ws.cell(row=row, column=col, value=PENDING_TEXT)
                    c.font = PLAIN_FONT
                    c.alignment = CENTER
                    c.fill = PENDING_FILL
        if vid:
            for j, metric in enumerate(("mse", "mae")):
                d = _delta_pct(results, vid, metric)
                if d is not None:
                    c = ws.cell(row=row, column=MAIN_DELTA_COL + j, value=d)
                    c.number_format = DELTA_FMT
                    c.font = CELL_FONT
                    c.alignment = CENTER
                d_done = _delta_pct(results, vid, metric, datasets=completed)
                if d_done is not None:
                    c = ws.cell(row=row, column=MAIN_COMPLETED_COL + j, value=d_done)
                    c.number_format = DELTA_FMT
                    c.font = CELL_FONT
                    c.alignment = CENTER
                elif completed:
                    c = ws.cell(row=row, column=MAIN_COMPLETED_COL + j, value="–")
                    c.font = PLAIN_FONT
                    c.alignment = CENTER
        else:
            for j in range(2):
                c = ws.cell(row=row, column=MAIN_DELTA_COL + j, value="–")
                c.font = PLAIN_FONT
                c.alignment = CENTER
                c = ws.cell(row=row, column=MAIN_COMPLETED_COL + j, value="–")
                c.font = PLAIN_FONT
                c.alignment = CENTER

    for ds in MAIN_DATASETS:
        for j, metric in enumerate(("mse", "mae")):
            col = MAIN_DS_TO_COL[ds] + j
            pairs = []
            for vi, (_, vid) in enumerate(MAIN_VARIANTS):
                v = _cross_horizon_mean(results, vid, ds, metric)
                if v is not None:
                    pairs.append((MAIN_DATA_START + vi, v))
            _apply_rank_fonts(ws, col, pairs)

    note_row = MAIN_DATA_END + 2
    pending = [ds for ds in MAIN_DATASETS if ds not in completed]
    note = (
        f"{PENDING_TEXT} = dataset not yet fully executed (all 8 OFAT variants x 4 horizons); "
        f"Δ vs Full (%) stays blank until all {len(MAIN_DATASETS)} datasets are complete. "
        f"Δ Completed (%) is (sum of variant MSE over the {len(completed)} completed datasets x 4 horizons) / (sum of none MSE over the same cells) - 1, "
        f"computed over: "
        f"{', '.join(completed) if completed else 'none'}. "
        f"Full M2Patch cells come from measured output/ablation/none.tsv where available and from "
        f"output/optuna/*_best_params.json otherwise."
    )
    c = ws.cell(row=note_row, column=1, value=note)
    c.font = PLAIN_FONT
    c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row, end_column=MAIN_LAST_COL)
    ws.row_dimensions[note_row].height = 45

    ws.column_dimensions["A"].width = 30
    for ds in MAIN_DATASETS:
        col = MAIN_DS_TO_COL[ds]
        ws.column_dimensions[get_column_letter(col)].width = 9
        ws.column_dimensions[get_column_letter(col + 1)].width = 9
    for col in (MAIN_DELTA_COL, MAIN_DELTA_COL + 1, MAIN_COMPLETED_COL, MAIN_COMPLETED_COL + 1):
        ws.column_dimensions[get_column_letter(col)].width = 10
    ws.freeze_panes = "B3"


def _write_metric_cells(ws, row, col_base, cell):
    if cell is None:
        return 0
    written = 0
    for j, metric in enumerate(("mse", "mae")):
        v = _display(cell[metric])
        if v is not None:
            c = ws.cell(row=row, column=col_base + j, value=v)
            c.number_format = NUM_FMT
            written += 1
    return written


def _build_detail_sheet(ws, results):
    _merge_styled(ws, 1, 1, DET_HEADER_ROWS, 1, "Variant", SECTION_FONT, HEADER_FILL, VCENTER)
    _merge_styled(ws, 1, 2, DET_HEADER_ROWS, 2, "Len", SECTION_FONT, HEADER_FILL)
    for col, ds in DS_COL_PAIRS:
        _merge_styled(ws, 1, col, 1, col + 1, ds, SECTION_FONT, HEADER_FILL)
        for j, label in enumerate(("MSE", "MAE")):
            _style_cell(ws, 2, col + j, label, SECTION_FONT, SECTION_FILL)

    for vi, (name, vid) in enumerate(MAIN_VARIANTS):
        base_row = DET_DATA_START + vi * ROWS_PER_VARIANT
        for pi in range(ROWS_PER_VARIANT):
            row = base_row + pi
            ws.row_dimensions[row].height = ROW_HEIGHT
            if pi == 0:
                ws.merge_cells(
                    start_row=base_row,
                    start_column=1,
                    end_row=base_row + ROWS_PER_VARIANT - 1,
                    end_column=1,
                )
                c = ws.cell(row=base_row, column=1, value=name)
                c.font = SECTION_FONT if not vid else PLAIN_FONT
                c.alignment = VCENTER
                if not vid:
                    for rr in range(base_row, base_row + ROWS_PER_VARIANT):
                        ws.cell(row=rr, column=1).fill = BASELINE_FILL
            c = ws.cell(row=row, column=2, value=_len_label(pi))
            c.font = PLAIN_FONT
            c.alignment = CENTER

    registered = 0
    for vi, (_, vid) in enumerate(MAIN_VARIANTS):
        base_row = DET_DATA_START + vi * ROWS_PER_VARIANT
        for ds, col_base in DS_TO_COL.items():
            for pi in range(N_PL):
                pl = _cell_pred_len(ds, pi)
                cell = results.get((vid, ds, pl))
                if (
                    vid
                    and cell is not None
                    and not cell["noop"]
                    and _is_numeric(cell["mse"])
                ):
                    registered += 1
                _write_metric_cells(ws, base_row + pi, col_base, cell)

    painted = 0
    for vi, (_, vid) in enumerate(MAIN_VARIANTS):
        if not vid:
            continue
        base_row = DET_DATA_START + vi * ROWS_PER_VARIANT
        for ds, col_base in DS_TO_COL.items():
            for pi in range(N_PL):
                pl = _cell_pred_len(ds, pi)
                cell = results.get((vid, ds, pl))
                if cell is not None and cell["noop"]:
                    for col in (col_base, col_base + 1):
                        ws.cell(row=base_row + pi, column=col).fill = NOOP_FILL
                    painted += 1
    if painted:
        print(f"Painted {painted} config no-op cells yellow (auto-filled from the baseline)")

    _update_detail_avg(ws)
    _highlight_detail(ws)

    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 12
    for col, _ in DS_COL_PAIRS:
        ws.column_dimensions[get_column_letter(col)].width = 9
        ws.column_dimensions[get_column_letter(col + 1)].width = 9
    ws.freeze_panes = "C3"
    return registered


def _update_detail_avg(ws):
    for vi in range(len(MAIN_VARIANTS)):
        base_row = DET_DATA_START + vi * ROWS_PER_VARIANT
        avg_row = base_row + N_PL
        for col_base, _ in DS_COL_PAIRS:
            for j in range(2):
                col = col_base + j
                vals = [ws.cell(row=base_row + pi, column=col).value for pi in range(N_PL)]
                vals = [v for v in vals if _is_numeric(v)]
                if len(vals) == N_PL:
                    c = ws.cell(row=avg_row, column=col, value=_fmt3(sum(vals) / N_PL))
                    c.number_format = NUM_FMT


def _highlight_detail(ws):
    for pi in range(ROWS_PER_VARIANT):
        for col_base, _ in DS_COL_PAIRS:
            for j in range(2):
                col = col_base + j
                pairs = []
                for vi in range(len(MAIN_VARIANTS)):
                    row = DET_DATA_START + vi * ROWS_PER_VARIANT + pi
                    v = ws.cell(row=row, column=col).value
                    if _is_numeric(v):
                        pairs.append((row, v))
                _apply_rank_fonts(ws, col, pairs)


def _warn_incomplete_main(results):
    completed = _completed_datasets(results)
    pending = [ds for ds in MAIN_DATASETS if ds not in completed]
    if pending:
        print(f"[INFO] Main Table marks {', '.join(pending)} as {PENDING_TEXT}; "
              f"Δ Completed (%) covers {', '.join(completed) if completed else 'no dataset'}")


def build_xlsx(xlsx_path, output_dir):
    results, missing_tsvs, des_mismatches, missing_baseline, filled_noop = collect_results(output_dir)

    if missing_tsvs:
        print(f"[WARN] missing variant TSVs under {output_dir}: {", ".join(sorted(missing_tsvs))}")
    for dir_name, tsv, parsed_des, expected in des_mismatches:
        print(
            f"[WARN] des mismatch: {dir_name}/{tsv} has des={parsed_des!r}, expected {expected!r}"
        )
    if missing_baseline:
        print(
            f"[WARN] baseline cells without any source (none.tsv/baseline.tsv/"
            f"long_term_forecast TSV/optuna JSON): {", ".join(missing_baseline)}"
        )
    if filled_noop:
        print(f"Auto-filled {filled_noop} config no-op cells from the baseline (yellow)")

    wb = Workbook()
    ws_main = wb.active
    ws_main.title = "Main Table"
    _build_main_sheet(ws_main, results)
    _warn_incomplete_main(results)

    ws_detail = wb.create_sheet("Full Detail")
    registered = _build_detail_sheet(ws_detail, results)
    print(f"Registered {registered} ablation MSE cells from {output_dir}")

    wb._fonts[0] = Font(name=FONT_NAME, size=FONT_SIZE)
    wb.save(xlsx_path)
    print(f"Saved {xlsx_path}")


def main():
    parser = argparse.ArgumentParser(description="Build the per-component M2Patch OFAT ablation xlsx")
    parser.add_argument(
        "--xlsx",
        default=None,
        help="Output xlsx path (default: <output-dir>/m2p-ablation.xlsx)",
    )
    parser.add_argument(
        "--output-dir",
        default="output/ablation",
        help="Root directory holding {variant}.tsv result stores (default: output/ablation)",
    )
    args = parser.parse_args()

    xlsx_path = args.xlsx or os.path.join(args.output_dir, "m2p-ablation.xlsx")
    parent = os.path.dirname(os.path.abspath(xlsx_path))
    os.makedirs(parent, exist_ok=True)
    build_xlsx(xlsx_path, args.output_dir)


if __name__ == "__main__":
    main()
