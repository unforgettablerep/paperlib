# Cross-dataset nonparametric tests (M2Patch vs baselines)

## Protocol

- Problem instances: one block per `(dataset, pred_len)` pair; rank 1 = lowest error.
- Models (k = 8): M2Patch, MMPD, SimpleTM, TimeMixer, iTransformer, PatchTST, DLinear, TimesNet.
- Complete blocks used (N = 12): ETTh2@96, ETTh2@192, ETTh2@336, ETTh2@720, ETTm1@96, ETTm1@192, ETTm1@336, ETTm1@720, Exchange@96, Exchange@192, Exchange@336, Exchange@720
- Significance level alpha = 0.05; Holm-Bonferroni correction across 7 pairwise comparisons per metric.
- Friedman chi-square is tie-corrected; Iman-Davenport F uses df1 = k-1, df2 = (k-1)(N-1).
- Nemenyi CD = q_alpha * sqrt(k(k+1)/(6N)), two-tailed Studentized range over infinite df.
- Wilcoxon signed-rank: two-sided, zero differences discarded (`wilcox`), exact when possible, asymptotic otherwise.
- Effect size: matched-pairs rank-biserial r = (W+ - W-) / (W+ + W-); positive r favours M2Patch.
- Scope: core datasets only. Pass `--include-all` after filling every dataset to recompute a global test.

## Data coverage

| Dataset | Horizons | Status | Models with data (order: M2Patch, MMPD, SimpleTM, TimeMixer, iTransformer, PatchTST, DLinear, TimesNet) |
|---|---|---|---|
| ETTh2 | 4 | OK | 4, 4, 4, 4, 4, 4, 4, 4 |
| ETTm1 | 4 | OK | 4, 4, 4, 4, 4, 4, 4, 4 |
| Exchange | 4 | OK | 4, 4, 4, 4, 4, 4, 4, 4 |
| ETTh1 | 4 | PENDING | 4, 0, 0, 4, 4, 4, 4, 4 |
| ETTm2 | 4 | PENDING | 4, 0, 0, 4, 4, 4, 4, 4 |
| Weather | 4 | PENDING | 4, 0, 0, 4, 4, 4, 4, 4 |
| ECL | 4 | PENDING | 4, 0, 0, 4, 4, 4, 4, 4 |
| Solar | 4 | PENDING | 0, 0, 0, 4, 4, 4, 4, 4 |
| Traffic | 4 | PENDING | 0, 0, 0, 4, 4, 4, 4, 4 |
| PEMS08 | 4 | PENDING | 0, 0, 0, 4, 4, 4, 4, 4 |
| Illness | 4 | PENDING | 4, 0, 0, 4, 4, 4, 4, 4 |

Missing cells (first 40): ETTh1@96:MMPD; ETTh1@96:SimpleTM; ETTh1@192:MMPD; ETTh1@192:SimpleTM; ETTh1@336:MMPD; ETTh1@336:SimpleTM; ETTh1@720:MMPD; ETTh1@720:SimpleTM; ETTm2@96:MMPD; ETTm2@96:SimpleTM; ETTm2@192:MMPD; ETTm2@192:SimpleTM; ETTm2@336:MMPD; ETTm2@336:SimpleTM; ETTm2@720:MMPD; ETTm2@720:SimpleTM; Weather@96:MMPD; Weather@96:SimpleTM; Weather@192:MMPD; Weather@192:SimpleTM; Weather@336:MMPD; Weather@336:SimpleTM; Weather@720:MMPD; Weather@720:SimpleTM; ECL@96:MMPD; ECL@96:SimpleTM; ECL@192:MMPD; ECL@192:SimpleTM; ECL@336:MMPD; ECL@336:SimpleTM; ECL@720:MMPD; ECL@720:SimpleTM; Solar@96:M2Patch; Solar@96:MMPD; Solar@96:SimpleTM; Solar@192:M2Patch; Solar@192:MMPD; Solar@192:SimpleTM; Solar@336:M2Patch; Solar@336:MMPD

## MSE

Friedman: chi2_F = 33.4722, Iman-Davenport F = 7.28697 (df1 = 7, df2 = 77), p_F = 1.08179e-06, p_chi2 = 2.16171e-05.

| Position | Model | Average rank |
|---|---|---|
| 1 | PatchTST | 2.2500 |
| 2 | DLinear | 3.0833 |
| 3 | TimeMixer | 3.8333 |
| 4 | MMPD | 4.0833 |
| 5 | M2Patch | 4.3333 |
| 6 | iTransformer | 5.5833 |
| 7 | SimpleTM | 5.9167 |
| 8 | TimesNet | 6.9167 |

Nemenyi CD = 3.0309 (q_alpha = 3.0309). Models whose average ranks differ by less than the CD are not significantly different.

| Baseline | N pairs | W | p | p_Holm | r | Win/Tie/Loss | Method | Significant |
|---|---|---|---|---|---|---|---|---|
| MMPD | 12 | 28 | 0.4238 | 1 | -0.2821 | 4/0/8 | exact | no |
| SimpleTM | 12 | 26 | 0.3394 | 1 | +0.3333 | 8/0/4 | exact | no |
| TimeMixer | 12 | 31 | 0.5693 | 1 | -0.2051 | 5/0/7 | exact | no |
| iTransformer | 12 | 27 | 0.3804 | 1 | +0.3077 | 9/0/3 | exact | no |
| PatchTST | 12 | 10 | 0.021 | 0.147 | -0.7436 | 3/0/9 | exact | no |
| DLinear | 12 | 27 | 0.3804 | 1 | -0.3077 | 5/0/7 | exact | no |
| TimesNet | 12 | 15 | 0.06396 | 0.3838 | +0.6154 | 10/0/2 | exact | no |

## MAE

Friedman: chi2_F = 40.1389, Iman-Davenport F = 10.0665 (df1 = 7, df2 = 77), p_F = 7.14354e-09, p_chi2 = 1.18404e-06.

| Position | Model | Average rank |
|---|---|---|
| 1 | PatchTST | 2.2500 |
| 2 | DLinear | 2.5833 |
| 3 | TimeMixer | 3.9167 |
| 4 | MMPD | 4.0833 |
| 5 | M2Patch | 4.3333 |
| 6 | iTransformer | 5.5833 |
| 7 | SimpleTM | 6.0833 |
| 8 | TimesNet | 7.1667 |

Nemenyi CD = 3.0309 (q_alpha = 3.0309). Models whose average ranks differ by less than the CD are not significantly different.

| Baseline | N pairs | W | p | p_Holm | r | Win/Tie/Loss | Method | Significant |
|---|---|---|---|---|---|---|---|---|
| MMPD | 12 | 32 | 0.6221 | 1 | -0.1795 | 5/0/7 | exact | no |
| SimpleTM | 12 | 20 | 0.1514 | 0.647 | +0.4872 | 10/0/2 | exact | no |
| TimeMixer | 12 | 33 | 0.6772 | 1 | -0.1538 | 5/0/7 | exact | no |
| iTransformer | 12 | 27 | 0.3804 | 1 | +0.3077 | 9/0/3 | exact | no |
| PatchTST | 12 | 14 | 0.05225 | 0.3135 | -0.6410 | 2/0/10 | exact | no |
| DLinear | 12 | 19 | 0.1294 | 0.647 | -0.5128 | 3/0/9 | exact | no |
| TimesNet | 12 | 7 | 0.009277 | 0.06494 | +0.8205 | 10/0/2 | exact | no |

## Notes

- M2Patch cells are the measured Optuna-config baseline (`output/ablation/none.tsv`); missing datasets fall back to the exported HPO best-trial JSON and are labelled `optuna:` in the matrix CSV.
- Baseline cells are measured under the shared protocol (`output/benchmark/{dataset}.tsv`) when present; otherwise they come from the curated main table `assets/m2p_eff_results_1.xlsx` and are labelled with that source.
- `PENDING` rows in `benchmark_matrix.csv` are placeholders for datasets not yet executed; they never enter a test.
- Rows with `status=PENDING` and `note=outside default scope` can be activated with `--include-all` once their benchmark TSVs exist.
