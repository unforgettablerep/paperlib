#!/bin/bash
# Collect case-study artifacts (prediction npy + ground truth) from
# temp/results/ into output/case_study/record_{DATASET}/, then drop the
# large raw CASESTUDY caches under temp/.
#
# Usage:
#   bash output/case_study/collect_results.sh [ETTm2|ETTm1|ECL|Exchange]
#
# PRED_LENS follows CASE_STUDY_PL (default 96) so the runner and the
# collector stay in sync.

set -u

DATASET="${1:-ETTm2}"
RECORD_DIR="output/case_study/record_${DATASET}"
MODELS=(M2Patch MMPD S_Mamba iTransformer PatchTST)
PRED_LENS=(${CASE_STUDY_PL:-96})

# temp/results subdirectories are keyed by "{model_id_prefix}_96", i.e. the
# dataset name as spelled in src.configs.m2patch_profiles.DATASET_META.
MODEL_ID="${DATASET}_96"

mkdir -p "$RECORD_DIR"

echo "Collecting case-study results for ${DATASET} -> ${RECORD_DIR}/"

COPIED=0
MISSING=0

for model in "${MODELS[@]}"; do
    for pred_len in "${PRED_LENS[@]}"; do
        DIR_PATTERN="temp/results/${MODEL_ID}_${pred_len}_${model}_CASESTUDY_l*_itr*"
        RESULT_DIR=$(ls -d $DIR_PATTERN 2>/dev/null | head -1)

        if [ -z "$RESULT_DIR" ]; then
            echo "  [miss] ${model} pred_len=${pred_len}: no dir matching ${DIR_PATTERN}"
            MISSING=$((MISSING + 1))
            continue
        fi

        PRED_FILE="${RESULT_DIR}/${model}_96_${pred_len}_pred.npy"
        TRUE_FILE="${RESULT_DIR}/${model}_96_${pred_len}_true.npy"

        if [ -f "$PRED_FILE" ]; then
            cp "$PRED_FILE" "${RECORD_DIR}/${model}_96_${pred_len}_pred.npy"
            echo "  [pred] ${model}_96_${pred_len}_pred.npy"
            COPIED=$((COPIED + 1))
        else
            echo "  [miss] ${PRED_FILE}"
            MISSING=$((MISSING + 1))
        fi

        if [ -f "$TRUE_FILE" ] && [ ! -f "${RECORD_DIR}/true_${pred_len}.npy" ]; then
            cp "$TRUE_FILE" "${RECORD_DIR}/true_${pred_len}.npy"
            echo "  [true] true_${pred_len}.npy (from ${model})"
        fi
    done
done

for pred_len in "${PRED_LENS[@]}"; do
    rm -rf temp/results/"${MODEL_ID}_${pred_len}"_*CASESTUDY* \
        temp/test_results/"${MODEL_ID}_${pred_len}"_*CASESTUDY*
done

echo "Collection complete: ${COPIED} copied, ${MISSING} missing"
ls -lh "${RECORD_DIR}"/ 2>/dev/null | tail -n +2
