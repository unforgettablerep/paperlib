NO_ABLATION = "none"

MODEL_ABLATION_FLAGS = ("none", "euclid_manifold", "zero_prior_bridge", "no_hyp_cond")

ABLATION_GROUPS = {
    "euclid_manifold": {"ablation": "euclid_manifold", "use_hyp_manifold": 0},
    "no_hyp_manifold": {"use_hyp_manifold": 0},
    "zero_prior_bridge": {"ablation": "zero_prior_bridge", "use_prior_bridge": 0},
    "no_prior_bridge": {"use_prior_bridge": 0},
    "no_hyp_cond": {"ablation": "no_hyp_cond", "use_hyp_cond": 0},
    "no_adaln": {"use_adaln": 0},
    "no_denoise_refinement": {"use_denoiser": 0},
    "no_causal_prefix_norm": {"use_causal_norm": 0},
    "no_hyp_loss": {"lambda_hyp": 0.0},
    "no_prior_loss": {"lambda_prior": 0.0},
    "no_aux_loss": {"lambda_hyp": 0.0, "lambda_prior": 0.0},
    "hyp_c_low": {"manifold_c": 0.1},
    "hyp_c_high": {"manifold_c": 5.0},
    "ddim_steps_2": {"diff_steps": 2},
    "ddim_steps_4": {"diff_steps": 4},
    "diff_schedule_linear": {"diff_schedule": "linear"},
    "diff_eta_0p2": {"diff_eta": 0.2},
    "diff_depth_1": {"d_layers_diff": 1},
    "diff_depth_3": {"d_layers_diff": 3},
    "patch_single": {"patch_len": 8, "stride": 4},
    "patch_wide": {"patch_len": 32, "stride": 16},
    "no_compress": {},
}

_BASE_AWARE_GROUPS = ("no_compress",)

MAIN_ABLATION_VARIANTS = [
    "euclid_manifold",
    "no_hyp_cond",
    "zero_prior_bridge",
    "no_adaln",
    "no_denoise_refinement",
    "no_causal_prefix_norm",
    "no_hyp_loss",
    "no_prior_loss",
]

MAIN_ABLATION_LABELS = {
    "euclid_manifold": "w/ Euclidean Manifold",
    "no_hyp_cond": "w/o Hyperbolic Conditioning",
    "zero_prior_bridge": "w/ Zero-Mean Prior Bridge",
    "no_adaln": "w/o AdaLN-Zero Modulation",
    "no_denoise_refinement": "w/o Diffusion Denoiser",
    "no_causal_prefix_norm": "w/o Causal Prefix Norm",
    "no_hyp_loss": "w/o Hyperbolic Alignment Loss",
    "no_prior_loss": "w/o Prior Anchor Loss",
}

ABLATION_CHOICES = [NO_ABLATION] + list(ABLATION_GROUPS.keys())

MECHANISM_VARIANTS = [
    NO_ABLATION,
    "euclid_manifold",
    "zero_prior_bridge",
    "no_hyp_cond",
    "no_prior_loss",
]

DEFAULT_ABLATION_VARIANTS = list(MAIN_ABLATION_VARIANTS)

_MODEL_DEFAULTS = {
    "use_hyp_manifold": 1,
    "use_prior_bridge": 1,
    "use_hyp_cond": 1,
    "use_adaln": 1,
    "use_denoiser": 1,
    "use_causal_norm": 1,
}

assert set(MAIN_ABLATION_VARIANTS) <= set(ABLATION_GROUPS.keys())
assert set(MAIN_ABLATION_LABELS.keys()) == set(MAIN_ABLATION_VARIANTS)
assert set(MECHANISM_VARIANTS) <= set(ABLATION_CHOICES)
assert set(DEFAULT_ABLATION_VARIANTS) <= set(ABLATION_CHOICES)


def resolve_ablation(args):
    name = str(getattr(args, "ablation", NO_ABLATION) or NO_ABLATION).strip()
    if name in ("", NO_ABLATION, "baseline"):
        args.ablation = NO_ABLATION
        args.ablation_group = NO_ABLATION
        return

    group = ABLATION_GROUPS.get(name)
    if group is None:
        raise ValueError(
            "Unknown ablation group {!r}. Valid: {}".format(
                name, ", ".join(ABLATION_CHOICES)
            )
        )
    for key, value in group.items():
        setattr(args, key, value)
    if name in _BASE_AWARE_GROUPS:
        setattr(args, "d_hyp", getattr(args, "d_model"))
    args.ablation_group = name
    if str(getattr(args, "ablation", NO_ABLATION)) not in MODEL_ABLATION_FLAGS:
        args.ablation = NO_ABLATION


def _effective_baseline_config(dataset, pred_len, baseline="optuna"):
    if baseline == "optuna":
        from src.configs.m2patch_profiles import load_optuna_best_params

        cfg = dict(_MODEL_DEFAULTS)
        cfg.update(load_optuna_best_params(dataset, pred_len))
        return cfg
    if baseline != "profile":
        raise ValueError(f"Unknown baseline {baseline!r}; expected 'optuna' or 'profile'")
    from src.configs.m2patch_profiles import resolve

    cfg = dict(_MODEL_DEFAULTS)
    cfg.update(resolve(dataset, pred_len))
    return cfg


def is_noop_ablation(dataset, pred_len, name, baseline="optuna"):
    """True when every override of the ablation group already matches the
    effective baseline config for (dataset, pred_len), i.e. running the variant
    would reproduce the baseline bit-exactly.

    baseline="optuna" (default) compares against load_optuna_best_params, the
    paper protocol shared by the baseline and every OFAT variant; a missing JSON
    is reported and the cell is treated as runnable. baseline="profile" is
    deprecated and only kept for legacy analysis; paper runs must not use it.
    Override keys absent from both sources fall back to the model-level defaults
    in _MODEL_DEFAULTS.
    """
    if name in (NO_ABLATION, "", "baseline"):
        return False

    try:
        cfg = _effective_baseline_config(dataset, pred_len, baseline=baseline)
    except FileNotFoundError as exc:
        if baseline == "optuna":
            print(f"[is_noop_ablation] {exc} — treating {name} as runnable")
            return False
        raise

    group = ABLATION_GROUPS.get(name)
    if not group:
        return False

    for key, value in group.items():
        if key == "ablation":
            continue
        effective = cfg.get(key, _MODEL_DEFAULTS.get(key))
        if effective != value:
            return False
    return True
