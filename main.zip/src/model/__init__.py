import importlib


def _load(name):
    try:
        module = importlib.import_module(".{}".format(name), __name__)
        return module.Model
    except Exception as exc:
        error = exc
        def _missing(*args, **kwargs):
            raise ImportError("Model {} is unavailable: {}".format(name, error)) from error
        return _missing


Transformer = _load("Transformer")
Informer = _load("Informer")
Reformer = _load("Reformer")
Flowformer = _load("Flowformer")
Flashformer = _load("Flashformer")
Autoformer = _load("Autoformer")
S_Mamba = _load("S_Mamba")
PatchTST = _load("PatchTST")
DLinear = _load("DLinear")
BiMamba4TS = _load("BiMamba4TS")
iTransformer = _load("iTransformer")
M2Patch = _load("M2Patch")
Crossformer = _load("Crossformer")
TimesNet = _load("TimesNet")
TiDE = _load("TiDE")
TimeMixer = _load("TimeMixer")
DisenTS = _load("DisenTS")
MMPD = _load("MMPD")
SimpleTM = _load("SimpleTM")
