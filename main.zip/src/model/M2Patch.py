import torch.nn as nn

from src.layers.M2Patch_layers import M2Patch_backbone


class Model(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.backbone = M2Patch_backbone(configs)

    def forward(self, x, x_mark_enc=None, x_dec=None, x_mark_dec=None, y_true=None):
        return self.backbone(x, y_true)
