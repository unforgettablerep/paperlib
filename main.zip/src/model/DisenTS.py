import copy

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.layers.DisenTS_layers import Gate, BACKBONE_DICT
from src.layers.RevIn import RevIN


class Model(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.configs = configs
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.in_c = configs.enc_in
        self.disen_times = configs.disen_times
        self.similar_weight = configs.similar_weight
        self.sample_num = configs.sample_num
        self.is_revin = configs.is_RevIN
        self.revin = RevIN(self.in_c, affine=False)
        self._build_model()
        self.d_gate = configs.d_gate
        self.gate = Gate(self.seq_len, self.d_gate, self.disen_times, configs.dropout)
        self.forecaster_project = nn.Sequential(
            nn.Linear(self.seq_len * self.pred_len // 16, 4 * self.d_gate),
            nn.ReLU(),
            nn.Linear(4 * self.d_gate, self.d_gate),
        )
        self.equivalent_linear_weights = nn.Parameter(
            torch.randn(self.disen_times, self.seq_len * self.pred_len),
            requires_grad=False,
        )
        self.init = False
        self.auxiliary_losses = None
        self._init_linear_weights()
        self.ce = nn.CrossEntropyLoss(reduction="mean")

    def _build_model(self):
        backbone_cls = BACKBONE_DICT[self.configs.disen_backbone]
        config_model = copy.deepcopy(self.configs)
        self.model = nn.ModuleList(
            [backbone_cls(config_model).float() for _ in range(self.disen_times)]
        )

    @torch.no_grad()
    def _init_linear_weights(self):
        device = self.equivalent_linear_weights.device
        for i in range(self.disen_times):
            foo_series = torch.randn(64, self.seq_len, 1, device=device)
            model = self.model[i]
            foo_pred = model(foo_series).squeeze(-1)
            linear_weight = torch.linalg.pinv(foo_series[:, :, 0]).matmul(foo_pred)
            self.equivalent_linear_weights[i] = linear_weight.detach().view(-1).to(device)

    def forward(self, x, x_mark, dec_inp, y_mark):
        pred_len = self.pred_len
        in_c = self.in_c
        if self.is_revin:
            x = self.revin(x, "norm")
        bs = x.shape[0]
        x = x.permute(0, 2, 1)
        forecaster_state = self.equivalent_linear_weights.reshape(
            self.equivalent_linear_weights.shape[0], self.seq_len, self.pred_len
        )
        forecaster_state_pool = (
            F.avg_pool2d(forecaster_state.unsqueeze(1), kernel_size=4, stride=4)
            .squeeze(1)
            .reshape(self.equivalent_linear_weights.shape[0], -1)
        )
        forecaster_rep = self.forecaster_project(forecaster_state_pool)
        betas = torch.softmax(self.gate(x, forecaster_rep), dim=-1)
        x4weight = x.unsqueeze(-1).reshape(bs * in_c, self.seq_len, 1)
        x = x.permute(0, 2, 1)
        pred_final = torch.zeros(bs, in_c, pred_len, device=x.device, dtype=x.dtype)
        self.equivalent_linear_weights_batch = []
        self.pred_per_backbone = []
        for i in range(self.disen_times):
            model = self.model[i]
            beta = betas[:, i].unsqueeze(-1).unsqueeze(-1)
            pred_model = model(x)[:, -pred_len:, :]
            pred_model = pred_model.permute(0, 2, 1).reshape(bs * in_c, pred_len, 1)
            pred4weight = pred_model
            index = self._topk_sample(bs * in_c, beta.view(-1))
            self.equivalent_linear_weights_batch.append(
                torch.linalg.pinv(x4weight[index, :, 0], atol=1e-2)
                .matmul(pred4weight[index, :, 0])
                .view(-1)
            )
            self.pred_per_backbone.append(pred_model)
            weighted_pred_model = beta * pred_model
            weighted_pred_model = weighted_pred_model.squeeze(-1).reshape(bs, in_c, pred_len)
            pred_final = pred_final + weighted_pred_model
        pred_final = pred_final.permute(0, 2, 1)
        if self.is_revin:
            pred_final = self.revin(pred_final, "denorm")
        if self.training and self.similar_weight > 0:
            self.auxiliary_losses = [(self.similar_weight, self.similar_loss())]
        else:
            self.auxiliary_losses = None
        return pred_final

    def similar_loss(self):
        self.normalized_linear_weights_batch = F.normalize(
            torch.stack(self.equivalent_linear_weights_batch).view(self.disen_times, -1)
        )
        dot_products = torch.matmul(
            self.normalized_linear_weights_batch, self.equivalent_linear_weights.T
        )
        label = torch.arange(
            self.disen_times, dtype=torch.long, device=dot_products.device
        )
        return self.ce(dot_products, label)

    def _topk_sample(self, length, beta):
        k = min(length, self.sample_num)
        _, index = torch.topk(beta, k)
        return index

    @torch.no_grad()
    def post_step(self):
        if not self.init:
            for i in range(self.disen_times):
                self.equivalent_linear_weights[i] = (
                    self.normalized_linear_weights_batch[i].detach()
                )
            self.init = True
        else:
            beta = 0.99
            for i in range(self.disen_times):
                self.equivalent_linear_weights[i] = (
                    beta * self.equivalent_linear_weights[i]
                    + (1 - beta) * self.normalized_linear_weights_batch[i].detach()
                )
