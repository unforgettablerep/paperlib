import torch
import torch.nn as nn

from src.layers.MMPD_layers import (
    DecoderOnlyTransformer,
    EncoderDecoderTransformer,
    MMPD_Loss,
)

BACKBONE_DICT = {
    "Decoder": DecoderOnlyTransformer,
    "EncoderDecoder": EncoderDecoderTransformer,
}


class Model(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.configs = configs
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.patch_size = configs.patch_size
        self.point_weight = configs.point_weight
        self.weighted = bool(configs.weighted)
        self.sample_expectation = bool(getattr(configs, "mmpd_sample_expectation", 0))
        self.sample_num = configs.sample_num
        self.temperature = configs.temperature
        self.gmm_components = configs.gmm_components
        self.prior_pi_decay = configs.prior_pi_decay
        self.prior_precision_shape = configs.prior_precision_shape
        self.gmm_iterations = configs.gmm_iterations

        backbone_cls = BACKBONE_DICT[configs.mmpd_backbone]
        self.backbone = backbone_cls(configs)
        self.loss_func = MMPD_Loss(configs)
        self.auxiliary_losses = None

    def load_state_dict(self, state_dict, strict=True, assign=False):
        filtered = {
            key: value
            for key, value in state_dict.items()
            if not key.startswith("loss_func.gen_diffusion.")
        }

        return super().load_state_dict(filtered, strict=False, assign=assign)

    def _instance_stats(self, x_seq):
        mean = torch.mean(x_seq, dim=-1).detach()
        stdev = torch.sqrt(torch.var(x_seq, dim=-1, correction=0)).detach()
        stdev[stdev < 10 * torch.finfo(stdev.dtype).eps] = 1.0

        return mean, stdev

    def _normalize(self, x_seq, mean, stdev):
        return (x_seq - mean[..., None]) / stdev[..., None]

    def _select_condition(self, dec_condition, mean, stdev, num_targets):
        if num_targets != dec_condition.shape[1]:
            dec_condition = dec_condition[:, -num_targets:]
            mean = mean[:, -num_targets:]
            stdev = stdev[:, -num_targets:]

        return dec_condition, mean, stdev

    def compute_train_loss(self, batch_x, batch_y, batch_x_mark=None, batch_y_mark=None):
        x_seq = batch_x.float().permute(0, 2, 1).contiguous()
        y_seq = batch_y.float().permute(0, 2, 1).contiguous()

        mean, stdev = self._instance_stats(x_seq)
        normed_x = self._normalize(x_seq, mean, stdev)
        normed_y = self._normalize(y_seq, mean[:, -y_seq.shape[1] :], stdev[:, -y_seq.shape[1] :])

        dec_condition = self.backbone(normed_x)
        dec_condition, mean, stdev = self._select_condition(dec_condition, mean, stdev, y_seq.shape[1])

        loss = self.loss_func.compute_loss(normed_y, dec_condition, point_weight=self.point_weight)
        if self.weighted:
            loss = (stdev**2) * loss

        return loss.mean()

    def forward(self, batch_x, batch_x_mark=None, dec_inp=None, batch_y_mark=None, y_true=None):
        x_seq = batch_x.float().permute(0, 2, 1).contiguous()
        mean, stdev = self._instance_stats(x_seq)
        normed_x = self._normalize(x_seq, mean, stdev)

        dec_condition = self.backbone(normed_x)

        if self.sample_expectation:
            normed_pred, _, _ = self.loss_func.sample_predict(
                dec_condition,
                sample_num=self.sample_num,
                temperature=self.temperature,
                gmm_components=self.gmm_components,
                prior_pi_decay=self.prior_pi_decay,
                prior_precision_shape=self.prior_precision_shape,
                gmm_iterations=self.gmm_iterations,
            )
        else:
            normed_pred = self.loss_func.point_predict(dec_condition)

        pred = normed_pred * stdev[..., None] + mean[..., None]

        return pred.permute(0, 2, 1).contiguous(), None

    @torch.no_grad()
    def predict_multimode(self, batch_x):
        x_seq = batch_x.float().permute(0, 2, 1).contiguous()
        mean, stdev = self._instance_stats(x_seq)
        normed_x = self._normalize(x_seq, mean, stdev)
        dec_condition = self.backbone(normed_x)

        deterministic_pred = self.loss_func.point_predict(dec_condition)
        deterministic_pred = deterministic_pred * stdev[..., None] + mean[..., None]

        sample_mean, prob_samples, multi_mode_pred = self.loss_func.sample_predict(
            dec_condition,
            sample_num=self.sample_num,
            temperature=self.temperature,
            gmm=True,
            gmm_components=self.gmm_components,
            prior_pi_decay=self.prior_pi_decay,
            prior_precision_shape=self.prior_precision_shape,
            gmm_iterations=self.gmm_iterations,
        )
        prob_samples = prob_samples * stdev[:, :, None, None] + mean[:, :, None, None]
        sample_mean = sample_mean * stdev[..., None] + mean[..., None]
        if multi_mode_pred is not None:
            multi_mode_pred["mode_center"] = (
                multi_mode_pred["mode_center"] * stdev[:, :, None, None] + mean[:, :, None, None]
            )

        return deterministic_pred, sample_mean, prob_samples, multi_mode_pred
