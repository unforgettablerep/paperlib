from src.configs.m2patch_profiles import DATASET_META
from src.utils.result_io import canonical_dataset

PRED_LENS_BY_DATASET = {
    name: list(meta["pred_lens"]) for name, meta in DATASET_META.items()
}

DATASET_CONFIGS = {}
for _name, _meta in DATASET_META.items():
    DATASET_CONFIGS[_name] = {
        "data": _meta["data"],
        "root_path": _meta["root_path"],
        "data_path": _meta["data_path"],
        "enc_in": _meta["enc_in"],
        "dec_in": _meta["enc_in"],
        "c_out": _meta["c_out"],
        "freq": _meta["freq"] or "t",
        "total_rows": _meta["total_rows"],
        "seq_len": _meta["seq_len"],
        "label_len": _meta["label_len"],
    }


def get_dataset_config(dataset_name: str) -> dict:
    name = canonical_dataset(dataset_name)
    if name not in DATASET_CONFIGS:
        raise ValueError(
            f"Unknown dataset: {dataset_name}. Supported: {list(DATASET_CONFIGS.keys())}"
        )
    return DATASET_CONFIGS[name].copy()
