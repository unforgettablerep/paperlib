from src.configs.m2patch_profiles import CLI_ORDER, CONSTANTS, DATASET_META, resolve
from src.utils.result_io import canonical_dataset

SEARCH_SPACE_VERSION = "v5"

PARAM_ORDER = (
    "d_model",
    "e_layers",
    "d_hyp",
    "patch_len",
    "stride",
    "d_layers_diff",
    "diff_steps",
    "manifold_c",
    "lambda_hyp",
    "lambda_prior",
    "learning_rate",
)

HPO_PARAM_GROUPS: dict[str, tuple[str, ...]] = {
    "backbone_patch": ("d_model", "e_layers", "patch_len", "stride"),
    "hyperbolic_diffusion": (
        "d_hyp",
        "manifold_c",
        "d_layers_diff",
        "diff_steps",
        "lambda_hyp",
        "lambda_prior",
    ),
    "optimization": ("learning_rate",),
}

_HIGH_VARIATE_DATASETS = ("ECL", "Traffic", "PEMS03", "PEMS04", "PEMS07", "PEMS08")

_D_MODEL_LADDER = (128, 256, 384, 512)
_D_HYP_LADDER = (32, 64, 128)

_LR_LOW_FACTOR = 1.0 / 3.0
_LR_HIGH_FACTOR = 3.0
_LR_FLOOR = 1e-5
_LR_CEIL = 5e-3

_EXACT_D_MODEL = {
    ("ETTh1", 96): (384, 512),
    ("ETTh1", 192): (384, 512),
    ("ETTh1", 336): (384, 512),
    ("ETTh1", 720): (256, 384, 512),
    ("ETTm1", 96): (128, 256),
    ("ETTm1", 192): (128, 256, 384),
    ("ETTm1", 336): (128, 256, 512),
    ("ETTm1", 720): (128, 256, 512),
}

_EXACT_LEARNING_RATE = {
    ("ETTh1", 96): (2e-4, 1e-3),
    ("ETTh1", 192): (1e-4, 8e-4),
    ("ETTh1", 336): (2e-4, 1e-3),
    ("ETTh1", 720): (1e-4, 8e-4),
    ("ETTm1", 96): (1.5e-4, 8e-4),
    ("ETTm1", 192): (1e-4, 6e-4),
    ("ETTm1", 336): (1e-4, 1e-3),
    ("ETTm1", 720): (1e-4, 1e-3),
}

_LR_HIGH_CEILING = {
    ("ECL", 192): 8e-3,
    ("ECL", 336): 8e-3,
}

_EXACT_D_HYP = {
    "ETTh1": (32, 64, 128),
    "ETTm1": (64, 128),
    ("ETTm1", 336): (64, 128, 256),
    ("ETTm2", 720): (32, 64, 128),
    ("ECL", 720): (32, 64, 128, 256),
}

_EXACT_LAMBDA_PRIOR = {
    "ETTh1": (0.05, 0.6),
    "ETTm1": (0.03, 0.3),
    ("ECL", 96): (0.03, 1.0),
    ("ECL", 192): (0.03, 1.0),
    ("ECL", 336): (0.03, 1.0),
    ("ECL", 720): (0.03, 1.0),
    ("ETTm1", 336): (0.03, 1.0),
    ("ETTm1", 720): (0.03, 1.0),
    ("ETTm2", 720): (0.03, 1.0),
}

_EXACT_MANIFOLD_C = {
    ("ETTm2", 720): (0.25, 2.0),
}

_FIXED_PARAM_KEYS = (
    "train_epochs",
    "batch_size",
    "patience",
    "revin",
    "lradj",
    "optim",
    "diff_schedule",
    "diff_eta",
    "dropout",
    "pct_start",
)

HPO_DEFAULTS = {
    **CONSTANTS,
    "is_training": 1,
    "model": "M2Patch",
    "features": "M",
    "target": "OT",
    "freq": "h",
    "checkpoints": "./temp/checkpoints/",
    "checkpoint": 0,
    "enc_in": 7,
    "seq_len": 96,
    "pred_len": 96,
    "label_len": 48,
    "d_layers": 1,
    "moving_avg": 25,
    "factor": 1,
    "distil": True,
    "embed": "timeF",
    "output_attention": False,
    "do_predict": False,
    "num_workers": 2,
    "itr": 1,
    "loss": "MSE",
    "use_amp": False,
    "exp_name": "MTSF",
    "use_norm": True,
    "class_strategy": "projection",
    "inverse": False,
    "channel_independence": False,
    "efficient_training": False,
    "partial_start_index": 0,
    "use_gpu": True,
    "gpu": 0,
    "use_multi_gpu": False,
    "devices": "0",
    "noise_level": 0.0,
    "max_grad_norm": 0.0,
    "train_noise_level": 0.0,
    "use_cuda_accel": 1,
    "seed": 2023,
    "n_heads": 8,
    "save_tmp": 1,
    "weight_decay": 0.0,
    "d_model": 256,
    "ablation": "none",
    "activation": "gelu",
}

EFFECTIVE_PARAM_KEYS = tuple(
    dict.fromkeys(
        [
            *CLI_ORDER,
            "seed",
            "model",
            "dataset",
            "data",
            "data_path",
            "total_rows",
            "seq_len",
            "label_len",
            "pred_len",
            "enc_in",
            "dec_in",
            "c_out",
            "features",
            "target",
            "freq",
            "embed",
            "num_workers",
            "use_cuda_accel",
            "use_amp",
            "loss",
            "weight_decay",
            "max_grad_norm",
            "ablation",
            "activation",
            "n_heads",
            "inverse",
            "use_norm",
            "class_strategy",
            "channel_independence",
            "efficient_training",
            "partial_start_index",
            "noise_level",
            "train_noise_level",
        ]
    )
)


def _ladder_window(ladder: tuple, value) -> list:
    if value not in ladder:
        return [value]
    idx = ladder.index(value)
    return list(ladder[max(0, idx - 1) : idx + 2])


def _exact_lookup(mapping, name, pred_len):
    if (name, pred_len) in mapping:
        return mapping[(name, pred_len)]
    return mapping.get(name)


def _learning_rate_bounds(profile_lr: float) -> tuple[float, float]:
    low = min(max(profile_lr * _LR_LOW_FACTOR, _LR_FLOOR), _LR_CEIL)
    high = min(max(profile_lr * _LR_HIGH_FACTOR, _LR_FLOOR), _LR_CEIL)
    return low, high


def _assert_profile_included(space: dict, profile: dict) -> None:
    for name in PARAM_ORDER:
        if name not in space:
            continue
        spec = space[name]
        value = profile[name]
        if spec["type"] == "categorical":
            included = value in spec["choices"]
        else:
            included = spec["low"] <= value <= spec["high"]
        if not included:
            raise RuntimeError(
                f"Search space for '{name}' excludes the profile value {value}: {spec}"
            )


def build_search_space(dataset_name: str, pred_len: int) -> dict:
    name = canonical_dataset(dataset_name)
    profile = resolve(name, pred_len)
    tight = name in _HIGH_VARIATE_DATASETS

    d_model = _ladder_window(_D_MODEL_LADDER, profile["d_model"])

    d_hyp = _ladder_window(_D_HYP_LADDER, profile["d_hyp"])
    exact_d_hyp = _exact_lookup(_EXACT_D_HYP, name, pred_len)
    if exact_d_hyp is not None:
        d_hyp = list(exact_d_hyp)

    if tight:
        patch_choices = [profile["patch_len"]]
        stride_choices = [profile["stride"]]
    else:
        patch_choices = sorted({8, 16, profile["patch_len"]})
        stride_choices = sorted({4, 8, profile["stride"]})

    lr_low, lr_high = _learning_rate_bounds(profile["learning_rate"])
    lambda_prior_low, lambda_prior_high = 0.03, max(0.3, profile["lambda_prior"])
    exact_lambda_prior = _exact_lookup(_EXACT_LAMBDA_PRIOR, name, pred_len)
    if exact_lambda_prior is not None:
        lambda_prior_low, lambda_prior_high = exact_lambda_prior
    manifold_c_low, manifold_c_high = _EXACT_MANIFOLD_C.get(
        (name, pred_len), (0.5, 2.0)
    )

    space = {
        "d_model": {"type": "categorical", "choices": d_model},
        "e_layers": {"type": "categorical", "choices": [profile["e_layers"]]},
        "d_hyp": {"type": "categorical", "choices": d_hyp},
        "patch_len": {"type": "categorical", "choices": patch_choices},
        "stride": {"type": "categorical", "choices": stride_choices},
        "d_layers_diff": {
            "type": "categorical",
            "choices": sorted({1, 2, profile["d_layers_diff"]}),
        },
        "diff_steps": {
            "type": "categorical",
            "choices": sorted({1, 2, profile["diff_steps"]}),
        },
        "manifold_c": {
            "type": "loguniform",
            "low": manifold_c_low,
            "high": manifold_c_high,
        },
        "lambda_hyp": {
            "type": "loguniform",
            "low": 0.03,
            "high": max(0.3, profile["lambda_hyp"]),
        },
        "lambda_prior": {
            "type": "loguniform",
            "low": lambda_prior_low,
            "high": lambda_prior_high,
        },
        "learning_rate": {"type": "loguniform", "low": lr_low, "high": lr_high},
    }

    if (name, pred_len) in _EXACT_D_MODEL:
        space["d_model"]["choices"] = list(_EXACT_D_MODEL[(name, pred_len)])
    if (name, pred_len) in _EXACT_LEARNING_RATE:
        space["learning_rate"]["low"], space["learning_rate"]["high"] = (
            _EXACT_LEARNING_RATE[(name, pred_len)]
        )
    if (name, pred_len) in _LR_HIGH_CEILING:
        space["learning_rate"]["high"] = _LR_HIGH_CEILING[(name, pred_len)]

    ordered = {key: space[key] for key in PARAM_ORDER}
    _assert_profile_included(ordered, profile)
    return ordered


def get_fixed_params(dataset_name: str = "", pred_len: int | None = None) -> dict:
    name = canonical_dataset(dataset_name) if dataset_name else ""
    if name not in DATASET_META:
        return {key: CONSTANTS[key] for key in _FIXED_PARAM_KEYS}

    pred_lens = DATASET_META[name]["pred_lens"]
    effective_pl = pred_len if pred_len in pred_lens else min(pred_lens)
    profile = resolve(name, effective_pl)
    fixed = {key: profile[key] for key in _FIXED_PARAM_KEYS}
    return fixed
