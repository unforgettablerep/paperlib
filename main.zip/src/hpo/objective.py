import argparse
import gc
import os
import random
import sys

import numpy as np
import optuna
import torch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(_PROJECT_ROOT)

from src.configs.m2patch_profiles import CONSTANTS, D_FF_CAP
from src.experiments.exp_long_term_forecasting import Exp_Long_Term_Forecast
from src.hpo.search_space import EFFECTIVE_PARAM_KEYS, HPO_DEFAULTS, PARAM_ORDER, build_search_space, get_fixed_params
from src.utils.result_io import canonical_dataset
from src.hpo.gpu_budget import (
    PerGPUBudget,
    estimate_cuda_accel_test_peak_mb,
    estimate_m2patch_memory_mb,
    should_disable_cuda_accel,
    TOTAL_GPU_MEMORY_MB,
)


_ARCH_SIG_KEYS = [
    "d_model",
    "d_ff",
    "e_layers",
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
]

_RUNTIME_KEYS = [
    "dataset",
    "data",
    "root_path",
    "data_path",
    "freq",
    "total_rows",
    "seq_len",
    "label_len",
    "pred_len",
    "enc_in",
    "dec_in",
    "c_out",
    "model_id",
    "model",
    "des",
    "gpu",
    "save_tmp",
    "use_cuda_accel",
    "use_amp",
    "num_workers",
    "batch_size",
    "train_epochs",
    "patience",
    "seed",
]


def resolve_fixed_params(fixed_params: dict) -> dict:
    dataset_name = canonical_dataset(fixed_params.get("dataset", ""))
    pred_len = fixed_params.get("pred_len", HPO_DEFAULTS["pred_len"])
    fixed = {key: value for key, value in HPO_DEFAULTS.items() if key not in PARAM_ORDER}
    fixed.update(get_fixed_params(dataset_name, pred_len))
    fixed.update({key: fixed_params[key] for key in _RUNTIME_KEYS if key in fixed_params})
    if dataset_name:
        fixed["dataset"] = dataset_name
    return fixed


def _detect_physical_gpu(default: int = 0) -> int:
    cvd = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if cvd:
        first = cvd.split(",")[0].strip()
        if first.isdigit():
            return int(first)
    return default


def _suggest_one(trial, name: str, spec: dict):
    t = spec["type"]
    if t == "categorical":
        return trial.suggest_categorical(name, spec["choices"])
    elif t == "int":
        return trial.suggest_int(name, spec["low"], spec["high"], step=spec.get("step", 1))
    elif t == "loguniform":
        return trial.suggest_float(name, spec["low"], spec["high"], log=True)
    elif t == "uniform":
        return trial.suggest_float(name, spec["low"], spec["high"])
    raise ValueError(f"Unknown param type '{t}' for '{name}'")


def _suggest_params(trial, space: dict) -> dict:
    params = {}
    for name in PARAM_ORDER:
        if name in space:
            params[name] = _suggest_one(trial, name, space[name])
    for name in space:
        if name not in params:
            params[name] = _suggest_one(trial, name, space[name])
    return params


def _build_args(fixed: dict, suggested: dict, trial=None) -> argparse.Namespace:
    merged = {**HPO_DEFAULTS, **suggested, **fixed}

    d_model_val = merged.get("d_model", 256)
    merged["d_ff"] = min(d_model_val * 2, D_FF_CAP)

    args = argparse.Namespace(**merged)
    args.use_gpu = True
    args.optuna_trial = trial
    return args


def _build_setting(args) -> str:
    setting = (
        "{}_{}|{}|batch:{}|epochs:{}|dm:{}|patch:{}|stride:{}|dh:{}|mc:{}|"
        "dld:{}|steps:{}|sched:{}|eta:{}|lh:{}|lp:{}|abl:{}|rc:{}|"
        "el:{}|df:{}|lr:{}|wd:{}|dropout:{}|pat:{}|ps:{}|itr:0"
    ).format(
        args.model_id,
        args.model,
        args.des,
        args.batch_size,
        args.train_epochs,
        args.d_model,
        args.patch_len,
        args.stride,
        args.d_hyp,
        args.manifold_c,
        args.d_layers_diff,
        args.diff_steps,
        args.diff_schedule,
        args.diff_eta,
        args.lambda_hyp,
        args.lambda_prior,
        args.ablation,
        args.revin,
        args.e_layers,
        args.d_ff,
        args.learning_rate,
        args.weight_decay,
        args.dropout,
        args.patience,
        getattr(args, "pct_start", CONSTANTS["pct_start"]),
    )
    return setting


def _estimate(enc_in, suggested, seq_len, pred_len, batch_size):
    d_model_val = suggested.get("d_model", 256)
    d_ff_val = min(d_model_val * 2, D_FF_CAP)
    return estimate_m2patch_memory_mb(
        enc_in=enc_in,
        d_model=d_model_val,
        d_ff=d_ff_val,
        seq_len=seq_len,
        pred_len=pred_len,
        batch_size=batch_size,
        e_layers=suggested["e_layers"],
        patch_len=suggested.get("patch_len", 16),
        stride=suggested.get("stride", 8),
        d_hyp=suggested.get("d_hyp", 64),
        d_layers_diff=suggested.get("d_layers_diff", 2),
        diff_steps=suggested.get("diff_steps", 1),
    )


def _release_cuda_cache() -> None:
    gc.collect()
    try:
        torch.cuda.empty_cache()
    except Exception:
        pass


def create_objective(
    fixed_params: dict,
    metric: str = "mse",
    physical_gpu: int | None = None,
    stop_check=None,
):
    fixed = resolve_fixed_params(fixed_params)
    enc_in = fixed["enc_in"]
    pred_len = fixed["pred_len"]
    seq_len = fixed["seq_len"]
    dataset_name = fixed.get("dataset", "")

    model_space = build_search_space(dataset_name, pred_len)

    study_tag = f"{dataset_name}_pl{pred_len}"

    if physical_gpu is None:
        physical_gpu = _detect_physical_gpu(fixed.get("gpu", 0))
    budget = PerGPUBudget(physical_gpu)

    def _execute_attempt(trial, suggested):
        trial_fixed = dict(fixed)
        if "use_cuda_accel" in suggested:
            trial_fixed["use_cuda_accel"] = suggested["use_cuda_accel"]
        args = _build_args(trial_fixed, suggested, trial=trial)
        effective_params = {key: vars(args)[key] for key in EFFECTIVE_PARAM_KEYS if key in vars(args)}
        trial.set_user_attr("effective_params", effective_params)
        arch_sig = "|".join(str(getattr(args, k, 0)) for k in _ARCH_SIG_KEYS)
        args.des = f"HPO_OPTUNA_{trial.number}"

        setting = _build_setting(args)

        exp = Exp_Long_Term_Forecast(args)
        try:
            exp.train(setting)

            if hasattr(exp, "_nan_detected") and exp._nan_detected:
                raise optuna.TrialPruned("nan_loss_during_final_epoch")

            test_result = exp.test(setting)

            if isinstance(test_result, dict):
                mse = test_result.get("mse")
                mae = test_result.get("mae")
            else:
                fallback = getattr(exp, "_last_test_result", None)
                mse = fallback.get("mse") if isinstance(fallback, dict) else None
                mae = fallback.get("mae") if isinstance(fallback, dict) else None

            if mse is None or mae is None or not (np.isfinite(mse) and np.isfinite(mae)):
                print(
                    f"[WARN] Trial {trial.number}: non-finite test metrics "
                    f"mse={mse}, mae={mae}"
                )
                trial.set_user_attr("status", "non_finite_test")
                raise optuna.TrialPruned("non_finite_test")

            trial.set_user_attr("mse", float(mse))
            trial.set_user_attr("mae", float(mae))
            trial.set_user_attr("setting", setting)
            trial.set_user_attr("arch_signature", arch_sig)
            trial.set_user_attr("checkpoint", getattr(exp, "_last_checkpoint_seq", None))

            return float(mse) if metric == "mse" else float(mae)
        finally:
            if exp is not None and not int(getattr(args, "keep_checkpoint", 0)) and not getattr(args, "save_tmp", 1):
                from src.utils.checkpoint import cleanup_checkpoint

                seq = (
                    getattr(exp, "_lr_checkpoint_to_cleanup", None)
                    or getattr(exp, "_active_ckpt_seq", None)
                    or getattr(exp, "_last_checkpoint_seq", None)
                )
                if seq is not None:
                    cleanup_checkpoint(args, seq)
                    exp._last_checkpoint_seq = None
                    trial.set_user_attr("checkpoint", None)
            _release_cuda_cache()

    def objective(trial) -> float:
        if stop_check and stop_check():
            trial.set_user_attr("status", "stop_requested")
            raise optuna.TrialPruned("stop requested")

        seed = fixed["seed"]
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        suggested = _suggest_params(trial, model_space)
        batch_size = fixed["batch_size"]

        est_mb = _estimate(enc_in, suggested, seq_len, pred_len, batch_size)

        trial.set_constraint("gpu_memory_mb", float(est_mb - TOTAL_GPU_MEMORY_MB))
        trial.set_constraint("stride_leq_patch_len", float(suggested["stride"] - suggested["patch_len"]))

        if suggested["stride"] > suggested["patch_len"]:
            print(
                f"[CAUSALITY] Trial {trial.number} pruned: stride "
                f"{suggested["stride"]} > patch_len {suggested["patch_len"]}"
            )
            trial.set_user_attr("status", "stride_exceeds_patch_len")
            raise optuna.TrialPruned("stride_exceeds_patch_len")

        if est_mb > TOTAL_GPU_MEMORY_MB:
            print(
                f"[OOM] Trial {trial.number} skipped: "
                f"estimated {est_mb:.0f} MB > limit {TOTAL_GPU_MEMORY_MB} MB"
            )
            trial.set_user_attr("status", "skipped_over_budget")
            trial.set_user_attr("est_mb", est_mb)
            return float("inf")

        trial.set_user_attr("batch_size", batch_size)
        trial.set_user_attr("seed", seed)

        cuda_accel = fixed.get("use_cuda_accel", 1)
        total_rows = fixed.get("total_rows", 0)
        if cuda_accel:
            if should_disable_cuda_accel(
                enc_in, pred_len, total_rows, seq_len
            ):
                suggested["use_cuda_accel"] = 0
                trial.set_user_attr("cuda_accel_auto_disabled", True)
            else:
                overhead = estimate_cuda_accel_test_peak_mb(
                    enc_in, pred_len, total_rows, seq_len
                )
                if est_mb + overhead > TOTAL_GPU_MEMORY_MB:
                    suggested["use_cuda_accel"] = 0
                    trial.set_user_attr("cuda_accel_auto_disabled", True)
                else:
                    est_mb += overhead
                    trial.set_user_attr("cuda_accel_overhead_mb", overhead)

        budget_key = f"{study_tag}:{os.getpid()}:{trial.number}"
        acquired = budget.acquire(budget_key, est_mb, timeout=1800)
        if not acquired:
            trial.set_user_attr("status", "timeout_waiting_gpu")
            raise optuna.TrialPruned("timeout_waiting_gpu")

        try:
            return _execute_attempt(trial, suggested)
        except optuna.TrialPruned:
            raise
        except Exception as e:
            if "out of memory" in str(e).lower():
                print(
                    f"[OOM] Trial {trial.number}: CUDA out of memory during training"
                )
                trial.set_user_attr("status", "cuda_oom")
                raise optuna.TrialPruned("cuda_oom")
            raise
        finally:
            budget.release(budget_key)

    return objective
