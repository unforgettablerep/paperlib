import json
import math
import os

from src.configs.m2patch_profiles import resolve
from src.utils.result_io import canonical_dataset

_OUTPUT_DIR = "./output/optuna"
_PROFILE_SOURCE = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "configs", "m2patch_profiles.py"))


def _is_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and (isinstance(value, int) or math.isfinite(value))


def _normalize_param(value, spec: dict) -> tuple[object, str | None]:
    if not isinstance(spec, dict):
        return value, "invalid search-space specification"

    kind = spec.get("type")
    if kind == "categorical":
        choices = spec.get("choices")
        if not isinstance(choices, (list, tuple)) or not choices:
            return value, "categorical specification has no choices"
        for choice in choices:
            if isinstance(choice, (int, float)) and not isinstance(choice, bool) and not _is_number(choice):
                return value, "categorical specification contains a non-finite choice"
            if choice is not None and not isinstance(choice, (bool, int, float, str)):
                return value, "categorical specification contains a non-scalar choice"
        if isinstance(value, bool):
            for choice in choices:
                if isinstance(choice, bool) and value is choice:
                    return choice, None
        elif _is_number(value):
            for choice in choices:
                if _is_number(choice) and value == choice:
                    return choice, None
        elif value is None or isinstance(value, str):
            for choice in choices:
                if type(value) is type(choice) and value == choice:
                    return choice, None
        return value, f"expected one of {choices!r} with a compatible scalar type"

    if kind not in ("int", "uniform", "loguniform"):
        return value, f"unsupported search-space type {kind!r}"

    low, high = spec.get("low"), spec.get("high")
    if not _is_number(low) or not _is_number(high) or low > high:
        return value, "invalid finite search-space bounds"
    if kind == "int":
        step = spec.get("step", 1)
        if any(not isinstance(item, int) or isinstance(item, bool) for item in (low, high, step)) or step <= 0:
            return value, "integer specification requires integer bounds and a positive integer step"
        if not isinstance(value, int) or isinstance(value, bool):
            return value, "expected an integer (booleans and floats are not integers)"
        if value < low or value > high or (value - low) % step != 0:
            return value, f"outside integer range [{low}, {high}] with step {step}"
        return value, None

    if kind == "loguniform" and low <= 0:
        return value, "loguniform specification requires positive bounds"
    if not _is_number(value):
        return value, "expected a finite number (booleans are not numbers)"
    if value < low or value > high:
        return value, f"outside {kind} range [{low}, {high}]"
    try:
        normalized = float(value)
    except OverflowError:
        return value, "number is outside the finite float range"
    if not math.isfinite(normalized):
        return value, "expected a finite float"
    return normalized, None


def _is_valid_param(value, spec: dict) -> bool:
    return _normalize_param(value, spec)[1] is None


def _numeric_bounds(spec: dict | None) -> tuple | None:
    if not isinstance(spec, dict):
        return None
    if spec.get("type") == "categorical":
        choices = spec.get("choices", ())
        if not isinstance(choices, (list, tuple)) or not choices or not all(_is_number(value) for value in choices):
            return None
        return min(choices), max(choices)
    if spec.get("type") in ("int", "uniform", "loguniform"):
        low, high = spec.get("low"), spec.get("high")
        if _is_number(low) and _is_number(high) and low <= high:
            return low, high
    return None


def _validation_report(baseline: dict, search_space: dict, fixed_params: dict) -> tuple[dict, dict]:
    accepted = {}
    ignored = {}
    for key, value in baseline.items():
        if key in fixed_params:
            ignored[key] = {"value": value, "reason": f"fixed at {fixed_params[key]!r} for this study"}
        elif key not in search_space:
            ignored[key] = {"value": value, "reason": "not in the current search space"}
        else:
            normalized, reason = _normalize_param(value, search_space[key])
            if reason is None:
                accepted[key] = normalized
            else:
                ignored[key] = {"value": value, "reason": reason}

    def discard(key: str, reason: str) -> None:
        ignored[key] = {"value": accepted.pop(key), "reason": reason}

    patch_len = fixed_params.get("patch_len", accepted.get("patch_len"))
    stride = fixed_params.get("stride", accepted.get("stride"))
    if patch_len is not None and stride is not None:
        if not _is_number(patch_len) or not _is_number(stride) or stride > patch_len:
            reason = f"stride <= patch_len violated by stride={stride!r}, patch_len={patch_len!r}"
            if "stride" in accepted:
                discard("stride", reason)
                stride = None
            elif "patch_len" in accepted:
                discard("patch_len", reason)
                patch_len = None
            else:
                for key in list(accepted):
                    discard(key, f"infeasible fixed configuration: {reason}")
                return accepted, ignored

    if patch_len is not None and stride is None and "patch_len" in accepted:
        bounds = _numeric_bounds(search_space.get("stride"))
        if bounds is not None and (not _is_number(patch_len) or patch_len < bounds[0]):
            discard("patch_len", f"no feasible stride in the current search space for patch_len={patch_len!r}")
    if stride is not None and patch_len is None and "stride" in accepted:
        bounds = _numeric_bounds(search_space.get("patch_len"))
        if bounds is not None and (not _is_number(stride) or stride > bounds[1]):
            discard("stride", f"no feasible patch_len in the current search space for stride={stride!r}")

    return accepted, ignored


def _log_validation(source: str, accepted: dict, ignored: dict) -> None:
    print(f"  Warm start {source}: accepted {len(accepted)} params, ignored {len(ignored)} params")
    for key, value in accepted.items():
        print(f"    + {key}={value!r}")
    for key, entry in ignored.items():
        print(f"    - {key}={entry["value"]!r} ({entry["reason"]})")


def validate_baseline(baseline: dict, search_space: dict, fixed_params: dict | None = None) -> dict:
    accepted, ignored = _validation_report(baseline, search_space, fixed_params or {})
    _log_validation("validation", accepted, ignored)
    return accepted


def load_baseline(dataset: str, pred_len: int, optuna_dir: str | os.PathLike[str] | None = None) -> dict | None:
    name = canonical_dataset(dataset)
    directory = _OUTPUT_DIR if optuna_dir is None else optuna_dir
    filenames = dict.fromkeys((
        f"M2Patch_{name}_pl{pred_len}_best_params.json",
        f"M2Patch_{name.lower()}_pl{pred_len}_best_params.json",
    ))
    for filename in filenames:
        path = os.path.join(directory, filename)
        try:
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
        except FileNotFoundError:
            print(f"  Warm start JSON missing: {path}")
            continue
        except (OSError, ValueError, RecursionError) as exc:
            print(f"  Warm start JSON ignored: {path} ({type(exc).__name__}: {exc})")
            continue
        if not isinstance(data, dict) or not isinstance(data.get("best_params"), dict) or not data["best_params"]:
            print(f"  Warm start JSON ignored: {path} (expected a nonempty best_params object)")
            continue
        return {
            "best_params": dict(data["best_params"]),
            "source_file": os.path.abspath(path),
            "best_value": data.get("best_value"),
            "best_trial_number": data.get("best_trial_number"),
        }
    print(f"  Warm start: no usable exact-horizon JSON for {name}_pl{pred_len}; using the profile anchor")
    return None


def _metadata_value(value):
    if isinstance(value, float) and not math.isfinite(value):
        return repr(value)
    if isinstance(value, dict):
        return {key: _metadata_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_metadata_value(item) for item in value]
    return value


def initialize_study(
    study,
    dataset: str,
    pred_len: int,
    search_space: dict,
    fixed_params: dict,
    warm_start: bool = True,
    optuna_dir: str | os.PathLike[str] | None = None,
) -> list[dict]:
    print(
        f"  Initialization: JSON warm_start={int(bool(warm_start))}, "
        f"fixed dropout={fixed_params.get("dropout", "<sampled>")!r}, "
        f"fixed pct_start={fixed_params.get("pct_start", "<sampled>")!r}"
    )
    existing_trials = study.trials
    if existing_trials:
        print(f"  Initialization skipped: study has {len(existing_trials)} existing trials (including waiting/running)")
        return []

    name = canonical_dataset(dataset)
    candidates = []
    if warm_start:
        baseline = load_baseline(name, pred_len, optuna_dir=optuna_dir)
        if baseline is not None:
            candidates.append(("json", baseline["best_params"], baseline))
    else:
        print("  JSON warm start disabled (--warm_start 0); profile anchor remains enabled")
    try:
        profile = resolve(name, pred_len)
    except (KeyError, TypeError, ValueError) as exc:
        print(f"  Profile anchor unavailable for {name}_pl{pred_len}: {exc}")
    else:
        candidates.append(("profile", profile, {
            "source_file": _PROFILE_SOURCE,
            "best_value": None,
            "best_trial_number": None,
        }))

    enqueued = []
    for seed_source, values, provenance in candidates:
        accepted, ignored = _validation_report(values, search_space, fixed_params)
        _log_validation(seed_source, accepted, ignored)
        if not accepted:
            print(f"  Warm start {seed_source} skipped: no valid searchable parameters")
            continue
        if any(accepted == entry["params"] for entry in enqueued):
            print(f"  Warm start {seed_source} skipped: duplicate of an earlier initialization candidate")
            continue
        metadata = _metadata_value({
            "source_file": provenance["source_file"],
            "best_value": provenance["best_value"],
            "best_trial_number": provenance["best_trial_number"],
            "dataset": name,
            "pred_len": pred_len,
            "accepted": accepted,
            "ignored": ignored,
        })
        study.enqueue_trial(accepted, user_attrs={"seed_source": seed_source, "warm_start": metadata}, skip_if_exists=True)
        enqueued.append({"seed_source": seed_source, "params": accepted, "warm_start": metadata})
        print(f"  Warm start {seed_source}: enqueued {len(accepted)} params from {provenance["source_file"]}")
    print(f"  Initialization complete: {len(enqueued)} candidate(s) enqueued for fresh evaluation")
    return enqueued
