import json
import os

import optuna
from optuna.samplers import TPESampler
from optuna.storages import RetryHeartbeatStaleTrialCallback

from src.configs.m2patch_profiles import CLI_ORDER, D_FF_CAP
from src.hpo.search_space import EFFECTIVE_PARAM_KEYS, HPO_DEFAULTS, PARAM_ORDER, SEARCH_SPACE_VERSION, get_fixed_params

TEMP_OPTUNA_DIR = "./temp/optuna"
OUTPUT_OPTUNA_DIR = "./output/optuna"
STORAGE_TEMPLATE = "sqlite:///./temp/optuna/{}.db"

HPO_CONFIG_ATTR = "hpo_config"

LEGACY_ENV_INFO_KEYS = ("optuna_version", "torch_version")
LEGACY_FIXED_PARAM_KEYS = ("mask_ratio", "train_mask_ratio", "mask_value")

PRUNER_MIN_RESOURCE = 4
PRUNER_REDUCTION_FACTOR = 3


def _pruner_spec(train_epochs: int) -> dict:
    return {
        "name": "HyperbandPruner",
        "min_resource": PRUNER_MIN_RESOURCE,
        "max_resource": train_epochs,
        "reduction_factor": PRUNER_REDUCTION_FACTOR,
    }


def _make_pruner(train_epochs: int) -> optuna.pruners.HyperbandPruner:
    spec = _pruner_spec(train_epochs)
    return optuna.pruners.HyperbandPruner(
        min_resource=spec["min_resource"],
        max_resource=spec["max_resource"],
        reduction_factor=spec["reduction_factor"],
    )


def _db_path(study_name: str) -> str:
    return os.path.join(TEMP_OPTUNA_DIR, f"{study_name}.db")


def study_db_exists(study_name: str) -> bool:
    return os.path.isfile(_db_path(study_name))


def _make_storage(study_name: str) -> optuna.storages.RDBStorage:
    return optuna.storages.RDBStorage(
        url=STORAGE_TEMPLATE.format(study_name),
        heartbeat_interval=60,
        grace_period=120,
        heartbeat_stale_trial_callback=RetryHeartbeatStaleTrialCallback(max_retry=1),
        engine_kwargs={"connect_args": {"timeout": 30}},
    )


def _build_hpo_config(
    metric: str,
    train_epochs: int,
    patience: int,
    batch_size: int,
    use_amp: bool,
    seed: int,
    search_space_spec: dict | None,
    fixed_params: dict | None = None,
) -> dict:
    config = {
        "metric": metric,
        "train_epochs": train_epochs,
        "patience": patience,
        "batch_size": batch_size,
        "use_amp": use_amp,
        "seed": seed,
        "fixed_params": {key: value for key, value in (fixed_params or {}).items() if key in EFFECTIVE_PARAM_KEYS},
        "d_ff_cap": D_FF_CAP,
        "pruner": _pruner_spec(train_epochs),
        "search_space_spec": search_space_spec,
        "search_space_version": SEARCH_SPACE_VERSION,
    }
    return json.loads(json.dumps(config, sort_keys=True, default=str))


def _hpo_config_mismatch_description(stored: dict, expected: dict) -> str:
    diffs = []
    for key in sorted(set(stored) | set(expected)):
        stored_val = stored.get(key, "<missing>")
        expected_val = expected.get(key, "<missing>")
        if stored_val != expected_val:
            diffs.append(f"{key}: study={stored_val!r} requested={expected_val!r}")
    return "; ".join(diffs)


def _apply_hpo_config(study: optuna.Study, expected: dict) -> None:
    stored = study.user_attrs.get(HPO_CONFIG_ATTR)
    if stored is None:
        study.set_user_attr(HPO_CONFIG_ATTR, expected)
        return
    stored = {key: value for key, value in stored.items() if key not in LEGACY_ENV_INFO_KEYS}
    if isinstance(stored.get("fixed_params"), dict):
        stored["fixed_params"] = {
            key: value for key, value in stored["fixed_params"].items() if key not in LEGACY_FIXED_PARAM_KEYS
        }
    if stored != expected:
        raise RuntimeError(
            f"Study '{study.study_name}' already exists with a different HPO configuration "
            f"(user attr '{HPO_CONFIG_ATTR}'); mixed resume is not allowed. "
            f"Mismatched fields: {_hpo_config_mismatch_description(stored, expected)}. "
            f"Move or delete {STORAGE_TEMPLATE.format(study.study_name)} to start a fresh study, "
            f"or recreate it with the configuration recorded in the study."
        )


def create_study(
    study_name: str,
    direction: str = "minimize",
    n_startup_trials: int = 15,
    metric: str = "mse",
    train_epochs: int | None = None,
    patience: int | None = None,
    batch_size: int | None = None,
    use_amp: bool | None = None,
    search_space_spec: dict | None = None,
    seed: int = 2023,
    fixed_params: dict | None = None,
) -> optuna.Study:
    os.makedirs(TEMP_OPTUNA_DIR, exist_ok=True)
    os.makedirs(OUTPUT_OPTUNA_DIR, exist_ok=True)

    supplied = fixed_params or {}
    dataset_name, pred_len = _parse_study_name(study_name)
    dataset_name = supplied.get("dataset", dataset_name)
    pred_len = supplied.get("pred_len", pred_len)
    profile_fixed = get_fixed_params(dataset_name, pred_len)
    effective_fixed = {key: value for key, value in HPO_DEFAULTS.items() if key not in PARAM_ORDER}
    effective_fixed.update(profile_fixed)
    effective_fixed.update(supplied)
    for key in ("dropout", "pct_start"):
        effective_fixed[key] = profile_fixed[key]
    if train_epochs is None:
        train_epochs = effective_fixed["train_epochs"]
    if patience is None:
        patience = effective_fixed["patience"]
    if batch_size is None:
        batch_size = effective_fixed["batch_size"]
    if use_amp is None:
        use_amp = effective_fixed["use_amp"]
    seed = supplied.get("seed", seed)
    effective_fixed.update(
        train_epochs=train_epochs,
        patience=patience,
        batch_size=batch_size,
        use_amp=bool(use_amp),
        seed=seed,
    )

    storage = _make_storage(study_name)

    try:
        existing = optuna.load_study(study_name=study_name, storage=storage)
    except KeyError:
        existing = None
    if existing is not None and HPO_CONFIG_ATTR not in existing.user_attrs:
        raise RuntimeError(
            f"Study '{study_name}' predates config fingerprinting (missing user attr "
            f"'{HPO_CONFIG_ATTR}'); resuming it would mix configurations. "
            f"Move or delete {STORAGE_TEMPLATE.format(study_name)} to start a fresh study."
        )

    expected_config = _build_hpo_config(
        metric=metric,
        train_epochs=train_epochs,
        patience=patience,
        batch_size=batch_size,
        use_amp=use_amp,
        seed=seed,
        search_space_spec=search_space_spec,
        fixed_params=effective_fixed,
    )

    sampler_seed = None if existing is not None and len(existing.trials) > 0 else seed
    sampler = TPESampler(
        multivariate=True,
        group=True,
        constant_liar=True,
        seed=sampler_seed,
        n_startup_trials=n_startup_trials,
    )
    print(
        "  Sampler seed: random (resuming existing study)"
        if sampler_seed is None
        else f"  Sampler seed: {sampler_seed} (new study)"
    )

    study = optuna.create_study(
        study_name=study_name,
        storage=storage,
        direction=direction,
        sampler=sampler,
        pruner=_make_pruner(train_epochs),
        load_if_exists=True,
    )
    _apply_hpo_config(study, expected_config)
    return study


def load_study(study_name: str) -> optuna.Study:
    storage = _make_storage(study_name)
    return optuna.load_study(study_name=study_name, storage=storage)


def get_best_params(study_name: str) -> dict:
    study = load_study(study_name)
    return study.best_params


_PARAMS_ORDER = ["e_layers", "batch_size", "seed"] + [
    key for key in CLI_ORDER if key not in ("e_layers", "batch_size")
]

_USER_ATTRS_ORDER = ["mse", "mae", "checkpoint", "arch_signature"]

_USER_ATTR_KEYS = ["batch_size", "seed"]

_PUBLIC_PARAM_KEYS = set(CLI_ORDER) | {"seed"}


def _ordered(src: dict, order: list) -> dict:
    result = {}
    for key in order:
        if key in src:
            result[key] = src[key]
    for key in src:
        if key not in result:
            result[key] = src[key]
    return result


def _parse_study_name(study_name: str) -> tuple[str, int]:
    dataset_name = ""
    pred_len = 0
    prefix = "M2Patch_"
    if study_name.startswith(prefix):
        rest = study_name[len(prefix) :]
        pl_idx = rest.rfind("_pl")
        if pl_idx > 0:
            dataset_name = rest[:pl_idx]
            try:
                pred_len = int(rest[pl_idx + 3 :])
            except ValueError:
                pass
    return dataset_name, pred_len


def _atomic_write_text(path: str, content: str) -> None:
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "w") as f:
        f.write(content)
    os.replace(tmp_path, path)


def export_results(study_name: str):
    import pandas as pd

    study = load_study(study_name)
    df = study.trials_dataframe()

    csv_dir = os.path.join(OUTPUT_OPTUNA_DIR, "csv")
    os.makedirs(csv_dir, exist_ok=True)
    csv_path = os.path.join(csv_dir, f"{study_name}_results.csv")
    csv_tmp = f"{csv_path}.tmp"
    df.to_csv(csv_tmp, index=False)
    os.replace(csv_tmp, csv_path)

    try:
        best_trial = study.best_trial
    except ValueError:
        print(f"No completed trials in study {study_name}, skipping best params export")
        return df

    user_attrs = dict(best_trial.user_attrs)

    snapshot = user_attrs.get("effective_params")
    if isinstance(snapshot, dict) and snapshot:
        best_params = dict(snapshot)
    else:
        stored_config = study.user_attrs.get(HPO_CONFIG_ATTR, {})
        stored_fixed = stored_config.get("fixed_params", {})
        best_params = dict(stored_fixed)
        for key in ("train_epochs", "patience", "batch_size", "use_amp", "seed"):
            if key in stored_config:
                best_params[key] = stored_config[key]
        best_params.update(best_trial.params)
        for key in _USER_ATTR_KEYS:
            if key in user_attrs:
                best_params[key] = user_attrs[key]
        d_ff_cap = stored_config.get("d_ff_cap", stored_fixed.get("d_ff_cap"))
        if "d_ff" not in best_params and "d_model" in best_params and d_ff_cap is not None:
            best_params["d_ff"] = min(best_params["d_model"] * 2, d_ff_cap)

    best_params = _ordered({key: value for key, value in best_params.items() if key in _PUBLIC_PARAM_KEYS}, _PARAMS_ORDER)
    ordered_attrs = _ordered(
        {key: value for key, value in user_attrs.items() if key in _USER_ATTRS_ORDER or key.startswith("cuda_accel")},
        _USER_ATTRS_ORDER,
    )

    best_path = os.path.join(OUTPUT_OPTUNA_DIR, f"{study_name}_best_params.json")

    best_data = {
        "study_name": study_name,
        "version": "v6",
        "best_value": study.best_value,
        "best_params": best_params,
        "best_trial_number": best_trial.number,
        "best_trial_user_attrs": ordered_attrs,
    }
    _atomic_write_text(best_path, json.dumps(best_data, indent=4, default=str))

    return df


def make_best_callback(study_name: str, metric: str = "mse"):
    def _callback(study, trial):
        try:
            if study.best_trial.number == trial.number:
                print(
                    f" ★ New best {metric.upper()}: {study.best_value:.6f} (trial #{trial.number}) — results exported"
                )
                export_results(study_name)
        except ValueError:
            pass

    return _callback
