import json
import os
import subprocess
import time
import fcntl

TEMP_OPTUNA_DIR = "./temp/optuna"
BUDGET_LOCK_FILE = os.path.join(TEMP_OPTUNA_DIR, "gpu_budget.lock")
BUDGET_JSON_FILE = os.path.join(TEMP_OPTUNA_DIR, "gpu_budget.json")
MULTI_BUDGET_FILE = os.path.join(TEMP_OPTUNA_DIR, "gpu_budget_multi.json")
PER_GPU_BUDGET_TEMPLATE = os.path.join(TEMP_OPTUNA_DIR, "gpu_budget_gpu{}.json")
PER_GPU_LOCK_TEMPLATE = os.path.join(TEMP_OPTUNA_DIR, "gpu_budget_gpu{}.lock")

_JSON_INDENT = 4


def _detect_gpu_memory_mb() -> int:
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return int(result.stdout.strip().split("\n")[0].strip())
    except Exception:
        pass
    return 24 * 1024


TOTAL_GPU_MEMORY_MB = _detect_gpu_memory_mb()


def _entry_mb(entry) -> float:
    if isinstance(entry, dict):
        return entry.get("mb", 0)
    return float(entry)


def _entry_pid(entry):
    if isinstance(entry, dict):
        return entry.get("pid")
    return None


def estimate_m2patch_memory_mb(
    enc_in: int,
    d_model: int,
    d_ff: int,
    seq_len: int,
    pred_len: int,
    batch_size: int,
    e_layers: int,
    patch_len: int = 16,
    stride: int = 8,
    d_hyp: int = 64,
    d_layers_diff: int = 2,
    diff_steps: int = 1,
) -> float:
    if seq_len < patch_len:
        left_pad = patch_len - seq_len
    else:
        remainder = (seq_len - patch_len) % stride
        left_pad = 0 if remainder == 0 else stride - remainder
    n_hist = (seq_len + left_pad - patch_len) // stride + 1
    n_future = int((pred_len + patch_len - 1) // patch_len)

    tokenizer_params = patch_len * d_model + n_hist * d_model
    history_params = e_layers * (4 * d_model * d_model + 2 * d_model * d_ff + 4 * d_model)
    prior_params = d_model + d_model * pred_len
    hist_hyp_params = d_model * d_hyp + d_hyp
    denoiser_block = 8 * d_model * d_model + 2 * d_model * d_ff + 9 * d_model * d_model + 6 * d_model
    denoiser_params = (
        patch_len * d_model
        + n_future * d_model
        + 9 * d_model * d_model
        + d_layers_diff * denoiser_block
        + 2 * d_model
        + 2 * d_model * patch_len
        + d_model * d_hyp
        + patch_len * d_hyp
    )
    total_params = (
        enc_in * 2
        + tokenizer_params
        + history_params
        + prior_params
        + hist_hyp_params
        + denoiser_params
    )

    bytes_per_param = 4
    param_mem = total_params * bytes_per_param / 1024 / 1024
    optimizer_mem = param_mem * 2
    grad_mem = param_mem

    per_sample = (
        n_hist * d_model * 3
        + n_future * d_model * 4
        + n_future * d_hyp * 2
        + pred_len * d_model
    )
    activation_mem = batch_size * enc_in * per_sample * bytes_per_param / 1024 / 1024
    activation_mem *= 1.0 + 0.1 * diff_steps
    cuda_overhead = 512

    total = (
        param_mem + optimizer_mem + grad_mem + activation_mem + cuda_overhead
    ) * 1.05
    return total


def estimate_cuda_accel_test_peak_mb(
    enc_in: int,
    pred_len: int,
    total_rows: int,
    seq_len: int = 96,
    test_ratio: float = 0.2,
) -> float:
    n_test = int(total_rows * test_ratio) - seq_len - pred_len + 1
    n_test = max(n_test, 0)
    if n_test == 0:
        return 0.0
    elem_bytes = 4
    per_elem = n_test * pred_len * enc_in
    preds_trues_bytes = 2 * per_elem * elem_bytes
    batch_overhead_bytes = 4 * per_elem * elem_bytes
    peak_bytes = preds_trues_bytes + batch_overhead_bytes
    return peak_bytes / (1024 * 1024)


def should_disable_cuda_accel(
    enc_in: int,
    pred_len: int = 96,
    total_rows: int = 0,
    seq_len: int = 96,
    available_mb: float | None = None,
) -> bool:
    if total_rows > 0 and available_mb is not None:
        overhead = estimate_cuda_accel_test_peak_mb(
            enc_in, pred_len, total_rows, seq_len
        )
        if overhead > available_mb:
            return True
    return False


class PerGPUBudget:
    def __init__(self, physical_gpu: int, total_mb: int | None = None):
        self.physical_gpu = int(physical_gpu)
        self.total_mb = total_mb or TOTAL_GPU_MEMORY_MB
        self._pid = os.getpid()
        self._path = PER_GPU_BUDGET_TEMPLATE.format(self.physical_gpu)
        self._lock_path = PER_GPU_LOCK_TEMPLATE.format(self.physical_gpu)
        os.makedirs(TEMP_OPTUNA_DIR, exist_ok=True)

    def _read(self) -> dict:
        try:
            with open(self._path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, ValueError, OSError):
            default = {"used_mb": 0.0, "trials": {}}
            self._write(default)
            return default

    def _write(self, data: dict):
        with open(self._path, "w") as f:
            json.dump(data, f, indent=_JSON_INDENT, ensure_ascii=False)

    def _cleanup_stale(self, budget: dict) -> dict:
        stale_keys = []
        for key, entry in budget["trials"].items():
            pid = _entry_pid(entry)
            if pid is not None:
                try:
                    os.kill(pid, 0)
                except (OSError, ProcessLookupError):
                    stale_keys.append(key)
            else:
                stale_keys.append(key)
        for key in stale_keys:
            del budget["trials"][key]
        budget["used_mb"] = sum(_entry_mb(e) for e in budget["trials"].values())
        return budget

    def acquire(self, key: str, needed_mb: float, timeout: int = 3600) -> bool:
        start = time.time()
        while time.time() - start < timeout:
            with open(self._lock_path, "w") as lock_f:
                fcntl.flock(lock_f, fcntl.LOCK_EX)
                try:
                    budget = self._read()
                    budget = self._cleanup_stale(budget)
                    available = self.total_mb - budget["used_mb"]
                    if needed_mb <= available:
                        budget["used_mb"] += needed_mb
                        budget["trials"][key] = {"pid": self._pid, "mb": needed_mb}
                        self._write(budget)
                        return True
                finally:
                    fcntl.flock(lock_f, fcntl.LOCK_UN)
            time.sleep(5)
        return False

    def release(self, key: str):
        with open(self._lock_path, "w") as lock_f:
            fcntl.flock(lock_f, fcntl.LOCK_EX)
            try:
                budget = self._read()
                if key in budget["trials"]:
                    mb = _entry_mb(budget["trials"][key])
                    budget["used_mb"] -= mb
                    del budget["trials"][key]
                    budget["used_mb"] = max(0.0, budget["used_mb"])
                    self._write(budget)
            finally:
                fcntl.flock(lock_f, fcntl.LOCK_UN)


def _migrate_gpu_state(gpu_state: dict) -> dict:
    if "reservations" in gpu_state and "reserved_by" not in gpu_state:
        return gpu_state
    reserved_mb = 0.0
    reservations = {}
    if gpu_state.get("reserved_by") is not None:
        reservations[gpu_state["reserved_by"]] = {
            "pid": gpu_state.get("reserve_pid"),
            "mb": float(gpu_state.get("used_mb", 0)),
        }
        reserved_mb = float(gpu_state.get("used_mb", 0))
    return {"reserved_mb": reserved_mb, "reservations": reservations}


class GPUBudget:
    def __init__(self, total_mb: int | None = None):
        self.total_mb = total_mb or TOTAL_GPU_MEMORY_MB
        self._pid = os.getpid()
        os.makedirs(TEMP_OPTUNA_DIR, exist_ok=True)
        if not os.path.exists(BUDGET_JSON_FILE):
            self._write_budget({"used_mb": 0, "trials": {}})

    def _read_budget(self) -> dict:
        try:
            with open(BUDGET_JSON_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, ValueError):
            default = {"used_mb": 0, "trials": {}}
            self._write_budget(default)
            return default

    def _write_budget(self, data: dict):
        with open(BUDGET_JSON_FILE, "w") as f:
            json.dump(data, f, indent=_JSON_INDENT, ensure_ascii=False)

    def _cleanup_stale(self, budget: dict) -> dict:
        stale_ids = []
        for tid, entry in budget["trials"].items():
            pid = _entry_pid(entry)
            if pid is not None:
                try:
                    os.kill(pid, 0)
                except (OSError, ProcessLookupError):
                    stale_ids.append(tid)
            else:
                stale_ids.append(tid)
        for tid in stale_ids:
            del budget["trials"][tid]
        used = sum(_entry_mb(e) for e in budget["trials"].values())
        budget["used_mb"] = used
        return budget

    def acquire(self, trial_id: str, needed_mb: float, timeout: int = 3600) -> bool:
        start = time.time()
        while time.time() - start < timeout:
            with open(BUDGET_LOCK_FILE, "w") as lock_f:
                fcntl.flock(lock_f, fcntl.LOCK_EX)
                try:
                    budget = self._read_budget()
                    budget = self._cleanup_stale(budget)
                    available = self.total_mb - budget["used_mb"]
                    if needed_mb <= available:
                        budget["used_mb"] += needed_mb
                        budget["trials"][trial_id] = {"pid": self._pid, "mb": needed_mb}
                        self._write_budget(budget)
                        return True
                finally:
                    fcntl.flock(lock_f, fcntl.LOCK_UN)
            time.sleep(5)
        return False

    def release(self, trial_id: str):
        with open(BUDGET_LOCK_FILE, "w") as lock_f:
            fcntl.flock(lock_f, fcntl.LOCK_EX)
            try:
                budget = self._read_budget()
                if trial_id in budget["trials"]:
                    mb = _entry_mb(budget["trials"][trial_id])
                    budget["used_mb"] -= mb
                    del budget["trials"][trial_id]
                    budget["used_mb"] = max(0.0, budget["used_mb"])
                    self._write_budget(budget)
            finally:
                fcntl.flock(lock_f, fcntl.LOCK_UN)

    def release_stale(self) -> int:
        with open(BUDGET_LOCK_FILE, "w") as lock_f:
            fcntl.flock(lock_f, fcntl.LOCK_EX)
            try:
                budget = self._read_budget()
                before = len(budget["trials"])
                budget = self._cleanup_stale(budget)
                removed = before - len(budget["trials"])
                self._write_budget(budget)
            finally:
                fcntl.flock(lock_f, fcntl.LOCK_UN)
        return removed

    def release_by_prefix(self, prefix: str) -> int:
        with open(BUDGET_LOCK_FILE, "w") as lock_f:
            fcntl.flock(lock_f, fcntl.LOCK_EX)
            try:
                budget = self._read_budget()
                removed = 0
                for tid in list(budget["trials"].keys()):
                    if tid.startswith(prefix):
                        mb = _entry_mb(budget["trials"][tid])
                        budget["used_mb"] -= mb
                        del budget["trials"][tid]
                        removed += 1
                budget["used_mb"] = max(0.0, budget["used_mb"])
                self._write_budget(budget)
            finally:
                fcntl.flock(lock_f, fcntl.LOCK_UN)
        return removed

    def get_available_mb(self) -> float:
        budget = self._read_budget()
        return self.total_mb - budget["used_mb"]


class MultiGPUBudget:
    def __init__(self, gpu_ids: list[int], total_mb: int = TOTAL_GPU_MEMORY_MB):
        self.gpu_ids = gpu_ids
        self.total_mb = total_mb
        self._pid = os.getpid()
        os.makedirs(TEMP_OPTUNA_DIR, exist_ok=True)
        default = {"gpus": {str(g): {"reserved_mb": 0.0, "reservations": {}} for g in gpu_ids}}
        if not os.path.exists(MULTI_BUDGET_FILE):
            self._write_budget(default)
        else:
            with open(BUDGET_LOCK_FILE, "w") as lock_f:
                fcntl.flock(lock_f, fcntl.LOCK_EX)
                try:
                    budget = self._read_budget()
                    for g in gpu_ids:
                        gk = str(g)
                        if gk not in budget["gpus"]:
                            budget["gpus"][gk] = {"reserved_mb": 0.0, "reservations": {}}
                        else:
                            budget["gpus"][gk] = _migrate_gpu_state(budget["gpus"][gk])
                    self._write_budget(budget)
                finally:
                    fcntl.flock(lock_f, fcntl.LOCK_UN)

    def _read_budget(self) -> dict:
        try:
            with open(MULTI_BUDGET_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, ValueError):
            default = {"gpus": {str(g): {"reserved_mb": 0.0, "reservations": {}} for g in self.gpu_ids}}
            self._write_budget(default)
            return default

    def _write_budget(self, data: dict):
        with open(MULTI_BUDGET_FILE, "w") as f:
            json.dump(data, f, indent=_JSON_INDENT, ensure_ascii=False)

    def _cleanup_stale(self, budget: dict) -> dict:
        for gpu_key, gpu_state in budget["gpus"].items():
            stale_tags = []
            for tag, entry in gpu_state.get("reservations", {}).items():
                pid = entry.get("pid") if isinstance(entry, dict) else None
                if pid is not None:
                    try:
                        os.kill(pid, 0)
                    except (OSError, ProcessLookupError):
                        stale_tags.append(tag)
            for tag in stale_tags:
                mb = gpu_state["reservations"][tag].get("mb", 0)
                gpu_state["reserved_mb"] = max(0.0, gpu_state.get("reserved_mb", 0) - mb)
                del gpu_state["reservations"][tag]
        return budget

    def reserve(self, study_tag: str, needed_mb: float, timeout: int = 7200) -> int | None:
        start = time.time()
        while time.time() - start < timeout:
            with open(BUDGET_LOCK_FILE, "w") as lock_f:
                fcntl.flock(lock_f, fcntl.LOCK_EX)
                try:
                    budget = self._read_budget()
                    budget = self._cleanup_stale(budget)
                    best_gpu = None
                    best_available = -1
                    for g in self.gpu_ids:
                        gpu_key = str(g)
                        gpu_state = budget["gpus"].get(gpu_key, {"reserved_mb": 0.0, "reservations": {}})
                        used = gpu_state.get("reserved_mb", 0.0)
                        available = self.total_mb - used
                        if available >= needed_mb and available > best_available:
                            best_gpu = g
                            best_available = available
                    if best_gpu is not None:
                        gpu_key = str(best_gpu)
                        if gpu_key not in budget["gpus"]:
                            budget["gpus"][gpu_key] = {"reserved_mb": 0.0, "reservations": {}}
                        budget["gpus"][gpu_key]["reserved_mb"] += needed_mb
                        budget["gpus"][gpu_key].setdefault("reservations", {})[study_tag] = {
                            "pid": self._pid, "mb": needed_mb
                        }
                        self._write_budget(budget)
                        return best_gpu
                finally:
                    fcntl.flock(lock_f, fcntl.LOCK_UN)
            time.sleep(2)
        return None

    def unreserve(self, study_tag: str):
        with open(BUDGET_LOCK_FILE, "w") as lock_f:
            fcntl.flock(lock_f, fcntl.LOCK_EX)
            try:
                budget = self._read_budget()
                for gpu_key, gpu_state in budget["gpus"].items():
                    reservations = gpu_state.get("reservations", {})
                    if study_tag in reservations:
                        mb = reservations[study_tag].get("mb", 0)
                        gpu_state["reserved_mb"] = max(0.0, gpu_state.get("reserved_mb", 0) - mb)
                        del reservations[study_tag]
                        break
                self._write_budget(budget)
            finally:
                fcntl.flock(lock_f, fcntl.LOCK_UN)

    def get_available_per_gpu(self) -> dict[int, float]:
        budget = self._read_budget()
        result = {}
        for g in self.gpu_ids:
            gpu_state = budget["gpus"].get(str(g), {"reserved_mb": 0.0})
            result[g] = self.total_mb - gpu_state.get("reserved_mb", 0.0)
        return result


def release_budget_by_pid(pid: int) -> float:
    if not os.path.exists(BUDGET_JSON_FILE):
        return 0.0
    with open(BUDGET_LOCK_FILE, "w") as lock_f:
        fcntl.flock(lock_f, fcntl.LOCK_EX)
        try:
            with open(BUDGET_JSON_FILE, "r") as f:
                budget = json.load(f)
            trials = budget.get("trials", {})
            to_remove = [
                tid
                for tid, entry in trials.items()
                if isinstance(entry, dict) and entry.get("pid") == pid
            ]
            if not to_remove:
                return 0.0
            freed = sum(_entry_mb(trials[tid]) for tid in to_remove)
            for tid in to_remove:
                del trials[tid]
            budget["used_mb"] = max(0.0, budget.get("used_mb", 0) - freed)
            budget["trials"] = trials
            with open(BUDGET_JSON_FILE, "w") as f:
                json.dump(budget, f, indent=_JSON_INDENT, ensure_ascii=False)
            return freed
        finally:
            fcntl.flock(lock_f, fcntl.LOCK_UN)


def release_multi_budget_by_pid(pid: int) -> float:
    if not os.path.exists(MULTI_BUDGET_FILE):
        return 0.0
    with open(BUDGET_LOCK_FILE, "w") as lock_f:
        fcntl.flock(lock_f, fcntl.LOCK_EX)
        try:
            with open(MULTI_BUDGET_FILE, "r") as f:
                budget = json.load(f)
            total_freed = 0.0
            for gpu_key, gpu_state in budget.get("gpus", {}).items():
                reservations = gpu_state.get("reservations", {})
                to_remove = [
                    tag
                    for tag, entry in reservations.items()
                    if isinstance(entry, dict) and entry.get("pid") == pid
                ]
                if not to_remove:
                    continue
                freed = sum(reservations[tag].get("mb", 0) for tag in to_remove)
                for tag in to_remove:
                    del reservations[tag]
                gpu_state["reserved_mb"] = max(0.0, gpu_state.get("reserved_mb", 0) - freed)
                total_freed += freed
            if total_freed > 0:
                with open(MULTI_BUDGET_FILE, "w") as f:
                    json.dump(budget, f, indent=_JSON_INDENT, ensure_ascii=False)
            return total_freed
        finally:
            fcntl.flock(lock_f, fcntl.LOCK_UN)


def release_study_reservation(study_tag: str) -> float:
    if not os.path.exists(MULTI_BUDGET_FILE):
        return 0.0
    with open(BUDGET_LOCK_FILE, "w") as lock_f:
        fcntl.flock(lock_f, fcntl.LOCK_EX)
        try:
            with open(MULTI_BUDGET_FILE, "r") as f:
                budget = json.load(f)
            for gid_str, gpu in budget["gpus"].items():
                if study_tag in gpu.get("reservations", {}):
                    freed = gpu["reservations"][study_tag].get("mb", 0)
                    gpu["reserved_mb"] = max(0.0, gpu.get("reserved_mb", 0) - freed)
                    del gpu["reservations"][study_tag]
                    with open(MULTI_BUDGET_FILE, "w") as f:
                        json.dump(budget, f, indent=_JSON_INDENT, ensure_ascii=False)
                    return freed
            return 0.0
        finally:
            fcntl.flock(lock_f, fcntl.LOCK_UN)
