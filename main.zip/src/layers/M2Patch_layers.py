import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.ablation.registry import MODEL_ABLATION_FLAGS

REVIN_STD_FLOOR_RATIO = 0.2
TARGET_CLIP = 10.0
HYP_MAX_TANGENT = 2.0
LAMBDA_RAW = 1.0


class RevIN(nn.Module):
    """History-only RevIN with cached statistics for strict target normalization.

    forward(x, "stats") caches mean/stdev without normalizing the history.
    """

    def __init__(self, num_features: int, eps: float = 1e-5, affine: bool = False, subtract_last: bool = False):
        super().__init__()
        self.num_features = num_features
        self.eps = eps
        self.affine = affine
        self.subtract_last = subtract_last
        self.std_floor_ratio = REVIN_STD_FLOOR_RATIO
        self.target_clip = TARGET_CLIP
        self.mean = None
        self.stdev = None
        self.last = None
        if affine:
            self.affine_weight = nn.Parameter(torch.ones(num_features))
            self.affine_bias = nn.Parameter(torch.zeros(num_features))

    def forward(self, x, mode: str):
        if mode in ("norm", "stats"):
            self._get_statistics(x)
            if mode == "stats":
                return x
            return self._normalize(x)
        if mode == "denorm":
            return self._denormalize(x)
        raise NotImplementedError

    def _get_statistics(self, x):
        reduce_dims = tuple(range(1, x.ndim - 1))
        if self.subtract_last:
            self.last = x[:, -1:, :].detach()
            self.mean = torch.zeros_like(x[:, :1, :]).detach()
        else:
            self.mean = x.mean(dim=reduce_dims, keepdim=True).detach()
        raw_std = torch.sqrt(x.var(dim=reduce_dims, keepdim=True, unbiased=False) + self.eps)
        if self.num_features > 1:
            median_std = raw_std.median(dim=-1, keepdim=True).values
            floor = (self.std_floor_ratio * median_std).clamp_min(self.eps)
            raw_std = torch.maximum(raw_std, floor)
        self.stdev = raw_std.detach()

    def _affine_forward(self, x):
        if self.affine:
            x = x * self.affine_weight + self.affine_bias
        return x

    def _affine_inverse(self, x):
        if self.affine:
            weight = torch.where(self.affine_weight.abs() >= self.eps, self.affine_weight, torch.full_like(self.affine_weight, self.eps))
            x = (x - self.affine_bias) / weight
        return x

    def _normalize(self, x):
        if self.subtract_last:
            x = x - self.last
        else:
            x = x - self.mean
        x = x / self.stdev
        x = torch.clamp(x, -self.target_clip, self.target_clip)
        return self._affine_forward(x)

    def normalize_target(self, y):
        if self.mean is None or self.stdev is None:
            raise RuntimeError("RevIN statistics are not initialized; call forward(x, \"stats\") first")
        if self.subtract_last:
            y = y - self.last
        else:
            y = y - self.mean
        y = y / self.stdev
        y = torch.clamp(y, -self.target_clip, self.target_clip)
        return self._affine_forward(y)

    def _denormalize(self, x):
        x = self._affine_inverse(x)
        x = x * self.stdev
        if self.subtract_last:
            x = x + self.last
        else:
            x = x + self.mean
        return x

    def denormalize(self, x):
        return self._denormalize(x)


class PoincareBallManifold(nn.Module):
    """Constant negative curvature -c Poincare ball evaluated in FP32."""

    def __init__(self, c: float = 1.0, eps: float = 1e-5):
        super().__init__()
        if c <= 0:
            raise ValueError("manifold curvature parameter c must be positive")
        self.c = float(c)
        self.eps = float(eps)

    def _to_fp32(self, z):
        return z.float() if z.dtype != torch.float32 else z

    def project(self, z, eps=None):
        z32 = self._to_fp32(z)
        eps = self.eps if eps is None else eps
        max_norm = (1.0 - eps) / math.sqrt(self.c)
        norm = z32.norm(dim=-1, keepdim=True)
        scale = torch.clamp(max_norm / norm.clamp_min(eps), max=1.0)
        return z32 * scale

    def exp_map0(self, v):
        v32 = self._to_fp32(v)
        sqrt_c = math.sqrt(self.c)
        norm = v32.norm(dim=-1, keepdim=True)
        factor = torch.tanh(sqrt_c * norm) / (sqrt_c * norm.clamp_min(self.eps))
        return self.project(factor * v32)

    def log_map0(self, z):
        z32 = self.project(z)
        sqrt_c = math.sqrt(self.c)
        norm = z32.norm(dim=-1, keepdim=True)
        ratio = torch.clamp(sqrt_c * norm, max=1.0 - self.eps)
        factor = torch.atanh(ratio) / (sqrt_c * norm.clamp_min(self.eps))
        return factor * z32

    def mobius_add(self, x, y):
        x32 = self._to_fp32(x)
        y32 = self._to_fp32(y)
        c = self.c
        x2 = (x32 * x32).sum(dim=-1, keepdim=True)
        y2 = (y32 * y32).sum(dim=-1, keepdim=True)
        xy = (x32 * y32).sum(dim=-1, keepdim=True)
        num = (1.0 + 2.0 * c * xy + c * y2) * x32 + (1.0 - c * x2) * y32
        den = 1.0 + 2.0 * c * xy + c * c * x2 * y2
        return self.project(num / den.clamp_min(self.eps))

    def log_map(self, base, z):
        return self.log_map0(self.mobius_add(-base, z))

    def geodesic_dist(self, x, y, keepdim: bool = False):
        x32 = self._to_fp32(x)
        y32 = self._to_fp32(y)
        c = self.c
        diff2 = ((x32 - y32) ** 2).sum(dim=-1, keepdim=True)
        x2 = (x32 * x32).sum(dim=-1, keepdim=True)
        y2 = (y32 * y32).sum(dim=-1, keepdim=True)
        denom = ((1.0 - c * x2) * (1.0 - c * y2)).clamp_min(self.eps)
        arg = 1.0 + 2.0 * c * diff2 / denom
        dist = (1.0 / math.sqrt(c)) * torch.acosh(arg.clamp_min(1.0 + 1e-7))
        dist = torch.where(diff2 <= 1e-12, torch.zeros_like(dist), dist)
        if keepdim:
            return dist
        return dist.squeeze(-1)


class EuclideanManifold(nn.Module):
    """Euclidean identity chart backing the euclid_manifold ablation."""

    def __init__(self, eps: float = 1e-5):
        super().__init__()
        self.eps = float(eps)

    def project(self, z, eps=None):
        return z

    def exp_map0(self, v):
        return v

    def log_map0(self, z):
        return z

    def mobius_add(self, x, y):
        return x + y

    def log_map(self, base, z):
        return z - base

    def geodesic_dist(self, x, y, keepdim: bool = False):
        dist = (x - y).pow(2).sum(dim=-1).clamp_min(0.0).sqrt()
        if keepdim:
            return dist.unsqueeze(-1)
        return dist


def resolve_ablation_flags(configs):
    name = str(getattr(configs, "ablation", "none"))
    if name not in MODEL_ABLATION_FLAGS:
        raise ValueError(f"ablation must be one of {MODEL_ABLATION_FLAGS}, got {name!r}")
    use_hyp_manifold = getattr(configs, "use_hyp_manifold", 1) == 1 and name != "euclid_manifold"
    use_prior_bridge = getattr(configs, "use_prior_bridge", 1) == 1 and name != "zero_prior_bridge"
    use_hyp_cond = getattr(configs, "use_hyp_cond", 1) == 1 and name != "no_hyp_cond"
    return use_hyp_manifold, use_prior_bridge, use_hyp_cond


def _bounded_exp_map0(manifold, tangent, max_norm: float = HYP_MAX_TANGENT):
    tangent32 = tangent.float()
    norm = tangent32.norm(dim=-1, keepdim=True).clamp_min(manifold.eps)
    scale = torch.clamp(norm, max=max_norm) / norm
    return manifold.exp_map0(tangent32 * scale)


def _left_pad_len(seq_len, patch_len, stride):
    if seq_len <= 0 or patch_len <= 0 or stride <= 0:
        raise ValueError("seq_len, patch_len and stride must be positive")
    if seq_len < patch_len:
        return patch_len - seq_len
    remainder = (seq_len - patch_len) % stride
    return 0 if remainder == 0 else stride - remainder


def _num_patches(seq_len, patch_len, stride):
    effective_len = seq_len + _left_pad_len(seq_len, patch_len, stride)
    return (effective_len - patch_len) // stride + 1


def _compute_patch_boundaries(seq_len, patch_len, stride):
    left_pad = _left_pad_len(seq_len, patch_len, stride)
    n_patches = _num_patches(seq_len, patch_len, stride)
    boundaries = []
    for i in range(n_patches):
        start = i * stride - left_pad
        end = start + patch_len
        left = max(0, start)
        right = min(seq_len, end)
        if right <= left:
            right = min(seq_len, max(left + 1, patch_len - left_pad))
        boundaries.append([left, right])
    return boundaries


class CausalPatchTokenizer(nn.Module):
    """Single-scale causal patch tokenizer with strictly causal prefix normalization."""

    def __init__(
        self,
        patch_len: int,
        stride: int,
        d_model: int,
        seq_len: int,
        dropout: float = 0.1,
        causal_norm: bool = True,
        norm_eps: float = 1e-5,
        norm_prior: float = 1.0,
    ):
        super().__init__()
        self.patch_len = patch_len
        self.stride = stride
        self.embed = nn.Linear(patch_len, d_model)
        self.num_patches = _num_patches(seq_len, patch_len, stride)
        self.pos_embed = nn.Parameter(torch.zeros(1, self.num_patches, d_model))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        self.dropout = nn.Dropout(dropout)
        self.causal_norm = causal_norm
        self.norm_eps = norm_eps
        self.norm_prior = norm_prior
        left_pad = _left_pad_len(seq_len, patch_len, stride)
        ends = [
            max(1, min(seq_len, i * stride - left_pad + patch_len))
            for i in range(self.num_patches)
        ]
        self.register_buffer("prefix_ends", torch.tensor(ends, dtype=torch.long), persistent=False)

    def _causal_normalize(self, x, patches):
        ends = self.prefix_ends
        counts = ends.float()
        x32 = x.float()
        cumsum = x32.cumsum(dim=-1)
        cumsum2 = (x32 * x32).cumsum(dim=-1)
        mean = cumsum.index_select(-1, ends - 1) / counts
        var = (cumsum2.index_select(-1, ends - 1) / counts - mean.pow(2)).clamp_min(0.0)
        shrink = counts / (counts + self.norm_prior)
        mean = (mean * shrink).detach()
        var = (var * shrink + (1.0 - shrink)).detach()
        std = torch.sqrt(var + self.norm_eps)
        normalized = (patches.float() - mean.unsqueeze(-1)) / std.unsqueeze(-1)
        return normalized.to(x.dtype)

    def forward(self, x):
        seq_len = x.shape[-1]
        left_pad = _left_pad_len(seq_len, self.patch_len, self.stride)
        x_padded = x
        if left_pad > 0:
            left = x[..., :1].expand(*x.shape[:-1], left_pad)
            x_padded = torch.cat([left, x], dim=-1)
        patches = x_padded.unfold(-1, self.patch_len, self.stride).contiguous()
        if self.causal_norm:
            patches = self._causal_normalize(x, patches)
        emb = self.embed(patches) + self.pos_embed[:, : patches.shape[1]]
        return self.dropout(emb)


def _causal_additive_mask(num_tokens, device, dtype):
    upper = torch.triu(torch.ones(num_tokens, num_tokens, device=device, dtype=torch.bool), diagonal=1)
    mask = torch.zeros(num_tokens, num_tokens, device=device, dtype=dtype)
    return mask.masked_fill(upper, float("-inf"))


class CausalSelfAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1):
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError("d_model must be divisible by n_heads")
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model)
        self.out = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, attn_mask):
        batch, num_tokens, _ = x.shape
        qkv = self.qkv(x).view(batch, num_tokens, 3, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        query, key, value = qkv[0], qkv[1], qkv[2]
        scores = (query @ key.transpose(-2, -1)) / math.sqrt(self.head_dim)
        scores = scores + attn_mask
        attn = self.dropout(scores.softmax(dim=-1))
        out = (attn @ value).transpose(1, 2).reshape(batch, num_tokens, self.n_heads * self.head_dim)
        return self.out(out)


class CausalEncoderBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attn = CausalSelfAttention(d_model, n_heads, dropout)
        self.norm2 = nn.LayerNorm(d_model)
        self.ff = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, attn_mask):
        x = x + self.dropout(self.attn(self.norm1(x), attn_mask))
        x = x + self.dropout(self.ff(self.norm2(x)))
        return x


class CausalHistoryEncoder(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, n_layers: int, dropout: float = 0.1):
        super().__init__()
        self.layers = nn.ModuleList(
            [CausalEncoderBlock(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)]
        )
        self.norm = nn.LayerNorm(d_model)

    def forward(self, x):
        attn_mask = _causal_additive_mask(x.shape[1], x.device, x.dtype)
        for layer in self.layers:
            x = layer(x, attn_mask)
        return self.norm(x)


class SinusoidalTimeEmbedding(nn.Module):
    def __init__(self, d_model: int, max_period: float = 10000.0):
        super().__init__()
        self.d_model = d_model
        half = max(d_model // 2, 1)
        freqs = torch.exp(-math.log(max_period) * torch.arange(half, dtype=torch.float32) / half)
        self.register_buffer("freqs", freqs, persistent=False)

    def forward(self, t):
        args = t.float()[:, None] * self.freqs[None, :]
        emb = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        if self.d_model % 2 == 1:
            emb = F.pad(emb, (0, 1))
        return emb


class AdaLNZero(nn.Module):
    def __init__(self, d_model: int, n_chunks: int = 9):
        super().__init__()
        self.n_chunks = n_chunks
        self.mlp = nn.Sequential(nn.SiLU(), nn.Linear(d_model, n_chunks * d_model))
        nn.init.zeros_(self.mlp[1].weight)
        nn.init.zeros_(self.mlp[1].bias)

    def forward(self, cond):
        return self.mlp(cond).chunk(self.n_chunks, dim=-1)


class FutureDenoiserBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float = 0.1, use_adaln: bool = True):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.self_attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(d_model)
        self.cross_attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.norm3 = nn.LayerNorm(d_model)
        self.ff = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
        )
        self.ada = AdaLNZero(d_model, 9)
        self.use_adaln = use_adaln
        self.dropout = nn.Dropout(dropout)

    def _modulation(self, cond):
        if self.use_adaln:
            return self.ada(cond)
        shift = torch.zeros_like(cond)
        scale = torch.zeros_like(cond)
        gate = torch.ones_like(cond)
        return (shift, scale, gate, shift, scale, gate, shift, scale, gate)

    def forward(self, x, cond, history):
        shift1, scale1, gate1, shift2, scale2, gate2, shift3, scale3, gate3 = self._modulation(cond)
        h = self.norm1(x) * (1.0 + scale1[:, None, :]) + shift1[:, None, :]
        x = x + gate1[:, None, :] * self.dropout(self.self_attn(h, h, h, need_weights=False)[0])
        h = self.norm2(x) * (1.0 + scale2[:, None, :]) + shift2[:, None, :]
        x = x + gate2[:, None, :] * self.dropout(self.cross_attn(h, history, history, need_weights=False)[0])
        h = self.norm3(x) * (1.0 + scale3[:, None, :]) + shift3[:, None, :]
        x = x + gate3[:, None, :] * self.dropout(self.ff(h))
        return x


class HyperbolicConditionedPatchDenoiser(nn.Module):
    """Time-conditioned AdaLN-Zero denoiser with causal history cross-attention."""

    def __init__(
        self,
        patch_len: int,
        num_patches: int,
        d_model: int,
        n_heads: int,
        d_ff: int,
        n_layers: int,
        d_hyp: int,
        manifold,
        dropout: float = 0.1,
        hyp_max_tangent: float = HYP_MAX_TANGENT,
        use_adaln: bool = True,
    ):
        super().__init__()
        self.patch_len = patch_len
        self.num_patches = num_patches
        self.patch_embed = nn.Linear(patch_len, d_model)
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, d_model))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        self.time_embed = SinusoidalTimeEmbedding(d_model)
        self.time_mlp = nn.Sequential(
            nn.Linear(d_model, 4 * d_model),
            nn.SiLU(),
            nn.Linear(4 * d_model, d_model),
        )
        self.context_proj = nn.Linear(d_model, d_model)
        self.blocks = nn.ModuleList(
            [FutureDenoiserBlock(d_model, n_heads, d_ff, dropout, use_adaln=use_adaln) for _ in range(n_layers)]
        )
        self.norm_out = nn.LayerNorm(d_model)
        self.head_x0 = nn.Linear(d_model, patch_len)
        nn.init.normal_(self.head_x0.weight, std=0.02)
        nn.init.zeros_(self.head_x0.bias)
        self.head_eps = nn.Linear(d_model, patch_len)
        nn.init.zeros_(self.head_eps.weight)
        nn.init.zeros_(self.head_eps.bias)
        self.head_hyp = nn.Linear(d_model, d_hyp)
        self.manifold = manifold
        self.hyp_scale = 1.0 / math.sqrt(d_hyp)
        self.hyp_max_tangent = float(hyp_max_tangent)

    def forward(self, p_t, t, history, cond, prior_patches, hyp_cond=None):
        x = self.patch_embed(p_t) + self.pos_embed[:, : p_t.shape[1]]
        cond_emb = self.time_mlp(self.time_embed(t)) + self.context_proj(cond)
        if hyp_cond is not None:
            cond_emb = cond_emb + hyp_cond
        for block in self.blocks:
            x = block(x, cond_emb, history)
        x = self.norm_out(x)
        pred_p0 = prior_patches + self.head_x0(x)
        pred_eps = self.head_eps(x)
        z_fut_hyp = _bounded_exp_map0(self.manifold, self.head_hyp(x) * self.hyp_scale, self.hyp_max_tangent)
        return pred_p0, pred_eps, z_fut_hyp


class BridgeVPSDE(nn.Module):
    """VP-SDE with a non-zero limit mean (LatticeVPSDE-style prior bridge)."""

    def __init__(self, schedule: str = "cosine", beta_min: float = 0.1, beta_max: float = 20.0, min_t: float = 1e-3):
        super().__init__()
        if schedule not in ("cosine", "linear"):
            raise ValueError("diff_schedule must be one of: cosine, linear")
        self.schedule = schedule
        self.beta_min = beta_min
        self.beta_max = beta_max
        self.min_t = min_t

    def coefficients(self, t):
        t = t.float()
        if t.dim() == 0:
            t = t.view(1, 1, 1)
        elif t.dim() == 1:
            t = t[:, None, None]
        if self.schedule == "cosine":
            s = 0.008
            alpha = torch.cos((t + s) / (1.0 + s) * math.pi * 0.5) / math.cos(s / (1.0 + s) * math.pi * 0.5)
        else:
            log_alpha = -0.25 * t.pow(2) * (self.beta_max - self.beta_min) - 0.5 * t * self.beta_min
            alpha = torch.exp(log_alpha)
        alpha = alpha.clamp(min=1e-6, max=1.0)
        sigma = (1.0 - alpha.pow(2)).clamp_min(0.0).sqrt()
        return alpha, sigma

    def sample_timesteps(self, n, device, dtype=torch.float32):
        return torch.rand(n, device=device, dtype=dtype) * (1.0 - self.min_t) + self.min_t


def bridge_ddim_step(p_t, pred_p0, pred_eps, prior, alpha_t, sigma_t, alpha_prev, sigma_prev, eta: float = 0.0):
    mean = alpha_prev * pred_p0 + (1.0 - alpha_prev) * prior + sigma_prev * pred_eps
    if eta > 0:
        ratio = (alpha_t.pow(2) / alpha_prev.pow(2).clamp_min(1e-6)).clamp(max=1.0)
        var = eta * eta * (1.0 - alpha_prev.pow(2)) / (1.0 - alpha_t.pow(2)).clamp_min(1e-6) * (1.0 - ratio)
        mean = mean + var.clamp_min(0.0).sqrt() * torch.randn_like(p_t)
    return mean


def _split_future_patches(y, patch_len):
    batch, length, channels = y.shape
    num_patches = int(math.ceil(length / patch_len))
    total = num_patches * patch_len
    if total > length:
        pad = total - length
        tail = y.new_zeros(batch, pad, channels)
        y = torch.cat([y, tail], dim=1)
    return y.permute(0, 2, 1).reshape(batch, channels, num_patches, patch_len)


def _future_valid_mask(pred_len, num_patches, patch_len, batch_channels, device, dtype):
    positions = torch.arange(num_patches * patch_len, device=device)
    mask = (positions < pred_len).view(1, num_patches, patch_len)
    return mask.expand(batch_channels, -1, -1).to(dtype)


def _huber(x, delta: float = 1.0):
    abs_x = x.abs()
    return torch.where(abs_x <= delta, 0.5 * x.square(), delta * (abs_x - 0.5 * delta))


def compute_m2patch_diffusion_loss(
    pred_series,
    target_series,
    aux,
    lambda_hyp: float = 0.1,
    lambda_prior: float = 0.1,
    lambda_raw: float = LAMBDA_RAW,
):
    """Bridge denoising score matching + hyperbolic alignment + prior anchor."""
    required = (
        "target_patches",
        "pred_patches",
        "pred_noise",
        "noisy_patches",
        "prior_patches",
        "alpha",
        "sigma",
        "z_hist_hyp",
        "z_fut_hyp",
        "z_target_hyp",
        "y_prior",
        "y_target",
        "manifold",
        "valid_mask",
        "patch_mask",
    )
    if aux is None:
        raise ValueError("compute_m2patch_diffusion_loss requires an aux dictionary")
    missing = [key for key in required if aux.get(key) is None]
    if missing:
        raise ValueError(f"compute_m2patch_diffusion_loss missing required aux keys: {missing}")

    target = aux["target_patches"].float()
    pred = aux["pred_patches"].float()
    noisy = aux["noisy_patches"].float()
    prior = aux["prior_patches"].float().detach()
    alpha = aux["alpha"].float()
    sigma = aux["sigma"].float().clamp_min(1e-6)
    valid = aux["valid_mask"].float()
    patch_valid = aux["patch_mask"].float()
    manifold = aux["manifold"]

    eps_true = (noisy - alpha * target - (1.0 - alpha) * prior) / sigma
    snr = alpha.pow(2) / sigma.pow(2)
    weights = (snr / (1.0 + snr)).reshape(-1)
    valid_count_i = valid.sum(dim=(1, 2)).clamp_min(1.0)
    x0_err = _huber(pred - target)
    x0_i = (x0_err * valid).sum(dim=(1, 2)) / valid_count_i
    x0_scale = (target.square() * valid).sum(dim=(1, 2)) / valid_count_i
    loss_x0 = (weights * x0_i / (x0_scale + 1.0)).mean()
    noise_err = _huber(aux["pred_noise"].float() - eps_true)
    noise_i = (noise_err * valid).sum(dim=(1, 2)) / valid_count_i
    noise_scale = (eps_true.square() * valid).sum(dim=(1, 2)) / valid_count_i
    loss_noise = (noise_i / (noise_scale + 1.0)).mean()

    z_fut = aux["z_fut_hyp"].float()
    z_target = aux["z_target_hyp"].float()
    z_hist = aux["z_hist_hyp"].float()
    patch_count = patch_valid.sum().clamp_min(1.0)
    geo = manifold.geodesic_dist(z_fut, z_target)
    geo_bounded = geo.pow(2) / (1.0 + geo.pow(2))
    loss_geo = (geo_bounded * patch_valid).sum() / patch_count
    z_last = z_hist[:, -1:, :]
    tangent_fut = manifold.log_map(z_last, z_fut[:, :1, :])
    tangent_target = manifold.log_map(z_last, z_target[:, :1, :])
    trans_dist = (tangent_fut - tangent_target).pow(2).sum(dim=-1).reshape(-1)
    trans_valid = patch_valid[:, 0]
    trans_bounded = trans_dist / (1.0 + trans_dist)
    loss_trans = (trans_bounded * trans_valid).sum() / trans_valid.sum().clamp_min(1.0)
    inv_fut = manifold.mobius_add(-z_last, z_fut[:, :1, :])
    inv_target = manifold.mobius_add(-z_last, z_target[:, :1, :])
    trans_invariant = manifold.geodesic_dist(inv_fut, inv_target).pow(2).mean()
    loss_hyp = loss_geo + loss_trans

    y_prior = aux["y_prior"].float()
    y_target = aux["y_target"].float()
    prior_i = _huber(y_prior - y_target).mean(dim=(1, 2))
    prior_scale = y_target.square().mean(dim=(1, 2)) + 1.0
    loss_prior = (prior_i / prior_scale).mean()
    pred_series_f = pred_series.float()
    target_series_f = target_series.float()
    raw_i = _huber(pred_series_f - target_series_f).mean(dim=(1, 2))
    raw_scale = target_series_f.square().mean(dim=(1, 2)) + 1.0
    loss_raw = (raw_i / raw_scale).mean()
    raw_mse = (pred_series_f - target_series_f).pow(2).mean()
    raw_weighted = lambda_raw * loss_raw
    loss_bridge = loss_x0 + loss_noise
    loss_total = loss_bridge + raw_weighted + lambda_hyp * loss_hyp + lambda_prior * loss_prior
    parts = {
        "total": loss_total,
        "bridge": loss_bridge,
        "bridge_dsm": loss_bridge + raw_weighted,
        "x0": loss_x0,
        "noise": loss_noise,
        "raw": raw_weighted,
        "raw_unweighted": loss_raw,
        "raw_mse": raw_mse,
        "series_mse": raw_weighted,
        "hyp": loss_hyp,
        "hyp_geo": loss_geo,
        "hyp_trans": loss_trans,
        "hyp_trans_invariant": trans_invariant,
        "prior": loss_prior,
    }
    loss_dict = {key: value.detach() for key, value in parts.items()}
    return loss_total, loss_dict


class M2Patch_backbone(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.enc_in = configs.enc_in
        d_model = configs.d_model
        d_ff = configs.d_ff
        n_layers = configs.e_layers
        dropout = configs.dropout
        n_heads = getattr(configs, "n_heads", 8)
        while d_model % n_heads != 0 and n_heads > 1:
            n_heads //= 2

        self.patch_len = getattr(configs, "patch_len", 16)
        self.stride = getattr(configs, "stride", 8)
        self.d_hyp = getattr(configs, "d_hyp", 64)
        if self.patch_len <= 0 or self.stride <= 0 or self.d_hyp <= 0:
            raise ValueError("patch_len, stride and d_hyp must be positive")
        n_diff_layers = max(1, int(getattr(configs, "d_layers_diff", 2)))
        self.use_revin = getattr(configs, "revin", 1) == 1
        self.use_hyp_manifold, self.use_prior_bridge, self.use_hyp_cond = resolve_ablation_flags(configs)
        self.use_adaln = getattr(configs, "use_adaln", 1) == 1
        self.use_denoiser = getattr(configs, "use_denoiser", 1) == 1
        self.use_causal_norm = getattr(configs, "use_causal_norm", 1) == 1
        if self.use_hyp_manifold:
            self.manifold = PoincareBallManifold(c=getattr(configs, "manifold_c", 1.0))
        else:
            self.manifold = EuclideanManifold()
        self.revin = None
        if self.use_revin:
            self.revin = RevIN(configs.enc_in, affine=getattr(configs, "affine", 0) == 1)

        self.tokenizer = CausalPatchTokenizer(
            self.patch_len,
            self.stride,
            d_model,
            self.seq_len,
            dropout,
            causal_norm=self.use_revin and self.use_causal_norm,
        )
        self.history_encoder = CausalHistoryEncoder(d_model, n_heads, d_ff, n_layers, dropout)
        self.hist_hyp_proj = nn.Linear(d_model, self.d_hyp)
        self.prior_base = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, 2 * d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(2 * d_model, self.pred_len),
        )
        self.num_future_patches = int(math.ceil(self.pred_len / self.patch_len))
        self.hyp_max_tangent = HYP_MAX_TANGENT
        self.future_valid_lens = tuple(
            min(self.patch_len, self.pred_len - i * self.patch_len)
            for i in range(self.num_future_patches)
        )
        self.denoiser = HyperbolicConditionedPatchDenoiser(
            self.patch_len,
            self.num_future_patches,
            d_model,
            n_heads,
            d_ff,
            n_diff_layers,
            self.d_hyp,
            self.manifold,
            dropout,
            self.hyp_max_tangent,
            use_adaln=self.use_adaln,
        )
        self.target_patch_proj = nn.Linear(self.patch_len, self.d_hyp)
        with torch.no_grad():
            t = torch.arange(self.patch_len, dtype=torch.float32) + 0.5
            rows = []
            for k in range(self.d_hyp):
                freq = (k % self.patch_len) + 1
                phase = (k // self.patch_len) * (math.pi / 4.0)
                rows.append(torch.cos(math.pi * freq * t / self.patch_len + phase))
            basis = torch.stack(rows, dim=0)
            if self.d_hyp >= self.patch_len:
                orthonormal, _ = torch.linalg.qr(basis)
            else:
                orthonormal, _ = torch.linalg.qr(basis.t())
                orthonormal = orthonormal.t()
            self.target_patch_proj.weight.copy_(orthonormal)
            self.target_patch_proj.bias.zero_()
        self.target_hyp_mlp = nn.Sequential(nn.GELU(), nn.Linear(self.d_hyp, self.d_hyp))
        nn.init.eye_(self.target_hyp_mlp[1].weight)
        nn.init.zeros_(self.target_hyp_mlp[1].bias)
        for param in self.target_patch_proj.parameters():
            param.requires_grad_(False)
        for param in self.target_hyp_mlp.parameters():
            param.requires_grad_(False)
        self.hyp_scale = 1.0 / math.sqrt(self.d_hyp)
        self.sde = BridgeVPSDE(schedule=getattr(configs, "diff_schedule", "cosine"))
        self.hyp_cond_proj = nn.Linear(self.d_hyp, d_model)
        nn.init.zeros_(self.hyp_cond_proj.weight)
        nn.init.zeros_(self.hyp_cond_proj.bias)
        self.diff_steps = max(1, int(getattr(configs, "diff_steps", 1)))
        self.diff_eta = float(getattr(configs, "diff_eta", 0.0))
        self.lambda_hyp = float(getattr(configs, "lambda_hyp", 0.1))
        self.lambda_prior = float(getattr(configs, "lambda_prior", 0.1))
        self._explanation_mode = False
        self._captured_latent = None

    def _patches_to_series(self, patches, batch, channels):
        series = patches.view(batch, channels, self.num_future_patches, self.patch_len)
        series = series.permute(0, 2, 3, 1).reshape(batch, self.num_future_patches * self.patch_len, channels)
        return series[:, : self.pred_len]

    def _future_mask(self, batch_channels, device, dtype):
        return _future_valid_mask(
            self.pred_len,
            self.num_future_patches,
            self.patch_len,
            batch_channels,
            device,
            dtype,
        )

    def _project_target_hyp(self, target_flat):
        if self.pred_len % self.patch_len == 0:
            tangent = self.target_hyp_mlp(self.target_patch_proj(target_flat))
        else:
            points = []
            for i, valid_len in enumerate(self.future_valid_lens):
                weight = self.target_patch_proj.weight[:, :valid_len]
                hidden = F.linear(target_flat[:, i, :valid_len], weight, self.target_patch_proj.bias)
                points.append(self.target_hyp_mlp(hidden))
            tangent = torch.stack(points, dim=1)
        return _bounded_exp_map0(self.manifold, tangent * self.hyp_scale, self.hyp_max_tangent)

    def _encode_history(self, x, batch, channels):
        x_channel = x.permute(0, 2, 1).reshape(batch * channels, x.shape[1])
        tokens = self.tokenizer(x_channel)
        h_hist = self.history_encoder(tokens)
        z_hist_hyp = _bounded_exp_map0(self.manifold, self.hist_hyp_proj(h_hist) * self.hyp_scale, self.hyp_max_tangent)
        hist_context = h_hist.mean(dim=1)
        if self.use_hyp_cond:
            z_hist_mean = z_hist_hyp.mean(dim=1)
            hyp_cond = self.hyp_cond_proj(self.manifold.log_map0(z_hist_mean))
        else:
            hyp_cond = None
        prior_base = self.prior_base(h_hist[:, -1])
        if self.pred_len % self.patch_len != 0:
            prior_base = F.pad(prior_base, (0, self.num_future_patches * self.patch_len - self.pred_len))
        prior_flat = prior_base.view(batch * channels, self.num_future_patches, self.patch_len)
        y_prior = prior_flat.view(batch, channels, self.num_future_patches, self.patch_len)
        y_prior = y_prior.permute(0, 2, 3, 1).reshape(batch, self.num_future_patches * self.patch_len, channels)
        y_prior = y_prior[:, : self.pred_len]
        return y_prior, z_hist_hyp, hist_context, h_hist, prior_flat, hyp_cond

    def _sample_prior_bridge(self, bridge_flat, h_hist, hist_context, hyp_cond):
        batch = bridge_flat.shape[0]
        valid_mask = self._future_mask(batch, bridge_flat.device, bridge_flat.dtype)
        p_t = bridge_flat * valid_mask
        pred_p0 = bridge_flat
        z_fut_hyp = None
        for step in range(self.diff_steps):
            t_cur = 1.0 - step / self.diff_steps
            t_prev = 1.0 - (step + 1) / self.diff_steps
            t_batch = torch.full((batch,), t_cur, device=bridge_flat.device, dtype=torch.float32)
            pred_p0, pred_eps, z_fut_hyp = self.denoiser(p_t, t_batch, h_hist, hist_context, bridge_flat, hyp_cond)
            pred_p0 = pred_p0.clamp(-TARGET_CLIP, TARGET_CLIP)
            alpha_cur, sigma_cur = self.sde.coefficients(t_batch)
            alpha_prev, sigma_prev = self.sde.coefficients(torch.full_like(t_batch, t_prev))
            p_t = bridge_ddim_step(p_t, pred_p0, pred_eps, bridge_flat, alpha_cur, sigma_cur, alpha_prev, sigma_prev, self.diff_eta)
            p_t = p_t.clamp(-TARGET_CLIP, TARGET_CLIP) * valid_mask
        return p_t, z_fut_hyp

    def _forward_train(self, x, y_true):
        batch, _, channels = x.shape
        if self.use_revin:
            self.revin(x, "stats")
        y_prior, z_hist_hyp, hist_context, h_hist, prior_flat, hyp_cond = self._encode_history(x, batch, channels)
        bridge_flat = prior_flat if self.use_prior_bridge else torch.zeros_like(prior_flat)
        valid_mask = self._future_mask(batch * channels, prior_flat.device, prior_flat.dtype)
        patch_mask = valid_mask.any(dim=-1)

        aux = {
            "h_hist_causal": h_hist,
            "y_prior": y_prior,
            "z_hist_hyp": z_hist_hyp,
            "manifold": self.manifold,
            "valid_mask": valid_mask,
            "patch_mask": patch_mask,
            "loss_total": None,
            "loss_dict": {},
        }

        target_raw = y_true[:, -self.pred_len :, :]
        if self.use_revin:
            target = self.revin.normalize_target(target_raw)
        else:
            target = target_raw
        target_patches = _split_future_patches(target, self.patch_len)
        target_flat = target_patches.reshape(batch * channels, self.num_future_patches, self.patch_len) * valid_mask
        prior_anchor = bridge_flat.detach() * valid_mask
        t = self.sde.sample_timesteps(target_flat.shape[0], target_flat.device)
        alpha, sigma = self.sde.coefficients(t)
        noise = torch.randn_like(target_flat)
        noisy = (alpha * target_flat + (1.0 - alpha) * prior_anchor + sigma * noise) * valid_mask
        if self.use_denoiser:
            pred_p0, pred_eps, z_fut_hyp = self.denoiser(noisy, t, h_hist, hist_context, prior_anchor, hyp_cond)
            pred_p0 = pred_p0 * valid_mask
            pred_eps = pred_eps * valid_mask
        else:
            pred_p0 = bridge_flat * valid_mask
            pred_eps = torch.zeros_like(pred_p0)
            with torch.no_grad():
                z_fut_hyp = self._project_target_hyp(pred_p0.detach())
        with torch.no_grad():
            z_target_hyp = self._project_target_hyp(target_flat)
        output_norm = self._patches_to_series(pred_p0, batch, channels)
        if self.use_revin:
            output = self.revin.denormalize(output_norm)
        else:
            output = output_norm
        aux.update(
            {
                "target_patches": target_flat,
                "pred_patches": pred_p0,
                "pred_noise": pred_eps,
                "noisy_patches": noisy,
                "prior_patches": prior_anchor,
                "alpha": alpha,
                "sigma": sigma,
                "z_fut_hyp": z_fut_hyp,
                "z_target_hyp": z_target_hyp,
                "y_target": target,
                "output_norm": output_norm,
            }
        )
        loss_total, loss_dict = compute_m2patch_diffusion_loss(
            output,
            target_raw,
            aux,
            self.lambda_hyp,
            self.lambda_prior,
        )
        aux["loss_total"] = loss_total
        aux["loss_dict"] = loss_dict

        if self._explanation_mode:
            self._captured_latent = {
                "h_hist_causal": h_hist.detach(),
                "z_hist_hyp": z_hist_hyp.detach(),
                "z_fut_hyp": z_fut_hyp.detach() if z_fut_hyp is not None else None,
                "y_prior": y_prior.detach(),
            }
        return output, aux

    def forward(self, x, y_true=None):
        if y_true is not None:
            return self._forward_train(x, y_true)

        batch, _, channels = x.shape
        if self.use_revin:
            self.revin(x, "stats")
        y_prior, z_hist_hyp, hist_context, h_hist, prior_flat, hyp_cond = self._encode_history(x, batch, channels)
        bridge_flat = prior_flat if self.use_prior_bridge else torch.zeros_like(prior_flat)
        valid_mask = self._future_mask(batch * channels, prior_flat.device, prior_flat.dtype)
        patch_mask = valid_mask.any(dim=-1)

        aux = {
            "h_hist_causal": h_hist,
            "y_prior": y_prior,
            "z_hist_hyp": z_hist_hyp,
            "manifold": self.manifold,
            "valid_mask": valid_mask,
            "patch_mask": patch_mask,
            "loss_total": None,
            "loss_dict": {},
        }
        if self.use_denoiser:
            pred_p0, z_fut_hyp = self._sample_prior_bridge(bridge_flat, h_hist, hist_context, hyp_cond)
        else:
            pred_p0 = bridge_flat * valid_mask
            z_fut_hyp = self._project_target_hyp(pred_p0)
        output_norm = self._patches_to_series(pred_p0, batch, channels)
        if self.use_revin:
            output = self.revin.denormalize(output_norm)
        else:
            output = output_norm
        aux.update(
            {
                "pred_patches": pred_p0,
                "z_fut_hyp": z_fut_hyp,
                "z_target_hyp": None,
                "y_target": None,
                "output_norm": output_norm,
            }
        )

        if self._explanation_mode:
            self._captured_latent = {
                "h_hist_causal": h_hist.detach(),
                "z_hist_hyp": z_hist_hyp.detach(),
                "z_fut_hyp": z_fut_hyp.detach() if z_fut_hyp is not None else None,
                "y_prior": y_prior.detach(),
            }
        return output, aux
