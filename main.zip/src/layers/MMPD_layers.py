import math

import numpy as np
import torch
import torch.nn as nn


def get_beta_schedule(beta_schedule, *, beta_start, beta_end, num_diffusion_timesteps):
    if beta_schedule == "linear":
        betas = np.linspace(beta_start, beta_end, num_diffusion_timesteps, dtype=np.float64)
    else:
        raise NotImplementedError(beta_schedule)
    assert betas.shape == (num_diffusion_timesteps,)

    return betas


def get_named_beta_schedule(schedule_name, num_diffusion_timesteps):
    if schedule_name == "linear":
        scale = 1000 / num_diffusion_timesteps
        return get_beta_schedule(
            "linear",
            beta_start=scale * 0.0001,
            beta_end=scale * 0.02,
            num_diffusion_timesteps=num_diffusion_timesteps,
        )
    elif schedule_name == "cosine":
        return betas_for_alpha_bar(
            num_diffusion_timesteps,
            lambda t: math.cos((t + 0.008) / 1.008 * math.pi / 2) ** 2,
        )
    else:
        raise NotImplementedError("unknown beta schedule: {}".format(schedule_name))


def betas_for_alpha_bar(num_diffusion_timesteps, alpha_bar, max_beta=0.9):
    betas = []
    for i in range(num_diffusion_timesteps):
        t1 = i / num_diffusion_timesteps
        t2 = (i + 1) / num_diffusion_timesteps
        betas.append(min(1 - alpha_bar(t2) / alpha_bar(t1), max_beta))

    return np.array(betas)


def extract(nums_seq, t, broadcast_shape):
    out = nums_seq[t]
    while len(out.shape) < len(broadcast_shape):
        out = out[..., None]

    return out + torch.zeros(broadcast_shape, device=t.device)


class GaussianDiffusion(nn.Module):
    def __init__(self, *, betas):
        super(GaussianDiffusion, self).__init__()

        def register_buffer(name, val):
            self.register_buffer(name, val.to(torch.float32))

        betas = torch.from_numpy(np.array(betas))
        register_buffer("betas", betas)
        assert len(betas.shape) == 1, "betas must be 1-D"
        assert (betas > 0).all() and (betas <= 1).all()

        self.num_timesteps = int(betas.shape[0])

        alphas = 1.0 - betas
        register_buffer("alphas", alphas)
        register_buffer("alphas_cumprod", torch.cumprod(alphas, dim=0))
        register_buffer("alphas_cumprod_prev", torch.cat([torch.tensor([1.0]), self.alphas_cumprod[:-1]]))
        register_buffer("alphas_cumprod_next", torch.cat([self.alphas_cumprod[1:], torch.tensor([0.0])]))
        assert self.alphas_cumprod_prev.shape == (self.num_timesteps,)

        register_buffer("sqrt_alphas_cumprod", torch.sqrt(self.alphas_cumprod))
        register_buffer("sqrt_one_minus_alphas_cumprod", torch.sqrt(1.0 - self.alphas_cumprod))
        register_buffer("log_one_minus_alphas_cumprod", torch.log(1.0 - self.alphas_cumprod))
        register_buffer("sqrt_recip_alphas_cumprod", torch.sqrt(1.0 / self.alphas_cumprod))
        register_buffer("sqrt_recipm1_alphas_cumprod", torch.sqrt(1.0 / self.alphas_cumprod - 1))

        register_buffer(
            "posterior_variance",
            self.betas * (1.0 - self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod),
        )

        register_buffer(
            "posterior_log_variance_clipped",
            torch.log(torch.cat([self.posterior_variance[1:2], self.posterior_variance[1:]])),
        )

        register_buffer(
            "posterior_mean_coef1",
            self.betas * torch.sqrt(self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod),
        )
        register_buffer(
            "posterior_mean_coef2",
            (1.0 - self.alphas_cumprod_prev) * torch.sqrt(self.alphas) / (1.0 - self.alphas_cumprod),
        )

        self.anchor_t = torch.argmin(torch.abs(self.alphas_cumprod - 0.5))

    def q_mean_variance(self, x_start, t):
        mean = extract(self.sqrt_alphas_cumprod, t, x_start.shape) * x_start
        variance = extract(1.0 - self.alphas_cumprod, t, x_start.shape)
        log_variance = extract(self.log_one_minus_alphas_cumprod, t, x_start.shape)

        return mean, variance, log_variance

    def q_sample(self, x_start, t, noise=None):
        if noise is None:
            noise = torch.randn(x_start.shape).to(x_start.device)
        assert noise.shape == x_start.shape

        return (
            extract(self.sqrt_alphas_cumprod, t, x_start.shape) * x_start
            + extract(self.sqrt_one_minus_alphas_cumprod, t, x_start.shape) * noise
        )

    def q_posterior_mean_variance(self, x_start, x_t, t):
        assert x_start.shape == x_t.shape
        posterior_mean = (
            extract(self.posterior_mean_coef1, t, x_t.shape) * x_start
            + extract(self.posterior_mean_coef2, t, x_t.shape) * x_t
        )
        posterior_variance = extract(self.posterior_variance, t, x_t.shape)
        posterior_log_variance_clipped = extract(self.posterior_log_variance_clipped, t, x_t.shape)
        assert (
            posterior_mean.shape[0]
            == posterior_variance.shape[0]
            == posterior_log_variance_clipped.shape[0]
            == x_start.shape[0]
        )

        return posterior_mean, posterior_variance, posterior_log_variance_clipped

    def p_mean_variance(self, model, x, condition, t):
        batch_size, patch_num, patch_size = x.shape
        assert t.shape == (batch_size,)
        model_output = model(x, condition, t)

        model_variance, model_log_variance = self.posterior_variance, self.posterior_log_variance_clipped
        model_variance = extract(model_variance, t, x.shape)
        model_log_variance = extract(model_log_variance, t, x.shape)

        pred_xstart = self._predict_xstart_from_eps(x_t=x, t=t, eps=model_output)
        model_mean, _, _ = self.q_posterior_mean_variance(x_start=pred_xstart, x_t=x, t=t)

        assert model_mean.shape == model_log_variance.shape == pred_xstart.shape == x.shape

        return {
            "mean": model_mean,
            "variance": model_variance,
            "log_variance": model_log_variance,
            "pred_xstart": pred_xstart,
        }

    def _predict_xstart_from_eps(self, x_t, t, eps):
        assert x_t.shape == eps.shape

        return (
            extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t
            - extract(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape) * eps
        )

    def _predict_eps_from_xstart(self, x_t, t, pred_xstart):
        return (
            extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t - pred_xstart
        ) / extract(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape)

    def _anchor_steps(self, batch_size, device):
        return torch.full((batch_size,), int(self.anchor_t), dtype=torch.long, device=device)

    def training_losses(self, model, x_start, condition, t, noise=None, point_weight=0.0):
        if noise is None:
            noise = torch.randn(x_start.shape).to(x_start.device)
        x_t = self.q_sample(x_start, t, noise=noise)

        terms = {}
        model_output = model(x_t, condition, t)

        target = noise
        assert model_output.shape == target.shape == x_start.shape
        diffusion_mse_nonreduced = (model_output - target) ** 2
        terms["diffusion_mse"] = diffusion_mse_nonreduced.sum(dim=(-1, -2))

        x_t_zeros = torch.zeros(x_start.shape).to(x_start.device)
        anchor_t = self._anchor_steps(x_start.shape[0], x_start.device)
        anchor_noise = self._predict_eps_from_xstart(x_t=x_t_zeros, t=anchor_t, pred_xstart=x_start)
        anchor_output = model(x_t_zeros, condition, anchor_t)

        point_loss_nonreduced = (anchor_noise - anchor_output) ** 2
        terms["point_loss"] = point_loss_nonreduced.sum(dim=(-1, -2))
        terms["loss"] = (1 - point_weight) * terms["diffusion_mse"] + point_weight * terms["point_loss"]

        return terms

    @torch.no_grad()
    def point_pred(self, model, patches_shape, condition):
        batch_size, patch_num, patch_size = patches_shape
        zeros = torch.zeros(patches_shape).to(condition.device)
        anchor_t = self._anchor_steps(batch_size, zeros.device)
        assert anchor_t.shape == (batch_size,)
        model_output = model(zeros, condition, anchor_t)
        pred_xstart = self._predict_xstart_from_eps(x_t=zeros, t=anchor_t, eps=model_output)

        return pred_xstart

    @torch.no_grad()
    def p_sample(self, model, x, condition, t, temperature=1.0):
        out = self.p_mean_variance(model, x, condition, t)

        noise = torch.randn(x.shape).to(x.device)
        nonzero_mask = (t != 0).float().view(-1, *([1] * (len(x.shape) - 1)))
        sample = out["mean"] + nonzero_mask * torch.exp(0.5 * out["log_variance"]) * noise * temperature

        return {"sample": sample, "pred_xstart": out["pred_xstart"]}

    @torch.no_grad()
    def p_sample_loop(
        self,
        model,
        x_shape,
        condition,
        sample_num=1,
        temperature=1.0,
        gmm=True,
        gmm_components=10,
        prior_pi_decay=0.5,
        prior_precision_shape=1e3,
        gmm_iterations=10,
    ):
        batch_size, patch_num, patch_size = x_shape
        _, _, d_condition = condition.shape
        folded_xt = torch.randn([batch_size * sample_num, patch_num, patch_size]).to(condition.device)
        folded_condition = condition[:, None, :, :].expand(-1, sample_num, -1, -1).reshape(
            batch_size * sample_num, patch_num, d_condition
        )
        indices = list(range(self.num_timesteps))[::-1]

        xt = folded_xt.reshape(batch_size, sample_num, patch_num * patch_size)

        if gmm:
            gmm = DiffusionVariationalGaussianMixture(
                n_components=gmm_components,
                alphas_cumprod=self.alphas_cumprod,
                prior_pi_decay=prior_pi_decay,
                prior_precision_shape=prior_precision_shape,
                batch_x=xt,
            )

        for i in indices:
            if gmm:
                xt = folded_xt.reshape(batch_size, sample_num, patch_num * patch_size)
                for _ in range(gmm_iterations):
                    log_resp = gmm.e_step(xt)
                    gmm.m_step(xt, log_resp, i)

            t = torch.tensor([i] * (batch_size * sample_num)).to(condition.device)
            out = self.p_sample(model, folded_xt, folded_condition, t, temperature=temperature)
            folded_xt = out["sample"]

        if gmm:
            xt = folded_xt.reshape(batch_size, sample_num, patch_num * patch_size)
            for _ in range(gmm_iterations):
                log_resp = gmm.e_step(xt)
                gmm.m_step(xt, log_resp, i)

            log_resp = gmm.predict(xt)
            assigned_cluster = torch.argmax(log_resp, dim=-1)

            xt = folded_xt.reshape(batch_size, sample_num, patch_num * patch_size)

            num_in_mode, mode_median, confidence_interval = multi_mode_summary(
                xt, assigned_cluster, gmm_components, confidence=[0.5, 0.9]
            )

            gmm_results = {
                "assigned_cluster": assigned_cluster,
                "num_in_mode": num_in_mode,
                "mode_median": mode_median,
                "confidences": [0.5, 0.9],
                "confidence_intervals": confidence_interval,
            }
        else:
            gmm_results = None

        denoised_x0 = out["sample"].view(batch_size, sample_num, patch_num, patch_size)

        return denoised_x0, gmm_results


def space_timesteps(num_timesteps, section_counts):
    if isinstance(section_counts, str):
        if section_counts.startswith("ddim"):
            desired_count = int(section_counts[len("ddim") :])
            for i in range(1, num_timesteps):
                if len(range(0, num_timesteps, i)) == desired_count:
                    return set(range(0, num_timesteps, i))
            raise ValueError("cannot create exactly {} steps with an integer stride".format(num_timesteps))
        section_counts = [int(x) for x in section_counts.split(",")]
    size_per = num_timesteps // len(section_counts)
    extra = num_timesteps % len(section_counts)
    start_idx = 0
    all_steps = []
    for i, section_count in enumerate(section_counts):
        size = size_per + (1 if i < extra else 0)
        if size < section_count:
            raise ValueError("cannot divide section of {} steps into {}".format(size, section_count))
        if section_count <= 1:
            frac_stride = 1
        else:
            frac_stride = (size - 1) / (section_count - 1)
        cur_idx = 0.0
        taken_steps = []
        for _ in range(section_count):
            taken_steps.append(start_idx + round(cur_idx))
            cur_idx += frac_stride
        all_steps += taken_steps
        start_idx += size

    return set(all_steps)


class SpacedDiffusion(GaussianDiffusion):
    def __init__(self, use_timesteps, **kwargs):
        self.use_timesteps = set(use_timesteps)
        timestep_map = []
        self.original_num_steps = len(kwargs["betas"])

        base_diffusion = GaussianDiffusion(**kwargs)
        last_alpha_cumprod = 1.0
        new_betas = []
        for i, alpha_cumprod in enumerate(base_diffusion.alphas_cumprod):
            if i in self.use_timesteps:
                new_betas.append(1 - alpha_cumprod / last_alpha_cumprod)
                last_alpha_cumprod = alpha_cumprod
                timestep_map.append(i)
        kwargs["betas"] = np.array(new_betas)
        super().__init__(**kwargs)
        self.register_buffer("timestep_map", torch.tensor(timestep_map))

    def p_mean_variance(self, model, *args, **kwargs):
        return super().p_mean_variance(self._wrap_model(model), *args, **kwargs)

    def training_losses(self, model, *args, **kwargs):
        return super().training_losses(self._wrap_model(model), *args, **kwargs)

    def _wrap_model(self, model):
        if isinstance(model, _WrappedModel):
            return model

        return _WrappedModel(model, self.timestep_map, self.original_num_steps)

    def _scale_timesteps(self, t):
        return t


class _WrappedModel:
    def __init__(self, model, timestep_map, original_num_steps):
        self.model = model
        self.timestep_map = timestep_map
        self.original_num_steps = original_num_steps

    def __call__(self, x, condition, ts, **kwargs):
        new_ts = self.timestep_map[ts]

        return self.model(x, condition, new_ts, **kwargs)


def create_diffusion(
    timestep_respacing,
    noise_schedule="linear",
    use_kl=False,
    sigma_small=True,
    predict_xstart=False,
    learn_sigma=False,
    rescale_learned_sigmas=False,
    diffusion_steps=1000,
):
    betas = get_named_beta_schedule(noise_schedule, diffusion_steps)
    if timestep_respacing is None or timestep_respacing == "":
        timestep_respacing = [diffusion_steps]

    return SpacedDiffusion(
        use_timesteps=space_timesteps(diffusion_steps, timestep_respacing),
        betas=betas,
    )


class MLP_block(nn.Module):
    def __init__(self, d_model, dropout=0.0):
        super(MLP_block, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, d_model),
        )

    def forward(self, x):
        x = self.mlp(x)

        return x


class diffusion_timestamp_embeder(nn.Module):
    def __init__(self, d_model, max_steps=1000, dropout=0.0):
        super(diffusion_timestamp_embeder, self).__init__()
        self.d_model = d_model
        self.max_steps = max_steps

        pe = torch.zeros(max_steps, d_model)
        position = torch.arange(0, max_steps, dtype=torch.float)[:, None]
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(max_steps) / d_model))[None, :]
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe)

        self.mlp = MLP_block(d_model, dropout)

    def forward(self, denoise_t):
        position_embed = self.pe[denoise_t, :]
        position_embed = self.mlp(position_embed)

        return position_embed


class DMLP_block(nn.Module):
    def __init__(self, d_model, dropout=0.0):
        super().__init__()
        self.norm = nn.LayerNorm(d_model, elementwise_affine=False, eps=1e-6)
        self.mlp = MLP_block(d_model, dropout)
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, 3 * d_model, bias=True),
        )

    def forward(self, x, c):
        shift_mlp, scale_mlp, gate_mlp = self.adaLN_modulation(c).chunk(3, dim=-1)

        skip_x = x
        x = self.norm(x) * (1 + scale_mlp) + shift_mlp
        x = skip_x + gate_mlp * self.mlp(x)

        return x


class FinalLayer(nn.Module):
    def __init__(self, d_model, patch_size, dropout=0.0):
        super().__init__()
        self.norm = nn.LayerNorm(d_model, elementwise_affine=False, eps=1e-6)
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, 2 * d_model, bias=True),
        )
        self.out_project = nn.Linear(d_model, patch_size, bias=True)

    def forward(self, x, c):
        shift, scale = self.adaLN_modulation(c).chunk(2, dim=-1)
        x = self.norm(x) * (1 + scale) + shift
        x = self.out_project(x)

        return x


class Patch_Consistent_MLP(nn.Module):
    def __init__(
        self,
        max_diffusion_steps,
        d_condition,
        d_diffusion,
        patch_size,
        num_layers,
        radius,
        dropout=0.0,
        *args,
        **kwargs,
    ):
        super(Patch_Consistent_MLP, self).__init__()

        self.max_diffusion_steps = max_diffusion_steps
        self.patch_size = patch_size
        self.d_condition = d_condition
        self.d_diffusion = d_diffusion
        self.num_layers = num_layers
        self.radius = radius
        self.dropout = dropout

        self.patch_embedder = nn.Linear(patch_size, d_diffusion, bias=False)
        self.prev_patches_embedder = nn.Conv1d(
            patch_size, d_diffusion, kernel_size=self.radius, padding=self.radius, bias=False
        )
        self.next_patches_embedder = nn.Conv1d(
            patch_size, d_diffusion, kernel_size=self.radius, padding=self.radius, bias=False
        )

        self.t_embedder = diffusion_timestamp_embeder(d_diffusion, max_diffusion_steps, dropout)
        self.condition_embedder = nn.Linear(d_condition, d_diffusion)

        self.blocks = nn.ModuleList([DMLP_block(d_diffusion, dropout) for _ in range(num_layers)])
        self.final_layer = FinalLayer(d_diffusion, patch_size, dropout)

    def forward(self, noisy_patch, condition, diffusion_t):
        batch_size, patch_num, patch_size = noisy_patch.shape

        t = self.t_embedder(diffusion_t)
        expanded_t = t[:, None, :].expand(-1, patch_num, -1)
        dec_condition = self.condition_embedder(condition)

        previous_patch_emb = self.prev_patches_embedder(noisy_patch.transpose(1, 2)).transpose(1, 2)[
            :, : -self.radius - 1, :
        ]
        next_patch_emb = self.next_patches_embedder(noisy_patch.transpose(1, 2)).transpose(1, 2)[
            :, self.radius + 1 :, :
        ]
        adj_patch_emb = previous_patch_emb + next_patch_emb

        x = self.patch_embedder(noisy_patch)
        condition = dec_condition + expanded_t + adj_patch_emb

        for block in self.blocks:
            x = block(x, condition)

        x = self.final_layer(x, condition)

        return x


class DiffusionVariationalGaussianMixture:
    def __init__(
        self,
        n_components=1,
        alphas_cumprod=None,
        prior_pi_decay=0.2,
        prior_precision_shape=2.0,
        batch_x=None,
    ):
        self.n_components = n_components
        self.alphas_cumprod = alphas_cumprod
        self.timestamps = len(alphas_cumprod)

        batch_size, n_samples, n_features = batch_x.shape
        self.batch_size = batch_size
        self.n_samples = n_samples
        self.n_features = n_features
        self.device = batch_x.device

        self.prior_pi_concentration = torch.tensor(
            [1.0 * prior_pi_decay**i for i in range(n_components)]
        ).to(self.device)

        self.prior_precision_shape = prior_precision_shape
        self.prior_precision_rate = ((prior_precision_shape) * (1 - self.alphas_cumprod)).to(self.device)

        self.post_pi_concentration = self.prior_pi_concentration[None, :].expand(batch_size, -1).clone()

        self.post_precision_shape = torch.ones(batch_size, n_components).to(self.device) * self.prior_precision_shape
        self.post_precision_rate = torch.ones(batch_size, n_components).to(self.device) * self.prior_precision_rate[-1]

        self.post_mu = torch.zeros(batch_size, n_components, n_features).to(self.device)

    def e_step(self, batch_x):
        batch_size, n_samples, n_features = batch_x.shape

        expected_precision = self.post_precision_shape / self.post_precision_rate
        log_prob_term1 = expected_precision[:, None, :] * (
            (batch_x[:, :, None, :] - self.post_mu[:, None, :, :]) ** 2
        ).sum(-1)
        log_prob_term2 = n_features * math.log(2 * math.pi)
        log_prob_term3 = n_features * (torch.digamma(self.post_precision_shape) - torch.log(self.post_precision_rate))
        log_gaussian_prob = -0.5 * (log_prob_term1 + log_prob_term2 - log_prob_term3[:, None, :])

        log_pi = torch.digamma(self.post_pi_concentration) - torch.digamma(
            self.post_pi_concentration.sum(-1, keepdim=True)
        )

        weighted_log_prob = log_gaussian_prob + log_pi[:, None, :]
        log_prob_norm = torch.logsumexp(weighted_log_prob, dim=-1, keepdim=True)
        log_resp = weighted_log_prob - log_prob_norm

        return log_resp

    def m_step(self, batch_x, log_resp, t):
        n_features = batch_x.shape[-1]
        resp = torch.exp(log_resp)

        nk = resp.sum(dim=1)
        new_post_pi_concentration = self.prior_pi_concentration[None, :] + nk

        new_post_mu = (resp[:, :, :, None] * batch_x[:, :, None, :]).sum(1) / (
            nk[:, :, None] + 10 * torch.finfo(resp.dtype).eps
        )

        new_post_precision_shape = self.prior_precision_shape + 0.5 * n_features * nk
        weighted_var = (
            resp * ((batch_x[:, :, None, :] - new_post_mu[:, None, :, :]) ** 2).sum(-1)
        ).sum(1)
        new_post_precision_rate = self.prior_precision_rate[t] + 0.5 * weighted_var

        self.post_pi_concentration = new_post_pi_concentration
        self.post_mu = new_post_mu
        self.post_precision_shape = new_post_precision_shape
        self.post_precision_rate = new_post_precision_rate

    def predict(self, batch_x):
        log_resp = self.e_step(batch_x)

        return log_resp


def multi_mode_summary(samples, assigned_cluster, num_modes=10, confidence=[0.5, 0.9]):
    batch_size, sample_num, n_features = samples.shape

    batch_num_in_mode = []
    batch_mode_median = []
    batch_confidence_interval = []

    for i in range(batch_size):
        num_in_mode = []
        mode_median = []
        mode_interval = []
        for j in range(num_modes):
            assignment = assigned_cluster[i] == j
            if assignment.sum() > 0:
                samples_in_cluster = samples[i][assignment]
                median_curve = torch.quantile(samples_in_cluster, 0.5, dim=0)

                confidence_intervals = []
                for c in confidence:
                    down_curve = torch.quantile(samples_in_cluster, 0.5 - 0.5 * c, dim=0)
                    up_curve = torch.quantile(samples_in_cluster, 0.5 + 0.5 * c, dim=0)
                    c_interval = torch.stack([down_curve, up_curve], dim=0)
                    confidence_intervals.append(c_interval)
                confidence_intervals = torch.stack(confidence_intervals, dim=0)
            else:
                median_curve = torch.zeros(n_features).to(samples.device)
                confidence_intervals = torch.zeros(len(confidence), 2, n_features).to(samples.device)
            num_in_mode.append(assignment.sum())
            mode_median.append(median_curve)
            mode_interval.append(confidence_intervals)
        num_in_mode = torch.tensor(num_in_mode).to(samples.device)
        mode_order = torch.argsort(num_in_mode, descending=True)
        num_in_mode = num_in_mode[mode_order]
        mode_median = torch.stack(mode_median, dim=0)[mode_order, :]
        mode_interval = torch.stack(mode_interval, dim=0)[mode_order, :, :, :]

        batch_num_in_mode.append(num_in_mode)
        batch_mode_median.append(mode_median)
        batch_confidence_interval.append(mode_interval)

    batch_num_in_mode = torch.stack(batch_num_in_mode, dim=0)
    batch_mode_median = torch.stack(batch_mode_median, dim=0)
    batch_confidence_interval = torch.stack(batch_confidence_interval, dim=0)

    return batch_num_in_mode, batch_mode_median, batch_confidence_interval


class learnable_position_embedding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        self.d_model = d_model
        self.max_len = max_len
        self.position_embedding = nn.Parameter(torch.randn(max_len, d_model), requires_grad=True)

    def forward(self, seq_idxs):
        batch_size = seq_idxs.shape[0]

        position_embedding_expand = self.position_embedding[None, :, :].expand(batch_size, -1, -1)
        idxs_expand = seq_idxs[:, :, None].expand(-1, -1, self.d_model)
        pe = position_embedding_expand.gather(1, idxs_expand)

        return pe


class DecoderOnlyTransformer(nn.Module):
    def __init__(self, configs):
        super(DecoderOnlyTransformer, self).__init__()

        self.in_len = configs.seq_len
        self.out_len = configs.pred_len
        self.patch_size = configs.patch_size
        self.d_model = configs.d_model
        self.d_ff = configs.d_ff
        self.n_heads = configs.n_heads
        self.d_layers = configs.d_layers
        self.dropout = configs.dropout

        self.patch_embedding = nn.Linear(self.patch_size, self.d_model, bias=False)

        self.position_embedding = learnable_position_embedding(self.d_model)
        self.learnable_patch = nn.Parameter(torch.randn(self.d_model))

        encoder_layer = nn.TransformerEncoderLayer(
            self.d_model, self.n_heads, self.d_ff, self.dropout, batch_first=True
        )
        self.decoder = nn.TransformerEncoder(encoder_layer, self.d_layers)

    def forward(self, x_seq, *args, **kwargs):
        batch_size, data_dim, seq_len = x_seq.shape
        x_seq = x_seq.reshape(batch_size * data_dim, seq_len)

        point_to_pad = (self.patch_size - (seq_len % self.patch_size)) % self.patch_size
        if point_to_pad > 0:
            x_seq = torch.cat([x_seq[:, 0:1].expand(-1, point_to_pad), x_seq], dim=1)
            seq_len = x_seq.shape[1]

        input_patch_num = seq_len // self.patch_size
        output_patch_num = math.ceil(self.out_len / self.patch_size)
        flatten_batch_size = x_seq.shape[0]

        patch_seq = x_seq.reshape(flatten_batch_size, input_patch_num, self.patch_size)

        patch_embed = self.patch_embedding(patch_seq)
        in_idxs = torch.arange(input_patch_num)[None, :].expand(flatten_batch_size, -1).to(x_seq.device)
        in_pos_embed = self.position_embedding(in_idxs)
        input_embed = patch_embed + in_pos_embed

        out_idxs = (
            torch.arange(input_patch_num, input_patch_num + output_patch_num)[None, :]
            .expand(flatten_batch_size, -1)
            .to(x_seq.device)
        )
        out_pos_embed = self.position_embedding(out_idxs)
        out_patch_embed = out_pos_embed + self.learnable_patch[None, None, :]
        dec_in = torch.cat([input_embed, out_patch_embed], dim=1)
        dec_out = self.decoder(dec_in)[:, -output_patch_num:, :]

        dec_out = dec_out.reshape(batch_size, data_dim, output_patch_num, self.d_model)

        return dec_out


class EncoderDecoderTransformer(nn.Module):
    def __init__(self, configs):
        super(EncoderDecoderTransformer, self).__init__()

        self.in_len = configs.seq_len
        self.out_len = configs.pred_len
        self.patch_size = configs.patch_size
        self.d_model = configs.d_model
        self.d_ff = configs.d_ff
        self.n_heads = configs.n_heads
        self.e_layers = configs.e_layers
        self.d_layers = configs.d_layers
        self.dropout = configs.dropout

        self.patch_embedding = nn.Linear(self.patch_size, self.d_model, bias=False)
        self.position_embedding = learnable_position_embedding(self.d_model)

        self.encoder_decoder = nn.Transformer(
            d_model=self.d_model,
            nhead=self.n_heads,
            num_encoder_layers=self.e_layers,
            num_decoder_layers=self.d_layers,
            dim_feedforward=self.d_ff,
            dropout=self.dropout,
            batch_first=True,
        )

    def forward(self, x_seq, *args, **kwargs):
        batch_size, data_dim, seq_len = x_seq.shape
        x_seq = x_seq.reshape(batch_size * data_dim, seq_len)

        point_to_pad = (self.patch_size - (seq_len % self.patch_size)) % self.patch_size
        if point_to_pad > 0:
            x_seq = torch.cat([x_seq[:, 0:1].expand(-1, point_to_pad), x_seq], dim=1)
            seq_len = x_seq.shape[1]

        input_patch_num = seq_len // self.patch_size
        output_patch_num = math.ceil(self.out_len / self.patch_size)
        flatten_batch_size = x_seq.shape[0]

        patch_seq = x_seq.reshape(flatten_batch_size, input_patch_num, self.patch_size)
        patch_embed = self.patch_embedding(patch_seq)

        pos_idxs = (
            torch.arange(input_patch_num + output_patch_num)[None, :]
            .expand(flatten_batch_size, -1)
            .to(x_seq.device)
        )
        pos_embed = self.position_embedding(pos_idxs)
        in_pos_embed = pos_embed[:, :input_patch_num, :]
        out_pos_embed = pos_embed[:, input_patch_num:, :]

        enc_in = patch_embed + in_pos_embed
        dec_in = out_pos_embed
        dec_out = self.encoder_decoder(src=enc_in, tgt=dec_in)

        dec_out = dec_out.reshape(batch_size, data_dim, output_patch_num, self.d_model)

        return dec_out


class MMPD_Loss(nn.Module):
    def __init__(self, configs):
        super(MMPD_Loss, self).__init__()

        self.d_condition = configs.d_model
        self.d_diffusion = configs.d_diffusion
        self.patch_size = configs.patch_size
        self.out_len = configs.pred_len
        self.diffusion_layers = configs.diffusion_layers
        self.max_diffusion_steps = configs.max_diffusion_steps
        self.beta_schedule = configs.beta_schedule
        self.radius = configs.radius
        self.num_sampling_steps = configs.num_sampling_steps
        self.dropout = configs.dropout

        self.net = Patch_Consistent_MLP(
            self.max_diffusion_steps,
            self.d_condition,
            self.d_diffusion,
            self.patch_size,
            self.diffusion_layers,
            self.radius,
            dropout=0.0,
            data_dim=configs.enc_in,
        )

        self.train_diffusion = create_diffusion(
            timestep_respacing="",
            noise_schedule=self.beta_schedule,
            diffusion_steps=self.max_diffusion_steps,
        )
        self.gen_diffusion = create_diffusion(
            timestep_respacing=self.num_sampling_steps,
            noise_schedule=self.beta_schedule,
            diffusion_steps=self.max_diffusion_steps,
        )

    def compute_loss(self, target_seq, dec_condition, point_weight=0.0, *args, **kwargs):
        batch_size, data_dim, seq_len = target_seq.shape
        _, _, patch_num, _ = dec_condition.shape

        assert patch_num == math.ceil(self.out_len / self.patch_size), (
            "Each token corresponds to a patch of length {}, so the number of patches should be "
            "ceil(out_len / patch_size)={}, but got {}.".format(
                self.patch_size, math.ceil(self.out_len / self.patch_size), patch_num
            )
        )

        target_seq = target_seq.reshape(batch_size * data_dim, seq_len)
        dec_condition = dec_condition.reshape(batch_size * data_dim, patch_num, -1)

        flatten_batch_size = target_seq.shape[0]

        point_to_pad = (self.patch_size - (seq_len % self.patch_size)) % self.patch_size
        if point_to_pad > 0:
            target_seq = torch.cat([target_seq, target_seq[:, -1:].expand(-1, point_to_pad)], dim=1)

        target_patches = target_seq.reshape(flatten_batch_size, -1, self.patch_size)
        t = torch.randint(0, self.max_diffusion_steps, (flatten_batch_size,)).to(dec_condition.device).long()

        loss_dict = self.train_diffusion.training_losses(
            self.net, target_patches, dec_condition, t, point_weight=point_weight
        )
        loss = loss_dict["loss"]
        loss = loss.reshape(batch_size, data_dim)

        return loss

    @torch.no_grad()
    def point_predict(self, dec_condition, out_len=None):
        out_len = self.out_len if out_len is None else out_len
        batch_size, data_dim, patch_num, _ = dec_condition.shape
        dec_condition = dec_condition.reshape(batch_size * data_dim, patch_num, -1)
        flatten_batch_size = dec_condition.shape[0]

        deterministic_patches = self.train_diffusion.point_pred(
            model=self.net,
            patches_shape=[flatten_batch_size, patch_num, self.patch_size],
            condition=dec_condition,
        )
        deterministic_seq = deterministic_patches.reshape(flatten_batch_size, -1)[:, :out_len]
        deterministic_pred = deterministic_seq.reshape(batch_size, data_dim, out_len)

        return deterministic_pred

    @torch.no_grad()
    def sample_predict(
        self,
        dec_condition,
        sample_num=1,
        temperature=1.0,
        gmm=False,
        gmm_components=5,
        prior_pi_decay=0.5,
        prior_precision_shape=1e3,
        gmm_iterations=10,
    ):
        out_len = self.out_len
        batch_size, data_dim, patch_num, _ = dec_condition.shape
        dec_condition = dec_condition.reshape(batch_size * data_dim, patch_num, -1)
        flatten_batch_size = dec_condition.shape[0]

        sampled_patches, gmm_results = self.gen_diffusion.p_sample_loop(
            model=self.net,
            x_shape=[flatten_batch_size, patch_num, self.patch_size],
            condition=dec_condition,
            sample_num=sample_num,
            temperature=temperature,
            gmm=gmm,
            gmm_components=gmm_components,
            prior_pi_decay=prior_pi_decay,
            prior_precision_shape=prior_precision_shape,
            gmm_iterations=gmm_iterations,
        )

        sampled_seqs = sampled_patches.reshape(flatten_batch_size, sample_num, -1)[:, :, :out_len]
        prob_samples = sampled_seqs.reshape(batch_size, data_dim, sample_num, out_len)
        mean_pred = prob_samples.mean(dim=2)

        multi_mode_pred = None
        if gmm_results is not None:
            num_in_mode = gmm_results["num_in_mode"].reshape(batch_size, data_dim, -1)
            mode_center = gmm_results["mode_median"].reshape(batch_size, data_dim, -1, out_len)
            mode_ci = gmm_results["confidence_intervals"].reshape(
                batch_size, data_dim, -1, len(gmm_results["confidences"]), 2, out_len
            )
            mode_prob = 1.0 * num_in_mode / num_in_mode.sum(dim=-1, keepdim=True)
            multi_mode_pred = {
                "mode_prob": mode_prob,
                "mode_center": mode_center,
                "confidences": gmm_results["confidences"],
                "mode_CI": mode_ci,
            }

        return mean_pred, prob_samples, multi_mode_pred
