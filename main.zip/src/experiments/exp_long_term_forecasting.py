import os
import random
import time
import warnings
from datetime import datetime

import json
import numpy as np
import optuna
import torch
import torch.nn as nn
from torch import optim

from src.data_provider.data_factory import data_provider
from src.experiments.exp_basic import Exp_Basic
from src.layers.M2Patch_layers import (
    _compute_patch_boundaries,
)
from src.utils.checkpoint import save_checkpoint, load_checkpoint, checkpoint_exists
from src.utils.cuda_accel import (
    cuda_accel_enabled,
    enable_cuda_accel,
    finalise_metrics_gpu,
    TorchStandardScaler,
)
from src.utils.metrics import metric
from src.utils.result_io import write_test_result
from src.utils.scheduler import adjust_learning_rate, build_scheduler
from src.utils.tools import EarlyStopping, visual

warnings.filterwarnings("ignore")


class Exp_Long_Term_Forecast(Exp_Basic):
    def __init__(self, args):
        super(Exp_Long_Term_Forecast, self).__init__(args)
        self._nan_detected = False
        enable_cuda_accel(getattr(args, "use_cuda_accel", 1) == 1)
        self._lambda_hyp = getattr(args, "lambda_hyp", 0.1)
        self._lambda_prior = getattr(args, "lambda_prior", 0.1)
        expl = getattr(args, "explanation", None)
        if expl == "all":
            self._explanation_groups = {"manifold", "training", "attribution"}
        elif expl in ("manifold", "training", "attribution"):
            self._explanation_groups = {expl}
        else:
            self._explanation_groups = set()
        self._loss_history = None
        if "training" in self._explanation_groups:
            self._loss_history = {
                "total": [],
                "bridge_dsm": [],
                "raw": [],
                "hyp_align": [],
                "prior": [],
                "vali_total": [],
                "vali_mse": [],
            }

    @property
    def _model_ref(self):
        return self.model.module if hasattr(self.model, "module") else self.model

    def _build_dec_inp(self, batch_y):
        if self.args.model == "M2Patch":
            return None
        dec_inp = torch.zeros(
            batch_y.shape[0],
            self.args.pred_len,
            batch_y.shape[2],
            device=batch_y.device,
            dtype=torch.float32,
        )
        return torch.cat([batch_y[:, : self.args.label_len, :], dec_inp], dim=1)

    def _forward_model(self, batch_x, batch_x_mark, dec_inp, batch_y_mark, batch_y_target=None):
        if self.args.model == "M2Patch" and batch_y_target is not None:
            raw = self.model(
                batch_x, batch_x_mark, dec_inp, batch_y_mark, y_true=batch_y_target
            )
        else:
            raw = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
        if isinstance(raw, tuple):
            return raw[0], raw[1]
        return raw, None

    def _compute_train_loss(self, batch_x, batch_y, batch_x_mark, batch_y_mark, dec_inp, criterion):
        f_dim = -1 if self.args.features == "MS" else 0
        batch_y_target = batch_y[:, -self.args.pred_len :, f_dim:]

        model_ref = self._model_ref
        if hasattr(model_ref, "compute_train_loss"):
            loss = model_ref.compute_train_loss(
                batch_x, batch_y_target, batch_x_mark, batch_y_mark
            )
            return self._add_auxiliary_loss(loss)

        outputs, latent_features = self._forward_model(
            batch_x,
            batch_x_mark,
            dec_inp,
            batch_y_mark,
            batch_y_target=batch_y_target,
        )

        outputs = outputs[:, -self.args.pred_len :, f_dim:]
        batch_y = batch_y_target

        if self.args.model == "M2Patch":
            if latent_features is None or latent_features.get("loss_total") is None:
                raise RuntimeError(
                    "M2Patch training requires the diffusion loss, but the model returned no loss_total. "
                    "Ensure batch_y_target is forwarded to _forward_model."
                )
            loss = latent_features["loss_total"]
            loss_dict = latent_features.get("loss_dict", {})
            if "training" in self._explanation_groups:
                self._loss_history["total"].append(loss.item())
                self._loss_history["bridge_dsm"].append(float(loss_dict["bridge_dsm"]))
                self._loss_history["raw"].append(float(loss_dict["raw"]))
                self._loss_history["hyp_align"].append(float(loss_dict["hyp"]))
                self._loss_history["prior"].append(float(loss_dict["prior"]))
        else:
            loss = criterion(outputs, batch_y)

        return self._add_auxiliary_loss(loss)

    def add_gaussian_noise(self, batch_x, noise_level=0.0):
        if noise_level <= 0:
            return batch_x

        noise = torch.randn_like(batch_x) * noise_level

        return batch_x + noise

    def _build_model(self):
        model_class = self.model_dict[self.args.model]
        model = model_class(self.args).float()

        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(
            "model_params: total={}, trainable={}".format(total_params, trainable_params)
        )

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        base_lr = self.args.learning_rate
        wd = getattr(self.args, "weight_decay", 0.0)
        optim_type = getattr(self.args, "optim", "Adam")

        # Models may provide a custom optimizer via build_optimizer(). This
        # keeps the optimizer choice model-driven instead of branching on
        # model names here.
        model_ref = self._model_ref
        if hasattr(model_ref, "build_optimizer"):
            return model_ref.build_optimizer(lr=base_lr, weight_decay=wd, optim_type=optim_type)

        if getattr(self.args, "use_8bit", 0) == 1:
            import bitsandbytes as bnb

            optim_cls = (
                bnb.optim.AdamW8bit if optim_type == "AdamW" else bnb.optim.Adam8bit
            )
        else:
            optim_cls = optim.AdamW if optim_type == "AdamW" else optim.Adam
        model_optim = optim_cls(self.model.parameters(), lr=base_lr, weight_decay=wd)
        return model_optim

    def _select_criterion(self):
        criterion = nn.MSELoss()
        return criterion

    def _add_auxiliary_loss(self, loss):
        model_ref = self._model_ref
        if hasattr(model_ref, "auxiliary_losses") and model_ref.auxiliary_losses:
            for w, aux in model_ref.auxiliary_losses:
                loss = loss + w * aux
        return loss

    def _prepare_batch_marks(self, batch_x_mark, batch_y_mark):
        if "PEMS" in self.args.data or "Solar" in self.args.data:
            return None, None
        return batch_x_mark.float().to(self.device), batch_y_mark.float().to(self.device)

    def vali(self, vali_data, vali_loader, criterion):
        total_loss_innovative = []
        total_loss_standard = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(
                vali_loader
            ):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()

                batch_x_mark, batch_y_mark = self._prepare_batch_marks(batch_x_mark, batch_y_mark)

                dec_inp = self._build_dec_inp(batch_y)
                if dec_inp is not None:
                    dec_inp = dec_inp.to(self.device)

                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        outputs, _ = self._forward_model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark,
                            batch_y_target=None,
                        )
                else:
                    outputs, _ = self._forward_model(
                        batch_x,
                        batch_x_mark,
                        dec_inp,
                        batch_y_mark,
                        batch_y_target=None,
                    )

                f_dim = -1 if self.args.features == "MS" else 0
                outputs = outputs[:, -self.args.pred_len :, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len :, f_dim:].to(self.device)

                if cuda_accel_enabled():
                    loss_std = criterion(outputs.detach(), batch_y.detach())
                else:
                    pred = outputs.detach().cpu()
                    true = batch_y.detach().cpu()
                    loss_std = criterion(pred, true)

                total_loss_standard.append(loss_std)
                total_loss_innovative.append(loss_std)

        if cuda_accel_enabled():
            std_tensors = [x if isinstance(x, torch.Tensor) else torch.tensor(x, device=self.device) for x in total_loss_standard]
            innov_tensors = [x if isinstance(x, torch.Tensor) else torch.tensor(x, device=self.device) for x in total_loss_innovative]
            avg_std = torch.stack(std_tensors).mean().item()
            avg_innov = torch.stack(innov_tensors).mean().item()
        else:
            avg_std = np.average([x.item() if isinstance(x, torch.Tensor) else x for x in total_loss_standard])
            avg_innov = np.average([x.item() if isinstance(x, torch.Tensor) else x for x in total_loss_innovative])

        self.model.train()
        return avg_innov, avg_std

    def train(self, setting):
        train_data, train_loader = self._get_data(flag="train")
        vali_data, vali_loader = self._get_data(flag="val")

        save_tmp = getattr(self.args, "save_tmp", 1)
        save_ckpt = bool(save_tmp) or int(getattr(self.args, "keep_checkpoint", 0)) == 1

        from src.utils.checkpoint import (
            _get_checkpoint_dir,
            _get_dataset_name,
            _get_next_seq,
            _ckpt_prefix,
        )

        ckpt_dir = _get_checkpoint_dir(self.args)
        os.makedirs(ckpt_dir, exist_ok=True)
        seq = _get_next_seq(self.args)
        prefix = _ckpt_prefix(self.args)
        best_model_path = os.path.join(ckpt_dir, f"{prefix}_{seq}.pth")
        self._active_ckpt_seq = seq

        if getattr(self.args, "checkpoint", 0) > 0:
            print(
                f"Loading checkpoint {_ckpt_prefix(self.args)}_{self.args.checkpoint}.pth for continued training"
            )
            load_checkpoint(self.args, self.model, self.args.checkpoint)

        time_now = time.time()

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(
            patience=self.args.patience, verbose=True, save_path=best_model_path
        )

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()

        scheduler = build_scheduler(model_optim, self.args, train_steps=train_steps)

        if self.args.use_amp:
            scaler = torch.cuda.amp.GradScaler()

        for epoch in range(self.args.train_epochs):
            iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()
            print(f"Epoch {epoch + 1} : LR {model_optim.param_groups[0]["lr"]:.8e}")
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(
                train_loader
            ):
                iter_count += 1
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                train_noise = getattr(self.args, "train_noise_level", 0.0)
                if train_noise > 0:
                    batch_x = self.add_gaussian_noise(batch_x, noise_level=train_noise)
                batch_x_mark, batch_y_mark = self._prepare_batch_marks(batch_x_mark, batch_y_mark)

                dec_inp = self._build_dec_inp(batch_y)

                loss = None
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        loss = self._compute_train_loss(
                            batch_x, batch_y, batch_x_mark, batch_y_mark, dec_inp, criterion
                        )
                else:
                    loss = self._compute_train_loss(
                        batch_x, batch_y, batch_x_mark, batch_y_mark, dec_inp, criterion
                    )

                if loss is not None and (torch.isnan(loss) or torch.isinf(loss)):
                    self._nan_detected = True
                    continue
                train_loss.append(loss.item())

                if (i + 1) % 100 == 0:
                    print(
                        "\titers: {0}, epoch: {1} | loss: {2:.7f}".format(
                            i + 1, epoch + 1, loss.item()
                        )
                    )
                    speed = (time.time() - time_now) / iter_count
                    if self.args.use_gpu and torch.cuda.is_available():
                        allocated_memory = torch.cuda.max_memory_allocated() / (
                            1024 * 1024 * 1024
                        )
                        print("allocated_memory:", allocated_memory)
                        torch.cuda.reset_peak_memory_stats()
                    left_time = speed * (
                        (self.args.train_epochs - epoch) * train_steps - i
                    )
                    print(
                        "\tspeed: {:.4f}s/iter; left time: {:.4f}s".format(
                            speed, left_time
                        )
                    )
                    iter_count = 0
                    time_now = time.time()

                if self.args.use_amp:
                    scaler.scale(loss).backward()
                    max_grad_norm = getattr(self.args, "max_grad_norm", 0.0)
                    if max_grad_norm > 0:
                        scaler.unscale_(model_optim)
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(), max_grad_norm
                        )
                    scaler.step(model_optim)
                    scaler.update()
                else:
                    loss.backward()
                    max_grad_norm = getattr(self.args, "max_grad_norm", 0.0)
                    if max_grad_norm > 0:
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(), max_grad_norm
                        )
                    model_optim.step()
                model_ref = self._model_ref
                if hasattr(model_ref, "post_step"):
                    model_ref.post_step()
                if self.args.lradj == "onecycle":
                    scheduler.step()

            if scheduler is not None and self.args.lradj != "onecycle":
                scheduler.step()
            if self.args.lradj in ("type1", "type2", "sigmoid"):
                adjust_learning_rate(model_optim, epoch + 1, self.args)
            print("Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)
            if self._nan_detected:
                print(
                    f"NaN/Inf detected during epoch {epoch + 1}, treating as worst validation loss"
                )
                self._nan_detected = False
                vali_loss_innov = float("inf")
                vali_loss_std = float("inf")
            else:
                vali_loss_innov, vali_loss_std = self.vali(vali_data, vali_loader, criterion)

            if self._loss_history is not None and "training" in self._explanation_groups:
                self._loss_history["vali_total"].append(vali_loss_innov)
                self._loss_history["vali_mse"].append(vali_loss_std)

            if self.args.model == "M2Patch":
                print(
                    "Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f} Vali MSE: {4:.7f}".format(
                        epoch + 1, train_steps, train_loss, vali_loss_innov, vali_loss_std
                    )
                )
            else:
                print(
                    "Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f}".format(
                        epoch + 1, train_steps, train_loss, vali_loss_innov
                    )
                )
            optuna_trial = getattr(self.args, "optuna_trial", None)
            if optuna_trial is not None:
                optuna_trial.report(float(vali_loss_std), step=epoch + 1)
                if not optuna_trial.user_attrs.get("warm_start") and optuna_trial.should_prune():
                    raise optuna.TrialPruned(f"pruned_at_epoch_{epoch + 1}")

            early_stopping(vali_loss_innov, self.model, best_model_path)
            if early_stopping.early_stop:
                print("Early stopping")
                break

        if best_model_path is not None and os.path.exists(best_model_path):
            self.model.load_state_dict(
                torch.load(best_model_path, map_location=self.device)
            )
            if save_ckpt:
                save_checkpoint(self.args, self.model, seq=seq)
            self._last_checkpoint_seq = seq
        else:
            self._last_checkpoint_seq = None

        self._lr_checkpoint_to_cleanup = (
            seq
            if (
                getattr(self.args, "low_rank", 0) > 0
                or not save_ckpt
                or int(getattr(self.args, "cleanup_checkpoint", 0)) == 1
            )
            and self._last_checkpoint_seq is not None
            and not int(getattr(self.args, "keep_checkpoint", 0))
            else None
        )

        if self._loss_history is not None and "training" in self._explanation_groups:
            metrics_dir = os.path.join("./output/explanation/metrics", self._get_output_subdir())
            os.makedirs(metrics_dir, exist_ok=True)
            with open(os.path.join(metrics_dir, "loss_history.json"), "w") as f:
                json.dump(self._loss_history, f, indent=2)
            print(f"[explanation] Loss history saved ({len(self._loss_history["total"])} iters)")

        return self.model

    def test(self, setting, test=0):
        save_tmp = getattr(self.args, "save_tmp", 1)
        test_data, test_loader = self._get_data(flag="test")
        if test:
            print("loading model")
            if getattr(self.args, "checkpoint", 0) > 0:
                load_checkpoint(self.args, self.model, self.args.checkpoint)
            else:
                checkpoint_path = self._get_checkpoint_path(setting)
                self.model.load_state_dict(
                    torch.load(os.path.join(checkpoint_path, "checkpoint.pth"))
                )

        preds = []
        trues = []
        _gpu_preds = []
        _gpu_trues = []
        _gpu_scaler = None
        if cuda_accel_enabled() and test_data.scale and self.args.inverse:
            _gpu_scaler = TorchStandardScaler.from_dataset(
                test_data, device=self.device
            )
        folder_path = None
        if save_tmp:
            folder_path = self._get_test_results_path(setting)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)

        self.model.eval()

        explanation_active = bool(self._explanation_groups)
        _explanation_collected = False

        if explanation_active:
            model_ref = self._model_ref
            if hasattr(model_ref, "backbone"):
                model_ref.backbone._explanation_mode = True

        with torch.no_grad():
            _infer_total = 0.0
            _infer_iters = 0
            _infer_warmup = min(5, max(0, len(test_loader) - 1))
            _cuda_sync = bool(
                getattr(self.args, "use_gpu", False) and torch.cuda.is_available()
            )
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(
                test_loader
            ):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                if self.args.noise_level > 0:
                    batch_x = self.add_gaussian_noise(
                        batch_x, noise_level=self.args.noise_level
                    )
                batch_x_mark, batch_y_mark = self._prepare_batch_marks(batch_x_mark, batch_y_mark)

                dec_inp = self._build_dec_inp(batch_y)

                _timed = i >= _infer_warmup
                if _cuda_sync:
                    torch.cuda.synchronize()
                _infer_start = time.perf_counter() if _timed else None
                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        outputs, _ = self._forward_model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark,
                            batch_y_target=None,
                        )
                else:
                    outputs, _ = self._forward_model(
                        batch_x,
                        batch_x_mark,
                        dec_inp,
                        batch_y_mark,
                        batch_y_target=None,
                    )
                if _cuda_sync:
                    torch.cuda.synchronize()
                if _timed:
                    _infer_total += time.perf_counter() - _infer_start
                    _infer_iters += 1

                if explanation_active and not _explanation_collected:
                    self._save_explanation_metrics(
                        setting, batch_x, outputs, batch_y)
                    _explanation_collected = True

                f_dim = -1 if self.args.features == "MS" else 0
                outputs = outputs[:, -self.args.pred_len :, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len :, f_dim:].to(self.device)

                if cuda_accel_enabled():
                    if _gpu_scaler is not None:
                        shape = outputs.shape
                        outputs = _gpu_scaler.inverse_transform(
                            outputs.float().reshape(-1, outputs.shape[-1])
                        ).reshape(shape)
                        batch_y = _gpu_scaler.inverse_transform(
                            batch_y.float().reshape(-1, batch_y.shape[-1])
                        ).reshape(shape)
                    _gpu_preds.append(outputs.detach().float())
                    _gpu_trues.append(batch_y.detach().float())
                else:
                    outputs = outputs.detach().cpu().numpy()
                    batch_y = batch_y.detach().cpu().numpy()
                    if test_data.scale and self.args.inverse:
                        shape = outputs.shape
                        outputs = test_data.inverse_transform(
                            outputs.reshape(-1, shape[-1])
                        ).reshape(shape)
                        batch_y = test_data.inverse_transform(
                            batch_y.reshape(-1, shape[-1])
                        ).reshape(shape)

                    pred = outputs
                    true = batch_y

                    preds.append(pred)
                    trues.append(true)

            if i % 20 == 0:
                input = batch_x.detach().cpu().numpy()
                if test_data.scale and self.args.inverse and not cuda_accel_enabled():
                    shape = input.shape
                    input = test_data.inverse_transform(input.reshape(-1, shape[-1])).reshape(shape)
                elif test_data.scale and self.args.inverse and _gpu_scaler is not None:
                    shape = input.shape
                    input_t = _gpu_scaler.inverse_transform(
                        batch_x.float().reshape(-1, batch_x.shape[-1])
                    ).reshape(shape)
                    input = input_t.cpu().numpy()
                if cuda_accel_enabled():
                    gt_np = np.concatenate(
                        (input[0, :, -1], _gpu_trues[-1][-1, :, -1].cpu().numpy()),
                        axis=0,
                    )
                    pd_np = np.concatenate(
                        (input[0, :, -1], _gpu_preds[-1][-1, :, -1].cpu().numpy()),
                        axis=0,
                    )
                else:
                    gt = np.concatenate((input[0, :, -1], true[0, :, -1]), axis=0)
                    pd = np.concatenate((input[0, :, -1], pred[0, :, -1]), axis=0)
                    gt_np, pd_np = gt, pd
                if folder_path is not None:
                    visual(gt_np, pd_np, os.path.join(folder_path, str(i) + ".png"))

        if _infer_iters:
            print(
                "inference_speed: {:.6f}s/iter".format(_infer_total / _infer_iters)
            )

        if cuda_accel_enabled():
            (mae, mse, rmse, mape, mspe), preds, trues = finalise_metrics_gpu(
                _gpu_preds, _gpu_trues
            )
            print("test shape:", preds.shape, trues.shape)
            preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
            trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
            print("test shape:", preds.shape, trues.shape)
        else:
            preds = np.array(preds)
            trues = np.array(trues)
            print("test shape:", preds.shape, trues.shape)
            preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
            trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
            print("test shape:", preds.shape, trues.shape)

            mae, mse, rmse, mape, mspe = metric(preds, trues)
        print("mse:{}, mae:{}".format(mse, mae))

        if save_tmp:
            folder_path = self._get_results_path(setting)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)

        check_seq = getattr(self, "_last_checkpoint_seq", None)
        if check_seq is None:
            check_seq = getattr(self.args, "checkpoint", 0)
        write_test_result(self.args, setting, mse, mae, checkpoint=check_seq)

        file_prefix = f"{self.args.model}_{self.args.seq_len}_{self.args.pred_len}"
        if save_tmp:
            np.save(
                os.path.join(folder_path, f"{file_prefix}_metrics.npy"),
                np.array([mae, mse, rmse, mape, mspe]),
            )
            np.save(os.path.join(folder_path, f"{file_prefix}_pred.npy"), preds)
            np.save(os.path.join(folder_path, f"{file_prefix}_true.npy"), trues)

        self._last_test_result = {"mse": float(mse), "mae": float(mae)}

        return {"mae": mae, "mse": mse, "rmse": rmse, "mape": mape, "mspe": mspe}

    def _save_explanation_metrics(self, setting, batch_x, outputs, batch_y):
        model_ref = self._model_ref
        if self.args.model != "M2Patch" or not hasattr(model_ref, "backbone"):
            return

        subdir = self._get_output_subdir()
        metrics_dir = os.path.join("./output/explanation/metrics", subdir)
        os.makedirs(metrics_dir, exist_ok=True)
        backbone = model_ref.backbone
        seq_len = int(batch_x.shape[1])
        patch_len = getattr(self.args, "patch_len", 16)
        stride = getattr(self.args, "stride", 8)

        meta = {
            "setting": subdir,
            "dataset": self.args.data,
            "model": self.args.model,
            "seq_len": seq_len,
            "pred_len": self.args.pred_len,
            "enc_in": self.args.enc_in,
            "d_model": self.args.d_model,
            "d_hyp": getattr(self.args, "d_hyp", 64),
            "manifold_c": getattr(self.args, "manifold_c", 1.0),
            "patch_len": patch_len,
            "stride": stride,
            "e_layers": self.args.e_layers,
            "d_layers_diff": getattr(self.args, "d_layers_diff", 2),
            "diff_steps": getattr(self.args, "diff_steps", 2),
            "diff_schedule": getattr(self.args, "diff_schedule", "cosine"),
            "diff_eta": getattr(self.args, "diff_eta", 0.0),
            "lambda_hyp": self._lambda_hyp,
            "lambda_prior": self._lambda_prior,
            "train_epochs": self.args.train_epochs,
            "explanation_groups": sorted(self._explanation_groups),
            "timestamp": datetime.now().isoformat(),
        }
        with open(os.path.join(metrics_dir, "meta.json"), "w") as f:
            json.dump(meta, f, indent=4)

        groups = self._explanation_groups

        if "manifold" in groups or "attribution" in groups:
            np.save(os.path.join(metrics_dir, "input_raw.npy"),
                    batch_x.detach().cpu().numpy())
            boundaries = _compute_patch_boundaries(seq_len, patch_len, stride)
            with open(os.path.join(metrics_dir, "patch_boundaries.json"), "w") as f:
                json.dump({"patch_len": patch_len, "stride": stride, "boundaries": boundaries}, f, indent=2)

        if "manifold" in groups:
            latent_data = getattr(backbone, "_captured_latent", None)
            if latent_data is not None:
                for key, val in latent_data.items():
                    if isinstance(val, torch.Tensor):
                        np.save(os.path.join(metrics_dir, f"{key}.npy"), val.detach().cpu().numpy())

        if "attribution" in groups:
            np.save(os.path.join(metrics_dir, "final_output.npy"),
                    outputs.detach().cpu().numpy())
            np.save(os.path.join(metrics_dir, "ground_truth.npy"),
                    batch_y.detach().cpu().numpy())
            self._compute_and_save_attribution(metrics_dir, batch_x)

        print(f"[explanation] Metrics saved to {metrics_dir} (groups: {sorted(groups)})")

    def _compute_and_save_attribution(self, metrics_dir, batch_x):
        model_ref = self._model_ref
        model_ref.zero_grad()
        with torch.enable_grad():
            batch_x_grad = batch_x.clone().detach().requires_grad_(True)
            output, aux = model_ref(batch_x_grad, None, None, None)
            z_fut = aux.get("z_fut_hyp") if isinstance(aux, dict) else None
            f_dim = -1 if self.args.features == "MS" else 0
            output[:, -self.args.pred_len :, f_dim:].sum().backward(
                retain_graph=z_fut is not None
            )
            if batch_x_grad.grad is not None:
                attr = batch_x_grad.grad.abs().sum(dim=-1).detach().cpu().numpy()
                np.save(os.path.join(metrics_dir, "attribution_input.npy"), attr)
                patch_len = getattr(self.args, "patch_len", 16)
                stride = getattr(self.args, "stride", 8)
                boundaries = _compute_patch_boundaries(attr.shape[1], patch_len, stride)
                patch_attr = np.stack(
                    [attr[:, left:right].mean(axis=-1) for left, right in boundaries],
                    axis=-1,
                )
                np.save(os.path.join(metrics_dir, "attribution_patches.npy"), patch_attr)
            if z_fut is not None:
                model_ref.zero_grad()
                batch_x_grad.grad = None
                z_fut.float().pow(2).sum().backward()
                if batch_x_grad.grad is not None:
                    hyp_attr = batch_x_grad.grad.abs().sum(dim=-1).detach().cpu().numpy()
                    np.save(os.path.join(metrics_dir, "attribution_manifold.npy"), hyp_attr)
        model_ref.zero_grad()

    def get_input(self, setting):
        test_data, test_loader = self._get_data(flag="test")
        inputs = []
        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
            input = batch_x.detach().cpu().numpy()
            inputs.append((input))
        folder_path = self._get_results_path(setting)
        np.save(folder_path + "input.npy", inputs)

    def predict(self, setting, load=False):
        pred_data, pred_loader = self._get_data(flag="pred")

        if load:
            if getattr(self.args, "checkpoint", 0) > 0:
                load_checkpoint(self.args, self.model, self.args.checkpoint)
            else:
                checkpoint_path = self._get_checkpoint_path(setting)
                best_model_path = os.path.join(checkpoint_path, "checkpoint.pth")
                self.model.load_state_dict(torch.load(best_model_path))

        preds = []

        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(
                pred_loader
            ):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                dec_inp = self._build_dec_inp(batch_y)
                if dec_inp is not None:
                    dec_inp = dec_inp.to(self.device)

                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        outputs, _ = self._forward_model(
                            batch_x, batch_x_mark, dec_inp, batch_y_mark
                        )
                else:
                    outputs, _ = self._forward_model(
                        batch_x, batch_x_mark, dec_inp, batch_y_mark
                    )

                outputs = outputs.detach().cpu().numpy()
                if pred_data.scale and self.args.inverse:
                    shape = outputs.shape
                    outputs = pred_data.inverse_transform(outputs.squeeze(0)).reshape(
                        shape
                    )
                preds.append(outputs)

        preds = np.array(preds)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])

        folder_path = self._get_results_path(setting)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        np.save(folder_path + "real_prediction.npy", preds)

        return
