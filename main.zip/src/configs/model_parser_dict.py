from src.configs.common import add_common_args
from src.configs.custom_S_Mamba import add_s_mamba_parser
from src.configs.custom_PatchTST import add_patchtst_parser
from src.configs.custom_DLinear import add_dlinear_parser
from src.configs.custom_BiMamba4TS import add_bimamba4ts_parser
from src.configs.custom_M2Patch import add_m2patch_parser
from src.configs.custom_Crossformer import add_crossformer_parser
from src.configs.custom_TimesNet import add_timesnet_parser
from src.configs.custom_TiDE import add_tide_parser
from src.configs.custom_TimeMixer import add_timemixer_parser
from src.configs.custom_DisenTS import add_disents_parser
from src.configs.custom_MMPD import add_mmpd_parser
from src.configs.custom_SimpleTM import add_simpletm_parser

model_parser_dict = {
    "__all__": [add_common_args],
    "Transformer": [],
    "Informer": [],
    "Reformer": [],
    "Flowformer": [],
    "Flashformer": [],
    "Autoformer": [],
    "S_Mamba": [add_s_mamba_parser],
    "PatchTST": [add_patchtst_parser],
    "DLinear": [add_dlinear_parser],
    "BiMamba4TS": [add_bimamba4ts_parser],
    "iTransformer": [],
    "M2Patch": [add_m2patch_parser],
    "Crossformer": [add_crossformer_parser],
    "TimesNet": [add_timesnet_parser],
    "TiDE": [add_tide_parser],
    "TimeMixer": [add_timemixer_parser],
    "DisenTS": [add_disents_parser],
    "MMPD": [add_mmpd_parser],
    "SimpleTM": [add_simpletm_parser],
}

model_aliases = {
    "Transformer": "Transformer",
    "Informer": "Informer",
    "Reformer": "Reformer",
    "Flowformer": "Flowformer",
    "Flashformer": "Flashformer",
    "Autoformer": "Autoformer",
    "S_Mamba": "S_Mamba",
    "PatchTST": "PatchTST",
    "DLinear": "DLinear",
    "BiMamba4TS": "BiMamba4TS",
    "iTransformer": "iTransformer",
    "M2Patch": "M2Patch",
    "Crossformer": "Crossformer",
    "TimesNet": "TimesNet",
    "TiDE": "TiDE",
    "TimeMixer": "TimeMixer",
    "DisenTS": "DisenTS",
    "MMPD": "MMPD",
    "SimpleTM": "SimpleTM",
}
