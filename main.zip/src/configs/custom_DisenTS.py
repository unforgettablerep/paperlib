def add_disents_parser(parser):
    """Add DisenTS model-specific parameters to the parser."""

    parser.add_argument(
        "--disen_backbone",
        type=str,
        default="DLinear",
        help="backbone forecaster in the expert pool: DLinear or PatchTST",
    )
    parser.add_argument(
        "--disen_times",
        type=int,
        default=4,
        help="number of disentangled forecasting experts",
    )
    parser.add_argument(
        "--is_RevIN",
        type=int,
        default=1,
        help="apply RevIN at the DisenTS framework level (1/0)",
    )
    parser.add_argument(
        "--similar_weight",
        type=float,
        default=0.01,
        help="weight of the Similarity Constraint loss",
    )
    parser.add_argument(
        "--sample_num",
        type=int,
        default=128,
        help="number of samples used to estimate the approximated forecaster state",
    )
    parser.add_argument(
        "--d_gate",
        type=int,
        default=64,
        help="hidden dimension of the Forecaster Aware Gate",
    )

    parser.add_argument(
        "--individual",
        type=int,
        default=0,
        help="DLinear backbone: per-channel linear layers (1/0). "
        "DisenTS LWA requires channel-independent backbone, keep 0.",
    )

    parser.add_argument(
        "--patch_len", type=int, default=16, help="PatchTST backbone: patch length"
    )
    parser.add_argument(
        "--stride", type=int, default=8, help="PatchTST backbone: patch stride"
    )
    parser.add_argument(
        "--padding_patch",
        type=str,
        default="end",
        help="PatchTST backbone: padding mode",
    )
    parser.add_argument(
        "--fc_dropout",
        type=float,
        default=0.05,
        help="PatchTST backbone: fully connected dropout",
    )
    parser.add_argument(
        "--head_dropout",
        type=float,
        default=0.0,
        help="PatchTST backbone: head dropout",
    )
    parser.add_argument(
        "--tst_individual",
        type=int,
        default=0,
        help="PatchTST backbone: individual head (1/0)",
    )
    parser.add_argument(
        "--decomposition",
        type=int,
        default=0,
        help="PatchTST backbone: enable trend/seasonal decomposition (1/0)",
    )
    parser.add_argument(
        "--kernel_size",
        type=int,
        default=25,
        help="PatchTST backbone: decomposition moving-average kernel",
    )
