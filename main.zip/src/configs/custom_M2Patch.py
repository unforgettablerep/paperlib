from src.configs.m2patch_profiles import CONSTANTS
from src.ablation.registry import ABLATION_CHOICES


def add_m2patch_parser(parser):
    parser.add_argument(
        "--patch_len",
        type=int,
        default=CONSTANTS["patch_len"],
        help="Causal history patch length",
    )
    parser.add_argument(
        "--stride",
        type=int,
        default=CONSTANTS["stride"],
        help="Causal history patch stride (left-tail padding only)",
    )
    parser.add_argument(
        "--d_hyp",
        type=int,
        default=CONSTANTS["d_hyp"],
        help="Poincare ball hyperbolic manifold dimension",
    )
    parser.add_argument(
        "--manifold_c",
        type=float,
        default=CONSTANTS["manifold_c"],
        help="Constant negative curvature parameter c > 0 of the Poincare ball",
    )
    parser.add_argument(
        "--d_layers_diff",
        type=int,
        default=CONSTANTS["d_layers_diff"],
        help="Number of conditional diffusion denoiser layers",
    )
    parser.add_argument(
        "--diff_steps",
        type=int,
        default=CONSTANTS["diff_steps"],
        help="Number of deterministic prior-bridge DDIM sampling steps K >= 1",
    )
    parser.add_argument(
        "--diff_schedule",
        type=str,
        default=CONSTANTS["diff_schedule"],
        choices=["cosine", "linear"],
        help="VP-SDE noise schedule for the prior bridge",
    )
    parser.add_argument(
        "--diff_eta",
        type=float,
        default=CONSTANTS["diff_eta"],
        help="DDIM stochasticity coefficient (0.0 = fully deterministic)",
    )
    parser.add_argument(
        "--lambda_hyp",
        type=float,
        default=CONSTANTS["lambda_hyp"],
        help="Weight of the Poincare geodesic denoising alignment loss",
    )
    parser.add_argument(
        "--lambda_prior",
        type=float,
        default=CONSTANTS["lambda_prior"],
        help="Weight of the historical causal prior anchor loss",
    )
    parser.add_argument(
        "--revin",
        type=int,
        default=CONSTANTS["revin"],
        help="Use history-only RevIN normalization (1=yes, 0=no)",
    )
    parser.add_argument(
        "--lradj",
        type=str,
        default=CONSTANTS["lradj"],
        help="Learning rate scheduler: onecycle (default for M2Patch)",
    )
    parser.add_argument(
        "--optim",
        type=str,
        default=CONSTANTS["optim"],
        help="Optimizer type: Adam (default for M2Patch) or AdamW",
    )
    parser.add_argument(
        "--pct_start",
        type=float,
        default=CONSTANTS["pct_start"],
        help="pct_start for OneCycleLR (default 0.2)",
    )
    parser.add_argument(
        "--ablation",
        type=str,
        default="none",
        choices=ABLATION_CHOICES,
        help="Ablation group resolved by src.ablation.registry.resolve_ablation",
    )
