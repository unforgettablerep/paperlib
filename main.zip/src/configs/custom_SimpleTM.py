def add_simpletm_parser(parser):
    parser.add_argument(
        "--d_model",
        type=int,
        default=32,
        help="dimension of the pseudo temporal tokens",
    )
    parser.add_argument(
        "--d_ff",
        type=int,
        default=32,
        help="dimension of the feed-forward network",
    )
    parser.add_argument(
        "--e_layers",
        type=int,
        default=1,
        help="number of SimpleTM layers",
    )
    parser.add_argument(
        "--geomattn_dropout",
        type=float,
        default=0.5,
        help="dropout rate of the projection layers in geometric attention",
    )
    parser.add_argument(
        "--wv",
        type=str,
        default="db1",
        help="wavelet filter used by the stationary wavelet transform",
    )
    parser.add_argument(
        "--wavelet_levels",
        type=int,
        default=3,
        help="number of stationary wavelet decomposition levels",
    )
    parser.add_argument(
        "--kernel_size",
        type=int,
        default=None,
        help="length of randomly initialized wavelets (None uses the PyWavelets filter bank)",
    )
    parser.add_argument(
        "--alpha",
        type=float,
        default=1.0,
        help="weight of the wedge-product score in geometric attention",
    )
    parser.add_argument(
        "--l1_weight",
        type=float,
        default=5e-5,
        help="weight of the attention-statistic L1 regularizer",
    )
    parser.add_argument(
        "--requires_grad",
        type=int,
        default=1,
        help="make the wavelet filters learnable (1/0)",
    )
    parser.add_argument(
        "--optim",
        type=str,
        default="AdamW",
        help="optimizer type: AdamW (default for SimpleTM) or Adam",
    )
    parser.add_argument(
        "--lradj",
        type=str,
        default="type1",
        help="learning rate scheduler: type1 (default for SimpleTM)",
    )
