def add_tide_parser(parser):
    parser.add_argument(
        "--hidden_size",
        type=int,
        default=256,
        help="hidden size of each DNN residual layer in TiDE",
    )
    parser.add_argument(
        "--num_layers",
        type=int,
        default=2,
        help="number of encoder DNN residual layers in TiDE",
    )
    parser.add_argument(
        "--decoder_output_dim",
        type=int,
        default=8,
        help="decoder output dimension multiplier in TiDE",
    )
    parser.add_argument(
        "--final_decoder_hidden",
        type=int,
        default=64,
        help="final decoder hidden dimension in TiDE",
    )
    parser.add_argument(
        "--time_encoder_hidden",
        type=int,
        default=64,
        help="hidden dimension of the time feature encoder in TiDE",
    )
    parser.add_argument(
        "--tide_layer_norm",
        action="store_true",
        default=False,
        help="use layer normalization in TiDE residual blocks",
    )
    parser.add_argument(
        "--tide_dropout",
        type=float,
        default=0.0,
        help="dropout rate for TiDE residual blocks",
    )
    parser.add_argument(
        "--tide_transform",
        action="store_true",
        default=False,
        help="apply reversible affine transform in TiDE",
    )
