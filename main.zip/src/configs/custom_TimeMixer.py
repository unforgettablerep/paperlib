def add_timemixer_parser(parser):
    """Add TimeMixer model-specific parameters to the parser."""
    parser.add_argument(
        "--channel_independence",
        type=int,
        default=1,
        help="whether to use channel_independence mechanism (TimeMixer)",
    )
    parser.add_argument(
        "--down_sampling_layers",
        type=int,
        default=3,
        help="num of down sampling layers",
    )
    parser.add_argument(
        "--down_sampling_window",
        type=int,
        default=2,
        help="down sampling window size",
    )
    parser.add_argument(
        "--down_sampling_method",
        type=str,
        default="avg",
        help="down sampling method: avg/max/conv",
    )
    parser.add_argument(
        "--decomp_method",
        type=str,
        default="moving_avg",
        help="series decomposition method: moving_avg/dft_decomp",
    )
    parser.add_argument(
        "--top_k",
        type=int,
        default=5,
        help="top-k freq for dft_decomp",
    )
    parser.add_argument(
        "--use_future_temporal_feature",
        type=int,
        default=0,
        help="whether to use future temporal features",
    )
    parser.add_argument(
        "--use_norm",
        type=int,
        default=1,
        help="whether to use normalize; True 1 False 0",
    )
