def add_mmpd_parser(parser):
    parser.add_argument(
        "--mmpd_backbone",
        type=str,
        default="Decoder",
        choices=["Decoder", "EncoderDecoder"],
        help="MMPD backbone: decoder-only transformer or encoder-decoder transformer",
    )
    parser.add_argument(
        "--patch_size",
        type=int,
        default=12,
        help="length of each future patch modelled by the diffusion loss",
    )
    parser.add_argument(
        "--d_diffusion",
        type=int,
        default=256,
        help="hidden dimension of the patch-consistent diffusion MLP",
    )
    parser.add_argument(
        "--diffusion_layers",
        type=int,
        default=1,
        help="number of diffusion denoiser MLP blocks",
    )
    parser.add_argument(
        "--max_diffusion_steps",
        type=int,
        default=1000,
        help="number of diffusion training timesteps",
    )
    parser.add_argument(
        "--beta_schedule",
        type=str,
        default="linear",
        choices=["linear", "cosine"],
        help="noise schedule of the diffusion process",
    )
    parser.add_argument(
        "--radius",
        type=int,
        default=3,
        help="radius of adjacent patches used by the patch-consistent MLP",
    )
    parser.add_argument(
        "--point_weight",
        type=float,
        default=0.01,
        help="weight of the point-prediction regularizer in the MMPD loss",
    )
    parser.add_argument(
        "--weighted",
        type=int,
        default=1,
        help="weight the per-instance MMPD loss by the input variance (1/0)",
    )
    parser.add_argument(
        "--sample_num",
        type=int,
        default=100,
        help="number of diffusion samples for expectation/multi-mode inference",
    )
    parser.add_argument(
        "--num_sampling_steps",
        type=str,
        default="20",
        help="number of reverse-diffusion steps used by the sampling path",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="temperature scaling of diffusion sampling",
    )
    parser.add_argument(
        "--mmpd_sample_expectation",
        type=int,
        default=0,
        help="use the multi-sample expectation instead of the deterministic anchor prediction (1/0)",
    )
    parser.add_argument(
        "--gmm_components",
        type=int,
        default=10,
        help="maximum number of components in the variational GMM",
    )
    parser.add_argument(
        "--prior_pi_decay",
        type=float,
        default=0.5,
        help="Dirichlet prior decay of the variational GMM mixture weights",
    )
    parser.add_argument(
        "--prior_precision_shape",
        type=float,
        default=1e2,
        help="Gamma prior shape of the variational GMM precision",
    )
    parser.add_argument(
        "--gmm_iterations",
        type=int,
        default=10,
        help="EM iterations of the variational GMM at each diffusion step",
    )
    parser.add_argument(
        "--n_heads",
        type=int,
        default=4,
        help="number of attention heads in the backbone transformer",
    )
    parser.add_argument(
        "--d_layers",
        type=int,
        default=2,
        help="number of transformer layers in the backbone",
    )
    parser.add_argument(
        "--dropout",
        type=float,
        default=0.2,
        help="dropout rate",
    )
