import argparse
import sys

from src.configs.m2patch_profiles import (
    get_pred_lens,
    get_tier,
    list_datasets,
    to_cli_string,
    to_cli_string_from_optuna,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Emit M2Patch CLI flags for a (dataset, pred_len) pair.",
        usage="python -m src.configs.m2patch_cli [dataset] [pred_len] [options]",
    )
    parser.add_argument("dataset", nargs="?", help="Dataset name (e.g. ETTh1)")
    parser.add_argument("pred_len", nargs="?", type=int, help="Prediction horizon")
    parser.add_argument(
        "--with-meta", action="store_true",
        help="Include dataset metadata flags (root_path, data_path, enc_in, etc.)",
    )
    parser.add_argument(
        "--list-datasets", action="store_true",
        help="List all supported dataset names and exit",
    )
    parser.add_argument(
        "--pred-lens", action="store_true",
        help="List pred_lens for the given dataset and exit",
    )
    parser.add_argument(
        "--tier", action="store_true",
        help="Print the informational complexity tier for the given dataset and exit",
    )
    parser.add_argument(
        "--from-optuna", action="store_true",
        help="Read best_params from output/optuna/M2Patch_{ds}_pl{pl}_best_params.json "
        "instead of the frozen _PROFILE dict. Falls back to the nearest shorter "
        "standard horizon when an exact pred_len JSON is missing.",
    )
    parser.add_argument(
        "--optuna-dir", default="./output/optuna",
        help="Directory holding M2Patch_*_best_params.json (default: ./output/optuna)",
    )
    args = parser.parse_args()

    if args.list_datasets:
        for dataset in list_datasets():
            print(dataset)
        return

    if args.dataset is None:
        parser.error("dataset is required (unless --list-datasets)")

    if args.pred_lens:
        for pred_len in get_pred_lens(args.dataset):
            print(pred_len)
        return

    if args.tier:
        print(get_tier(args.dataset))
        return

    if args.pred_len is None:
        parser.error("pred_len is required (unless --pred-lens / --tier / --list-datasets)")

    if args.from_optuna:
        try:
            print(
                to_cli_string_from_optuna(
                    args.dataset, args.pred_len,
                    with_meta=args.with_meta, optuna_dir=args.optuna_dir,
                )
            )
        except (FileNotFoundError, KeyError) as exc:
            print("ERROR: {}".format(exc), file=sys.stderr)
            sys.exit(1)
    else:
        print(to_cli_string(args.dataset, args.pred_len, with_meta=args.with_meta))


if __name__ == "__main__":
    main()
    sys.exit(0)
