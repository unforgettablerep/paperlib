import json
import os
from typing import Any

from src.utils.result_io import canonical_dataset

D_FF_CAP = 768

CONSTANTS: dict[str, Any] = {
    "patch_len": 16,
    "stride": 8,
    "d_hyp": 64,
    "manifold_c": 1.0,
    "d_layers_diff": 2,
    "diff_steps": 1,
    "diff_schedule": "cosine",
    "diff_eta": 0.0,
    "lambda_hyp": 0.1,
    "lambda_prior": 0.1,
    "dropout": 0.1,
    "pct_start": 0.2,
    "patience": 5,
    "train_epochs": 15,
    "batch_size": 32,
    "optim": "Adam",
    "lradj": "onecycle",
    "revin": 1,
    "affine": 0,
}

DATASET_TIER: dict[str, str] = {
    "ETTh1": "low",
    "ETTh2": "med",
    "ETTm1": "low",
    "ETTm2": "med",
    "Weather": "low",
    "ECL": "low",
    "Exchange": "med",
    "Traffic": "med",
    "Solar": "low",
    "Illness": "tiny",
    "PEMS03": "low",
    "PEMS04": "low",
    "PEMS07": "low",
    "PEMS08": "low",
}

DATASET_META: dict[str, dict[str, Any]] = {
    "ETTh1": {
        "root_path": "./data/ETT-small/",
        "data_path": "ETTh1.csv",
        "data": "ETTh1",
        "model_id_prefix": "ETTh1",
        "enc_in": 7,
        "c_out": 7,
        "features": "M",
        "freq": "h",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 17420,
        "use_cuda_accel": 0,
    },
    "ETTh2": {
        "root_path": "./data/ETT-small/",
        "data_path": "ETTh2.csv",
        "data": "ETTh2",
        "model_id_prefix": "ETTh2",
        "enc_in": 7,
        "c_out": 7,
        "features": "M",
        "freq": "h",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 17420,
        "use_cuda_accel": 0,
    },
    "ETTm1": {
        "root_path": "./data/ETT-small/",
        "data_path": "ETTm1.csv",
        "data": "ETTm1",
        "model_id_prefix": "ETTm1",
        "enc_in": 7,
        "c_out": 7,
        "features": "M",
        "freq": "t",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 69680,
        "use_cuda_accel": 0,
    },
    "ETTm2": {
        "root_path": "./data/ETT-small/",
        "data_path": "ETTm2.csv",
        "data": "ETTm2",
        "model_id_prefix": "ETTm2",
        "enc_in": 7,
        "c_out": 7,
        "features": "M",
        "freq": "t",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 69680,
        "use_cuda_accel": 0,
    },
    "Weather": {
        "root_path": "./data/weather/",
        "data_path": "weather.csv",
        "data": "custom",
        "model_id_prefix": "weather",
        "enc_in": 21,
        "c_out": 21,
        "features": "M",
        "freq": "t",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 52696,
        "use_cuda_accel": 0,
    },
    "ECL": {
        "root_path": "./data/electricity/",
        "data_path": "electricity.csv",
        "data": "custom",
        "model_id_prefix": "ECL",
        "enc_in": 321,
        "c_out": 321,
        "features": "M",
        "freq": "h",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 26304,
        "use_cuda_accel": 0,
    },
    "Exchange": {
        "root_path": "./data/exchange_rate/",
        "data_path": "exchange_rate.csv",
        "data": "custom",
        "model_id_prefix": "Exchange",
        "enc_in": 8,
        "c_out": 8,
        "features": "M",
        "freq": "d",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 7588,
        "use_cuda_accel": 0,
    },
    "Traffic": {
        "root_path": "./data/traffic/",
        "data_path": "traffic.csv",
        "data": "custom",
        "model_id_prefix": "traffic",
        "enc_in": 862,
        "c_out": 862,
        "features": "M",
        "freq": "h",
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 17544,
        "use_cuda_accel": 0,
    },
    "Solar": {
        "root_path": "./data/Solar/",
        "data_path": "solar_AL.txt",
        "data": "Solar",
        "model_id_prefix": "solar",
        "enc_in": 137,
        "c_out": 137,
        "features": "M",
        "freq": None,
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [96, 192, 336, 720],
        "total_rows": 52560,
        "use_cuda_accel": 0,
    },
    "Illness": {
        "root_path": "./data/illness/",
        "data_path": "national_illness.csv",
        "data": "custom",
        "model_id_prefix": "ili",
        "enc_in": 7,
        "c_out": 7,
        "features": "M",
        "freq": "w",
        "seq_len": 36,
        "label_len": 18,
        "pred_lens": [24, 36, 48, 60],
        "total_rows": 966,
        "use_cuda_accel": 0,
    },
    "PEMS03": {
        "root_path": "./data/PEMS/",
        "data_path": "PEMS03.npz",
        "data": "PEMS",
        "model_id_prefix": "PEMS03",
        "enc_in": 358,
        "c_out": 358,
        "features": "M",
        "freq": None,
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [12, 24, 48, 96],
        "total_rows": 26208,
        "use_cuda_accel": 0,
    },
    "PEMS04": {
        "root_path": "./data/PEMS/",
        "data_path": "PEMS04.npz",
        "data": "PEMS",
        "model_id_prefix": "PEMS04",
        "enc_in": 307,
        "c_out": 307,
        "features": "M",
        "freq": None,
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [12, 24, 48, 96],
        "total_rows": 16992,
        "use_cuda_accel": 0,
    },
    "PEMS07": {
        "root_path": "./data/PEMS/",
        "data_path": "PEMS07.npz",
        "data": "PEMS",
        "model_id_prefix": "PEMS07",
        "enc_in": 883,
        "c_out": 883,
        "features": "M",
        "freq": None,
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [12, 24, 48, 96],
        "total_rows": 28224,
        "use_cuda_accel": 0,
    },
    "PEMS08": {
        "root_path": "./data/PEMS/",
        "data_path": "PEMS08.npz",
        "data": "PEMS",
        "model_id_prefix": "PEMS08",
        "enc_in": 170,
        "c_out": 170,
        "features": "M",
        "freq": None,
        "seq_len": 96,
        "label_len": 48,
        "pred_lens": [12, 24, 48, 96],
        "total_rows": 17856,
        "use_cuda_accel": 0,
    },
}


def _value(val, pred_len):
    return val[pred_len] if isinstance(val, dict) else val


def _ppl(
    pred_lens: list[int],
    *,
    e_layers,
    d_model,
    d_hyp,
    learning_rate,
    lambda_hyp,
    lambda_prior,
    pct_start,
    batch_size=32,
    patch_len=16,
    stride=8,
    manifold_c=1.0,
    d_layers_diff=2,
    diff_steps=1,
    diff_schedule="cosine",
    diff_eta=0.0,
    dropout=0.1,
) -> dict[int, dict[str, Any]]:
    result = {}
    for pred_len in pred_lens:
        d_model_pl = _value(d_model, pred_len)
        result[pred_len] = {
            "e_layers": _value(e_layers, pred_len),
            "d_model": d_model_pl,
            "d_ff": min(d_model_pl * 2, 768),
            "d_hyp": _value(d_hyp, pred_len),
            "patch_len": _value(patch_len, pred_len),
            "stride": _value(stride, pred_len),
            "manifold_c": _value(manifold_c, pred_len),
            "d_layers_diff": _value(d_layers_diff, pred_len),
            "diff_steps": _value(diff_steps, pred_len),
            "diff_schedule": _value(diff_schedule, pred_len),
            "diff_eta": _value(diff_eta, pred_len),
            "lambda_hyp": _value(lambda_hyp, pred_len),
            "lambda_prior": _value(lambda_prior, pred_len),
            "learning_rate": _value(learning_rate, pred_len),
            "pct_start": _value(pct_start, pred_len),
            "batch_size": _value(batch_size, pred_len),
            "dropout": _value(dropout, pred_len),
        }
    return result


_PROFILE: dict[str, dict[int, dict[str, Any]]] = {
    "ETTh1": _ppl(
        DATASET_META["ETTh1"]["pred_lens"],
        e_layers=2,
        d_model={96: 512, 192: 512, 336: 512, 720: 384},
        d_hyp={96: 64, 192: 128, 336: 32, 720: 64},
        learning_rate={
            96: 8.534128523925959e-4,
            192: 3.508937501685064e-4,
            336: 8.668838596957701e-4,
            720: 2.718528754729852e-4,
        },
        lambda_hyp={96: 0.2, 192: 0.05, 336: 0.2, 720: 0.05},
        lambda_prior={96: 0.5, 192: 0.2, 336: 0.5, 720: 0.2},
        pct_start=0.2,
    ),
    "ETTh2": _ppl(
        DATASET_META["ETTh2"]["pred_lens"],
        e_layers={96: 3, 192: 3, 336: 3, 720: 2},
        d_model={96: 512, 192: 128, 336: 512, 720: 256},
        d_hyp={96: 32, 192: 32, 336: 64, 720: 32},
        learning_rate={
            96: 5.146718534460848e-4,
            192: 9.456396403032724e-4,
            336: 6.804252515965716e-5,
            720: 1.2789077002715373e-3,
        },
        lambda_hyp={96: 0.05, 192: 0.05, 336: 0.05, 720: 0.2},
        lambda_prior={96: 0.5, 192: 0.5, 336: 0.05, 720: 0.05},
        pct_start=0.2,
    ),
    "ETTm1": _ppl(
        DATASET_META["ETTm1"]["pred_lens"],
        e_layers=2,
        d_model={96: 128, 192: 256, 336: 512, 720: 256},
        d_hyp={96: 64, 192: 128, 336: 128, 720: 64},
        learning_rate={
            96: 4.5240376062828457e-4,
            192: 2.7026226642261634e-4,
            336: 2.7026226642261634e-4,
            720: 2.7026226642261634e-4,
        },
        lambda_hyp={96: 0.2, 192: 0.1, 336: 0.1, 720: 0.1},
        lambda_prior={96: 0.05, 192: 0.2, 336: 0.2, 720: 0.2},
        pct_start=0.2,
    ),
    "ETTm2": _ppl(
        DATASET_META["ETTm2"]["pred_lens"],
        e_layers={96: 2, 192: 2, 336: 2, 720: 3},
        d_model={96: 128, 192: 256, 336: 256, 720: 384},
        d_hyp={96: 64, 192: 128, 336: 32, 720: 128},
        learning_rate={
            96: 4.6707351720954584e-4,
            192: 6.067922909833144e-4,
            336: 4.542111671414791e-4,
            720: 1.966373984055377e-4,
        },
        lambda_hyp={96: 0.1, 192: 0.05, 336: 0.05, 720: 0.05},
        lambda_prior={96: 0.1, 192: 0.05, 336: 0.2, 720: 0.1},
        pct_start=0.2,
    ),
    "Weather": _ppl(
        DATASET_META["Weather"]["pred_lens"],
        e_layers={96: 3, 192: 3, 336: 3, 720: 2},
        d_model={96: 128, 192: 384, 336: 512, 720: 384},
        d_hyp={96: 128, 192: 128, 336: 128, 720: 64},
        learning_rate={
            96: 1.1137237363873002e-3,
            192: 3.17116623435682e-4,
            336: 2.621771664528516e-4,
            720: 3.5661596173564865e-4,
        },
        lambda_hyp={96: 0.5, 192: 0.2, 336: 0.2, 720: 0.2},
        lambda_prior={96: 0.5, 192: 0.1, 336: 0.2, 720: 0.5},
        pct_start=0.2,
    ),
    "ECL": _ppl(
        DATASET_META["ECL"]["pred_lens"],
        e_layers=2,
        d_model={96: 256, 192: 128, 336: 128, 720: 128},
        d_hyp=64,
        learning_rate={
            96: 1.2529160729910747e-3,
            192: 1.9314178940972163e-3,
            336: 1.737846590709591e-3,
            720: 1.7137481206473558e-3,
        },
        lambda_hyp=0.05,
        lambda_prior=0.05,
        pct_start=0.2,
        batch_size=16,
    ),
    "Exchange": _ppl(
        DATASET_META["Exchange"]["pred_lens"],
        e_layers={96: 3, 192: 2, 336: 2, 720: 3},
        d_model={96: 512, 192: 384, 336: 384, 720: 128},
        d_hyp=64,
        learning_rate={
            96: 3.2398420178999165e-4,
            192: 5.40260841719727e-4,
            336: 3.655219295037924e-4,
            720: 5.167984768712174e-4,
        },
        lambda_hyp={96: 0.1, 192: 0.05, 336: 0.1, 720: 0.05},
        lambda_prior={96: 0.2, 192: 0.05, 336: 0.2, 720: 0.05},
        pct_start=0.2,
    ),
    "Traffic": _ppl(
        DATASET_META["Traffic"]["pred_lens"],
        e_layers=2,
        d_model=256,
        d_hyp=64,
        learning_rate={
            96: 8.980157865445423e-4,
            192: 9.281455765800239e-4,
            336: 5.915189028690807e-4,
            720: 8.355670686509813e-4,
        },
        lambda_hyp=0.05,
        lambda_prior={96: 0.1, 192: 0.05, 336: 0.05, 720: 0.05},
        pct_start=0.2,
        batch_size=16,
    ),
    "Solar": _ppl(
        DATASET_META["Solar"]["pred_lens"],
        e_layers=2,
        d_model={96: 256, 192: 128, 336: 256, 720: 256},
        d_hyp=64,
        learning_rate={
            96: 9.83337465726625e-4,
            192: 9.83337465726625e-4,
            336: 8.719273470763252e-4,
            720: 9.97144495583881e-4,
        },
        lambda_hyp={96: 0.1, 192: 0.05, 336: 0.05, 720: 0.05},
        lambda_prior={96: 0.05, 192: 0.1, 336: 0.05, 720: 0.05},
        pct_start=0.2,
    ),
    "Illness": _ppl(
        DATASET_META["Illness"]["pred_lens"],
        e_layers={24: 2, 36: 3, 48: 3, 60: 3},
        d_model={24: 512, 36: 384, 48: 512, 60: 384},
        d_hyp={24: 128, 36: 128, 48: 64, 60: 128},
        learning_rate={
            24: 9.459055014562454e-4,
            36: 8.148365089544816e-4,
            48: 7.463144903201623e-4,
            60: 9.871475886849416e-4,
        },
        lambda_hyp=0.05,
        lambda_prior=0.05,
        pct_start=0.2,
        dropout=0.2,
    ),
    "PEMS03": _ppl(
        DATASET_META["PEMS03"]["pred_lens"],
        e_layers=2,
        d_model=256,
        d_hyp=32,
        learning_rate={
            12: 6.861222351671419e-4,
            24: 8.44510684394044e-4,
            48: 9.584418642130095e-4,
            96: 9.118095154103382e-4,
        },
        lambda_hyp=0.05,
        lambda_prior=0.05,
        pct_start=0.2,
    ),
    "PEMS04": _ppl(
        DATASET_META["PEMS04"]["pred_lens"],
        e_layers=2,
        d_model=256,
        d_hyp={12: 32, 24: 32, 48: 64, 96: 32},
        learning_rate={
            12: 7.335052865183138e-4,
            24: 7.903395490902733e-4,
            48: 9.012042912888891e-4,
            96: 8.030494299690926e-4,
        },
        lambda_hyp={12: 0.05, 24: 0.2, 48: 0.1, 96: 0.05},
        lambda_prior={12: 0.2, 24: 0.2, 48: 0.05, 96: 0.2},
        pct_start=0.2,
    ),
    "PEMS07": _ppl(
        DATASET_META["PEMS07"]["pred_lens"],
        e_layers=2,
        d_model=256,
        d_hyp=32,
        learning_rate={
            12: 6.861222351671419e-4,
            24: 8.44510684394044e-4,
            48: 9.584418642130095e-4,
            96: 9.118095154103382e-4,
        },
        lambda_hyp=0.05,
        lambda_prior=0.05,
        pct_start=0.2,
        batch_size=16,
    ),
    "PEMS08": _ppl(
        DATASET_META["PEMS08"]["pred_lens"],
        e_layers={12: 3, 24: 2, 48: 3, 96: 3},
        d_model={12: 384, 24: 384, 48: 512, 96: 384},
        d_hyp={12: 64, 24: 64, 48: 64, 96: 32},
        learning_rate={
            12: 9.89387248394983e-4,
            24: 7.689325459423353e-4,
            48: 6.838619010623866e-4,
            96: 6.560476032180541e-4,
        },
        lambda_hyp={12: 0.05, 24: 0.05, 48: 0.05, 96: 0.2},
        lambda_prior={12: 0.05, 24: 0.05, 48: 0.05, 96: 0.05},
        pct_start=0.2,
    ),
}

CLI_ORDER = [
    "e_layers",
    "d_model",
    "d_ff",
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "dropout",
    "learning_rate",
    "pct_start",
    "batch_size",
    "optim",
    "lradj",
    "revin",
    "affine",
    "patience",
    "train_epochs",
]

META_ORDER = [
    "root_path",
    "data_path",
    "data",
    "model_id",
    "seq_len",
    "label_len",
    "pred_len",
    "enc_in",
    "c_out",
    "features",
    "freq",
    "use_cuda_accel",
]

_OPTUNA_DIR_DEFAULT = "./output/optuna"


OPTUNA_SKIP_KEYS = {"seed"}


def list_datasets() -> list[str]:
    return sorted(DATASET_META.keys())


def get_pred_lens(dataset: str) -> list[int]:
    dataset = canonical_dataset(dataset)
    if dataset not in DATASET_META:
        raise KeyError(f"Unknown dataset: {dataset}. Supported: {list_datasets()}")
    return list(DATASET_META[dataset]["pred_lens"])


def get_tier(dataset: str) -> str:
    dataset = canonical_dataset(dataset)
    if dataset not in DATASET_TIER:
        raise KeyError(f"Unknown dataset: {dataset}. Supported: {list_datasets()}")
    return DATASET_TIER[dataset]


def _fallback_pred_len(dataset: str, pred_len: int) -> int:
    candidates = DATASET_META[dataset]["pred_lens"]
    if pred_len in candidates:
        return pred_len
    shorter = [pl for pl in candidates if pl < pred_len]
    if shorter:
        return max(shorter)
    return min(candidates)


def finalize_config(cfg: dict[str, Any]) -> dict[str, Any]:
    cfg["d_ff"] = min(int(cfg["d_model"]) * 2, D_FF_CAP)
    return cfg


def resolve(dataset: str, pred_len: int) -> dict[str, Any]:
    dataset = canonical_dataset(dataset)
    if dataset not in _PROFILE:
        raise KeyError(f"Unknown dataset: {dataset}. Supported: {list_datasets()}")
    if pred_len not in _PROFILE[dataset]:
        raise KeyError(
            f"pred_len {pred_len} not configured for {dataset}. "
            f"Available: {get_pred_lens(dataset)}"
        )
    cfg = dict(CONSTANTS)
    cfg.update(_PROFILE[dataset][pred_len])
    return finalize_config(cfg)


def resolve_meta(dataset: str, pred_len: int) -> dict[str, Any]:
    dataset = canonical_dataset(dataset)
    if dataset not in DATASET_META:
        raise KeyError(f"Unknown dataset: {dataset}. Supported: {list_datasets()}")
    meta = DATASET_META[dataset]
    result = {
        "root_path": meta["root_path"],
        "data_path": meta["data_path"],
        "data": meta["data"],
        "model_id": f"{meta["model_id_prefix"]}_{meta["seq_len"]}_{pred_len}",
        "seq_len": meta["seq_len"],
        "label_len": meta["label_len"],
        "pred_len": pred_len,
        "enc_in": meta["enc_in"],
        "c_out": meta["c_out"],
        "use_cuda_accel": meta["use_cuda_accel"],
    }
    if meta["features"] is not None:
        result["features"] = meta["features"]
    if meta["freq"] is not None:
        result["freq"] = meta["freq"]
    return result


def _fmt(value: Any) -> str:
    if isinstance(value, bool):
        return "1" if value else "0"
    return str(value)


def emit_cli_args(cfg: dict[str, Any], meta: dict[str, Any] | None = None) -> list[str]:
    args: list[str] = []
    if meta is not None:
        for key in META_ORDER:
            if key in meta:
                args.extend([f"--{key}", _fmt(meta[key])])
    for key in CLI_ORDER:
        if key in cfg:
            args.extend([f"--{key}", _fmt(cfg[key])])
    return args


def to_cli_args(dataset: str, pred_len: int, *, with_meta: bool = False) -> list[str]:
    cfg = resolve(dataset, pred_len)
    meta = resolve_meta(dataset, pred_len) if with_meta else None
    return emit_cli_args(cfg, meta)


def to_cli_string(dataset: str, pred_len: int, *, with_meta: bool = False) -> str:
    return " ".join(to_cli_args(dataset, pred_len, with_meta=with_meta))


def load_optuna_best_params(
    dataset: str,
    pred_len: int,
    *,
    optuna_dir: str = _OPTUNA_DIR_DEFAULT,
) -> dict[str, Any]:
    dataset = canonical_dataset(dataset)
    if dataset not in DATASET_META:
        raise KeyError(f"Unknown dataset: {dataset}. Supported: {list_datasets()}")

    actual_pl = _fallback_pred_len(dataset, pred_len)
    names = (
        f"M2Patch_{dataset}_pl{actual_pl}_best_params.json",
        f"M2Patch_{dataset.lower()}_pl{actual_pl}_best_params.json",
    )
    path = None
    for name in names:
        candidate = os.path.join(optuna_dir, name)
        if os.path.isfile(candidate):
            path = candidate
            break
    if path is None:
        raise FileNotFoundError(
            f"No Optuna best_params for {dataset} pl={pred_len}: "
            f"{os.path.join(optuna_dir, names[0])}"
        )

    with open(path) as f:
        data = json.load(f)

    cfg = dict(CONSTANTS)
    for key, value in data.get("best_params", {}).items():
        if key in OPTUNA_SKIP_KEYS:
            continue
        cfg[key] = value
    return finalize_config(cfg)


def to_cli_args_from_optuna(
    dataset: str,
    pred_len: int,
    *,
    with_meta: bool = False,
    optuna_dir: str = _OPTUNA_DIR_DEFAULT,
) -> list[str]:
    cfg = load_optuna_best_params(dataset, pred_len, optuna_dir=optuna_dir)
    meta = resolve_meta(dataset, pred_len) if with_meta else None
    return emit_cli_args(cfg, meta)


def to_cli_string_from_optuna(
    dataset: str,
    pred_len: int,
    *,
    with_meta: bool = False,
    optuna_dir: str = _OPTUNA_DIR_DEFAULT,
) -> str:
    return " ".join(
        to_cli_args_from_optuna(
            dataset, pred_len, with_meta=with_meta, optuna_dir=optuna_dir
        )
    )
