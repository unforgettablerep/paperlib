import argparse
import math
import os
import re
import time
from contextlib import contextmanager

BASE_CONFIG_COLUMNS = [
    "d_model",
    "d_ff",
    "e_layers",
    "n_heads",
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "revin",
    "affine",
    "dropout",
    "learning_rate",
    "pct_start",
    "batch_size",
    "optim",
    "lradj",
    "patience",
    "train_epochs",
]

METADATA_COLUMNS = [
    "dataset",
    "model",
    "seq_len",
    "label_len",
    "pred_len",
    "mse",
    "mae",
    "status",
    "checkpoint",
    "timestamp",
    "des",
]

RESULT_COLUMNS = METADATA_COLUMNS + BASE_CONFIG_COLUMNS

ROBUSTNESS_RESULT_COLUMNS = RESULT_COLUMNS + ["noise_level"]

ABLATION_RESULT_COLUMNS = (
    RESULT_COLUMNS[: RESULT_COLUMNS.index("dropout")]
    + ["ablation"]
    + RESULT_COLUMNS[RESULT_COLUMNS.index("dropout"):]
)

CONFIG_COLUMNS = BASE_CONFIG_COLUMNS + ["ablation", "noise_level"]

SETTING_FIELD_MAP = {
    "lr": "learning_rate",
    "ll": "label_len",
    "dm": "d_model",
    "nh": "n_heads",
    "el": "e_layers",
    "df": "d_ff",
    "dh": "d_hyp",
    "mc": "manifold_c",
    "dld": "d_layers_diff",
    "steps": "diff_steps",
    "sched": "diff_schedule",
    "eta": "diff_eta",
    "lh": "lambda_hyp",
    "lp": "lambda_prior",
    "abl": "ablation",
    "rc": "revin",
    "do": "dropout",
    "pct": "pct_start",
    "bs": "batch_size",
    "ep": "train_epochs",
    "pat": "patience",
    "lrj": "lradj",
    "opt": "optim",
    "patch": "patch_len",
    "stride": "stride",
    "nl": "noise_level",
}

_ALL_COLUMN_SETS = (RESULT_COLUMNS, ROBUSTNESS_RESULT_COLUMNS, ABLATION_RESULT_COLUMNS)

DATASET_ORDER = [
    "ETTh1",
    "ETTh2",
    "ETTm1",
    "ETTm2",
    "Weather",
    "ECL",
    "Exchange",
    "Traffic",
    "Solar",
    "Illness",
    "PEMS03",
    "PEMS04",
    "PEMS07",
    "PEMS08",
]

def _header_line(columns):
    return "\t".join(columns) + "\n"


def columns_for_path(filepath):
    path = str(filepath).replace(os.sep, "/")
    name = os.path.basename(path)
    if name.endswith("_robustness.tsv"):
        return ROBUSTNESS_RESULT_COLUMNS
    if "output/ablation" in path or "output/mechanism/results" in path:
        return ABLATION_RESULT_COLUMNS
    if os.environ.get("ROBUSTNESS_OUTPUT_DIR"):
        return ROBUSTNESS_RESULT_COLUMNS
    if os.environ.get("ABLATION_OUTPUT_DIR") or os.environ.get("MECHANISM_OUTPUT_DIR"):
        return ABLATION_RESULT_COLUMNS
    return RESULT_COLUMNS


_DATASET_ALIASES = {
    "ili": "Illness",
    "illness": "Illness",
    "solar-energy": "Solar",
    "solar_energy": "Solar",
}

_RE_MSE = re.compile(r"mse:(nan|inf|-inf|[0-9.eE+-]+)")
_RE_MAE = re.compile(r"mae:(nan|inf|-inf|[0-9.eE+-]+)")
_RE_PL = re.compile(r"\|pl:(\d+)\|")
_RE_SL = re.compile(r"\|sl:(\d+)\|")
_RE_CKPT = re.compile(r"\|checkpoint:(\d+)\s*$")
_RE_MODEL_ID_PL = re.compile(r"^(.*?)_(\d+)_(\d+)_")
_RE_SETTING_FIELD = re.compile(r"(?:^|[_|])([a-z]{2,8}):([^|]+)")


def canonical_dataset(name):
    lowered = str(name).lower()
    lowered = _DATASET_ALIASES.get(lowered, lowered).lower()
    for dataset in DATASET_ORDER:
        if dataset.lower() == lowered:
            return dataset
    return str(name)


def is_valid_result(row):
    if not str(row.get("status", "")).startswith("ok"):
        return False
    try:
        return math.isfinite(float(row.get("mse", "")))
    except (TypeError, ValueError):
        return False


@contextmanager
def _dotlock(filepath, timeout=30, poll=0.1):
    lock_path = filepath + ".lock"
    tmp_path = filepath + ".tmp.{}".format(os.getpid())
    deadline = time.monotonic() + timeout
    owns_lock = False

    while True:
        try:
            fd = os.open(tmp_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            os.write(fd, "{}".format(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            if time.monotonic() > deadline:
                for stale in (tmp_path, lock_path):
                    try:
                        os.unlink(stale)
                    except OSError:
                        pass
                break
            time.sleep(poll)
            continue

        try:
            os.link(tmp_path, lock_path)
            owns_lock = True
        except OSError:
            pass

        if os.path.exists(tmp_path):
            try:
                nlink = os.stat(tmp_path).st_nlink
            except OSError:
                nlink = 0
            if nlink >= 2:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                break

        try:
            os.unlink(tmp_path)
        except OSError:
            pass

        if time.monotonic() > deadline:
            try:
                os.unlink(lock_path)
            except OSError:
                pass
            owns_lock = False
            break
        time.sleep(poll)

    try:
        yield
    finally:
        if owns_lock:
            try:
                os.unlink(lock_path)
            except OSError:
                pass


def _append_lines(filepath, lines):
    with open(filepath, "a") as f:
        for line in lines:
            f.write(line)
        f.flush()
        os.fsync(f.fileno())


def atomic_append(filepath, text, timeout=30, poll=0.1):
    with _dotlock(filepath, timeout=timeout, poll=poll):
        _append_lines(filepath, [text])


def format_result_row(row, columns=None):
    columns = RESULT_COLUMNS if columns is None else columns
    return "\t".join(str(row.get(col, "")) for col in columns) + "\n"


def _has_tsv_header(filepath, columns=None):
    columns = columns_for_path(filepath) if columns is None else columns
    try:
        with open(filepath, "r") as f:
            return f.readline().rstrip("\n").split("\t") == columns
    except OSError:
        return False


def _is_header_line(line):
    columns = line.rstrip("\n").split("\t")
    if len(columns) < 2:
        return False
    return all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", col) for col in columns)


def expand_setting_fields(setting):
    out = {}
    for key, value in _RE_SETTING_FIELD.findall(setting or ""):
        col = SETTING_FIELD_MAP.get(key)
        if col and col not in out:
            out[col] = value
    return out


def append_result(filepath, row, timeout=30, poll=0.1, columns=None):
    columns = columns_for_path(filepath) if columns is None else columns
    header_line = _header_line(columns)
    parent = os.path.dirname(filepath)
    if parent:
        os.makedirs(parent, exist_ok=True)
    line = format_result_row(row, columns)
    with _dotlock(filepath, timeout=timeout, poll=poll):
        if not _has_tsv_header(filepath, columns):
            _append_lines(filepath, [header_line])
        _append_lines(filepath, [line])


def _is_legacy_setting_line(line):
    if "|pl:" in line:
        return True
    return _RE_MODEL_ID_PL.search(line.split("|", 1)[0]) is not None


def _stem_dataset(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    for suffix in ("_robustness",):
        if stem.endswith(suffix):
            stem = stem[: -len(suffix)]
    return stem


def _parse_legacy_lines(lines, fallback_dataset=""):
    rows = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i].strip()
        i += 1
        if not line or not _is_legacy_setting_line(line):
            continue

        setting = line
        parts = setting.split("|")
        des = parts[1] if len(parts) >= 2 else ""
        model_id = parts[0] if parts else ""
        mid_match = _RE_MODEL_ID_PL.search(model_id)
        dataset = mid_match.group(1) if mid_match else fallback_dataset

        pred_len = ""
        pl_match = _RE_PL.search(setting)
        if pl_match:
            pred_len = pl_match.group(1)
        elif mid_match:
            pred_len = mid_match.group(3)

        seq_len = ""
        sl_match = _RE_SL.search(setting)
        if sl_match:
            seq_len = sl_match.group(1)
        elif mid_match:
            seq_len = mid_match.group(2)

        checkpoint = ""
        for ckpt_match in _RE_CKPT.finditer(setting):
            checkpoint = ckpt_match.group(1)

        model = model_id.rsplit("_", 1)[-1] if mid_match else ""

        mse_val = ""
        mae_val = ""
        while i < n:
            nxt = lines[i].strip()
            i += 1
            if not nxt:
                continue
            if _is_legacy_setting_line(nxt):
                i -= 1
                break
            mse_match = _RE_MSE.search(nxt)
            if mse_match:
                mae_match = _RE_MAE.search(nxt)
                mse_val = mse_match.group(1)
                mae_val = mae_match.group(1) if mae_match else ""
                break

        if not mse_val:
            continue

        rows.append(
            {
                "dataset": canonical_dataset(dataset),
                "model": model,
                "des": des,
                "seq_len": seq_len,
                "pred_len": pred_len,
                "mse": mse_val,
                "mae": mae_val,
                "status": "ok",
                "checkpoint": checkpoint,
                "timestamp": "",
                "setting": setting,
            }
        )
    return rows


def read_results(path):
    try:
        with open(path, "r") as f:
            first = f.readline()
            columns = None
            first_cols = first.rstrip("\n").split("\t")
            for candidate in _ALL_COLUMN_SETS:
                if first_cols == candidate:
                    columns = candidate
                    break
            if columns is None and _is_header_line(first):
                columns = first_cols
            if columns is not None:
                rows = []
                for line in f:
                    line = line.rstrip("\n")
                    if not line.strip():
                        continue
                    values = line.split("\t")
                    values += [""] * (len(columns) - len(values))
                    rows.append(dict(zip(columns, values)))
                return rows
            return _parse_legacy_lines(
                [first.rstrip("\n")] + f.read().splitlines(),
                fallback_dataset=_stem_dataset(path),
            )
    except FileNotFoundError:
        return []


def _sort_key_factory(order):
    def sort_key(row):
        dataset = str(row.get("dataset", ""))
        known = dataset in order
        try:
            seq_len = float(row.get("seq_len") or "inf")
        except ValueError:
            seq_len = float("inf")
        try:
            pred_len = float(row.get("pred_len") or "inf")
        except ValueError:
            pred_len = float("inf")
        try:
            noise_level = float(row.get("noise_level") or "0")
        except ValueError:
            noise_level = 0.0
        return (
            len(order) if not known else order.index(dataset),
            "" if known else dataset,
            str(row.get("model", "")),
            str(row.get("des", "")),
            seq_len,
            pred_len,
            noise_level,
        )

    return sort_key


def compact_results(path, dataset_order=None, dedup=True):
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    rows = read_results(path)
    columns = columns_for_path(path)
    order = list(dataset_order or DATASET_ORDER)

    if dedup:
        kept = {}
        for row in rows:
            key = (
                str(row.get("dataset", "")),
                str(row.get("model", "")),
                str(row.get("des", "")),
                str(row.get("seq_len", "")),
                str(row.get("pred_len", "")),
                str(row.get("ablation", "")),
                str(row.get("noise_level", "")),
            )
            kept[key] = row
        rows = list(kept.values())

    merged = sorted(rows, key=_sort_key_factory(order))
    text = (
        _header_line(columns)
        + "".join(format_result_row(row, columns) for row in merged)
    )
    with _dotlock(path):
        tmp_path = path + ".tmp.{}".format(os.getpid())
        with open(tmp_path, "w") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    return len(merged)


def _upgrade_row(row):
    upgraded = dict(row)
    setting = upgraded.pop("setting", "")
    if setting:
        upgraded.update(expand_setting_fields(setting))
    upgraded.setdefault("label_len", "")
    for col in CONFIG_COLUMNS:
        upgraded.setdefault(col, "")
    return upgraded


def upgrade_schema(path):
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    try:
        with open(path, "r") as f:
            first = f.readline().rstrip("\n").split("\t")
    except OSError:
        return False
    columns = columns_for_path(path)
    if first == columns:
        return False
    rows = read_results(path)
    if not rows:
        return False
    upgraded = [_upgrade_row(row) for row in rows]
    text = _header_line(columns) + "".join(
        format_result_row(row, columns) for row in upgraded
    )
    with _dotlock(path):
        tmp_path = path + ".tmp.{}".format(os.getpid())
        with open(tmp_path, "w") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    return True


def migrate_file(txt_path, dataset_order=None):
    tsv_path = os.path.splitext(txt_path)[0] + ".tsv"
    if os.path.exists(tsv_path):
        return None
    rows = read_results(txt_path)
    if not rows:
        return None
    columns = columns_for_path(tsv_path)
    upgraded = [_upgrade_row(row) for row in rows]
    with _dotlock(tsv_path):
        with open(tsv_path, "w") as f:
            f.write(_header_line(columns))
            for row in upgraded:
                f.write(format_result_row(row, columns))
            f.flush()
            os.fsync(f.fileno())
    compact_results(tsv_path, dataset_order, dedup=False)
    return tsv_path


def result_dataset_name(args):
    model_id = str(getattr(args, "model_id", ""))
    prefix = model_id.rsplit("_", 2)[0] if model_id.count("_") >= 2 else model_id
    if canonical_dataset(prefix) in DATASET_ORDER:
        return canonical_dataset(prefix)
    return str(getattr(args, "data", "custom"))


def _result_dir_and_name(args):
    dataset = result_dataset_name(args)
    model = str(getattr(args, "model", "model"))
    if os.environ.get("CASE_STUDY_MODE"):
        return "./output/case_study", "case_study.tsv"
    lookback_dir = os.environ.get("LOOKBACK_OUTPUT_DIR")
    if lookback_dir:
        return lookback_dir, "{}.tsv".format(model)
    ablation_dir = os.environ.get("ABLATION_OUTPUT_DIR")
    if ablation_dir:
        root = ablation_dir.rstrip("/")
        return os.path.dirname(root) or ".", "{}.tsv".format(os.path.basename(root))
    benchmark_dir = os.environ.get("BENCHMARK_OUTPUT_DIR")
    if benchmark_dir:
        return benchmark_dir, "{}.tsv".format(dataset)
    repro_dir = os.environ.get("REPRODUCIBILITY_OUTPUT_DIR")
    if repro_dir:
        return repro_dir, "{}.tsv".format(dataset)
    mechanism_dir = os.environ.get("MECHANISM_OUTPUT_DIR")
    if mechanism_dir:
        return mechanism_dir, "{}.tsv".format(dataset)
    robustness_dir = os.environ.get("ROBUSTNESS_OUTPUT_DIR")
    if robustness_dir:
        return robustness_dir, "{}_robustness.tsv".format(dataset)
    return "./output/long_term_forecast", "{}.tsv".format(dataset)


def resolve_result_file(args):
    output_dir, filename = _result_dir_and_name(args)
    return output_dir, os.path.join(output_dir, filename)


_ARG_FIELD_DEFAULTS = {
    "label_len": 48,
    "d_model": 256,
    "e_layers": 2,
    "n_heads": 8,
    "learning_rate": 0.0001,
    "noise_level": 0.0,
}


def _config_field_value(args, col):
    if col == "ablation":
        group = getattr(args, "ablation_group", None)
        if group is not None:
            return group
    from src.configs.m2patch_profiles import CONSTANTS

    default = CONSTANTS.get(col, _ARG_FIELD_DEFAULTS.get(col, ""))
    return getattr(args, col, default)


def build_result_row(args, setting, mse, mae, checkpoint=0, columns=None):
    columns = RESULT_COLUMNS if columns is None else columns
    status = "ok" if math.isfinite(float(mse)) and math.isfinite(float(mae)) else "diverged"
    row = {
        "dataset": result_dataset_name(args),
        "model": getattr(args, "model", ""),
        "seq_len": getattr(args, "seq_len", ""),
        "label_len": getattr(args, "label_len", ""),
        "pred_len": getattr(args, "pred_len", ""),
        "mse": float(mse),
        "mae": float(mae),
        "status": status,
        "checkpoint": checkpoint,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "des": getattr(args, "des", ""),
    }
    for col in columns[columns.index("d_model"):]:
        row[col] = _config_field_value(args, col)
    return row


def write_test_result(args, setting, mse, mae, checkpoint=0, extra=None):
    if os.environ.get("M2PATCH_SKIP_RESULT_WRITE") == "1":
        print("Result write skipped (M2PATCH_SKIP_RESULT_WRITE=1)")
        return None

    _, output_file = resolve_result_file(args)
    columns = columns_for_path(output_file)
    row = build_result_row(args, setting, mse, mae, checkpoint=checkpoint, columns=columns)
    if extra:
        row.update(extra)
    try:
        append_result(output_file, row, columns=columns)
        print("Results successfully written to: {}".format(output_file))
        return output_file
    except Exception as exc:
        print("ERROR: Failed to write results to {}: {}".format(output_file, exc))
        return None


def _main():
    parser = argparse.ArgumentParser(description="TSV result-store utilities")
    subparsers = parser.add_subparsers(dest="command", required=True)
    sort_parser = subparsers.add_parser("sort", help="compact + canonically reorder TSV result files")
    sort_parser.add_argument("paths", nargs="+", help="TSV result files")
    upgrade_parser = subparsers.add_parser(
        "upgrade", help="expand legacy setting strings into per-config columns"
    )
    upgrade_parser.add_argument("paths", nargs="+", help="TSV/TXT result files")
    args = parser.parse_args()

    if args.command == "sort":
        for path in args.paths:
            n_rows = compact_results(path)
            print("sorted {} ({} rows)".format(path, n_rows))
    elif args.command == "upgrade":
        for path in args.paths:
            if upgrade_schema(path):
                print("upgraded {} to the current column schema".format(path))
            else:
                print("skipped {} (already current or empty)".format(path))


if __name__ == "__main__":
    _main()
