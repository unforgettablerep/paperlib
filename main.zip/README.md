# M2Patch: Hyperbolic Causal Prior-Bridge Diffusion for Time Series Forecasting

M2Patch performs forecasting with a **strictly causal single-scale patch tokenizer**,
a **constant-negative-curvature Poincare-ball manifold**, and a
**history-prior bridge diffusion** process. A causal history encoder produces the
future prior and a hyperbolic history trajectory; a time-conditioned AdaLN-Zero
denoiser is trained with bridge denoising score matching, hyperbolic geodesic
alignment, and a prior anchor loss. Inference is a deterministic Bridge-DDIM
reverse loop initialized at the historical prior.

## Installation

### Environment Requirements

- Python 3.12.12
- PyTorch 2.8.0 and CUDA 12.8 baseline (the current `m2p` host runs 2.8.0+cu129 / CUDA 12.9)

### Step 1: Create Conda Environment

```bash
conda env create -f environment.yml && conda activate m2p
```

### Step 2: Install CUDA Runtime and PyTorch

```bash
conda install nvidia/label/cuda-12.8.0::cuda-runtime -y &&
pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu128 &&
pip install poetry
```

### Step 3: Install Additional Dependencies

```bash
poetry install
```

### Verify Setup

```bash
poetry run poe cuda
```

## Data

Place datasets under `./data/` (e.g. `./data/ETT-small/`, `./data/weather/`, `./data/exchange_rate/`).

## Quick Start

The following is an illustrative example. See `scripts/multivariate_forecasting/` for experiment scripts with tuned hyperparameters per dataset and prediction horizon.

```bash
python -u scripts/run.py --is_training 1 --model M2Patch --des MULTI_PRED \
    $(python -m src.configs.m2patch_cli ETTh1 96 --with-meta)
```

Tuned per-(dataset, pred_len) settings live in `src/configs/m2patch_profiles.py` and are emitted by `python -m src.configs.m2patch_cli`; do not copy them into commands or scripts.

## Architecture

The end-to-end pipeline is drawn in `assets/plots/M2Patch_architecture.drawio`: a history-only RevIN and causal patch tokenizer feed a causally masked history encoder, which produces the future prior, the Poincaré-ball history trajectory, and the hyperbolic conditioning vector. A prior-bridge VP-SDE corrupts future patches toward the prior during training; a time-conditioned AdaLN-Zero denoiser is optimized with bridge denoising, raw reconstruction, hyperbolic alignment, and prior-anchor losses. Inference starts at the prior and runs a deterministic Bridge-DDIM loop (`K=1` by default).

## Supported Datasets

| Dataset  | `--data` | `enc_in` | `seq_len` | pred_lens         |
| -------- | ---------- | ---------- | ----------- | ----------------- |
| ETTh1    | ETTh1      | 7          | 96          | 96, 192, 336, 720 |
| ETTh2    | ETTh2      | 7          | 96          | 96, 192, 336, 720 |
| ETTm1    | ETTm1      | 7          | 96          | 96, 192, 336, 720 |
| ETTm2    | ETTm2      | 7          | 96          | 96, 192, 336, 720 |
| Weather  | custom     | 21         | 96          | 96, 192, 336, 720 |
| ECL      | custom     | 321        | 96          | 96, 192, 336, 720 |
| Exchange | custom     | 8          | 96          | 96, 192, 336, 720 |
| Traffic  | custom     | 862        | 96          | 96, 192, 336, 720 |
| Solar    | Solar      | 137        | 96          | 96, 192, 336, 720 |
| PEMS03   | PEMS       | 358        | 96          | 12, 24, 48, 96    |
| PEMS04   | PEMS       | 307        | 96          | 12, 24, 48, 96    |
| PEMS07   | PEMS       | 883        | 96          | 12, 24, 48, 96    |
| PEMS08   | PEMS       | 170        | 96          | 12, 24, 48, 96    |
| Illness  | custom     | 7          | 36          | 24, 36, 48, 60    |

Experiment scripts: `scripts/multivariate_forecasting/{ETT,Weather,ECL,Exchange,Traffic,SolarEnergy,PEMS,illness}/M2Patch*.sh`; see [Experiment Workflows](#experiment-workflows) for efficiency, increasing lookback, robustness, OFAT ablation, mechanism analysis, cross-dataset statistics, case study and sensitivity.

## Key Parameters

CLI defaults are shown; per-dataset/profile values override them (see `src/configs/m2patch_profiles.py`).

| Parameter             | Default            | Description                                       |
| --------------------- | ------------------ | ------------------------------------------------- |
| `--patch_len`       | 16                 | Causal history patch length                       |
| `--stride`          | 8                  | Causal history patch stride                       |
| `--d_hyp`           | 64                 | Poincare ball hyperbolic manifold dimension       |
| `--manifold_c`      | 1.0                | Constant negative curvature parameter c > 0       |
| `--d_layers_diff`   | 2                  | Conditional diffusion denoiser layers             |
| `--diff_steps`      | 1                  | Deterministic Bridge-DDIM sampling steps K >= 1   |
| `--diff_schedule`   | `"cosine"`       | VP-SDE schedule (`cosine`/`linear`)            |
| `--diff_eta`        | 0.0                | DDIM stochasticity (0.0 = deterministic)          |
| `--lambda_hyp`      | 0.1                | Hyperbolic geodesic alignment loss weight         |
| `--lambda_prior`    | 0.1                | Causal prior anchor loss weight                   |
| `--revin`           | 1                  | History-only RevIN normalization                  |
| `--lradj`           | `"onecycle"`     | Learning rate scheduler (OneCycleLR)              |
| `--optim`           | `Adam`            | Optimizer; `weight_decay` defaults to 0.0 and is not passed by default |
| `--dropout`         | 0.1                | Fixed profile dropout; Illness uses 0.2           |
| `--pct_start`       | 0.2                | Fixed OneCycleLR warm-up fraction                 |
| `--ablation`        | `"none"`         | Mechanism switch; choices in `src/ablation/registry.py` |
| `--d_model`         | 256                | Patch embedding dimension                         |
| `--d_ff`            | 512                | Transformer feed-forward dimension                |
| `--e_layers`        | 2                  | Causal history encoder layers                     |

## Experiment Workflows

M2Patch runners source tuned per-dataset settings from `src/configs/m2patch_profiles.py` through `python -m src.configs.m2patch_cli`; baseline scripts keep explicit per-model settings, and the efficiency protocol applies the same 10-epoch budget to every model.

| Experiment | Entry point | Datasets / grid | Output |
| --- | --- | --- | --- |
| Efficiency | `bash scripts/efficiency/{1_ETTm1,2_Weather_96,4_ECL_336}.sh`; `bash scripts/efficiency/legacy/Exp{1_PEMS08,2_ECL,3_Weather,4_ETTm1}.sh` | ETTm1 96, Weather 96, ECL 336; M2Patch + 11 baselines; 10 epochs, `batch_size=16`, FP32, seed 2023 | `output/efficiency/m2patch_results/M2Patch_*.json`; baselines in `output/efficiency/results_by_dataset/*.jsonl`; `output/efficiency/exp_2_efficiency.png` |
| Increasing lookback | `bash scripts/increasing_lookback/run-lookback.sh [--gpu IDS] [--para N] [dataset] [model]` | ETTm1, Weather, ECL (48/96/192/336/720), PEMS08 (48/96/144/192); H=96; runner covers M2Patch, PatchTST, TimeMixer | `output/lookback/{model}.tsv`; `output/lookback/exp_4_lookback.png` |
| Zero-shot robustness | `bash scripts/robustness/run-robustness.sh [--para N] [--gpu IDS] [--phase all/train/test] [--noise_levels "0.1 0.2 0.3 0.5"] [dataset]` | ETTm1, ETTm2; H 96/192/336/720; noise sigma 0/0.1/0.2/0.3/0.5 | `output/robustness/{dataset}_robustness.tsv`; `output/robustness/exp_3_robustness*.png` |
| OFAT ablation | `bash scripts/ablation/run_all_ablation.sh --para N GPU...` | 8 single-variable variants against an Optuna-config `none` baseline; measured on ETTh2/ETTm1/Exchange, registered for Weather/ECL/Illness; 4 horizons per dataset | `output/ablation/{variant}.tsv`; `output/ablation/m2p-ablation.xlsx` (`Main Table`, `Full Detail`) |
| Mechanism | `bash scripts/mechanism/run_m2patch_mechanism.sh --para 2 --epochs 15 --plot 1 --gpu 0` | ETTh2, ETTm1, Exchange; H=96; Full + `euclid_manifold`/`zero_prior_bridge`/`no_hyp_cond`/`no_prior_loss` | `output/mechanism/results/{Dataset}.tsv`; `m2patch_mechanism_summary.tsv`; dataset panels, main panel and cross-dataset panel |
| Cross-dataset statistics | `python scripts/statistics/nonparametric_tests.py` | 3 datasets x 4 horizons = 12 blocks; 8 models; Friedman + Iman-Davenport, Nemenyi CD, Wilcoxon-Holm, rank-biserial | `output/statistics/stat_tests_results.csv`, `stat_tests_summary.md`, `critical_difference.png`, `m2p_stat_tests.xlsx` |
| Case study | `bash scripts/case_study/run_case_study.sh` (env `CASE_STUDY_PL`, `CASE_STUDY_GPUS`) | ETTm2, ETTm1, ECL, Exchange; 96 -> 96; M2Patch vs MMPD/S-Mamba/iTransformer/PatchTST | `output/case_study/case_study.tsv`, `record_*/`, `output/case_study/figures/case_study_comparison_96.png` |
| Hyperparameter sensitivity | `bash scripts/hyperparam/launch_sensitivity.sh --para N GPU...` | 5 datasets (ETTh1/ETTh2/ETTm1/Weather/Exchange) x 4 parameters x 4 values x 5 seeds; H=96 | `output/hyperparam/sensitivity_results_{dataset}.tsv`; `4_sensitivity.png`, `4_sensitivity_lines.png` |

Protocol notes:

- Efficiency uses one uniform protocol for M2Patch and every baseline: 10 epochs, `batch_size=16`, FP32, seed 2023, measured sequentially on a single RTX 4090 D. Baselines are MMPD (ICLR 2026), SimpleTM (ICLR 2025), TimeMixer, PatchTST, iTransformer, S-Mamba, DLinear, Autoformer, Informer, Flowformer and Transformer. `scripts/run.py` prints the trainable/total parameter count after model construction and the pure forward latency (`inference_speed`, CUDA-synchronised, first 5 test batches excluded) at the end of `test()`; both are stored in the JSONL/JSON/XLSX metrics as `params` and `inference_time_ms_per_iter`.
- OFAT ablation keeps one Optuna-config baseline (`none`) per (dataset, pred_len) and changes exactly one component per variant. ETTh2, ETTm1 and Exchange are measured across all four horizons; Weather, ECL and Illness are registered in the workbook with Optuna-reference baselines and `PENDING` variant cells until those runs land.
- Mechanism runs load `load_optuna_best_params(dataset, pred_len)`, force `Adam`/`onecycle`/`pct_start=0.2`, and lift a zero `lambda_hyp` to 0.1. Each dataset gets a 2x2 single-column panel (`m2patch_mechanism_{Dataset}.png`), ETTh2 is also exported as the main panel, and `m2patch_mechanism_cross_dataset.png` compares the five variants across the three datasets.
- Statistics treat each (dataset, pred_len) as a block, rank models per block, and apply Holm-Bonferroni within each metric; `--include-all` extends the test once the remaining benchmark cells exist.
- Increasing-lookback fixes all hyperparameters per dataset and varies only `seq_len`; the runner defaults to ETTm1, PEMS08, Weather and ECL. The committed `output/lookback/*.tsv` also contains S-Mamba, iTransformer and Transformer entries.
- Robustness trains once on clean data and reuses the checkpoint for every noise level (zero-shot, no noise augmentation).
- Case-study windows are selected deterministically and reported on the original physical scale via `--inverse`.
- Sensitivity sweeps `d_model` (64/128/256/512), `d_hyp` (16/32/64/128), `d_layers_diff` (1/2/3/4) and learning rate (1e-4/2.5e-4/5e-4/1e-3); non-swept values come from the pl96 Optuna export when available, otherwise from the frozen profile.

All analysis figures exported by the notebooks and every mechanism figure rendered by `plot_m2patch_mechanism.py` (`m2patch_mechanism_{Dataset}.png`, the 2x2 main panel `m2patch_mechanism_analysis.png`, the cross-dataset panel `m2patch_mechanism_cross_dataset.png`, and the statistical critical-difference plot `output/statistics/critical_difference.png`) are 600 dpi `.png` only.

## Hyperparameter Optimization

HPO fixes `dropout=0.1` (`0.2` for Illness) and `pct_start=0.2` for every horizon through `src/configs/m2patch_profiles.py`. The remaining model and learning-rate parameters are sampled by Optuna. These fixed values are practical defaults for the 15-epoch search budget.

```bash
poetry run poe optuna --dataset ETTh1 --pl 96 --trials 50 --gpu 0
poetry run poe optuna --dataset ETTh1 --pl 96 --trials 50 --gpu 0 --warm_start 0
sbatch scripts/batch/batch_3.sh
```

New studies automatically read the matching `output/optuna/M2Patch_{dataset}_pl{pred_len}_best_params.json`. Valid search parameters seed the first trial; current profile values supply fixed parameters, so old JSON dropout and warm-up values do not override them. A different frozen-profile candidate follows. Missing or unusable JSON falls back to the profile, and resumed studies keep their existing trial queue. Every candidate is trained and evaluated again. Use `--warm_start 0` to disable JSON seeding.

Study fingerprints include the effective fixed configuration, the Hyperband pruner configuration (`min_resource=4`, `max_resource=train_epochs`, `reduction_factor=3`; the first rung is epoch 4, after the OneCycleLR warm-up peak), and reject incompatible resumes. The best-params export records the actual trial configuration; explicit `--from-optuna` commands retain the historical values stored in JSON. Fresh studies use sampler seed 2023; resumed studies use a random sampler seed to avoid replaying earlier random-startup trial parameters, while the training seed stays 2023. Keep JSON exports when deleting old databases for a warm-started search; `hpo-clean --full` removes those exports too.

Run the isolated regression tests with:

```bash
python -B -m unittest discover -s tests/hpo -p 'test_hpo*.py' -v
```

## Citation

```bibtex
@article{m2patch2026,
  title={M2Patch: Hyperbolic Causal Prior-Bridge Diffusion for Time Series Forecasting},
  author={Chen, Xingsheng and Yiu, Siu-Ming},
  year={2026}
}
```
