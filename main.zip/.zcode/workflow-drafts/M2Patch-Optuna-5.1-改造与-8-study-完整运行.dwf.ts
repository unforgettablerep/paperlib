interface AuditVerdict {
    /** 是否通过:实现与计划阐述一致且无阻断问题。 */
    passed: boolean;
    /** 阻断性问题列表;空数组表示通过。 */
    blocking: { file: string; issue: string }[];
    /** 非阻断提醒。 */
    warnings: string[];
}

interface PhaseResult {
    /** 一句话说明完成了什么。 */
    summary: string;
    /** 改动的文件列表(工作区相对路径)。 */
    files: string[];
}

interface GpuReport {
    /** 压测是否通过(无 OOM、无 TTGIR/PassManager/SubprocException,显存余量充足)。 */
    pass: boolean;
    /** 每张 GPU 的峰值显存(MB)。 */
    perGpuPeakMb: { gpu: string; peakMb: number }[];
    /** eager fallback 机制是否被验证。 */
    compileFallbackVerified: boolean;
    /** 发现的问题。 */
    issues: string[];
}

interface StudyStatus {
    /** study 标识,如 ETTh1_pl96。 */
    study: string;
    /** RUNNING / COMPLETED_TRIALS / STALLED / FAILED。 */
    state: string;
    /** 已完成 trial 数。 */
    completed: number;
    /** 已剪枝 trial 数。 */
    pruned: number;
    /** 已失败 trial 数。 */
    failed: number;
    /** 最后一条 epoch/trial 进度行。 */
    lastProgress: string;
}

interface MonitorStatus {
    /** 是否达到稳定标准(8 study 存活、持续 trial 进度、无 OOM/未分类异常、观察≥15分钟)。 */
    stable: boolean;
    /** Slurm 作业是否仍在运行。 */
    jobRunning: boolean;
    /** 存活的 study 数。 */
    studiesAlive: number;
    /** 各 study 状态。 */
    details: StudyStatus[];
    /** 是否观察到真实 CUDA OOM。 */
    oom: boolean;
    /** 未分类错误摘要。 */
    errors: string[];
    /** 实际观察分钟数。 */
    observedMinutes: number;
}

interface Finding {
    where: string;
    what: string;
    evidence: string;
    status: "verified" | "unconfirmed";
    severity: "low" | "medium" | "high";
}

interface WorkflowReport {
    conclusion: string;
    findings: Finding[];
    verified: string[];
    notCovered: string[];
}

const PY = "/userhome/cs3/xschen2/miniconda3/envs/m2p/bin/python";
const SLURM_BIN = "/usr/local/slurm/bin";

const STYLE_RULES = [
    "代码风格(AGENTS.md):4 空格缩进、每级恰为 4 的倍数、行宽≤180、双引号字符串;",
    "禁止文件头注释块与多行用途 docstring(一行 purpose 注释允许);除张量形状标注或关键说明外不加行内注释;SBATCH 指令块豁免;",
    "匹配周围代码风格,不引入格式化器;禁止 git commit;改动前先读目标文件与相关调用方(grep 引用)。",
].join("\n");

const COMMON_CTX = [
    "仓库:/userhome/cs3/xschen2/projects/m2patch(conda 环境 m2p,Python 路径 " + PY + ",Optuna 5.1.0、PyTorch 2.8.0+cu128、Triton 3.4.0)。",
    "背景:上一轮 12-study HPO 全部因 M2Patch 训练图 Triton TTGIR 编译失败(PassManager::run failed)而 0 有效 trial,",
    "且 objective 把基础设施异常误转为 TrialPruned、hpo_tune 的 3 连 prune stopper 假完成退出。HPO 还硬编码 use_amp=True(历史 compile 成功案例全部 AMP=0)。",
    STYLE_RULES,
    "若指令之间存在无法同时满足的约束或检查不可能通过,直接向运行所有者升级说明,不要绕过或伪造。",
].join("\n");

artifact.table("study-status", {
    title: "8 个 study 运行状态",
    key: "study",
    columns: [
        { field: "study", label: "Study" },
        { field: "state", label: "状态" },
        { field: "completed", label: "完成" },
        { field: "pruned", label: "剪枝" },
        { field: "failed", label: "失败" },
        { field: "lastProgress", label: "最新进度" },
    ],
});

const findings: Finding[] = [];
let verified: string[] = [];
const notCovered: string[] = [];

// ── 第一波:两个互不相交文件集的并行实现 ──

phase("并行实现:Optuna 研究管理与训练评估修复");
const [resStudy, resTrain] = await Promise.all([
    agent("实现-研究管理", {
        system: "你是资深 PyTorch/Optuna 工程师,严格按需求改造 src/hpo/study_manager.py,不改其他文件。\n" + COMMON_CTX,
    }).ask<PhaseResult>(
        [
            "改造 src/hpo/study_manager.py(仅此文件),严格实现:",
            "1) 删除对 optuna.trial.Trial.set_constraint 的全局 monkey-patch(_set_constraint_tuple_compat/_install_set_constraint_tuple_compat)以及 optuna.samplers._tpe.sampler 与 optuna.study._constrained_optimization 的全部私有导入;objective 已使用 Optuna 5.1 公共命名标量 set_constraint。",
            "2) 删除 GroupedMultivariateTPESampler 整个类;create_study 改用官方 TPESampler(multivariate=True, group=True, constant_liar=True, seed=2023, n_startup_trials=15)。",
            "3) create_study 增加参数:metric、train_epochs、patience、batch_size、use_compile、use_amp、search_space_spec(dict)、seed;HyperbandPruner 的 max_resource 绑定传入的 train_epochs(不再写死 15),min_resource=3、reduction_factor=3。",
            "4) _make_storage 增加 heartbeat_stale_trial_callback=RetryHeartbeatStaleTrialCallback(max_retry=1)(从 optuna.storages 公共路径导入)。",
            "5) study 配置指纹:新建/恢复时在 study user attrs(hpo_config)写入并校验 {metric,train_epochs,patience,batch_size,use_compile,use_amp,seed,search_space_spec,search_space_version,optuna_version,torch_version};恢复时指纹不一致必须抛出带清晰信息的异常,禁止混合恢复。写入前用 " + PY + " 核对 Optuna 5.1 的 API 签名。",
            "6) export_results 改为临时文件 + os.replace 原子写(JSON 与 CSV 都要);JSON 保持现有键名/路径/顺序兼容(下游 update_excel 依赖),新增 trial_state_counts(COMPLETE/PRUNED/FAIL)与 failure_summary(按 user_attrs status 聚合的一行摘要);不把 traceback 全文写入 user attrs 的路径保持不变。",
            "7) 保持 load_study/study_db_exists/get_best_params 兼容;本文件不得 import torch 顶层重依赖(版本号用 importlib.metadata 惰性取)。",
            "完成后运行 " + PY + " -m py_compile src/hpo/study_manager.py 并 grep 全仓库确认无残留 GroupedMultivariateTPESampler/LOOKBACK 引用。返回 PhaseResult。",
        ].join("\n"),
    ),
    agent("实现-训练修复", {
        system: "你是资深时序训练工程师,改造训练/验证路径,不改 src/hpo/ 下任何文件。\n" + COMMON_CTX,
    }).ask<PhaseResult>(
        [
            "改造三个文件,严格实现:",
            "1) src/utils/tools.py:EarlyStopping 在 save_path 为 None(HPO save_tmp=0 场景)时把最佳 epoch 的模型权重以 CPU state_dict 副本保留在内存(self.best_state),save_path 存在时行为不变;NaN/Inf 计数逻辑保持。",
            "2) src/experiments/exp_long_term_forecasting.py train():best_model_path 为 None 时,训练循环结束后若 EarlyStopping 保留过 best_state,则 load_state_dict 恢复最佳权重(深拷贝入显存),修复当前最终 objective 评估最后一轮而非最佳轮的缺陷;有磁盘路径的现有逻辑不变。",
            "   同文件 vali():在现有返回 (innov,std) 基础上按元素数累积并额外给出 MAE(可用第三个返回值或属性,最小侵入);epoch 级 Optuna report 与 EarlyStopping 使用 getattr(args, 'hpo_metric', 'mse') 选择报告值:mse 报 vali MSE,mae 报新算的 MAE;默认行为与现状完全一致。",
            "3) src/data_provider/data_factory.py:flag=='val' 的 loader 改为 shuffle=False、drop_last=False(HPO 验证需完整确定性遍历);train/test 行为不变。",
            "完成后运行 " + PY + " -m py_compile 三个文件,并 grep 确认 vali 调用方兼容。返回 PhaseResult。",
        ].join("\n"),
    ),
]);
log("第一波实现完成:" + resStudy.summary + " / " + resTrain.summary);

phase("独立审计第一批改造并修复");
const auditWave = async (
    implName: string,
    auditorName: string,
    reqText: string,
    files: string[],
): Promise<AuditVerdict> => {
    const impl = agent(implName, { system: "你是该阶段的实现者,负责按审计意见修复自己刚完成的改动,保持同一上下文。\n" + COMMON_CTX });
    const auditor = agent(auditorName, {
        system: "你是独立审计员,只读审计(不得编辑任何文件),对照计划逐条核对实现;宁可报告问题也不放过偏差。\n" + COMMON_CTX,
    });
    let verdict: AuditVerdict = { passed: false, blocking: [], warnings: [] };
    let feedback = "首轮审计";
    for (let round = 1; round <= 2; round++) {
        verdict = await auditor.ask<AuditVerdict>(
            "第 " + round + " 轮审计(" + feedback + ")。逐条核对以下计划要求是否被真实实现(读代码取证,给 file:line 证据):" + reqText + "。涉及文件:" + files.join(", ") + "。同时检查:调用方兼容性、异常路径、是否引入计划外行为变更。返回 AuditVerdict。",
        );
        if (verdict.passed) break;
        feedback = "上轮阻断问题:" + JSON.stringify(verdict.blocking);
        await impl.ask("修复审计发现的阻断问题,不得引入新偏差:" + feedback);
    }
    return verdict;
};
const [auditA1, auditA2] = await Promise.all([
    auditWave(
        "实现-研究管理-修复",
        "审计-研究管理",
        "study_manager.py:无私有 API/monkey-patch;官方 TPESampler(multivariate,group,constant_liar,seed2023,n_startup15);Hyperband max_resource=train_epochs;RetryHeartbeatStaleTrialCallback(max_retry=1);study user attrs hpo_config 指纹写入+不一致拒绝恢复;JSON/CSV 原子导出且键兼容+新增 trial_state_counts/failure_summary;py_compile 通过。",
        ["src/hpo/study_manager.py"],
    ),
    auditWave(
        "实现-训练修复-修复",
        "审计-训练修复",
        "tools.py EarlyStopping 内存最佳权重(save_path=None);exp train() 结束恢复最佳权重;vali() 增加 MAE 且 epoch report/EarlyStopping 用 args.hpo_metric 选择(默认与现状一致);data_factory val loader shuffle=False/drop_last=False 且 train/test 不变。",
        ["src/utils/tools.py", "src/experiments/exp_long_term_forecasting.py", "src/data_provider/data_factory.py"],
    ),
]);
if (!auditA1.passed || !auditA2.passed) {
    findings.push({
        where: "第一波审计",
        what: "两轮修复后仍有阻断问题未消除",
        evidence: JSON.stringify([auditA1.blocking, auditA2.blocking]),
        status: "verified",
        severity: "high",
    });
}

// ── 第二波:三个互不相交文件集的并行实现 ──

phase("并行实现:HPO 核心、批处理脚本与清理工具");
const [resHpo, resBatch, resDocs] = await Promise.all([
    agent("实现-HPO核心", {
        system: "你是资深 HPO 工程师,实现搜索空间/目标函数/入口改造与 CPU 冒烟测试,不碰 scripts/batch 与 scripts/hpo 的 shell 脚本。\n" + COMMON_CTX,
    }).ask<PhaseResult>(
        [
            "改造以下文件,严格实现:",
            "1) src/hpo/search_space.py:build_search_space(dataset_name, pred_len) 从 src.configs.m2patch_profiles.resolve(dataset, pred_len) 派生逐 (数据集,horizon) 空间;固定有序的参数定义顺序(d_model,e_layers,d_hyp,patch_len,stride,d_layers_diff,diff_steps,manifold_c,lambda_hyp,lambda_prior,dropout,pct_start,learning_rate);不得用 set 遍历。本次 8 个 study 的精确空间:",
            "   ETTh1 pl96/192/336/720:d_model {384,512}/{384,512}/{384,512}/{256,384,512};e_layers {2};d_hyp {32,64,128};learning_rate logU[2e-4,1e-3]/[1e-4,8e-4]/[2e-4,1e-3]/[1e-4,8e-4]。",
            "   ETTm1 pl96/192/336/720:d_model {128,256}/{128,256,384}/{256,384,512}/{128,256,384};e_layers {2};d_hyp {64,128};learning_rate logU[1.5e-4,8e-4]/[1e-4,6e-4]/[1e-4,6e-4]/[1e-4,6e-4]。",
            "   两者共同:patch_len {8,16}、stride {4,8}(全部合法组合,无 stride>patch);d_layers_diff {1,2};diff_steps {1,2};manifold_c logU[0.5,2.0];lambda_hyp logU[0.03,0.3];ETTh1 lambda_prior logU[0.05,0.6]、ETTm1 logU[0.03,0.3];dropout U[0.05,0.2];pct_start U[0.2,0.4]。",
            "   其他数据集按同一规则从 profile 派生:learning_rate 取 profile LR 的 [1/3,3×] 并夹到 [1e-5,5e-3](修复旧上限 1e-3 排除 ETTh2-720/Weather-96/ECL tuned LR 的问题);d_model 取 profile 相邻档;ECL/Traffic/PEMS03/04/07/08 额外收紧(d_model 不超过 profile 档、patch/stride 固定为 profile 值);所有范围必须包含该 (dataset,pl) 的 profile 值。",
            "   get_fixed_params(dataset) 返回固定参数,其中 use_compile 按数据集策略:ECL/Traffic/PEMS03/04/07/08 恒 0,其余取 profile 值;batch_size/optim/lradj/patience 等取 profile;定义 SEARCH_SPACE_VERSION 常量并纳入指纹。",
            "2) src/hpo/objective.py:_RUNTIME_KEYS 增加 use_compile、use_amp、num_workers、hpo_metric;默认 use_amp=0、num_workers=2;fixed 覆盖后传入 Namespace;compile 走上述数据集策略(CLI 显式 0 永远生效);GPU 预算改为按物理 GPU 分文件(temp/optuna/gpu_budget_gpu{物理卡号}.json),键 {study}:{pid}:{trial(用 f-string 拼接)},不再使用 _NoopBudget 专卡假设;trial user attrs 记录 CUDA_VISIBLE_DEVICES、GPU UUID、pid、max_memory_allocated/reserved(MB)、use_amp、compile_requested/compile_effective;异常语义:TrialPruned 仅用于 stride 约束、预算等待超时、最终 NaN/inf 指标、真实 CUDA OOM(attr status=cuda_oom);编译失败签名(PassManager/SubprocException/BackendCompilerFailed/torch._inductor 字样)且 trial 尚无任何已上报 epoch 时:释放失败实例与 CUDA cache,进程级 latch 置 compile 失效,同参数同 seed 重建 eager 模型重跑本 trial,attr compile_fallback=原因;已有上报 epoch 后编译失败或其他未分类异常一律向上抛出(由 Optuna 记 FAIL),删除把异常统一转 TrialPruned 的兜底。",
            "3) scripts/hpo/hpo_tune.py:删除 ConsecutivePrunedStopper;create_study 传入指纹参数(metric/train_epochs/patience/batch_size/use_compile/use_amp/search_space_spec/seed);无历史 trial 时用 resolve 的 profile 值经 enqueue_trial(..., skip_if_exists=True) 作首个锚点(--warm_start 默认 0 不读旧 JSON);main 起始处 setdefault TORCHINDUCTOR_CACHE_DIR=temp/inductor/hpo/{study 名}_{pid}、TORCHINDUCTOR_COMPILE_THREADS=8、OMP_NUM_THREADS=4;新增 --use_amp/--use_compile(默认取数据集策略)与 --log-file(显式日志 owner,--bg 生成含微秒+pid 唯一后缀的新文件,重连不 append 旧文件);任一 study 异常或全部请求 study 完成后 0 个 finite COMPLETE → 进程退出码非 0;warm-start JSON 读取保留但默认关闭。",
            "4) src/configs/common.py:--use_amp BooleanOptionalAction default=False(全局默认关,显式 --use_amp 开启)。",
            "5) 为 fallback 验证加入测试钩子:objective 读环境变量 M2PATCH_TEST_COMPILE_FAIL_ONCE=1 时首个 trial 首次前向抛 RuntimeError('PassManager::run failed (simulated)'),仅此一次。",
            "6) 编写 temp/hpo_smoke_tests.py(纯 CPU、临时目录 temp/hpo_test_* 下自建 storage,不留垃圾):覆盖官方 TPE 采样+命名 set_constraint、log 分布边界、指纹不一致拒绝恢复、异常 FAIL(非 PRUNED)语义、原子导出、数据集 compile 策略传播、EarlyStopping 内存最佳权重恢复(微型 nn 模块);用 " + PY + " temp/hpo_smoke_tests.py 跑通后返回 PhaseResult。",
        ].join("\n"),
    ),
    agent("实现-批处理", {
        system: "你是资深 Slurm/Shell 工程师,只改 shell 与 gpu_budget_reset.py,不碰 Python 模型/HPO 代码。\n" + COMMON_CTX,
    }).ask<PhaseResult>(
        [
            "改造以下文件,严格实现:",
            "1) scripts/batch/batch_3.sh:删除 ETTm2 四行,固定 8 study 配对(slot0={ETTh1:720,ETTm1:96}, slot1={ETTh1:336,ETTm1:192}, slot2={ETTh1:192,ETTm1:336}, slot3={ETTh1:96,ETTm1:720}),每个 800 trials、--metric mse、--save_tmp 0 不变;卡位从 Slurm 实际分配映射:解析 $CUDA_VISIBLE_DEVICES(逗号列表→SLOT 数组,未设置则回退 0 1 2 3),不得假设物理卡号恒为 0-3;每张获配卡恰好 2 个 study;按启动序 (i%4)*20 秒错峰首编译;trap TERM INT 通知并等待全部子进程;启动时向 stdout 打 manifest 行(dataset、pl、slot、物理卡、PID、日志路径),并追加写 temp/optuna/launch_manifest.tsv;任一 study 非零退出 → 整体 exit 1;保留 conda activate m2p、PYTHON_BIN 导出、--gres=gpu:rtx_4090:4、log/slurm 输出。",
            "2) scripts/hpo/hpo_batch.sh:确认其日志为 log/optuna/{ds}_{pl}_study_时间戳.log 的唯一 owner(现状已如此则不动),pid 文件逻辑保留。",
            "3) scripts/hpo/hpo_parallel.sh:do_stop 不再自动调用 gpu_budget_reset.py --prune-study(删除该行,保留 --release-pid);do_stop_all 同理。",
            "4) scripts/hpo/gpu_budget_reset.py:prune_study 不再把 RUNNING trial tell 成 PRUNED;改为仅打印提示(心跳机制负责失联恢复),保留函数入口避免调用方破裂。",
            "完成后 bash -n 全部改动脚本。返回 PhaseResult。",
        ].join("\n"),
    ),
    agent("实现-清理文档", {
        system: "你是工程师,负责清理工具强化与文档同步,只改 hpo_clean.sh 与 AGENTS.md。\n" + COMMON_CTX,
    }).ask<PhaseResult>(
        [
            "严格实现:",
            "1) scripts/hpo/hpo_clean.sh:在现有 --dataset/--pl/--confirm/--dry-run 基础上增加 --full(同时删除对应 output/optuna/{study}_best_params.json、output/optuna/csv/{study}_results.csv、log/optuna/{ds}_{pl}_study_*.log)、--cache(删除 temp/inductor/hpo 下该 study 的编译缓存);执行删除前若 " + SLURM_BIN + "/squeue 存在且查到本用户名含 m2patch 的运行作业,则中止并提示(除非 --force);保持既有确认/干跑语义。",
            "2) AGENTS.md:更新与本次改动相关的三处表述——AMP 默认关闭(原 'AMP is ON (--no-use_amp disables)' 改为默认 FP32、--use_amp 显式开启);HPO 段落补充:官方 TPESampler(multivariate/group/constant_liar)、study 配置指纹校验、RetryHeartbeatStaleTrialCallback、日志位于 log/optuna/ 且每次重连新文件、compile 按数据集策略(ECL/Traffic/PEMS 恒关)。保持 AGENTS.md 现有简洁风格,不展开长段。",
            "返回 PhaseResult。",
        ].join("\n"),
    ),
]);
log("第二波实现完成:" + resHpo.summary + " / " + resBatch.summary + " / " + resDocs.summary);

phase("独立审计第二批改造并修复");
const [auditB1, auditB2, auditB3] = await Promise.all([
    auditWave(
        "实现-HPO核心-修复",
        "审计-HPO核心",
        "search_space 逐 (dataset,pl) 派生且 ETTh1/ETTm1 数值与计划表一致、有序定义、log/uniform 类型正确、范围含 profile 值、ECL/Traffic/PEMS compile 恒 0;objective 的 _RUNTIME_KEYS/默认值/预算按物理 GPU 分文件且键含 study+pid/trial attrs/异常语义(仅约束·超时·NaN·OOM 可 PRUNED;编译失败未上报 epoch 时 eager 重跑+fallback attr+进程 latch;其余抛出为 FAIL);hpo_tune 删除 stopper、指纹接入、锚点 enqueue(skip_if_exists)、独立 TORCHINDUCTOR_CACHE_DIR/线程上限、--log-file 唯一 owner、失败非零退出;common.py use_amp 默认 False;temp/hpo_smoke_tests.py 存在且自测通过。",
        ["src/hpo/search_space.py", "src/hpo/objective.py", "src/hpo/warm_start.py", "scripts/hpo/hpo_tune.py", "src/configs/common.py", "temp/hpo_smoke_tests.py"],
    ),
    auditWave(
        "实现-批处理-修复",
        "审计-批处理",
        "batch_3.sh 恰 8 study、配对正确、CUDA_VISIBLE_DEVICES→slot 映射、每卡 2 个、错峰、trap、manifest、失败非零、800 trials 与 gres 保留;hpo_parallel.sh 停止路径不再 prune-study;gpu_budget_reset.py 不再 tell PRUNED;全部 bash -n 通过。",
        ["scripts/batch/batch_3.sh", "scripts/hpo/hpo_parallel.sh", "scripts/hpo/gpu_budget_reset.py"],
    ),
    auditWave(
        "实现-清理文档-修复",
        "审计-清理文档",
        "hpo_clean.sh 的 --full/--cache/squeue 保护语义正确;AGENTS.md 三处更新准确且简洁。",
        ["scripts/hpo/hpo_clean.sh", "AGENTS.md"],
    ),
]);
if (!auditB1.passed || !auditB2.passed || !auditB3.passed) {
    findings.push({
        where: "第二波审计",
        what: "两轮修复后仍有阻断问题未消除",
        evidence: JSON.stringify([auditB1.blocking, auditB2.blocking, auditB3.blocking]),
        status: "verified",
        severity: "high",
    });
}

phase("全计划终审");
const fixer = agent("修复员", { system: "你是资深修复者,按终审与门禁失败输出做针对性修复,禁止绕过或放宽检查;若不可能通过则升级。\n" + COMMON_CTX });
const finalAudit = await agent("终审-全计划", {
    system: "你是从未参与实现的独立终审员,只读(不得编辑)。对照完整计划审查整体 git diff,找会破坏运行的问题。\n" + COMMON_CTX,
}).ask<AuditVerdict>(
    [
        "运行 git diff 查看全部未提交改动,对照计划核对整体一致性,重点:1) 波次间接口吻合(study_manager 新 create_study 签名 vs hpo_tune 调用;objective 的 hpo_metric/ EarlyStopping best_state 与 exp 的对接;数据集 compile 策略单源);",
        "2) 8-study 运行链路端到端可走通:batch_3 → hpo_tune → create_study 指纹 → objective → Exp 训练/验证 → 导出;",
        "3) 无残留:ConsecutivePrunedStopper、_NoopBudget 专卡路径、旧 monkey-patch、被删函数的调用点;",
        "4) 计划外行为变更清单(若有,逐条列出)。",
        "返回 AuditVerdict(passed 表示可进入测试)。",
    ].join("\n"),
);
verified.push("两波实现均经独立审计员逐条对照计划审计(含调用方兼容与异常路径)");
if (!finalAudit.passed) {
    await fixer.ask("终审阻断问题,逐条修复:" + JSON.stringify(finalAudit.blocking));
    const recheck = await agent("终审复核员", {
        system: "你是独立终审员,只读复核修复结果。\n" + COMMON_CTX,
    }).ask<AuditVerdict>("复核以下阻断问题是否已修复且未引入新问题:" + JSON.stringify(finalAudit.blocking));
    if (!recheck.passed) {
        findings.push({ where: "终审", what: "复核后仍存在阻断问题", evidence: JSON.stringify(recheck.blocking), status: "verified", severity: "high" });
    }
}

// ── 门禁:语法 + CPU 冒烟 ──

phase("语法检查与 CPU 冒烟门禁");
let cpuOk = false;
let cpuFeedback = "";
for (let round = 1; round <= 3 && !cpuOk; round++) {
    const syntax = await world.run("bash", ["-c", "for f in scripts/batch/*.sh scripts/hpo/*.sh; do bash -n \"$f\" || exit 1; done"]);
    if (syntax.exitCode !== 0) {
        cpuFeedback = "bash -n 失败:\n" + syntax.stdout + syntax.stderr;
        await fixer.ask("修复 shell 语法错误:" + cpuFeedback);
        continue;
    }
    const pycheck = await world.run("/userhome/cs3/xschen2/miniconda3/envs/m2p/bin/python", ["-m", "py_compile", "src/hpo/study_manager.py", "src/hpo/objective.py", "src/hpo/search_space.py", "src/hpo/warm_start.py", "scripts/hpo/hpo_tune.py", "scripts/hpo/gpu_budget_reset.py", "src/utils/tools.py", "src/experiments/exp_long_term_forecasting.py", "src/data_provider/data_factory.py", "src/configs/common.py"], { output: { tail: 8192 } });
    if (pycheck.exitCode !== 0) {
        cpuFeedback = "py_compile 失败:\n" + pycheck.stdout + pycheck.stderr;
        await fixer.ask("修复 Python 编译错误:" + cpuFeedback);
        continue;
    }
    const smoke = await world.run("/userhome/cs3/xschen2/miniconda3/envs/m2p/bin/python", ["temp/hpo_smoke_tests.py"], { timeoutMs: 600000, output: { tail: 16384 } });
    if (smoke.exitCode === 0) {
        cpuOk = true;
    } else {
        cpuFeedback = smoke.stdout + smoke.stderr;
        await fixer.ask("temp/hpo_smoke_tests.py 失败,针对性修复(测试或实现,不得删断言造假):" + cpuFeedback.slice(-4000));
    }
}
if (!cpuOk) {
    return {
        conclusion: "CPU 门禁三轮未通过,工作流按预案停止,未提交 sbatch。最后失败输出已交给修复员,仍无法通过。",
        findings,
        verified,
        notCovered: ["GPU 压测与正式 8-study 运行(CPU 门禁未过而中止)"],
    };
}
verified.push("bash -n 全部 shell 脚本通过;" + PY + " -m py_compile 全部改动 Python 通过;temp/hpo_smoke_tests.py 通过");

// ── GPU 压测 ──

phase("四卡 GPU 压测验证");
let gpuPass = false;
let gpuReport: GpuReport = { pass: false, perGpuPeakMb: [], compileFallbackVerified: false, issues: [] };
for (let round = 1; round <= 3 && !gpuPass; round++) {
    gpuReport = await agent("GPU压测员-" + round, {
        system: "你是 GPU 压测工程师,使用 srun 在 4090 节点实测,禁止 sbatch 正式作业、禁止改动源码;测完清理自己创建的 DB/日志/缓存。\n" + COMMON_CTX,
    }).ask<GpuReport>(
        [
            "在 debug 分区申请 1 节点 4 卡(srun -p debug --gres=gpu:rtx_4090:4 -t 30 --mem=64G,必要时 --cpus-per-task=16),执行真实 M2Patch 双并行压测:",
            "1) 在节点上以 8 个后台进程复现 batch_3 配对(每卡 2 个):ETTh1/ETTm1 对应 pl,每进程 " + PY + " scripts/hpo/hpo_tune.py --dataset X --pred_len N --n_trials 1 --gpu 0 --metric mse --save_tmp 0,各自 CUDA_VISIBLE_DEVICES 指向所在物理卡;FP32(默认)、compile 按策略开启。",
            "2) 期间每 20 秒采样 nvidia-smi 各卡显存,记录每卡峰值;同时 tail 各进程日志 grep PassManager|SubprocException|out of memory|Traceback。",
            "3) 单独验证 eager fallback:任一进程以 M2PATCH_TEST_COMPILE_FAIL_ONCE=1 再跑一次,确认该 trial 以 eager 重跑完成且 user attr compile_fallback 存在、退出码 0。",
            "4) 通过标准:8 进程全部出现≥1 个 epoch 完成且至少一个进程 trial COMPLETE;每卡峰值 ≤ 物理显存的 80%;无编译崩溃/OOM。",
            "5) 结束后删除你创建的 temp/optuna/M2Patch_ETTh1_pl*.db、M2Patch_ETTm1_pl*.db、对应 log/optuna/*.log 与 temp/inductor/hpo。",
            "返回 GpuReport(issues 里写明任何异常与未验证项;做不到的写明原因,不要伪造)。",
        ].join("\n"),
    );
    if (gpuReport.pass) {
        gpuPass = true;
    } else {
        await fixer.ask("GPU 压测第 " + round + " 轮未通过,按计划做针对性修复(例如 fallback 语义、缓存隔离、资源键;不得降低双并行或减少 study):" + JSON.stringify(gpuReport.issues));
    }
}
verified.push("四卡 GPU 双并行压测:每卡峰值 " + gpuReport.perGpuPeakMb.map((g) => g.gpu + "=" + g.peakMb + "MB").join(", ") + ";eager fallback 验证=" + String(gpuReport.compileFallbackVerified));
if (!gpuPass) {
    findings.push({ where: "GPU压测", what: "三轮修复后压测仍未通过", evidence: JSON.stringify(gpuReport.issues), status: "verified", severity: "high" });
}

// ── 清理旧状态 ──

phase("清理旧状态与测试产物");
const guard = await world.run("bash", ["-c", SLURM_BIN + "/squeue -u $USER -h -o '%A:%j' | grep m2patch | cut -d: -f1 | xargs -r " + SLURM_BIN + "/scancel; sleep 3; " + SLURM_BIN + "/squeue -u $USER -h -o '%A %j %T' | grep m2patch || true"]);
if (guard.stdout.trim() !== "") {
    findings.push({ where: "清理前置检查", what: "存在无法取消的 m2patch 作业,已中止清理", evidence: guard.stdout, status: "verified", severity: "high" });
    return { conclusion: "清理前置检查发现仍在运行的 m2patch 作业且 scancel 后未消失,工作流停止。", findings, verified, notCovered: ["正式运行"] };
}
const cleanup = await world.run("bash", ["-c", "rm -f temp/optuna/M2Patch_ETTh1_pl*.db temp/optuna/M2Patch_ETTm1_pl*.db temp/optuna/M2Patch_ETTm2_pl*.db temp/optuna/pids/*.pid temp/optuna/gpu_budget*.json temp/optuna/gpu_budget*.lock temp/optuna/_all_studies.db output/optuna/M2Patch_ETTh1_pl*_best_params.json output/optuna/M2Patch_ETTm1_pl*_best_params.json output/optuna/M2Patch_ETTm2_pl*_best_params.json output/optuna/csv/M2Patch_ETTh1_pl*_results.csv output/optuna/csv/M2Patch_ETTm1_pl*_results.csv output/optuna/csv/M2Patch_ETTm2_pl*_results.csv log/optuna/*.log log/slurm/*.out temp/compile_smoke.py temp/hpo_smoke_tests.py && rm -rf temp/inductor temp/hpo_test_* && mkdir -p log/slurm log/optuna temp/optuna temp/inductor && echo CLEAN_OK"]);
if (cleanup.exitCode !== 0 || !cleanup.stdout.includes("CLEAN_OK")) {
    return { conclusion: "清理命令失败,工作流停止:" + cleanup.stderr, findings, verified, notCovered: ["正式运行"] };
}
const fresh = await world.run("bash", ["-c", "ls temp/optuna/M2Patch_*.db 2>/dev/null | grep -E 'ETTh1|ETTm1' || echo FRESH"]);
if (!fresh.stdout.includes("FRESH")) {
    await world.run("bash", ["-c", "rm -f temp/optuna/M2Patch_ETTh1_pl*.db temp/optuna/M2Patch_ETTm1_pl*.db"]);
}
verified.push("旧失败 DB/导出/日志/编译缓存/诊断脚本已清理,正式 study 从零开始(清理前已确认无存活 m2patch 作业)");
log("旧状态清理完成,准备提交");

// ── 提交 ──

phase("提交 sbatch 并确认启动");
let jobId = "unknown";
for (let attempt = 1; attempt <= 2; attempt++) {
    const submit = await world.run("bash", ["-c", "mkdir -p log/slurm && " + SLURM_BIN + "/sbatch scripts/batch/batch_3.sh"], { timeoutMs: 120000 });
    const m = /Submitted batch job (\d+)/.exec(submit.stdout);
    if (m) {
        jobId = m[1]!;
        break;
    }
    await fixer.ask("sbatch 提交失败(第 " + attempt + " 次),诊断并修复(检查 #SBATCH 指令/目录/权限):" + submit.stdout + submit.stderr);
}
if (jobId === "unknown") {
    return { conclusion: "sbatch 两次提交失败,工作流停止。", findings, verified, notCovered: ["8-study 正式运行"] };
}
log("已提交作业 " + jobId + ",进入稳定性监测");

// ── 监测 ──

phase("监测 8 个 study 直至稳定运行");
let stable = false;
let lastStatus: MonitorStatus = { stable: false, jobRunning: false, studiesAlive: 0, details: [], oom: false, errors: [], observedMinutes: 0 };
for (let round = 1; round <= 4 && !stable; round++) {
    lastStatus = await agent("监测员-" + round, {
        system: "你是运行监测工程师,只读监测(禁止 scancel/编辑;发现致命问题立即返回而不是擅自动手)。\n" + COMMON_CTX,
    }).ask<MonitorStatus>(
        [
            "监测 Slurm 作业 " + jobId + "(m2patch-hpo-b3),总观察时长≥15分钟,每 5 分钟一轮:",
            "1) " + SLURM_BIN + "/squeue -j " + jobId + " 确认 RUNNING 与节点;",
            "2) log/slurm/m2patch-hpo-b3-" + jobId + ".out 应有 8 行 Launched 与 manifest;log/optuna/ 最新 8 个日志出现 Study 头、Single GPU mode: CUDA_VISIBLE_DEVICES 分布为 {0,0,1,1,2,2,3,3}(slot 映射)、[I ...] A new study created、Epoch 行;",
            "3) 用 " + SLURM_BIN + "/srun --jobid=" + jobId + " nvidia-smi 确认每卡恰好 2 个 python 进程并记录显存;",
            "4) 用 " + PY + " 只读加载各 study DB 统计 trial 状态(COMPLETE/PRUNED/FAIL)与最优值;",
            "5) grep 日志中 out of memory|PassManager|SubprocException|未分类 Traceback;",
            "6) 每轮把各 study 状态作为 details 返回;stable 判定=8 study 存活、合计≥8 个 COMPLETE 或持续新 trial、无 OOM/未分类异常、观察≥15 分钟。",
            "返回 MonitorStatus(字段据实填写,做不到的写进 errors)。",
        ].join("\n"),
    );
    for (const s of lastStatus.details) {
        report({ study: s.study, state: s.state, completed: s.completed, pruned: s.pruned, failed: s.failed, lastProgress: s.lastProgress.slice(0, 120) }, "study-status");
    }
    if (lastStatus.stable) {
        stable = true;
    } else {
        const stillRunning = await world.run("bash", ["-c", SLURM_BIN + "/squeue -j " + jobId + " -h -o %T"]);
        if (stillRunning.stdout.trim() === "") {
            await fixer.ask("作业 " + jobId + " 已死亡,按监测证据定位并修复后准备重提:" + JSON.stringify({ errors: lastStatus.errors, details: lastStatus.details }));
            const resub = await world.run("bash", ["-c", "mkdir -p log/slurm && " + SLURM_BIN + "/sbatch scripts/batch/batch_3.sh"], { timeoutMs: 120000 });
            const m2 = /Submitted batch job (\d+)/.exec(resub.stdout);
            jobId = m2 ? m2[1]! : jobId;
            log("重提作业,新 JOBID=" + jobId);
        } else {
            await fixer.ask("作业运行中但未达稳定标准,做针对性修复(不得降低双并行/删 study;若需改代码,注意只影响后续 trial):" + JSON.stringify(lastStatus.errors));
        }
    }
}
verified.push(
    "监测作业 " + jobId + ":" + lastStatus.observedMinutes + " 分钟,存活 study " + lastStatus.studiesAlive + "/8,OOM=" + String(lastStatus.oom) +
        ";各 study 进度见 study-status 表",
);
if (!stable) {
    findings.push({ where: "运行监测", what: "四轮监测后仍未完全达到稳定标准", evidence: JSON.stringify(lastStatus.errors), status: "verified", severity: "medium" });
}

// ── 清洁性终审 ──

phase("代码清洁性终审");
const cleanliness = await agent("清洁审计员", {
    system: "你是代码清洁审计员,允许编辑但只做注释/风格清理,严禁任何行为变更;完成后自跑语法检查。\n" + COMMON_CTX,
}).ask<PhaseResult>(
    [
        "对本次全部改动文件(git diff 列出)做清洁性清理:",
        "1) 删除冗余/啰嗦/过时的注释,仅保留必要的简明注释(张量形状标注、关键决策一句话);",
        "2) 核对 AGENTS.md 风格:无文件头注释块、无多行 docstring(一行 purpose 允许)、双引号、4 空格缩进、≤180 列;",
        "3) 删除实现过程中的临时调试代码、被注释掉的死代码、测试钩子除 M2PATCH_TEST_COMPILE_FAIL_ONCE 外一律不留;",
        "4) 完成后运行 bash -n(改动 shell)与 " + PY + " -m py_compile(改动 Python)确认语法完好;声明未改变任何行为。",
        "返回 PhaseResult(summary 说明清理了什么,files 列出触碰的文件)。",
    ].join("\n"),
);
const postClean = await world.run("bash", ["-c", "for f in scripts/batch/batch_3.sh scripts/hpo/hpo_tune.py src/hpo/study_manager.py src/hpo/objective.py src/hpo/search_space.py; do case \"$f\" in *.sh) bash -n \"$f\" || exit 1;; *) " + PY + " -m py_compile \"$f\" || exit 1;; esac; done && echo POSTCLEAN_OK"]);
if (!postClean.stdout.includes("POSTCLEAN_OK")) {
    findings.push({ where: "清洁终审", what: "清理后语法检查未通过,已回退风险", evidence: postClean.stdout + postClean.stderr, status: "verified", severity: "high" });
}
verified.push("清洁性终审完成(" + cleanliness.summary + "),清理后语法门禁复检通过");

notCovered.push("8×800 trials 的完整收敛(作业由 Slurm 独立继续,本次仅验证稳定启动)");
notCovered.push("ETTh2/ETTm2/Weather 等其余数据集的搜索空间仅经代码审计与单测,未实跑");

phase("汇总最终报告");
await artifact.markdown(
    "final-report",
    [
        "# M2Patch Optuna 5.1 改造与 8-study 运行报告",
        "",
        "- Slurm 作业:JOBID " + jobId + "(m2patch-hpo-b3,4×RTX 4090,每卡 2 study,各 800 trials)",
        "- 稳定性:观察 " + lastStatus.observedMinutes + " 分钟,存活 " + lastStatus.studiesAlive + "/8,OOM=" + String(lastStatus.oom),
        "- GPU 压测峰值:" + gpuReport.perGpuPeakMb.map((g) => g.gpu + " " + g.peakMb + "MB").join(";"),
        "- 实现摘要:第一波 " + resStudy.summary + " / " + resTrain.summary,
        "- 第二波 " + resHpo.summary + " / " + resBatch.summary + " / " + resDocs.summary,
        "- 清洁终审:" + cleanliness.summary,
        "",
        "## 各 study 状态",
        ...lastStatus.details.map((s) => "- " + s.study + ":" + s.state + "(完成 " + s.completed + "/剪枝 " + s.pruned + "/失败 " + s.failed + ")"),
        "",
        "## 已验证",
        ...verified.map((v) => "- " + v),
        "",
        "## 未覆盖",
        ...notCovered.map((v) => "- " + v),
    ].join("\n"),
    { title: "Optuna 5.1 改造与 8-study 运行报告", description: "实现、审计、压测、清理、提交与监测的全过程结论。", primary: true },
);

const result: WorkflowReport = {
    conclusion: "Optuna 5.1 化改造已按计划完成并通过分阶段独立审计、CPU 门禁与四卡 GPU 压测;旧失败状态清理后作业 " + jobId + " 已从零启动 8 个 study(每卡双并行),稳定观察 " + lastStatus.observedMinutes + " 分钟后按约定结束监测,完整 6400-trial 搜索由 Slurm 继续独立运行。",
    findings,
    verified,
    notCovered,
};
return result;