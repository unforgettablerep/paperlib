# M2Patch 实验报告：八组实验的结果、机理与论文写作参考

## 0. 文档定位与数据口径

本报告面向人工智能顶刊/顶会论文实验章节的撰写，汇总 M2Patch 在计算效率、长回看窗口、零样本高斯噪声、定性案例、机制分析、OFAT 消融、跨数据集非参数统计检验与核心超参数敏感性八组实验中的最终落盘结果，并给出与 `assets/1_specification.md` 中数学机理相对应的原因分析。核心实验数值取自 `output/` 下的最终产物；收缩偏差、标准化一阶差分等派生量按代码与数据复算，并在正文标注口径。不同实验的训练预算、批大小与评价空间在对应小节单独标注，跨实验的绝对数值不直接混用。

| 实验 | 主要数据源 | 规模 |
| --- | --- | --- |
| 计算效率 | `output/efficiency/m2patch_results/M2Patch_{ETTm1,Weather,ECL}_*.json`；`output/efficiency/results_by_dataset/{ETTm1,Weather,ECL}.jsonl` | 3 个 M2Patch 运行 + 11 个基线 × 3 个设置 = 36 条记录 |
| 长回看 | `output/lookback/{M2Patch,PatchTST,S_Mamba,TimeMixer,iTransformer,Transformer}.tsv` | 3 数据集 × 5 个 $L$ × 6 模型 = 90 行 |
| 零样本噪声 | `output/robustness/{ETTm1,ETTm2}_robustness.tsv` | 2 数据集 × 4 个 $H$ × 5 个 $\sigma$ = 40 行 |
| OFAT 消融 | `output/ablation/{none,euclid_manifold,no_hyp_cond,zero_prior_bridge,no_adaln,no_denoise_refinement,no_causal_prefix_norm,no_hyp_loss,no_prior_loss}.tsv` | 3 数据集 × 4 个 $H$ × 9 组（含 `none`）= 108 个实测单元；注册网格 6 数据集 |
| 机制分析 | `output/mechanism/results/{ETTh2,ETTm1,Exchange}.tsv`；`output/mechanism/m2patch_mechanism_summary.tsv` | 3 数据集 × 5 变体 = 15 行 |
| 跨数据集统计检验 | `output/statistics/{benchmark_matrix.csv,stat_tests_results.csv,stat_tests_summary.md}` | 3 数据集 × 4 个 $H$ = 12 个区块 × 8 模型 |
| 共享协议主表 | `output/benchmark/{ETTh2,ETTm1,Exchange}.tsv` | 3 数据集 × 4 个 $H$ × 7 个基线 = 84 行 |
| 定性案例 | `output/case_study/case_study.tsv`；`output/case_study/figures/captions.md`；`output/case_study/record_*/`（本地记录，git-ignored） | 4 数据集 × 5 模型 = 20 行 |
| 超参数敏感性 | `output/hyperparam/sensitivity_results_{ETTh1,ETTh2,ETTm1,Weather,Exchange}.tsv` | 5 数据集 × 4 参数 × 4 取值 × 5 seeds = 400 行 |

Robustness 的两个文件分别为 `output/robustness/ETTm1_robustness.tsv` 与 `output/robustness/ETTm2_robustness.tsv`；敏感性结果以 `output/hyperparam/sensitivity_results_ETTh1.tsv` 等命名。三个效率 JSON 分别为 `M2Patch_ETTm1_pl96_20261119_225733.json`、`M2Patch_Weather_pl96_20261119_230514.json`、`M2Patch_ECL_pl336_20261119_231341.json`。`record_*/` 为案例脚本的本地运行产物，`.gitignore` 已忽略；克隆仓库后需重跑 `scripts/case_study/run_case_study.sh` 生成，窗口 MSE 与选择结果另见 `output/case_study/figures/captions.md`。消融工作簿为 `output/ablation/m2p-ablation.xlsx`（`Main Table` 与 `Full Detail` 两个工作表），由 `output/ablation/update_ablation.py` 从各变体 TSV 重建；统计检验的完整逐项结果见 `output/statistics/stat_tests_results.csv`。

统一记号：$L$ 为历史回看长度，$H$ 为预测步长，$C$ 为通道数，$P$ 为 Patch 长度，$S$ 为 Patch 步长，$N_{\text{hist}}=(L+L_{\text{pad}}-P)/S+1$，$N_{\text{fut}}=\lceil H/P\rceil$，$d_{\text{model}}$ 为主干宽度，$d_{\text{hyp}}$ 为庞加莱球维数，$K$ 为 Bridge-DDIM 步数。

硬件与软件环境：单卡 NVIDIA RTX 4090 D（24 GB），PyTorch 2.8.0+cu129（CUDA 12.9，当前 `m2p` 环境），FP32 训练；安装脚本以 CUDA 12.8 为发布基线，当前主机存在 12.8→12.9 的运行时漂移。除特别说明外随机种子为 2023。

### 0.1 符号与落盘字段对照

报告中的数学符号与 `output/` 结果文件、CLI 参数使用不同命名。为便于后续写作时准确引用，对照如下：

| 数学符号 | 落盘字段 / CLI 名 | 含义 |
| --- | --- | --- |
| $d_{\text{model}}$ | `d_model` | 主干宽度 |
| $d_{\text{ff}}$ | `d_ff` | 前馈网络宽度 |
| $e$ | `e_layers` | 因果编码器层数 |
| — | `n_heads` | 注意力头数 |
| $d_{\text{hyp}}$ | `d_hyp` | 庞加莱球维数 |
| $d_{\text{layers\_diff}}$ | `d_layers_diff`（亦记作 `L_diff`） | 去噪器层数 |
| $K$ | `diff_steps`（`K=1` 为默认单步） | Bridge-DDIM 步数 |
| $\sigma$（σ） | `noise_level` | 测试集高斯噪声标准差 |
| — | `ablation` | 消融/机制变体标识 |
| $\lambda_{\text{hyp}}$ | `lambda_hyp` | 双曲几何损失权重 |
| $\lambda_{\text{prior}}$ | `lambda_prior` | 先验锚点损失权重 |
| $\eta$（η） | `learning_rate` | 优化器学习率（第 9 节扫描对象） |
| $\eta_{\text{DDIM}}$（η_DDIM） | `diff_eta` | DDIM 随机性系数（默认 0.0） |
| $L$ | `seq_len` | 历史回看长度 |
| $H$ | `pred_len` | 预测步长 |
| $C$ | `enc_in` | 通道数 |
| $P$ | `patch_len` | Patch 长度 |
| $S$ | `stride` | Patch 步长 |
| $c$ | `manifold_c` | 曲率参数 |
| — | `revin` | 历史统计量锁定 RevIN 开关 |
| — | `optim` / `lradj` / `train_epochs` / `batch_size` | 优化器 / 调度器 / 训练轮数 / 批大小 |
| — | `mse` / MSE | 均方误差（TSV 列名 `mse`） |
| — | `mae` / MAE | 平均绝对误差（TSV 列名 `mae`） |
| — | `O(d_hyp)` | 单个双曲算子的闭式复杂度 |

其中 `d_hyp`、`d_model`、`d_layers_diff`、`noise_level` 与 `ablation` 直接对应 `src/configs/custom_M2Patch.py` 与 `src/utils/result_io.py` 的字段名；第 9 节的 $\eta$ 专指学习率，避免与 `diff_eta` 混淆。

---

## 1. 实验设置与实现协议（Experimental Setup & Protocol）

### 1.1 数据集与任务定义

任务为多变量长期预测：给定历史窗口 $\mathbf{X}\in\mathbb{R}^{B\times L\times C}$，预测未来 $\mathbf{Y}\in\mathbb{R}^{B\times H\times C}$。所有数据集采用 `features=M`，损失与 MSE/MAE 覆盖全部 $C$ 个通道；数据表中所列的 OT 通道仅用于案例研究的可视化与窗口误差统计。

| 数据集 | 领域 / 采样频率 | $C$ | 训练/验证/测试（行数或比例） | $L$ | $H$ |
| --- | --- | --- | --- | --- | --- |
| ETTh1 / ETTh2 | 电力变压器 / 1 h | 7 | 8640 / 2880 / 2880 | 96 | 96, 192, 336, 720 |
| ETTm1 / ETTm2 | 电力变压器 / 15 min | 7 | 34560 / 11520 / 11520 | 96 | 96, 192, 336, 720 |
| Weather | 气象 / 10 min | 21 | 36887 / 5270 / 10539 | 96 | 96, 192, 336, 720 |
| ECL | 电力负荷 / 1 h | 321 | 18412 / 2632 / 5260 | 96 | 96, 192, 336, 720 |
| Exchange | 金融汇率 / 1 d | 8 | 5311 / 760 / 1517 | 96 | 96, 192, 336, 720 |
| Traffic | 城市交通 / 1 h | 862 | 12280 / 1756 / 3508 | 96 | 96, 192, 336, 720 |
| Solar | 光伏 / 10 min | 137 | 36792 / 5256 / 10512 | 96 | 96, 192, 336, 720 |
| PEMS03/04/07/08 | 高速交通 / 5 min | 358/307/883/170 | 60% / 20% / 20% | 96 | 12, 24, 48, 96 |
| Illness | 公共卫生 / 1 周 | 7 | 676 / 97 / 193 | 36 | 24, 36, 48, 60 |

数据集覆盖五类本质难点：

- **强周期与多尺度季节性**：ETT、ECL、Traffic、Solar 具有日/周周期，Weather 叠加日周期与年周期；长回看实验（第 3 节）主要检验模型对多周期历史的利用能力。
- **高维与尺度异质**：ECL 的 321 个用户通道标准差跨度约 $1.7\times 10^4$，Traffic 达 862 维；通道独立建模使有效批大小变为 $B\cdot C$，直接决定显存开销（第 2 节）。
- **非平稳与弱周期**：Exchange 为日频随机游走式汇率，训练样本仅 5311 行，容量过大时容易过拟合（第 9 节）。
- **缺失哨兵与结构零值**：Weather 含 `-9999` 缺失标记，Solar 夜间存在结构性零值；两者对归一化与方差下界敏感（第 4 节）。
- **小样本**：Illness 仅 966 行、$L=36$，用于检验模型在低资源场景的退化行为。

标准化协议：`StandardScaler` 仅在训练段拟合，再变换验证/测试段；模型内部再执行仅使用历史统计量的 RevIN。主表 MSE/MAE 在该数据集级标准化空间计算，案例研究通过 `--inverse` 还原到原始物理量纲。

### 1.2 基线模型家族

| 家族 | 模型 | 核心机制 | 覆盖路线 |
| --- | --- | --- | --- |
| 扩散 / 生成式 | MMPD (ICLR 2026) | Patch 一致扩散损失、patch-consistent MLP 去噪器与多模态 GMM 推断；本仓库使用确定性锚点预测 | 生成式损失与多模态分布建模 |
| 几何 / 信号分解 | SimpleTM (ICLR 2025) | 平稳小波变换与几何注意力，伪时间 Token 加线性投影 | 信号分解与轻量注意力 |
| Mamba / 状态空间模型 | S-Mamba | 选择性状态空间扫描，线性复杂度长序列建模 | 线性时间序列建模 |
| 倒置 / 分块 Transformer | iTransformer、PatchTST、Transformer、Informer、Autoformer、Flowformer | iTransformer 以变量为 Token；PatchTST 以 Patch 为 Token 并通道独立；其余为经典/稀疏/自相关/流注意力 Transformer | 注意力与 Patch 化 |
| 多尺度 MLP / 分解网络 | TimeMixer、DLinear | TimeMixer 多尺度可分解混合；DLinear 趋势-季节分解加线性映射 | 纯 MLP 与分解 |

效率实验的 M2Patch 与 11 个基线统一采用 10 epochs、`batch_size=16`、FP32（`use_amp=0`）、seed 2023，单卡顺序测量；每条基线记录均写入 `train_epochs=10`、`batch_size=16`、`use_amp=false`。主表、长回看、鲁棒性、案例研究、OFAT 消融与机制实验使用 15 epochs 的调优预算；超参数敏感性固定 $H=96$、15 epochs，并扫描 5 个随机种子。该分层协议区分“统一短预算横向对照”与“充分训练后的精度上界”两类结论。

### 1.3 损失函数

训练目标为四项耦合的三位一体损失（规范 §4.6）：

$$
\mathcal{L}_{\text{total}}
= \underbrace{\mathcal{L}_{x_0}+\mathcal{L}_{\text{noise}}}_{\mathcal{L}_{\text{bridge}}}
+ \lambda_{\text{raw}}\mathcal{L}_{\text{raw}}
+ \lambda_{\text{hyp}}\underbrace{\left(\mathcal{L}_{\text{geo}}+\mathcal{L}_{\text{trans}}\right)}_{\mathcal{L}_{\text{hyp}}}
+ \lambda_{\text{prior}}\mathcal{L}_{\text{prior}} .
$$

- **先验桥接去噪损失** $\mathcal{L}_{\text{bridge}}$：对未来 Patch 的干净目标 $x_0$ 与桥接噪声 $\epsilon$ 同时回归，权重为 SNR 因子 $w_t=\alpha_t^2$；每个样本按目标能量 $\frac{1}{V_i}\sum P_0^2+1$ 归一化，Huber 核 $\delta=1$。桥接前向分布为 $\mathbf{P}_t=\alpha_t\mathbf{P}_0+(1-\alpha_t)\mathbf{P}_{\text{prior}}+\sigma_t\epsilon$。
- **原始物理空间重构损失** $\mathcal{L}_{\text{raw}}$：在 RevIN 反归一化后的物理量纲上计算样本级能量归一化 Huber 损失，权重 $\lambda_{\text{raw}}=1.0$。
- **双曲几何损失** $\mathcal{L}_{\text{hyp}}$：$\mathcal{L}_{\text{geo}}$ 约束去噪未来流形点与冻结正交 DCT 目标流形点之间的测地线距离，采用有理饱和 $d^2/(1+d^2)$；$\mathcal{L}_{\text{trans}}$ 以最后一个历史流形点为基点，约束“历史末尾 $\to$ 未来首 Patch”的切空间跃迁向量。
- **先验锚点损失** $\mathcal{L}_{\text{prior}}$：监督历史先验 $\mathbf{Y}_{\text{prior}}$ 逼近归一化未来目标，保证桥接终点贴近真实趋势。

默认 $\lambda_{\text{hyp}}=0.1$、$\lambda_{\text{prior}}=0.1$；各数据集 profile 在 0.05–0.5 之间调整。该损失体系的关键性质是尺度不变：样本能量归一化与有理饱和共同抑制极端高幅值窗口对参数更新的主导。

### 1.4 优化与评价协议

| 实验 | epochs | batch size | 网格 | 评价空间 |
| --- | --- | --- | --- | --- |
| 主表 benchmark | 15 | 32 | ETTh2/ETTm1/Exchange × 4 个 $H$；7 个基线 | 标准化空间 |
| 长回看 / 鲁棒性 | 15 | 32（ECL 为 16） | $L\in\{48,96,192,336,720\}$；$\sigma\in\{0,0.1,0.2,0.3,0.5\}$ | 标准化空间 |
| 定性案例 | 15 | 32（ECL 为 16） | 4 数据集 × 96 -> 96 | 原始量纲 |
| OFAT 消融 | 15 | 32 | 3 个实测数据集 × 4 个 $H$ × 8 个变体 + `none` 基线（Optuna 配置） | 标准化空间 |
| 机制分析 | 15 | 32 | 3 数据集 × $H=96$ × 5 个变体（Optuna 配置） | 标准化空间 |
| 计算效率 | 10 | 16 | ETTm1 $H=96$、Weather $H=96$、ECL $H=336$ | 标准化空间 |
| 超参数敏感性 | 15 | 32 | 5 数据集 × 4 参数 × 4 取值 × 5 seeds，$H=96$ | 标准化空间 |

优化器为 Adam（`weight_decay=0`），调度器为 OneCycleLR（`pct_start=0.2`），早停 patience 为 5。SimpleTM 使用其官方默认的 AdamW 与 `type1` 调度。评价指标为

$$
\mathrm{MSE}=\frac{1}{NHC}\sum_{n,t,c}\left(\hat{Y}_{n,t,c}-Y_{n,t,c}\right)^2,
\qquad
\mathrm{MAE}=\frac{1}{NHC}\sum_{n,t,c}\left|\hat{Y}_{n,t,c}-Y_{n,t,c}\right|,
$$

其中 $N$ 为测试滑窗数。MSE 对大误差更敏感，用于检验陡峭波峰/波谷的还原；MAE 反映平均绝对偏差，用于检验整体水平与相位。

---

## 2. 计算效率与精度-资源权衡分析（Computational Efficiency Analysis）

### 2.1 测量口径

三个设置（ETTm1 $H=96$、Weather $H=96$、ECL $H=336$）的 M2Patch 与 11 个基线全部采用 10 epochs、`batch_size=16`、FP32（`use_amp=0`）、seed 2023，在单张 NVIDIA RTX 4090 D（24 GB）上顺序测量。`train_time_ms_per_iter` 为训练日志中每 100 次迭代的平均 step time 再对全日志取均值，包含数据加载、前向、反向与优化器更新；`avg_gpu_mem_allocated_mb` 为每 100 次迭代记录的 `torch.cuda.max_memory_allocated()` 峰值再取均值。`inference_time_ms_per_iter` 为测试阶段纯前向时延：CUDA 同步后计时，前 5 个测试批作为预热剔除，单位为一个 `batch_size=16` 的测试批。`params` 为模型构建后统计的总参数量。MSE/MAE 在数据集级标准化空间计算，不受计时环境影响。

### 2.2 精度对比

| 模型 | ETTm1 MSE | ETTm1 MAE | Weather MSE | Weather MAE | ECL MSE | ECL MAE |
| --- | --- | --- | --- | --- | --- | --- |
| M2Patch | 0.3289 | 0.3566 | 0.1737 | 0.2128 | 0.2061 | 0.2883 |
| MMPD | **0.3171** | **0.3520** | 0.1877 | 0.2251 | 0.2095 | 0.2907 |
| SimpleTM | 0.3475 | 0.3782 | 0.1889 | 0.2299 | 0.2457 | 0.3339 |
| S-Mamba | 0.3297 | 0.3661 | 0.1662 | 0.2093 | **0.1782** | 0.2738 |
| TimeMixer | 0.3359 | 0.3725 | **0.1626** | **0.2092** | 0.1867 | 0.2760 |
| iTransformer | 0.3403 | 0.3748 | 0.1774 | 0.2186 | 0.1809 | **0.2729** |
| PatchTST | 0.3269 | 0.3648 | 0.1756 | 0.2192 | 0.1966 | 0.2826 |
| DLinear | 0.3463 | 0.3733 | 0.1683 | 0.2137 | 0.2039 | 0.2883 |
| Autoformer | 0.6378 | 0.5326 | 0.3347 | 0.3916 | 0.2555 | 0.3573 |
| Informer | 0.6117 | 0.5518 | 0.3551 | 0.4198 | 0.3301 | 0.4186 |
| Flowformer | 0.4934 | 0.4844 | 0.3277 | 0.3994 | 0.2673 | 0.3615 |
| Transformer | 0.6328 | 0.5582 | 0.4963 | 0.5002 | 0.2694 | 0.3631 |

加粗为该设置下 12 个模型的最低值。M2Patch 的 MSE 排名为 ETTm1 第 3、Weather 第 4、ECL 第 6；MAE 排名为 ETTm1 第 2、Weather 第 3、ECL 第 5（M2Patch 0.2883138，DLinear 0.2883418 紧随）。以各设置最优基线为分母，M2Patch 的 MSE 差距为 ETTm1 $+3.73\%$（MMPD 0.3171）、Weather $+6.81\%$（TimeMixer 0.1626）、ECL $+15.64\%$（S-Mamba 0.1782）。三个设置的 12 模型平均秩中，M2Patch 为 4.33，S-Mamba 2.33、TimeMixer 3.00、PatchTST 3.67、iTransformer 4.67。

### 2.3 参数、推理时延与训练开销

**参数量（M）与推理时延（ms/batch，batch=16）**

| 模型 | ETTm1 Params | ETTm1 推理 | Weather Params | Weather 推理 | ECL Params | ECL 推理 |
| --- | --- | --- | --- | --- | --- | --- |
| M2Patch | 2.656 | 4.076 | 5.260 | 4.439 | 1.274 | 15.933 |
| MMPD | 1.996 | 2.084 | 1.996 | 2.382 | 2.024 | 23.903 |
| SimpleTM | 0.013 | 2.219 | 0.013 | 2.158 | 0.023 | **1.731** |
| S-Mamba | 1.151 | 2.581 | 4.459 | 2.661 | 4.582 | 2.513 |
| TimeMixer | 0.076 | 3.869 | 0.104 | 4.716 | 0.151 | 14.197 |
| iTransformer | 0.842 | 1.496 | 3.256 | **1.462** | 3.379 | 2.724 |
| PatchTST | 1.094 | **1.491** | 3.761 | 1.834 | 5.236 | 25.521 |
| DLinear | 0.130 | **1.195** | 0.391 | 2.165 | 20.924 | 29.428 |
| Autoformer | 1.467 | 8.496 | 5.889 | 11.753 | 7.425 | 26.613 |
| Informer | 1.665 | 4.336 | 6.655 | 4.763 | 7.730 | 8.228 |
| Flowformer | 1.467 | 4.931 | 5.867 | 5.122 | 6.943 | 11.776 |
| Transformer | 1.686 | 3.814 | 6.713 | 4.213 | 7.789 | 11.437 |

M2Patch 的参数量为 2.66 M、5.26 M、1.27 M；ECL 的 1.27 M 在 12 个模型中排第三小，低于 S-Mamba 的 4.58 M、iTransformer 的 3.38 M 与 PatchTST 的 5.24 M。推理时延为 4.08 ms、4.44 ms、15.93 ms，分别是最快模型的 3.41 倍、3.04 倍、9.20 倍；ECL 上低于 MMPD（23.90 ms）、PatchTST（25.52 ms）、DLinear（29.43 ms）与 Autoformer（26.61 ms）。

**训练迭代时间（ms/iter）与峰值显存（MB）**

| 模型 | ETTm1 时间 | ETTm1 显存 | Weather 时间 | Weather 显存 | ECL 时间 | ECL 显存 |
| --- | --- | --- | --- | --- | --- | --- |
| M2Patch | 19.46 | 124.8 | 20.94 | 422.7 | 68.06 | 3129.5 |
| MMPD | 9.23 | 160.7 | 10.65 | 382.8 | 124.31 | 5845.7 |
| SimpleTM | 8.10 | 20.2 | 7.95 | 22.5 | 8.32 | 106.7 |
| S-Mamba | 8.15 | 38.4 | 8.46 | 109.9 | 9.24 | 428.1 |
| TimeMixer | 13.14 | 51.8 | 18.29 | 158.8 | 36.16 | 2541.5 |
| iTransformer | 4.79 | 32.6 | 5.11 | 92.1 | 9.12 | 587.7 |
| PatchTST | 4.94 | 70.2 | 5.74 | 299.8 | 68.50 | 3711.5 |
| DLinear | 3.56 | 19.2 | 7.27 | 24.4 | 101.31 | 439.6 |
| Autoformer | 14.93 | 221.4 | 15.30 | 460.6 | 18.00 | 941.4 |
| Informer | 12.04 | 131.4 | 12.74 | 292.2 | 18.63 | 474.1 |
| Flowformer | 14.89 | 203.5 | 15.54 | 398.1 | 21.88 | 759.4 |
| Transformer | 14.60 | 204.7 | 14.63 | 383.2 | 21.38 | 743.5 |

以各设置最优精度基线为参照，M2Patch 的训练时间倍数为 ETTm1 $2.11\times$（MMPD 9.23 ms）、Weather $1.14\times$（TimeMixer 18.29 ms）、ECL $7.37\times$（S-Mamba 9.24 ms）；显存倍数为 $0.78\times$、$2.66\times$、$7.31\times$；参数量倍数为 $1.33\times$、$50.4\times$、$0.28\times$。与同为 Patch 范式的 PatchTST 相比，时间/显存倍数为 ETTm1 $3.94\times/1.78\times$、Weather $3.65\times/1.41\times$、ECL $0.99\times/0.84\times$。ECL 上 M2Patch 的显存 3129.5 MB 在 12 个模型中第三高，仅次于 MMPD 5845.7 MB 与 PatchTST 3711.5 MB。

### 2.4 计算复杂度构成

按规范的数据流，单个通道样本的一次训练迭代由五部分组成：

1. **因果分块与嵌入**：前缀统计量通过 `cumsum` 以 $O(L)$ 计算，线性嵌入为 $O(N_{\text{hist}}Pd_{\text{model}})$；由于 $P/S=2$，该项与 $L$ 近似线性。
2. **因果历史编码器**：$e$ 层下三角自注意力为 $O(eN_{\text{hist}}^2d_{\text{model}})$，前馈网络为 $O(eN_{\text{hist}}d_{\text{model}}d_{ff})$。
3. **庞加莱球算子**：球内投影、原点指数/对数映射、莫比乌斯加法与测地线距离均为 FP32 闭式解析式，逐点为 $O(d_{\text{hyp}})$，无矩阵特征分解；历史流形投影为 $O(N_{\text{hist}}d_{\text{model}}d_{\text{hyp}})$。
4. **先验桥接去噪器**：未来 Patch 自注意力 $O(N_{\text{fut}}^2d_{\text{model}})$，对历史隐状态的交叉注意力 $O(N_{\text{fut}}N_{\text{hist}}d_{\text{model}})$，前馈网络 $O(N_{\text{fut}}d_{\text{model}}d_{ff})$，乘以 $d_{\text{layers\_diff}}$。
5. **先验头与输出重排**：$O(Hd_{\text{model}})$ 与 $O(N_{\text{fut}}P)$。

记 $n_{\text{diff}}=d_{\text{layers\_diff}}$，主导项可写为

$$
T_{\text{iter}}\approx
B C\left[
e\left(N_{\text{hist}}^2d+N_{\text{hist}}dd_{ff}\right)
+n_{\text{diff}}\left(N_{\text{fut}}^2d+N_{\text{fut}}N_{\text{hist}}d+N_{\text{fut}}dd_{ff}\right)
+N_{\text{hist}}dd_{\text{hyp}}
\right].
$$

显存由激活主导：

$$
M\approx
B C\left[\left(N_{\text{hist}}+N_{\text{fut}}\right)d+\left(N_{\text{hist}}^2+N_{\text{fut}}^2+N_{\text{fut}}N_{\text{hist}}\right)\right]
+\Theta(\text{params}+\text{Adam states}).
$$

三个设置的实际几何差异如下：

| 设置 | $B\cdot C$ | $N_{\text{hist}}$ | $N_{\text{fut}}$ | $d_{\text{model}}$ | $d_{\text{hyp}}$ | 每通道样本 ms | 每通道样本 MB |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ETTm1 $H=96$ | 112 | 11 | 6 | 192 | 64 | 0.174 | 1.114 |
| Weather $H=96$ | 336 | 11 | 6 | 256 | 128 | 0.062 | 1.258 |
| ECL $H=336$ | 5136 | 7 | 14 | 128 | 64 | 0.013 | 0.609 |

ETTm1 到 ECL 的 $B\cdot C$ 增长 $45.9\times$，迭代时间从 19.46 ms 增至 68.06 ms（$3.50\times$），每通道样本时间从 0.174 ms 降至 0.013 ms。小批量下矩阵乘的算术强度低，核启动与访存开销占主导；ECL 的 5136 条通道序列使 GPU 利用率显著提高。显存从 124.8 MB 增至 3129.5 MB（$25.1\times$），低于 $B\cdot C$ 的 $45.9\times$，原因是 ECL 的 $d_{\text{model}}$ 从 192 降至 128、$N_{\text{hist}}$ 从 11 降至 7，抵消了部分通道扩张。ECL 的 3.13 GB 中，按张量形状估算，主要构成是 $B\cdot C\times(N_{\text{hist}}+N_{\text{fut}})\times d_{\text{model}}$ 的激活及其反向缓存；庞加莱球张量宽度为 $d_{\text{hyp}}=64$，仅为 $d_{\text{model}}$ 的一半，且不含二次注意力项，不构成显存瓶颈。

### 2.5 权衡结论与机理边界

- **精度-资源定位**：M2Patch 在统一 10-epoch 协议下三个设置的 MSE 距最优基线 3.7%–15.6%，平均秩 4.33/12。资源代价随数据集结构变化：ETTm1 的训练时间与显存接近最优基线（$2.11\times$、$0.78\times$），Weather 的时间接近（$1.14\times$）而显存较高（$2.66\times$），ECL 的时间与显存分别为 S-Mamba 的 $7.37\times$ 与 $7.31\times$。
- **参数效率**：M2Patch 的参数量在 ECL 为 1.27 M，低于 S-Mamba、iTransformer 与 PatchTST；在 Weather 为 5.26 M，高于 TimeMixer 的 0.10 M。参数规模与精度排序在三个设置上不一致，ECL 的最优精度模型 S-Mamba 参数量为 4.58 M。
- **推理时延**：$K=1$ 且 $\eta=0$ 时，推理从 $\mathbf{P}_{t=1}=\mathbf{P}_{\text{prior}}$ 出发，一次去噪器前向直接输出 $\hat{\mathbf{P}}_0$，没有 DDIM 的多步循环。M2Patch 的推理时延为 4.08–15.93 ms/batch，在 ETTm1 与 Weather 上低于 Autoformer、Flowformer，在 ECL 上低于 PatchTST、DLinear、MMPD 与 Autoformer。
- **$O(d_{\text{hyp}})$ 算子的实际权重**：庞加莱球算子逐点闭式，FLOPs 远低于 $d_{\text{model}}$ 上的矩阵乘；其主要成本是 `atanh`/`acosh`/`tanh` 等超越函数带来的核启动与 SFU 延迟，在小批量 ETTm1/Weather 上会放大固定开销。该部分不随 $H$ 或 $C$ 二次增长。
- **高维数据的成本中心**：ECL 的 321 通道使有效批大小为 5136，显存与时间主要由通道独立展开后的激活决定；在该设置下 M2Patch 的时间为 S-Mamba 的 $7.37\times$、显存为 $7.31\times$。高通道数场景是 M2Patch 资源效率的薄弱环节。
- **测量边界**：所有模型使用同一 10-epoch、FP32、`batch_size=16` 协议，排名反映该预算下的表现；与 15 epochs 主实验的精度排序存在差异。计时在同一张 RTX 4090 D 上顺序采集，跨主机比较应以同批次复测为准。

---

## 3. 长回看窗口扩展性分析（Increasing Lookback Horizon Analysis）

### 3.1 协议

固定 $H=96$，$L\in\{48,96,192,336,720\}$；每个数据集在全部 $L$ 上使用同一组超参数，仅改变 `seq_len`，因此 MSE 趋势可归因于历史长度。训练 15 epochs，batch size 32（ECL 为 16），seed 2023。基线 PatchTST、S-Mamba、TimeMixer、iTransformer、Transformer 使用各自的标准配置。M2Patch 的结果文件为 `output/lookback/M2Patch.tsv`，五个基线分别为 `output/lookback/{PatchTST,S_Mamba,TimeMixer,iTransformer,Transformer}.tsv`。评价在标准化空间进行。

### 3.2 完整结果

**ETTm1（MSE / MAE）**

| $L$ | M2Patch | PatchTST | S-Mamba | TimeMixer | iTransformer | Transformer |
| --- | --- | --- | --- | --- | --- | --- |
| 48 | 0.4692 / 0.4201 | 0.4654 / 0.4236 | 0.4442 / 0.4175 | **0.4164 / 0.4022** | 0.4706 / 0.4285 | 0.6520 / 0.5824 |
| 96 | 0.3323 / 0.3584 | **0.3203 / 0.3590** | 0.3331 / 0.3687 | 0.3215 / 0.3619 | 0.3399 / 0.3755 | 0.7764 / 0.6256 |
| 192 | 0.3333 / 0.3621 | **0.2903 / 0.3383** | 0.3052 / 0.3565 | 0.3106 / 0.3511 | 0.3055 / 0.3531 | 0.6450 / 0.5889 |
| 336 | 0.2946 / 0.3373 | **0.2872 / 0.3397** | 0.3041 / 0.3583 | 0.3182 / 0.3544 | 0.2996 / 0.3532 | 0.6839 / 0.6359 |
| 720 | **0.2841 / 0.3339** | 0.2943 / 0.3498 | 0.3053 / 0.3626 | 0.3081 / 0.3584 | 0.3110 / 0.3664 | 0.8290 / 0.6889 |

**Weather（MSE / MAE）**

| $L$ | M2Patch | PatchTST | S-Mamba | TimeMixer | iTransformer | Transformer |
| --- | --- | --- | --- | --- | --- | --- |
| 48 | 0.2218 / 0.2478 | 0.2104 / 0.2418 | 0.2226 / 0.2678 | **0.1889 / 0.2300** | 0.2049 / 0.2374 | 0.7220 / 0.6196 |
| 96 | 0.1673 / 0.2047 | 0.1812 / 0.2213 | 0.1886 / 0.2346 | **0.1627 / 0.2096** | 0.1806 / 0.2220 | 0.4715 / 0.4845 |
| 192 | 0.1613 / 0.2000 | 0.1601 / 0.2044 | 0.1752 / 0.2210 | **0.1529 / 0.2034** | 0.1694 / 0.2138 | 0.3111 / 0.3729 |
| 336 | 0.1582 / 0.2011 | **0.1509 / 0.1998** | 0.1788 / 0.2219 | 0.1534 / 0.2068 | 0.1653 / 0.2130 | 0.3431 / 0.3949 |
| 720 | 0.1580 / 0.2021 | **0.1453 / 0.1961** | 0.1713 / 0.2221 | 0.1488 / 0.2041 | 0.1620 / 0.2144 | 0.3023 / 0.3692 |

**ECL（MSE / MAE）**

| $L$ | M2Patch | PatchTST | S-Mamba | TimeMixer | iTransformer | Transformer |
| --- | --- | --- | --- | --- | --- | --- |
| 48 | 0.2395 / 0.3035 | 0.2363 / 0.2994 | **0.1609 / 0.2558** | 0.2014 / 0.2821 | 0.1824 / 0.2656 | 0.2659 / 0.3578 |
| 96 | 0.1848 / 0.2671 | 0.1849 / 0.2668 | **0.1443 / 0.2400** | 0.1568 / 0.2501 | 0.1499 / 0.2419 | 0.2637 / 0.3569 |
| 192 | 0.1442 / 0.2379 | 0.1438 / 0.2368 | 0.1339 / 0.2318 | 0.1332 / 0.2266 | **0.1332 / 0.2286** | 0.2640 / 0.3537 |
| 336 | 0.1387 / 0.2342 | 0.1360 / 0.2311 | 0.1350 / 0.2310 | **0.1295 / 0.2247** | 0.1310 / 0.2270 | 0.2804 / 0.3717 |
| 720 | 0.1326 / 0.2267 | **0.1318 / 0.2274** | 0.1354 / 0.2318 | 0.1321 / 0.2279 | 0.1334 / 0.2303 | 0.2659 / 0.3584 |

表中粗体为该行 MSE 最低的模型；MAE 未参与加粗排序。

### 3.3 相对增益汇总

| 数据集 | M2Patch $L=48$ | M2Patch $L=720$ | 相对变化 | $L=720$ 最优模型 | M2Patch 排名（$L=720$） | M2Patch 最优 $L$ |
| --- | --- | --- | --- | --- | --- | --- |
| ETTm1 | 0.4692 | **0.2841** | $-39.45\%$ | M2Patch 0.2841 | 1/6 | 720 |
| Weather | 0.2218 | **0.1580** | $-28.79\%$ | PatchTST 0.1453 | 3/6 | 720 |
| ECL | 0.2395 | **0.1326** | $-44.63\%$ | PatchTST 0.1318 | 3/6 | 720 |

三个数据集的相对变化分别为 ETTm1 -39.45%、Weather -28.79%、ECL -44.63%，对应 MSE 从 0.4692/0.2218/0.2395 降至 0.2841/0.1580/0.1326，其中 ETTm1 的 MSE 0.2841 为六模型最低。

基线对照：PatchTST 在 ETTm1 上从 0.4654 降至 0.2943（$-36.78\%$），最低点在 $L=336$ 的 0.2872，$L=720$ 回升 $+2.47\%$；TimeMixer 与 iTransformer 在 ECL 的 $L=720$ 分别回升 2.00% 与 1.81%，S-Mamba 仅 $+0.26\%$（接近平台）；ETTm1 上 S-Mamba 与 iTransformer 同样在 336 后回升。M2Patch 在 ETTm1 的 $L=720$ 取得六模型最优，并在三个数据集上均取得自身最优；Weather 与 ECL 的 $L=720$ 最优分别为 PatchTST 0.1453 与 0.1318。M2Patch 的 ETTm1 336→720 继续下降 3.58%，PatchTST、S-Mamba、iTransformer 在该区间回升；ECL 上 M2Patch 从 $L=48$ 落后最优 48.85% 收窄到 $L=720$ 落后 0.63%；Weather 上 PatchTST 在 $L\ge 192$ 反超，M2Patch 在 336 后进入平台（0.15816 → 0.15797，$-0.12\%$）。

### 3.4 整体下降趋势的机理

**（1）左填充单尺度严格因果分块：历史越长，有效 Token 越多且边界不引入伪影。**

对于 $P=16,S=8$，$L$ 从 48 增至 720 时 $N_{\text{hist}}$ 从 5 增至 89；ECL 的 $P=24,S=12$ 下从 3 增至 59。左端首值复制填充保证第 $i$ 个 Patch 的有效右端点 $e_i=\max(1,\min(L,iS-L_{\text{pad}}+P))$，最后一个 Patch 的右端点严格等于 $L$。历史窗口增长时，新增 Token 全部来自真实观测，右端不产生跨边界填充伪影；$P$ 与 $S$ 固定，使局部 Patch 的语义在全部 $L$ 上保持一致，编码器的局部滤波器无需随 $L$ 重新适配。PatchTST 采用端部填充，长 $L$ 下末端 Patch 含填充伪影；该差异是其在 ETTm1/ECL 的 $L=720$ 回升的候选原因之一。

**（2）逐前缀贝叶斯收缩归一化：历史越长，前缀统计量的收缩偏差越小。**

第 $i$ 个 Patch 的归一化使用截至 $e_i$ 的前缀均值/方差，并向 $\mathcal{N}(0,1)$ 收缩，权重 $\rho_i=e_i/(e_i+\tau_0)$，$\tau_0=1$。$L=48$ 时 ETTm1/Weather 的 $N_{\text{hist}}=5$，平均收缩偏差 $1-\bar{\rho}=3.48\%$；$L=720$ 时 $N_{\text{hist}}=89$，平均偏差降至 $0.56\%$。ECL 从 $L=48$ 的 2.91% 降至 $L=720$ 的 0.51%。长历史使绝大多数 Token 的前缀方差估计接近真实值，归一化噪声按 $O(1/e_i)$ 衰减；早期 Patch 的强收缩只影响少量浅层 Token，其影响在因果编码器的深层被稀释。逐前缀统计量随历史推进而更新，对局部分布漂移做分段校正；长历史让每个 Patch 的校正基准更稳定，减少全局归一化在非平稳段内的偏差。

**（3）负曲率流形：指数级容量容纳长程层次化依赖。**

庞加莱球 $\mathbb{B}_c^{d_{\text{hyp}}}$ 的体积元按 $\sinh^{d_{\text{hyp}}-1}(\sqrt{c}r)$ 增长，体积随半径呈指数级；负曲率空间可用 $O(\log n)$ 的径向分辨率嵌入 $n$ 个节点的树状层级。时间序列的多周期结构（日/周/月嵌套、突变前后的状态层级）具有树状因果层级，长历史提供更多层级节点。$d_{\text{hyp}}$ 固定为 64 或 128，而 $N_{\text{hist}}$ 从 5 增至 89，流形对每个 Token 的容量不随 $L$ 稀释；一种解释是：欧氏注意力基线的有效秩在长上下文下趋于饱和，其长程增益先于 M2Patch 停止。测地线距离在球边界附近对欧氏位移呈对数敏感，使“峰/谷/平台”等细粒度状态在小幅欧氏位移下仍可分离。

**（4）历史先验桥接：历史越长，先验锚点越准，残差越小。**

先验 $\mathbf{P}_{\text{prior}}$ 由最后一个因果隐状态 $\mathbf{h}_{N_{\text{hist}}-1}$ 经 PriorMLP 生成；该隐状态通过因果注意力聚合全部历史 Token。$L$ 增大时，聚合的独立证据增多，$\mathbf{h}_{N_{\text{hist}}-1}$ 的方差近似按 $1/N_{\text{hist}}$ 下降，先验更贴近真实未来的水平与趋势。桥接前向分布将去噪任务转化为“以先验为起点的残差精炼”，先验误差越小，去噪器需要建模的残差越小。Weather 在 $L=336$ 后先验已覆盖主要周期，继续增加历史只带来 $-0.12\%$ 的边缘收益；ETTm1 与 ECL 的多周期/高维结构在 720 步内仍未饱和，收益持续到 $L=720$。

**（5）跨界切空间跃迁对齐：边界状态越准，首 Patch 越稳。**

$\mathcal{L}_{\text{trans}}$ 以 $\mathbf{z}_{\text{last}}^{\text{hist}}$ 为基点约束首个未来 Patch 的切空间速度向量。$L$ 增大时 $\mathbf{z}_{\text{last}}^{\text{hist}}$ 的估计更稳定，跃迁方向与幅度的监督更可靠；首 Patch 的误差只进入该窗口的 MSE，一次性多步输出不将其沿 $H$ 递归放大，边界对齐的收益集中在该 Patch 及其邻域。

### 3.5 机理边界

- **Weather 的反超**：$L\ge 192$ 时 PatchTST 优于 M2Patch（$L=720$：0.1453 对 0.1580，M2Patch 落后 8.69%）。Weather 的 21 通道气象序列以强周期、低秩成分为主，PatchTST 的局部 Patch 注意力在长上下文下直接扩大统计样本；M2Patch 的先验桥接在 336 后已吸收主要可预测成分，额外历史对先验的边际增益很小。
- **ETTm1 的平台波动**：$L=96\to 192$ 时 MSE 从 0.33225 升至 0.33330（$+0.32\%$），整体趋势仍为下降（48→720，$-39.45\%$）。该波动处于单次运行的种子噪声量级，不改变长回看增益的结论。
- **ECL 的短回看短板**：$L=48$ 时 $N_{\text{hist}}=3$，因果编码器与先验头只有 3 个 Token，M2Patch 的 MSE 0.2395 落后 S-Mamba 的 0.1609 达 48.85%。M2Patch 的竞争力从 $L=192$ 开始显现（落后 8.29%），到 $L=720$ 收窄至 0.63%。该模型的设计目标是长历史利用，短回看落在其优势区间之外。
- **二次复杂度**：$N_{\text{hist}}\approx L/S$，编码器自注意力为 $O((L/S)^2d_{\text{model}})$；$L$ 从 336 增至 720 时 $N_{\text{hist}}$ 从 41 增至 89，注意力项约增长 $4.7\times$。超过 720 的回看未在本次实验中测量，本次结论限于 $L\le720$。

---

## 4. 零样本高斯噪声鲁棒性分析（Zero-Shot Noise Robustness Analysis）

### 4.1 协议

在 ETTm1 与 ETTm2 上，对每个 $H\in\{96,192,336,720\}$ 先用干净数据训练一次（15 epochs，batch size 32，seed 2023，profile 超参数），随后在测试阶段向模型输入注入零均值高斯噪声 $\epsilon\sim\mathcal{N}(0,\sigma^2)$，$\sigma\in\{0.0,0.1,0.2,0.3,0.5\}$，复用同一 checkpoint，训练阶段不加入任何噪声。噪声在数据集级标准化后的输入上叠加，$\sigma=0.5$ 对应半个训练集标准差。评价在标准化空间进行。共 $2\times4\times5=40$ 个测试单元。

### 4.2 ETTm1 结果

**MSE / MAE**

| $H$ | $\sigma=0.0$ | $\sigma=0.1$ | $\sigma=0.2$ | $\sigma=0.3$ | $\sigma=0.5$ |
| --- | --- | --- | --- | --- | --- |
| 96 | 0.3323 / 0.3584 | 0.3347 / 0.3631 | 0.3448 / 0.3758 | 0.3615 / 0.3942 | 0.4179 / 0.4470 |
| 192 | 0.3667 / 0.3831 | 0.3760 / 0.3909 | 0.3998 / 0.4127 | 0.4317 / 0.4388 | 0.5167 / 0.5037 |
| 336 | 0.4132 / 0.4187 | 0.4238 / 0.4304 | 0.4501 / 0.4531 | 0.4850 / 0.4786 | 0.5969 / 0.5503 |
| 720 | 0.4787 / 0.4589 | 0.4945 / 0.4748 | 0.5204 / 0.4933 | 0.5400 / 0.5052 | 0.6133 / 0.5499 |

**相对退化率（MSE / MAE，以 $\sigma=0$ 为基准）**

| $H$ | $\sigma=0.1$ | $\sigma=0.2$ | $\sigma=0.3$ | $\sigma=0.5$ |
| --- | --- | --- | --- | --- |
| 96 | +0.72% / +1.32% | +3.79% / +4.86% | +8.81% / +9.97% | +25.77% / +24.71% |
| 192 | +2.54% / +2.03% | +9.05% / +7.72% | +17.74% / +14.53% | +40.92% / +31.48% |
| 336 | +2.58% / +2.80% | +8.94% / +8.21% | +17.39% / +14.30% | +44.47% / +31.44% |
| 720 | +3.30% / +3.46% | +8.71% / +7.50% | +12.80% / +10.09% | +28.11% / +19.83% |

### 4.3 ETTm2 结果

**MSE / MAE**

| $H$ | $\sigma=0.0$ | $\sigma=0.1$ | $\sigma=0.2$ | $\sigma=0.3$ | $\sigma=0.5$ |
| --- | --- | --- | --- | --- | --- |
| 96 | 0.1778 / 0.2558 | 0.1781 / 0.2608 | 0.1811 / 0.2691 | 0.1869 / 0.2789 | 0.2067 / 0.3053 |
| 192 | 0.2481 / 0.3084 | 0.2508 / 0.3159 | 0.2544 / 0.3235 | 0.2593 / 0.3314 | 0.2767 / 0.3530 |
| 336 | 0.3252 / 0.3573 | 0.3276 / 0.3650 | 0.3335 / 0.3768 | 0.3403 / 0.3872 | 0.3633 / 0.4127 |
| 720 | 0.4278 / 0.4209 | 0.4295 / 0.4269 | 0.4376 / 0.4387 | 0.4523 / 0.4545 | 0.5013 / 0.4978 |

**相对退化率（MSE / MAE，以 $\sigma=0$ 为基准）**

| $H$ | $\sigma=0.1$ | $\sigma=0.2$ | $\sigma=0.3$ | $\sigma=0.5$ |
| --- | --- | --- | --- | --- |
| 96 | +0.16% / +1.95% | +1.83% / +5.19% | +5.07% / +9.04% | +16.25% / +19.35% |
| 192 | +1.10% / +2.43% | +2.56% / +4.91% | +4.54% / +7.46% | +11.52% / +14.47% |
| 336 | +0.72% / +2.14% | +2.53% / +5.44% | +4.63% / +8.37% | +11.69% / +15.49% |
| 720 | +0.39% / +1.41% | +2.28% / +4.23% | +5.73% / +7.96% | +17.19% / +18.26% |

### 4.4 阻尼机理

本节涉及的内部常数取自 `src/layers/M2Patch_layers.py`：`eta_floor=0.2`（$\eta_{\text{floor}}=0.2$，`REVIN_STD_FLOOR_RATIO`）、`HYP_MAX_TANGENT=2.0`（切空间范数裁剪）、`TARGET_CLIP=10.0`（归一化幅值裁剪）。

**（1）历史统计量锁定 RevIN：加性噪声被转换为有界的相对扰动。**

设通道历史方差为 $\sigma_x^2$，测试输入为 $\tilde{x}=x+\epsilon$，则含噪窗口方差为 $\sigma_x^2+\sigma^2$，在分母取含噪窗口标准差时，归一化后的噪声幅度为

$$
\frac{\sigma}{\sqrt{\sigma_x^2+\sigma^2}}\le 1 .
$$

当 $\sigma\ll\sigma_x$ 时该比值近似 $\sigma/\sigma_x$，退化随 $\sigma$ 线性增长；当 $\sigma\gg\sigma_x$ 时比值饱和到 1，噪声无法通过除法被无限放大。RevIN 的均值/方差只统计历史窗口，测试噪声不会改变目标归一化的基准；反归一化使用同一组历史统计量，输出尺度保持稳定。归一化后的输入与目标再经 $\pm10$ 的幅值裁剪（`TARGET_CLIP`），超过 10 个标准差的噪声尖峰被截断。

**（2）跨通道中位数标准差下界：低方差窗口不会被噪声主导。**

对通道 $c$，分母取 $\max(\sigma_c^{\text{raw}},0.2\cdot\tilde{\sigma})$，$\tilde{\sigma}$ 为同一样本内各通道窗口标准差的中位数。该下界在通道窗口标准差低于批次中位数的 0.2 倍时生效，用于防止近常数窗口的分母趋零、把微小噪声放大为大幅归一化扰动。测试噪声在数据集级 `StandardScaler` 之后注入，各通道训练段的全局方差已归一化到 1，噪声-信号比主要由 $\sigma$ 决定；下界的作用对象是局部方差远低于批次典型值的窗口。ETTm1 与 ETTm2 的差异来自序列自身的粗糙度：在训练段（前 34,560 行）上拟合 `StandardScaler` 后计算，ETTm1 的一阶差分标准差均值为 0.205，ETTm2 为 0.154；一阶自相关均值分别为 0.977 与 0.984。ETTm1 的高频分量更强、时间冗余更低，加性噪声更难与真实动态分离，因而在相同 $\sigma$ 下退化更大。两个数据集的 per-horizon 超参数不同，跨数据集比较同时受该差异影响。

**（3）切空间范数裁剪：流形点远离球边界。**

鲁棒性实验的 `manifold_c=1.0`。原点指数映射前，切向量按 $\tilde{\mathbf{v}}=\mathbf{v}\min(1,2/\lVert\mathbf{v}\rVert)$ 裁剪，映射半径为 $\tanh(\sqrt{c}\lVert\tilde{\mathbf{v}}\rVert)\le\tanh(2)=0.964$。庞加莱度规的共形因子 $2/(1-c\lVert\mathbf{z}\rVert^2)$ 在 $r=0.964$ 处为 28.3，远离 $r\to1$ 时的发散区。噪声引起的特征扰动最多把流形点推到半径 0.964，无法触发边界附近的梯度爆炸；裁剪后的指数映射为有界映射，单 Token 的噪声不会污染整个历史流形轨迹。

**（4）有理饱和测地线距离：大几何误差的梯度有界。**

$\mathcal{L}_{\text{geo}}$ 使用 $g(d)=d^2/(1+d^2)$，其导数为 $g'(d)=2d/(1+d^2)^2$，最大值在 $d=1/\sqrt{3}$ 处取得 $0.6495$，并随 $d$ 增大按 $2/d^3$ 衰减。噪声造成的离群窗口即使产生很大的测地线距离，其梯度也被限制在 $0.65$ 以内，不会主导参数更新。该性质使训练对高幅值异常窗口与噪声污染窗口保持稳定，代价是极端偏差的恢复力度被削弱；窗口级误差见第 5 节。

**（5）历史先验锚点桥接：噪声经过低通先验后才进入输出。**

$K=1$ 时输出为 $\hat{\mathbf{P}}_0=\mathbf{P}_{\text{prior}}+\mathbf{W}_{x_0}\mathbf{H}_{\text{out}}$，先验 $\mathbf{P}_{\text{prior}}$ 由 $\mathbf{h}_{N_{\text{hist}}-1}$ 经两层 MLP 生成，AdaLN-Zero 门控在初始化时将三个子层的贡献门控为零，残差头以零偏置、小方差权重初始化，模型从接近先验的起点开始学习残差。噪声需依次经过 RevIN、分块器、因果编码器、先验 MLP 与去噪器；先验 MLP 的平滑映射与因果注意力的加权平均共同衰减高频噪声。双曲条件 $\mathbf{c}_{\text{hyp}}=\mathbf{W}_{\text{cond}}\log_{\mathbf{0}}^c(\frac{1}{N_{\text{hist}}}\sum_i\mathbf{Z}_i^{\text{hist}})$ 对 $N_{\text{hist}}$ 个历史流形点取均值，独立噪声分量的方差降低为单点的 $1/N_{\text{hist}}$（$L=96$ 时约 1/11，ECL 约 1/7），条件信号更稳定。

**（6）直接多步输出：噪声不沿预测步递归累积。**

M2Patch 一次性输出全部 $H$ 个未来 Patch，Bridge-DDIM 在 $K=1$ 下没有自回归反馈；测试噪声只影响一次前向的输入，不会像递归预测那样逐步放大。这是 $\sigma=0.5$ 时 MSE 退化仍保持在 11.5%–44.5% 的结构性原因之一。

### 4.5 机理边界

- **数据集差异**：ETTm1 的退化显著高于 ETTm2（$\sigma=0.5$ 时 MSE $+25.8\%$–$44.5\%$ 对 $+11.5\%$–$17.2\%$）。在训练段上拟合 `StandardScaler` 后计算，ETTm1 的一阶差分标准差均值为 0.205（ETTm2 0.154），一阶自相关均值 0.977（ETTm2 0.984），其高频分量更强、时间冗余更低，噪声与真实动态更难分离。两个数据集的 per-horizon 超参数不同（$d_{\text{model}}$、$d_{\text{hyp}}$、$\lambda_{\text{hyp}}$、$\lambda_{\text{prior}}$ 均随数据集/步长变化），跨数据集对比同时受容量混杂影响，数据粗糙度只解释其中一部分。
- **Horizon 非单调**：ETTm1 的相对退化在 $H=336$ 达到峰值 44.47%，$H=720$ 回落至 28.11%；绝对 MSE 增量分别为 0.1837 与 0.1346。$H=720$ 的干净误差基数更大（0.4787），相同绝对增量对应更小的相对比例；$H=336$ 的干净基数 0.4132 较低，相对退化更敏感。ETTm2 的绝对增量从 $H=96$ 的 0.0289 增至 $H=720$ 的 0.0735，长 horizon 的先验外推误差随 $H$ 增大。
- **零样本设定**：全部结果来自未做噪声增强的干净模型；`--train_noise_level` 未启用。噪声感知训练未在本次实验中测量，结果限于零样本设定。
- **评价空间**：MSE/MAE 在标准化空间计算；原始量纲下的相对退化会受通道尺度影响，论文中应以标准化空间数值为主，并注明噪声注入位置。

---

## 5. 定性预测案例分析（Qualitative Case Study on ETTm2, ETTm1, ECL, and Exchange）

### 5.1 协议与窗口选择

设置：$96\to96$，四个数据集各选一个展示通道——ETTm2 的 OT、ETTm1 的 HUFL、ECL 的 OT、Exchange 的 OT；预测经 `--inverse` 还原到原始物理量纲。M2Patch 的四个单元格全部使用 `src.configs.m2patch_cli <DS> 96 --from-optuna --with-meta` 的 Optuna 配置，逐行超参数见 `case_study.tsv`：ETTm2 `d_model=128`、`d_hyp=32`、`stride=4`、`diff_steps=1`；ETTm1 `d_model=256`、`d_hyp=128`；ECL `d_model=256`、`d_hyp=32`、`manifold_c=1.1185`、`batch_size=16`；Exchange `d_model=512`、`patch_len=8`、`diff_steps=2`。基线 MMPD、S-Mamba、iTransformer、PatchTST 使用各自标准配置，全部 15 epochs、patience 5。

展示窗口按统一规则确定性选取：以步长 4 扫描全部测试窗口，要求 M2Patch 在展示通道 MSE 与全通道 MSE 上同时优于全部基线。ETTm2 要求相对最优基线至少 12% 裕度并限定在第一差分变化率前四分位窗口，按展示通道 MSE（`rank='fit'`）取最优；ETTm1 与 ECL 要求动态强度前 60%，按 `fit` 取最优；Exchange 要求 5% 裕度与动态强度前四分位，按 `rank='variation'` 取动态最强窗口。选择结果见 `output/case_study/figures/captions.md`，逐行超参数见 `case_study.tsv`。

### 5.2 展示窗口定量结果

**展示窗口 MSE（原始量纲）与 horizon 相关系数**

| 数据集（通道） | 窗口 | M2Patch 展示通道 MSE | 最优基线 | 相对最优基线 | M2Patch 全通道 MSE | 全通道最优基线 | 相对最优基线 | M2Patch $r$ | 展示通道最优基线 $r$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ETTm2（OT） | 872 | **0.6806** | PatchTST 2.0801 | $-67.3\%$ | **1.4201** | iTransformer 2.2019 | $-35.5\%$ | 0.9939 | 0.9880 |
| ETTm1（HUFL） | 1192 | **1.3615** | MMPD 2.0827 | $-34.6\%$ | **0.9648** | MMPD 1.3005 | $-25.8\%$ | 0.9942 | 0.9929 |
| ECL（OT） | 676 | **17487.4** | PatchTST 17891.9 | $-2.3\%$ | **1.4444$\times10^6$** | iTransformer 1.4650$\times10^6$ | $-1.4\%$ | 0.9739 | 0.9582 |
| Exchange（OT） | 168 | **0.00227** | S-Mamba 0.00282 | $-19.7\%$ | **0.00154** | PatchTST 0.00170 | $-9.4\%$ | 0.8068 | -0.5511 |

Exchange 窗口上五个模型的 horizon 相关系数为 M2Patch 0.8068、MMPD 0.1589、S-Mamba $-0.5511$、iTransformer $-0.8561$、PatchTST 0.0062；该窗口的展示通道与全通道 MSE 同时为五模型最低。ETTm2 窗口上 M2Patch 的 $r=0.9939$，MMPD 0.9686、S-Mamba 0.9843、iTransformer 0.9880、PatchTST 0.9870。

### 5.3 整段测试集结果

**整段测试集 MSE / MAE（原始量纲，单次运行）**

| 数据集 | M2Patch | MMPD | S-Mamba | iTransformer | PatchTST |
| --- | --- | --- | --- | --- | --- |
| ETTm2 | **11.5159 / 1.9674** | 12.0339 / 2.0489 | 11.8661 / 2.0355 | 11.9907 / 2.0462 | 12.0116 / 2.0354 |
| ETTm1 | 6.5489 / 1.2481 | **6.3388 / 1.2373** | 6.4939 / 1.2798 | 6.5512 / 1.2958 | 6.4283 / 1.2635 |
| ECL | 4.8697$\times10^6$ / 216.42 | 5.3217$\times10^6$ / 224.22 | 4.6843$\times10^6$ / 213.93 | **4.5052$\times10^6$ / 212.98** | 5.3535$\times10^6$ / 228.10 |
| Exchange | 8.965$\times10^{-4}$ / 0.01854 | 8.191$\times10^{-4}$ / 0.01754 | 8.027$\times10^{-4}$ / 0.01754 | 8.796$\times10^{-4}$ / 0.01838 | **7.711$\times10^{-4}$ / 0.01696** |

整段测试集上，M2Patch 在 ETTm2 取得五模型最优（比 S-Mamba 低 2.95%），在 ETTm1 比 MMPD 高 3.31%，在 ECL 比 iTransformer 高 8.09%，在 Exchange 比 PatchTST 高 16.25%。展示窗口的领先幅度与整段测试集排名并不一致，案例研究用于展示局部波形形态与相位/幅值特征，全测试集统计结论以 5.3 节表格为准。

### 5.4 窗口级误差结构

**ETTm2（OT，窗口 872）**：M2Patch 的 horizon 相关系数 0.9939，为五模型最高；展示通道 MSE 0.6806，为 PatchTST 2.0801 的 32.7%，全通道 MSE 1.4201，为 iTransformer 2.2019 的 64.5%。五模型在该窗口的 $r$ 落在 0.9686–0.9939。

**ETTm1（HUFL，窗口 1192）**：M2Patch 的 $r=0.9942$，五模型最高；展示通道 MSE 1.3615，为次优 MMPD 2.0827 的 65.4%；全通道 MSE 0.9648，为 MMPD 1.3005 的 74.2%。该窗口上 M2Patch 的展示通道与全通道 MSE 均为五模型最低。

**ECL（OT，窗口 676）**：M2Patch 的 $r=0.9739$，五模型最高；展示通道 MSE 17487.4，比 PatchTST 17891.9 低 2.3%；全通道 MSE 1.4444$\times10^6$，比 iTransformer 1.4650$\times10^6$ 低 1.4%。该窗口的相对改善幅度小于 ETT 数据集。

**Exchange（OT，窗口 168）**：M2Patch 的 $r=0.8068$，四个基线的 $r$ 落在 $-0.8561$ 到 $0.1589$ 之间；展示通道 MSE 0.0022651，为 S-Mamba 0.0028204 的 80.3%；全通道 MSE 0.0015416，为 PatchTST 0.0017014 的 90.6%。该窗口上 M2Patch 的相关系数与两级 MSE 同时占优。

### 5.5 机理分析

**（1）历史因果先验桥接提供水平与趋势骨架。** $\mathbf{P}_{\text{prior}}$ 由最后一个因果隐状态 $\mathbf{h}_{N_{\text{hist}}-1}$ 生成，后者聚合完整历史窗口。ETTm2 与 ETTm1 窗口的展示通道 MSE 分别为最优基线的 32.7% 与 65.4%，全通道 MSE 分别为 64.5% 与 74.2%；窗口级误差与先验桥接在机制实验中一致的正向作用（去掉先验桥接使 ETTh2/ETTm1/Exchange 的 MSE 上升 4.76%/10.90%/2.08%）方向一致。

**（2）跨界切空间跃迁对齐约束首 Patch 的方向与幅度。** $\mathcal{L}_{\text{trans}}$ 以 $\mathbf{z}_{\text{last}}^{\text{hist}}$ 为基点，比较预测与真实的首个未来 Patch 在切空间中的跃迁向量。四个窗口的 horizon 相关系数为 0.8068–0.9942，首段相位与展示通道的 MSE 同时处于五模型前列；Exchange 窗口的 $r=0.8068$ 与基线的负相关（$-0.8561$ 至 0.1589）形成对比。

**（3）负曲率几何放大峰/谷状态的可分性。** 庞加莱球的测地线距离对球边界附近的径向差异敏感，峰值、谷值、平台对应不同径向层级。ETTm2 与 ECL 窗口的 $r$ 分别为 0.9939 与 0.9739，五模型最高；Exchange 的低信噪比窗口上，双曲几何与先验桥接的组合使 $r$ 达到 0.8068。

**（4）AdaLN-Zero 条件调制与确定性输出。** 去噪器的 9 组仿射调制由时间步、历史上下文与双曲条件共同生成，零初始化使每个 block 从恒等映射开始。$K=1$ 且 $\eta=0$ 时输出为 $\hat{\mathbf{P}}_0$ 的确定性函数，没有随机采样方差；Exchange 的部署配置为 $K=2$，其余三个数据集为 $K=1$。

### 5.6 机理边界

- **窗口选择规则偏向 M2Patch**：展示窗口要求 M2Patch 在展示通道与全通道同时优于全部基线，并在满足条件的窗口中按动态强度或拟合优度选取。该规则确定性、可复现，选出的窗口是 M2Patch 的有利区间；整段测试集上 ETTm1、ECL、Exchange 分别落后最优基线 3.31%、8.09%、16.25%。
- **数据集差异**：ETTm2 的窗口与整段测试集均为五模型最优；Exchange 的窗口 $r$ 优势明显，整段 MSE 仍高于 PatchTST 16.25%。案例图用于展示机制在局部片段上的作用，全局排名以主表和统计检验为准。
- **单次运行**：四个数据集的 M2Patch 与基线均为单次运行，未报告种子方差；窗口级 MSE 与 $r$ 的差异包含种子噪声。

---

## 6. 机制分析（Mechanism Analysis）

### 6.1 协议与图件

机制套件在 ETTh2、ETTm1、Exchange 的 $H=96$ 上运行 5 个变体：`none`（满模型）、`euclid_manifold`、`zero_prior_bridge`、`no_hyp_cond`、`no_prior_loss`。配置来自 `load_optuna_best_params(dataset, pred_len)`，并统一为 `Adam` / `onecycle` / `pct_start=0.2`；`lambda_hyp=0` 的最优值被提升到 0.1，使对齐项保持激活。每个变体训练 15 epochs，结果写入 `output/mechanism/results/{Dataset}.tsv`。`plot_m2patch_mechanism.py` 从 checkpoint 提取 `z_hist`、`z_prior`、`z_pred`、`z_target`、`Y_prior`、`y_pred` 与 $\Delta Y_{\text{diff}}$，渲染 2×2 ACM TOIS 单栏面板（5.35 in × 4.60 in，600 dpi）：每个数据集一张 `m2patch_mechanism_{Dataset}.png`，ETTh2 同时作为主图 `m2patch_mechanism_analysis.png`，跨数据集比较为 `m2patch_mechanism_cross_dataset.png`（5.35 in × 4.35 in）。面板 (c) 读取 `output/mechanism/loss_history_{Dataset}_pl96.json` 的逐迭代损失分解，并对部署权重做 $K\in\{1,2,4\}$ 的 what-if 评估。

### 6.2 变体结果

| 数据集 | 变体 | MSE | ΔMSE | MAE | ΔMAE | 先验→去噪测地距离 | 对齐度 $1/(1+\bar d)$ | $\mathrm{RMSE}_\Delta$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ETTh2 | Full | 0.3019 | — | 0.3468 | — | 0.9972 → 0.9652 | 0.5088 | 0.1659 |
| ETTh2 | Euclid manifold | 0.2981 | -1.24% | 0.3464 | -0.11% | 0.4829 → 0.4696 | 0.6805 | 0.1735 |
| ETTh2 | Zero prior bridge | 0.3163 | +4.76% | 0.3593 | +3.60% | 1.0368 → 0.9957 | 0.5011 | 0.5268 |
| ETTh2 | No hyp. cond. | 0.2955 | -2.13% | 0.3414 | -1.58% | 0.9964 → 0.9663 | 0.5086 | 0.1749 |
| ETTh2 | No prior loss | 0.3080 | +2.03% | 0.3505 | +1.05% | 1.1009 → 0.9761 | 0.5060 | 0.5306 |
| ETTm1 | Full | 0.3142 | — | 0.3459 | — | 0.4021 → 0.3956 | 0.7165 | 0.1692 |
| ETTm1 | Euclid manifold | 0.3155 | +0.41% | 0.3466 | +0.20% | 0.1982 → 0.1974 | 0.8351 | 0.1957 |
| ETTm1 | Zero prior bridge | 0.3485 | +10.90% | 0.3649 | +5.49% | 0.4109 → 0.4030 | 0.7128 | 0.4018 |
| ETTm1 | No hyp. cond. | 0.3138 | -0.14% | 0.3455 | -0.11% | 0.4020 → 0.3956 | 0.7165 | 0.1849 |
| ETTm1 | No prior loss | 0.3549 | +12.94% | 0.3629 | +4.92% | 0.5083 → 0.3993 | 0.7146 | 0.7771 |
| Exchange | Full | 0.0966 | — | 0.2169 | — | 0.5921 → 0.5919 | 0.6282 | 0.3376 |
| Exchange | Euclid manifold | 0.0829 | -14.21% | 0.2035 | -6.18% | 0.2847 → 0.2866 | 0.7773 | 0.3373 |
| Exchange | Zero prior bridge | 0.0987 | +2.08% | 0.2223 | +2.48% | 0.5666 → 0.6183 | 0.6179 | 1.1583 |
| Exchange | No hyp. cond. | 0.0850 | -12.00% | 0.2044 | -5.80% | 0.5838 → 0.5758 | 0.6346 | 0.2212 |
| Exchange | No prior loss | 0.1025 | +6.05% | 0.2274 | +4.85% | 0.6886 → 0.6282 | 0.6142 | 0.9822 |

### 6.3 先验桥接、去噪校正与扩散步数

- **先验桥接与先验锚点损失在三个数据集上一致起作用**：`zero_prior_bridge` 使 MSE 上升 4.76%/10.90%/2.08%，`no_prior_loss` 使 MSE 上升 2.03%/12.94%/6.05%。两者的 $\mathrm{RMSE}_\Delta$ 分别为 0.527/0.402/1.158 与 0.531/0.777/0.982，高于满模型的 0.166/0.169/0.338，说明先验质量下降后去噪器需要承担更大的残差校正量。
- **去噪校正量相对先验误差的占比**：满模型的 $\mathrm{RMSE}_\Delta$ 为 0.166/0.169/0.338，先验 RMSE 为 1.482/1.427/2.674，占比 11.2%/11.9%/12.6%。去噪器在历史先验的基础上做小幅残差精炼，输出幅值没有出现大幅漂移。
- **平均测地距离**：先验到去噪未来的平均距离为 0.9972→0.9652（ETTh2，$-3.21\%$）、0.4021→0.3956（ETTm1，$-1.60\%$）、0.5921→0.5919（Exchange，$-0.03\%$）。对齐度 $1/(1+\bar d)$ 为 0.5088、0.7165、0.6282。
- **扩散步数**：ETTh2 的 $\mathrm{RMSE}_\Delta$ 从 $K=1$ 的 1.495 升至 $K=4$ 的 1.608；ETTm1 从 1.417 升至 1.481；Exchange 从 $K=1$ 的 2.644 升至部署 $K=2$ 的 2.665 与 $K=4$ 的 2.684。增加步数没有降低残差负担，部署步数由各数据集 Optuna 配置决定（ETTh2 1、ETTm1 1、Exchange 2）。

### 6.4 结果解读

双曲条件注入与欧氏流形替换在三个数据集上没有统一方向：`no_hyp_cond` 的 MSE 变化为 -2.13%/-0.14%/-12.00%，`euclid_manifold` 为 -1.24%/+0.41%/-14.21%。双曲组件在三数据集上的点预测变化方向不一致。双曲几何的证据来自距离行为：ETTh2 的去噪未来在测地距离上靠近目标 3.21%，ETTm1 靠近 1.60%；欧氏变体的对齐度 0.6805/0.8351/0.7773 由欧氏距离计算，与双曲对齐度属于不同度量，图中以空心标记区分。

### 6.5 机理边界

- 每个数据集只运行一个种子，变体间差异包含种子噪声；ETTh2 的 `no_hyp_cond` 与 `euclid_manifold` 差距 2.13 与 1.24 个百分点，处于单次运行波动范围。
- 机制实验固定在 $H=96$，未覆盖长预测步长与高通道数据集；ECL、Traffic、PEMS 的几何行为未测量。
- 对齐度依赖目标流形投影与当前 checkpoint；不同变体的流形尺度不同，跨变体比较以 MSE/MAE 为主，距离指标用于同一几何内的前后对比。

---

## 7. OFAT 消融分析（One-Factor-At-A-Time Ablation）

### 7.1 协议

OFAT 套件以 6 个数据集（ETTh2、ETTm1、Exchange、Weather、ECL、Illness）× 4 个预测步长为目标网格，包含 `none` 基线与 8 个单变量变体：`euclid_manifold`、`no_hyp_cond`、`zero_prior_bridge`、`no_adaln`、`no_denoise_refinement`、`no_causal_prefix_norm`、`no_hyp_loss`、`no_prior_loss`。每个单元格由 `python -m src.configs.m2patch_cli <DS> <PL> --from-optuna --with-meta` 启动，基线为对应单元格的 Optuna 最优配置，因此变体与基线的差异只来自被替换的组件。当前 ETTh2、ETTm1、Exchange 已完成 8 变体 × 4 步长的实测（108 个单元，含 `none`）；Weather、ECL、Illness 的基线格由 Optuna 导出填充，变体格为 `PENDING`。结果由 `output/ablation/update_ablation.py` 汇总为 `output/ablation/m2p-ablation.xlsx`。

### 7.2 跨步长均值

表内 ΔMSE 的聚合口径：对每个变体，取 3 个数据集 × 4 个步长共 12 个单元格的 MSE 之和，除以 `none` 同 12 格的 MSE 之和后减 1；分数据集列为该数据集 4 个步长的 MSE 之和相对 `none` 同 4 格的变化。该口径先汇总 MSE 再取相对差；12 格聚合列与三个分数据集列都不是逐格 ΔMSE 的算术平均。

| 变体 | ETTh2 MSE / MAE | ΔMSE | ETTm1 MSE / MAE | ΔMSE | Exchange MSE / MAE | ΔMSE | 12 格聚合 ΔMSE |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Full M2Patch | 0.4028 / 0.4140 | — | 0.3862 / 0.3975 | — | 0.3838 / 0.4215 | — | — |
| w/ Euclidean Manifold | 0.3963 / 0.4114 | -1.62% | 0.3879 / 0.3975 | +0.46% | 0.3862 / 0.4174 | +0.62% | -0.20% |
| w/o Hyperbolic Conditioning | 0.3848 / 0.4069 | -4.46% | 0.3868 / 0.3971 | +0.16% | 0.3720 / 0.4100 | -3.10% | -2.49% |
| w/ Zero-Mean Prior Bridge | 0.4078 / 0.4219 | +1.23% | 0.3887 / 0.3941 | +0.65% | 0.3811 / 0.4216 | -0.71% | +0.40% |
| w/o AdaLN-Zero Modulation | 0.3859 / 0.4061 | -4.19% | 0.3984 / 0.4013 | +3.17% | 0.3864 / 0.4199 | +0.66% | -0.18% |
| w/o Diffusion Denoiser | 0.3770 / 0.3996 | -6.40% | 0.3875 / 0.3952 | +0.33% | 0.3411 / 0.3966 | -11.14% | -5.74% |
| w/o Causal Prefix Norm | 0.4096 / 0.4213 | +1.68% | 0.4239 / 0.4192 | +9.78% | 0.3487 / 0.4272 | -9.16% | +0.80% |
| w/o Hyperbolic Alignment Loss | 0.3833 / 0.4049 | -4.83% | 0.3963 / 0.4041 | +2.64% | 0.3937 / 0.4273 | +2.58% | +0.05% |
| w/o Prior Anchor Loss | 0.3892 / 0.4105 | -3.38% | 0.3830 / 0.3910 | -0.81% | 0.4002 / 0.4297 | +4.26% | -0.03% |

### 7.3 逐变体观察

- **历史先验桥接**：`zero_prior_bridge` 的 12 格聚合 MSE 上升 0.40%，在 ETTh2 与 ETTm1 上分别上升 1.23% 与 0.65%，在 Exchange 上下降 0.71%。零均值桥接在三数据集上的平均方向为劣化，单格方向不一致。
- **先验锚点损失**：`no_prior_loss` 在 ETTm1 上 MSE 下降 0.81%，在 ETTh2 上下降 3.38%，在 Exchange 上上升 4.26%，12 格聚合值 -0.03%。该损失的作用方向依赖数据集，Exchange 的小样本与非平稳性使其收益最明显。
- **因果前缀归一化**：`no_causal_prefix_norm` 在 ETTm1 上升 9.78%，在 ETTh2 上升 1.68%，在 Exchange 下降 9.16%，12 格聚合值 +0.80%。ETTm1 的 7 通道、15 分钟采样序列对逐前缀统计量最敏感；Exchange 的日频弱周期序列上去掉该归一化反而降低误差。
- **双曲流形与双曲条件注入**：`euclid_manifold` 的 12 格聚合值 -0.20%，`no_hyp_cond` 为 -2.49%；`no_hyp_cond` 在 ETTh2 与 Exchange 上降低 MSE，在 ETTm1 上上升 0.16%；`euclid_manifold` 仅在 ETTh2 上降低 MSE，在 ETTm1 与 Exchange 上升。双曲组件在三数据集上的增益方向不一致。
- **AdaLN-Zero 与去噪器**：`no_adaln` 的 12 格聚合值 -0.18%，`no_denoise_refinement` 为 -5.74%。`no_denoise_refinement` 在 Exchange 上 MSE 下降 11.14%，在 ETTh2 下降 6.40%，在 ETTm1 上升 0.33%；直接输出历史先验在低信噪比与小样本数据上具有竞争力。
- **双曲对齐损失**：`no_hyp_loss` 的 12 格聚合值 +0.05%，ETTh2 -4.83%、ETTm1 +2.64%、Exchange +2.58%，方向不一致。

### 7.4 机理边界

- OFAT 结果按数据集分化，12 格聚合值用于汇总方向，逐数据集结论以各列数值为准；论文主表按数据集报告，并说明每个组件的适用区间。
- Exchange 的 4 个步长中 $H=720$ 的 MSE 为 0.86，远高于其余步长，跨步长均值由该单元格主导；逐格结果见 `Full Detail` 工作表。
- Weather、ECL、Illness 的变体单元格尚未实测，当前工作簿中的这三列只有 Optuna 基线；在补齐前不纳入跨数据集均值。

---

## 8. 跨数据集非参数统计检验（Cross-Dataset Nonparametric Tests）

### 8.1 协议

`scripts/statistics/nonparametric_tests.py` 以 `(dataset, pred_len)` 为一个问题实例，在 ETTh2、ETTm1、Exchange 的 4 个步长共 12 个完整区块上比较 8 个模型：M2Patch、MMPD、SimpleTM、TimeMixer、iTransformer、PatchTST、DLinear、TimesNet。每个区块内按误差升序排名（rank 1 最低），使用 tie-corrected Friedman $\chi_F^2$ 检验整体差异，Iman-Davenport 校正给出 $F_F$（$df_1=k-1$，$df_2=(k-1)(N-1)$），Nemenyi 临界差 $CD=q_\alpha\sqrt{k(k+1)/(6N)}$ 用于平均秩比较。成对检验为双侧 Wilcoxon 符号秩检验，零差异剔除，7 个基线的 $p$ 值经 Holm-Bonferroni 校正；效应量为 matched-pairs rank-biserial $r=(W_+-W_-)/(W_++W_-)$，$r>0$ 表示 M2Patch 误差更低。

M2Patch 的单元格取自 `output/ablation/none.tsv` 的实测 Optuna 配置基线；基线的单元格在 `output/benchmark/{dataset}.tsv` 存在时取共享 15-epoch 协议实测值，否则取 `assets/m2p_eff_results_1.xlsx` 的主表值。每个单元格的来源记录在 `output/statistics/benchmark_matrix.csv`。

### 8.2 Friedman 与 Iman-Davenport

| 指标 | $\chi_F^2$ | $F_F$ | $df_1$ / $df_2$ | $p_F$ | M2Patch 平均秩 | Nemenyi CD |
| --- | --- | --- | --- | --- | --- | --- |
| MSE | 33.4722 | 7.28697 | 7 / 77 | $1.08\times10^{-6}$ | 4.333（5/8） | 3.0309 |
| MAE | 40.1389 | 10.0665 | 7 / 77 | $7.14\times10^{-9}$ | 4.333（5/8） | 3.0309 |

MSE 平均秩：PatchTST 2.250、DLinear 3.083、TimeMixer 3.833、MMPD 4.083、M2Patch 4.333、iTransformer 5.583、SimpleTM 5.917、TimesNet 6.917。MAE 平均秩：PatchTST 2.250、DLinear 2.583、TimeMixer 3.917、MMPD 4.083、M2Patch 4.333、iTransformer 5.583、SimpleTM 6.083、TimesNet 7.167。

### 8.3 成对 Wilcoxon 检验（M2Patch vs 基线，Holm 校正）

| 基线 | MSE W | MSE $p$ | MSE $p_{\text{Holm}}$ | MSE $r$ | MSE 胜/平/负 | MAE $p$ | MAE $p_{\text{Holm}}$ | MAE $r$ | MAE 胜/平/负 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MMPD | 28 | 0.4238 | 1.000 | -0.2821 | 4/0/8 | 0.6221 | 1.000 | -0.1795 | 5/0/7 |
| SimpleTM | 26 | 0.3394 | 1.000 | +0.3333 | 8/0/4 | 0.1514 | 0.647 | +0.4872 | 10/0/2 |
| TimeMixer | 31 | 0.5693 | 1.000 | -0.2051 | 5/0/7 | 0.6772 | 1.000 | -0.1538 | 5/0/7 |
| iTransformer | 27 | 0.3804 | 1.000 | +0.3077 | 9/0/3 | 0.3804 | 1.000 | +0.3077 | 9/0/3 |
| PatchTST | 10 | 0.0210 | 0.147 | -0.7436 | 3/0/9 | 0.05225 | 0.3135 | -0.6410 | 2/0/10 |
| DLinear | 27 | 0.3804 | 1.000 | -0.3077 | 5/0/7 | 0.1294 | 0.647 | -0.5128 | 3/0/9 |
| TimesNet | 15 | 0.0640 | 0.3838 | +0.6154 | 10/0/2 | 0.00928 | 0.0649 | +0.8205 | 10/0/2 |

### 8.4 结果解读

- Friedman 检验在 MSE 与 MAE 上均拒绝“8 个模型无差异”的原假设（$p_F=1.08\times10^{-6}$ 与 $7.14\times10^{-9}$），模型整体存在差异。
- Holm 校正后没有任何单对比较达到 $\alpha=0.05$；最小的校正 $p$ 为 MSE 对 PatchTST 的 0.147 与 MAE 对 TimesNet 的 0.0649。在 12 个区块上，论文不据此声明 M2Patch 显著优于某一基线。
- M2Patch 的平均秩为 4.333，位于 PatchTST、DLinear、TimeMixer、MMPD 之后；对 TimesNet 的效应量 $r=+0.6154$（MSE）与 $+0.8205$（MAE），对 SimpleTM 为 $+0.3333$ 与 $+0.4872$，对 PatchTST 为 $-0.7436$ 与 $-0.6410$。
- 当前检验范围限于 3 个核心数据集。`--include-all` 需要其余数据集的 benchmark 单元格齐备；缺失单元格不会进入检验。

---

## 9. 核心超参数敏感性分析（Hyperparameter Sensitivity Analysis）

### 9.1 协议

5 个数据集（ETTh1、ETTh2、ETTm1、Weather、Exchange）× 4 个参数（字段名 `d_model`、`d_hyp`、`d_layers_diff`/`L_diff`、`learning_rate`）× 4 个取值 × 5 个 seeds（2022–2026），固定 $H=96$、15 epochs、batch size 32、OneCycleLR。扫描范围：$d_{\text{model}}\in\{64,128,256,512\}$（$d_{ff}=\min(2d_{\text{model}},768)$，`n_heads` 按整除对齐），$d_{\text{hyp}}\in\{16,32,64,128\}$，$d_{\text{layers\_diff}}\in\{1,2,3,4\}$，学习率 $\eta\in\{10^{-4},2.5\times10^{-4},5\times10^{-4},10^{-3}\}$（此处的 $\eta$ 指优化器学习率，区别于 DDIM 的 `--diff_eta`）。非扫描参数按 sweep 期间（TSV 写入时间 2026-11-18 23:48 前）的 `output/optuna/` pl96 JSON 取值：ETTh1/ETTh2/ETTm1 使用当时已有的 JSON；Exchange 使用当时版本的 JSON；Weather 当时无 pl96 JSON，取冻结 profile。Weather 的 pl96 JSON 于 2026-11-19 07:19 生成，Exchange 的 pl96 JSON 于 2026-11-19 04:58 更新，均晚于 sweep，该次 sweep 的配置由 TSV 记录固定，当前 JSON 已更新。表中为 5 个种子的 MSE 均值 ± 标准差。

### 9.2 均值与标准差

| 数据集 | 参数 | 取值 1 | 取值 2 | 取值 3 | 取值 4 |
| --- | --- | --- | --- | --- | --- |
| ETTh1 | $d_{\text{model}}$ | 64: 0.4367±0.0158 | 128: 0.3963±0.0050 | 256: **0.3888±0.0076** | 512: 0.3955±0.0068 |
| ETTh1 | $d_{\text{hyp}}$ | 16: 0.3950±0.0078 | 32: 0.3974±0.0097 | 64: 0.3982±0.0134 | 128: **0.3909±0.0049** |
| ETTh1 | $L_{\text{diff}}$ | 1: 0.3909±0.0049 | 2: 0.3865±0.0071 | 3: **0.3859±0.0042** | 4: 0.3859±0.0030 |
| ETTh1 | lr | 1e-4: **0.3931±0.0057** | 2.5e-4: 0.3933±0.0060 | 5e-4: 0.3977±0.0107 | 1e-3: 0.4003±0.0118 |
| ETTh2 | $d_{\text{model}}$ | 64: **0.2938±0.0055** | 128: 0.2945±0.0024 | 256: 0.3034±0.0075 | 512: 0.2979±0.0073 |
| ETTh2 | $d_{\text{hyp}}$ | 16: 0.3045±0.0096 | 32: 0.2979±0.0073 | 64: **0.2967±0.0067** | 128: 0.3031±0.0059 |
| ETTh2 | $L_{\text{diff}}$ | 1: 0.3107±0.0093 | 2: 0.2979±0.0073 | 3: **0.2969±0.0054** | 4: 0.2972±0.0039 |
| ETTh2 | lr | 1e-4: 0.2998±0.0053 | 2.5e-4: 0.2971±0.0011 | 5e-4: 0.3010±0.0100 | 1e-3: **0.2951±0.0060** |
| ETTm1 | $d_{\text{model}}$ | 64: 0.3358±0.0026 | 128: 0.3259±0.0033 | 256: **0.3186±0.0076** | 512: 0.3236±0.0022 |
| ETTm1 | $d_{\text{hyp}}$ | 16: **0.3166±0.0015** | 32: 0.3196±0.0057 | 64: 0.3169±0.0039 | 128: 0.3186±0.0076 |
| ETTm1 | $L_{\text{diff}}$ | 1: 0.3294±0.0051 | 2: **0.3186±0.0076** | 3: 0.3188±0.0047 | 4: 0.3187±0.0038 |
| ETTm1 | lr | 1e-4: 0.3310±0.0066 | 2.5e-4: 0.3178±0.0059 | 5e-4: **0.3146±0.0022** | 1e-3: 0.3280±0.0116 |
| Weather | $d_{\text{model}}$ | 64: 0.1720±0.0016 | 128: **0.1689±0.0010** | 256: 0.1697±0.0008 | 512: 0.1746±0.0008 |
| Weather | $d_{\text{hyp}}$ | 16: 0.1706±0.0018 | 32: 0.1698±0.0013 | 64: **0.1687±0.0015** | 128: 0.1689±0.0010 |
| Weather | $L_{\text{diff}}$ | 1: 0.1712±0.0014 | 2: **0.1689±0.0010** | 3: 0.1697±0.0012 | 4: 0.1693±0.0008 |
| Weather | lr | 1e-4: 0.1780±0.0024 | 2.5e-4: 0.1722±0.0014 | 5e-4: 0.1728±0.0036 | 1e-3: **0.1692±0.0006** |
| Exchange | $d_{\text{model}}$ | 64: **0.0881±0.0021** | 128: 0.0976±0.0052 | 256: 0.1001±0.0126 | 512: 0.0977±0.0089 |
| Exchange | $d_{\text{hyp}}$ | 16: 0.1043±0.0098 | 32: **0.0914±0.0107** | 64: 0.1046±0.0112 | 128: 0.0977±0.0089 |
| Exchange | $L_{\text{diff}}$ | 1: 0.0992±0.0050 | 2: 0.0977±0.0089 | 3: 0.0966±0.0086 | 4: **0.0949±0.0069** |
| Exchange | lr | 1e-4: 0.0991±0.0117 | 2.5e-4: 0.1029±0.0114 | 5e-4: **0.0969±0.0046** | 1e-3: 0.1041±0.0174 |

### 9.3 稳定性区间

以各数据集的最优均值为基准，定义“稳定区间”为均值不超过最优值 1% 的取值集合。

| 数据集 | $d_{\text{model}}$ 最优 / 稳定 | $d_{\text{hyp}}$ 最优 / 稳定 | $L_{\text{diff}}$ 最优 / 稳定 | lr 最优 / 稳定 | 参数极差（最大/最小−1） |
| --- | --- | --- | --- | --- | --- |
| ETTh1 | 256 / {256} | 128 / {128} | 3 / {2,3,4} | 1e-4 / {1e-4, 2.5e-4} | 12.3% / 1.9% / 1.3% / 1.8% |
| ETTh2 | 64 / {64,128} | 64 / {32,64} | 3 / {2,3,4} | 1e-3 / {2.5e-4, 1e-3} | 3.3% / 2.6% / 4.7% / 2.0% |
| ETTm1 | 256 / {256} | 16 / {16,32,64,128} | 2 / {2,3,4} | 5e-4 / {5e-4} | 5.4% / 1.0% / 3.4% / 5.2% |
| Weather | 128 / {128,256} | 64 / {32,64,128} | 2 / {2,3,4} | 1e-3 / {1e-3} | 3.3% / 1.1% / 1.3% / 5.2% |
| Exchange | 64 / {64} | 32 / {32} | 4 / {4} | 5e-4 / {5e-4} | 13.6% / 14.5% / 4.5% / 7.4% |

### 9.4 参数偏好与机理

**（1）主干容量 $d_{\text{model}}$：128–256 为通用最优带，Exchange 强烈偏好 64。**

ETTh1、ETTm1 的最优点为 256，Weather 为 128（256 在 1% 稳定区间内），ETTh2 为 64（128 在稳定区间内）；512 在全部数据集上均未取得最优，ETTh1 上 64 比 256 差 12.3%，Exchange 上 256 比 64 差 13.6%。主干容量的最优值与训练样本量、通道数、信噪比相关：ETTh1/ETTm1 的 7 通道、8.6k/34.6k 训练行支持 256 维；Weather 的 21 通道、36.9k 训练行在 128 维已足够；Exchange 仅 5.3k 训练行、日频弱周期，256/512 维迅速过拟合，64 维最优。高容量并未带来长程建模收益，说明 M2Patch 的表达能力主要来自流形与先验桥接，主干宽度的边际收益有限。

**（2）双曲维数 $d_{\text{hyp}}$：平坦参数，64 维是安全的通用值。**

$d_{\text{hyp}}$ 的极差在 ETTm1 为 1.0%、Weather 1.1%、ETTh1 1.9%、ETTh2 2.6%，四个数据集上 64 维距各自最优不超过 1.9%。Exchange 是唯一敏感数据集（极差 14.5%），最优为 32、次优为 128，16 与 64 均较差（0.1043/0.1046），呈非单调。Exchange 的日频汇率序列近似随机游走，层次结构弱，过宽或过窄的流形都会放大噪声；32 维在容量与正则之间取得平衡。其余数据集的周期层级可由 64 维充分容纳，继续增大到 128 只带来 0.1%–2.2% 的变化。该结果为论文的默认配置 $d_{\text{hyp}}=64$ 提供了直接依据。

**（3）去噪深度 $L_{\text{diff}}$：2 层是拐点，1 层稳定不足，3–4 层收益饱和。**

$L_{\text{diff}}=1$ 在五个数据集上均非最优，相对各自最优的损失为 ETTh1 +1.3%、ETTh2 +4.7%、ETTm1 +3.4%、Weather +1.4%、Exchange +4.5%；$L_{\text{diff}}\ge2$ 后，ETTh1/ETTh2/ETTm1/Weather 的 2–4 层均落在 1% 稳定区间内，Exchange 在 4 层取得最优，1–4 层的极差为 4.5%、2–4 层为 3.0%。该模式说明单个 FutureDenoiserBlock 的交叉注意力与 AdaLN 调制未完成残差精炼，两层跨过拐点；继续堆叠的边际收益小于种子方差。论文可将 2 层作为默认值，并在敏感性分析中报告 1 层的退化幅度。

**（4）学习率：5e-4 是跨数据集较稳的默认值，低频/高噪声数据偏好更低或更高的端点。**

5e-4 在 ETTm1 与 Exchange 取得最优，在 ETTh1 距最优 1.2%、Weather 2.1%、ETTh2 2.0%。1e-4 在 Weather 与 ETTm1 上分别差 5.2%（欠拟合），1e-3 在 ETTm1 上差 4.3% 且标准差升至 0.0116（训练不稳定），在 Exchange 上差 7.4%、标准差 0.0174。ETTh1 偏好 1e-4–2.5e-4 的低学习率，Weather 偏好 1e-3 的高学习率：前者的 7 通道小时级序列可训练窗口少，低学习率更稳；后者的 21 通道、36.9k 窗口与强周期信号支持更快的收敛。OneCycleLR 的 15 epochs 预算放大了学习率的作用，过长或过短的训练预算会改变该排序。

**（5）种子方差：Weather 最稳，Exchange 最不稳定。**

Weather 的标准差为 0.0006–0.0036，为五组中最低；Exchange 全部扫描单元为 0.0021–0.0174（最小值来自 `d_model=64`，最大值来自 `lr=1e-3`），为五组中最高，最大标准差出现在 `lr=1e-3`（0.0174）与 `d_model=256`（0.0126）。Exchange 的小样本与非平稳性使单次运行的结论可靠性较低，论文中应以 5 seed 均值±标准差报告，避免引用单一种子的最优值。

### 9.5 机理边界

- **单变量扫描不识别交互**：$d_{\text{model}}$ 的扫描同时改变 $d_{ff}$ 与 `n_heads`，$d_{\text{hyp}}$ 的扫描只改变流形宽度；两者的联合最优可能偏离各自的单变量最优。当前结果给出默认值附近的稳定性区间，未做全局最优声明。
- **数据集覆盖**：敏感性实验仅覆盖 5 个数据集与 $H=96$，ECL、Traffic、Solar、PEMS、Illness 未纳入；高通道与小样本数据的最优容量可能落在扫描范围之外。
- **Weather 与 Exchange 的基线来源**：Weather 在 sweep 时点无 pl96 Optuna JSON，使用冻结 profile；该 JSON 于 2026-11-19 07:19 生成。Exchange 的 pl96 JSON 在 sweep 后于 2026-11-19 04:58 更新（当前 `patch_len=8`、`lr=1.227e-4`），与 sweep 时的非扫描值不同。两者的最优点与使用稳定 Optuna 配置的 ETTh1/ETTh2/ETTm1 不完全同口径。
- **训练预算**：全部单元使用 15 epochs，未做早停以外的预算扫描；更长训练可能改变 $d_{\text{model}}$ 与学习率的最优值。

---

## 10. 跨实验综合结论与论文写作要点

1. **统一效率协议给出了可比的精度-资源画像。** 12 个模型在 10 epochs、`batch_size=16`、FP32、seed 2023 下顺序测量；M2Patch 的 MSE 排名为 ETTm1 3/12、Weather 4/12、ECL 6/12，距最优基线 3.73%、6.81%、15.64%，平均秩 4.33。参数量为 2.66 M、5.26 M、1.27 M，推理时延为 4.08 ms、4.44 ms、15.93 ms/batch。ECL 的 321 通道使有效批大小达到 5136，训练时间与显存分别为 S-Mamba 的 $7.37\times$ 与 $7.31\times$，是高通道场景的主要成本。
2. **长回看扩展性是 M2Patch 最有力的实证信号。** ETTm1 从 $L=48$ 到 $L=720$ 的 MSE 下降 39.45%，在 $L=720$ 以 0.2841 取得六模型最优；ECL 下降 44.63%，与最优基线的差距从 48.85% 收窄到 0.63%；Weather 下降 28.79%。该趋势由严格因果分块、逐前缀收缩归一化、负曲率流形容量与先验桥接共同支撑，其中平均收缩偏差从 3.48% 降至 0.56% 是可量化的直接证据。
3. **零样本噪声鲁棒性来自五段有界机制。** RevIN 将加性噪声转为有界相对扰动（$\sigma/\sqrt{\sigma_x^2+\sigma^2}\le1$），中位数下界保护局部低方差窗口，切空间裁剪把流形半径限制在 0.964，有理饱和测地线把梯度限制在 0.65 以内，先验桥接提供低通骨架。$\sigma=0.5$ 时 ETTm2 的 MSE 退化 11.5%–17.2%，ETTm1 为 25.8%–44.5%。
4. **机制实验确认先验桥接与先验锚点损失的作用，双曲几何的证据主要来自 ETTh2 与 ETTm1 的测地距离。** `zero_prior_bridge` 使三个数据集的 MSE 上升 4.76%/10.90%/2.08%，`no_prior_loss` 上升 2.03%/12.94%/6.05%；`no_hyp_cond` 与 `euclid_manifold` 的点预测变化为 -2.13%/-0.14%/-12.00% 与 -1.24%/+0.41%/-14.21%，没有统一增益。先验到去噪未来的平均测地距离在 ETTh2 与 ETTm1 上分别缩短 3.21% 与 1.60%，Exchange 为 0.03%。
5. **OFAT 消融按数据集分化。** 12 格聚合值上，`zero_prior_bridge` +0.40%、`no_causal_prefix_norm` +0.80%、`no_hyp_loss` +0.05%、`no_prior_loss` -0.03%、`euclid_manifold` -0.20%、`no_hyp_cond` -2.49%、`no_adaln` -0.18%、`no_denoise_refinement` -5.74%。历史先验桥接在 ETTh2 与 ETTm1 上有效，因果前缀归一化在 ETTm1 上有效，去掉去噪器在 Exchange 上反而降低 MSE。论文应按数据集报告消融结果，并将 Weather/ECL/Illness 标注为待测。
6. **跨数据集统计检验未给出成对显著性。** 12 个区块、8 个模型的 Friedman 检验在 MSE/MAE 上均显著（$p_F=1.08\times10^{-6}$ 与 $7.14\times10^{-9}$），Holm 校正后 7 个基线的 $p$ 值均大于 0.05，最小校正 $p$ 为 0.147（MSE vs PatchTST）与 0.0649（MAE vs TimesNet）。M2Patch 平均秩 4.333，论文应报告平均秩、效应量与校正 $p$ 值，不使用“显著优于”表述。
7. **案例研究展示局部波形优势，全局排名以主表为准。** 四个展示窗口上 M2Patch 的展示通道 MSE 相对最优基线为 -67.3%、-34.6%、-2.3%、-19.7%；整段测试集上 ETTm2 最优，ETTm1、ECL、Exchange 分别落后 3.31%、8.09%、16.25%。Exchange 窗口的 $r=0.8068$ 与基线的负相关形成对比，是机制在低信噪比序列上的直接证据。
8. **写作定位。** 将第 3 节的长回看曲线作为主图，第 4 节的噪声退化曲线作为鲁棒性图，第 2 节作为“精度-资源”权衡表，第 6 节作为机制主图，第 5 节作为定性案例，第 7 节作为消融表，第 8 节作为统计检验表，第 9 节作为附录级敏感性分析。核心叙事围绕“长历史因果建模 + 双曲几何 + 先验桥接”的机制一致性展开，局限性段落直接写出短回看（$L=48$）、高通道（ECL）、极端幅值与 ETTm1/Exchange 整段排名四个边界。

---

### 附：图表格式约定

本报告涉及的 Notebook 分析实验图表统一输出 600 dpi `.png`：`output/efficiency/exp_2_efficiency.png`、`output/lookback/exp_4_lookback.png`、`output/robustness/exp_3_robustness.png` 与 `exp_3_robustness_ETTm1.png`、`output/case_study/figures/case_study_comparison_96.png`、`output/hyperparam/4_sensitivity.png` / `4_sensitivity_lines.png` / `exp_6_sensitivity.png`；机制实验图（`output/mechanism/figures/m2patch_mechanism_{Dataset}.png`、2×2 主图 `m2patch_mechanism_analysis.png` 与跨数据集汇总图 `m2patch_mechanism_cross_dataset.png`）与统计检验图 `output/statistics/critical_difference.png` 同样按 600 dpi 输出。配色统一取自 `scripts/color.py` 的 NPG 调色板。
