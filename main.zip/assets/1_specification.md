# M2Patch 模型技术规范与架构设计说明 (Model Specification)

## 1. 模型概述与设计动机 (Overview & Motivation)

**M2Patch**（**M**anifold-**M**odulated **Patch** Diffusion Forecaster，基于庞加莱球双曲流形与先验桥接条件扩散的因果 Patch 预测模型）是针对多元时间序列长期预测（Multivariate Long-Term Time Series Forecasting, MTSF）设计的深度几何生成式预测架构。

现有基于 Patch 的确定性前馈预测模型（如 PatchTST）与早期时间序列扩散模型（如 TimeDART、TimeGrad）普遍存在以下四大瓶颈：

1. **分块与归一化过程中的非因果信息泄露（Causality Violation）**：传统方法在序列尾部进行跨边界填充（Right-Padding），或在 Patch 内部混用全窗口未来统计量，破坏了局部表征的时间因果律；
2. **欧氏潜空间的几何退化（Euclidean Bottleneck）**：从历史窗口向未来长周期窗口推演时，潜在动态模态与不确定性随时间步呈指数级分叉膨胀，平坦的欧氏线性潜空间难以等距嵌入此类具有树状因果层级与多频突变的轨迹；
3. **零均值高斯扩散的路径冗余与采样方差（Zero-Mean Diffusion Gap）**：标准扩散模型将未来序列向无信息零均值白噪声 $\mathcal{N}(\mathbf{0}, \mathbf{I})$ 腐蚀，逆向生成时需跨越巨大的分布鸿沟，不仅需要数十上百步迭代，还会引入损害点预测指标（MSE/MAE）的随机采样方差；
4. **训练与推理阶段的时间步/条件失配**：部分自监督 Patch 扩散模型（如 TimeDART）在去噪解码器中忽略了扩散时间步 $t$ 的显式调制，甚至在下游微调/推理时丢弃去噪器，未能将扩散去噪能力真正转化为测试集上的预测增益。

为系统性解决上述问题，**M2Patch** 将**严格因果单尺度 Patch 范式**、**常数负曲率庞加莱球双曲流形（Poincaré Ball Manifold, $\mathbb{B}_c^d$）**与**非零历史先验桥接连续时间扩散（Prior-Bridge VP-SDE）**有机融合，在不引入任何未来信息泄露的前提下，实现了兼具高精度与单步/少步确定性极速推理的时间序列预测。

---

## 2. 核心创新点归纳 (Core Innovations)

M2Patch 的方法论建立在以下**四大核心创新支柱**之上：

### 创新点一：零未来泄露的双重因果归一化与单尺度因果 Patch 编码 (Strictly Causal Patching & Dual-Level Normalization)

- **左端首值复制填充（Left-Only Replication Padding）**：当历史序列长度 $L$ 无法被 $(P, S)$ 整除时，仅在历史起点 $t=0$ 左侧复制首时刻观测值进行填充，确保第 $i$ 个 Patch 的右边界 $e_i$ 严格落在历史观测区间内，且最后一个 Patch 的右端点精确对齐当前时刻 $t=L$。
- **逐前缀贝叶斯收缩归一化（Causal Prefix Shrinkage Normalization）**：在分块器内部，每个 Patch $i$ 仅利用截至其自身右端点 $e_i$ 的因果前缀累积统计量 $(\mu_{\le e_i}, \sigma_{\le e_i}^2)$ 进行局部归一化，并引入贝叶斯先验收缩因子 $\rho_i = \frac{e_i}{e_i + \tau_0}$ 抑制早期短前缀的方差估计噪声；配合外层仅缓存历史统计量的稳健中位数下界 `RevIN`，从根源上杜绝任何跨时间步或跨数据集分割的信息泄露。

### 创新点二：常数负曲率庞加莱球双曲流形表征与黎曼条件注入 (Poincaré-Ball Hyperbolic Manifold & Geodesic Conditioning)

- **精确闭式双曲几何映射**：抛弃经验性的欧氏瓶颈层，引入具有严格数学定义的常数负曲率 $-c$（$c > 0$）庞加莱球流形 $\mathbb{B}_c^{d_{\text{hyp}}} = \{\mathbf{z} \in \mathbb{R}^{d_{\text{hyp}}} : c\|\mathbf{z}\|_2^2 < 1\}$。所有流形运算（球内安全投影 $\Pi_{\mathbb{B}_c}$、原点指数映射 $\exp_{\mathbf{0}}^c$、原点对数映射 $\log_{\mathbf{0}}^c$、莫比乌斯加法 $\oplus_c$、基点对数映射 $\log_{\mathbf{x}}^c(\mathbf{y})$ 及测地线距离 $d_{\mathbb{B}}^c$）均以 FP32 闭式解析算子实现，计算复杂度仅为 $\mathcal{O}(d_{\text{hyp}})$，无需任何矩阵特征分解。
- **双曲历史流形均值条件注入**：将因果历史流形轨迹的质心通过原点对数映射拉回切空间并注入去噪器（`hyp_cond_proj`），使未来 Patch 的扩散去噪过程直接感知历史序列在负曲率空间中的几何位置与能量层级。

### 创新点三：历史因果先验桥接扩散与 AdaLN-Zero 条件去噪器 (Historical Prior-Bridge VP-SDE & AdaLN-Zero Denoiser)

- **非零极限均值的先验桥接扩散（Prior-Bridge VP-SDE）**：受晶体结构生成中非零物理极限先验 SDE 的启发，M2Patch 由最末一个因果历史状态生成未来序列的确定性先验锚点 $\mathbf{P}_{\text{prior}}$，并构建连接真实未来 Patch $\mathbf{P}_0$（$t=0$）与历史先验 $\mathbf{P}_{\text{prior}}$（$t=1$）的连续时间桥接前向边缘分布：
  $$
  \mathbf{P}_t = \alpha_t \mathbf{P}_0 + (1 - \alpha_t)\mathbf{P}_{\text{prior}} + \sigma_t \boldsymbol{\epsilon}, \quad \alpha_t^2 + \sigma_t^2 = 1

  $$

  该设计将扩散模型的任务从“凭空由白噪声生成全序列”转化为“以历史因果先验为起点的条件残差去噪精炼”。
- **AdaLN-Zero 调制与确定性 Bridge-DDIM 推理**：去噪器采用独立于历史编码器的未来 Patch 嵌入层，结合连续时间正弦编码、历史全局上下文与双曲几何条件，通过零初始化自适应层归一化（`AdaLN-Zero`）调制未来自注意力、历史交叉注意力与前馈网络。在推理阶段，从先验中心 $\mathbf{P}_{t=1} = \mathbf{P}_{\text{prior}}$ 出发执行确定性 Bridge-DDIM 逆向更新（默认仅需 $K=1$ 步即可完成高质量精炼），兼具完全确定性与极低推理时延。

### 创新点四：样本级尺度不变的三位一体损失函数 (Scale-Invariant Trinity Loss Function)

摒弃传统模型中与预测目标脱节的经验平滑正则，设计了由**先验桥接去噪得分匹配（$\mathcal{L}_{\text{bridge}}$）+ 原始物理空间重构（$\mathcal{L}_{\text{raw}}$）+ 庞加莱球双曲测地线与跨界切空间平移对齐（$\mathcal{L}_{\text{hyp}}$）+ 历史因果先验锚点监督（$\mathcal{L}_{\text{prior}}$）**组成的统一损失体系：

- 引入样本级能量自归一化 Huber 损失与有理饱和测地线距离 $\frac{d_{\mathbb{B}}^c(\cdot)^2}{1 + d_{\mathbb{B}}^c(\cdot)^2}$，彻底消除极端高幅值异常窗口或流形边界高曲率梯度爆炸对参数更新的主导；
- 通过以历史末尾流形点 $\mathbf{z}_{N_{\text{in}}}^{\text{hist}}$ 为基点的对数映射 $\log_{\mathbf{z}_{N_{\text{in}}}^{\text{hist}}}^c(\cdot)$ 约束“历史末尾 $\to$ 未来首 Patch”的切空间跨界跃迁向量，保证历史与未来交界处在双曲流形上的几何连续性。

---

## 3. 整体架构与前向数据流 (Architecture & Data Flow)

给定批次大小为 $B$、历史回顾窗口长度为 $L = \text{seq\_len}$、预测步长为 $H = \text{pred\_len}$、变量（通道）数为 $C = \text{enc\_in}$ 的输入时间序列 $\mathbf{X} \in \mathbb{R}^{B \times L \times C}$ 以及（训练阶段）真实未来序列 $\mathbf{Y}_{\text{true}} \in \mathbb{R}^{B \times H \times C}$，M2Patch（定义于 `src/model/M2Patch.py` 与 `src/layers/M2Patch_layers.py`）的完整数据流分为五个阶段。对应的理论流水线图见 `assets/plots/M2Patch_architecture.drawio`，图中同时标出训练回路与确定性推理回路。

```text
历史输入 X [B, L, C] ──► RevIN("stats") 仅统计并缓存历史均值 μ_X 与带中位数下界标准差 σ_X
   │
   ├─► (1) 通道独立展开 [B*C, L] ──► CausalPatchTokenizer (左端首值填充 + 逐前缀因果收缩归一化 + 线性嵌入)
   │        ──► 历史因果 Tokens [B*C, N_hist, d_model]
   │
   ├─► (2) CausalHistoryEncoder (严格下三角因果掩码 Multi-Head Self-Attention × e_layers)
   │        ──► 因果历史隐状态 H_hist [B*C, N_hist, d_model]
   │             ├──► 历史全局上下文: c_hist = Mean(H_hist) [B*C, d_model]
   │             ├──► 历史因果先验头: PriorMLP(H_hist[:, -1]) ──► 先验未来 Patch P_prior [B*C, N_fut, P] & Y_prior [B, H, C]
   │             └──► 庞加莱球指数映射: Z_hist_hyp = exp_0^c(W_hyp H_hist) ∈ B_c^{d_hyp}
   │                   └──► 双曲条件向量: c_hyp = W_cond(log_0^c(Mean(Z_hist_hyp))) [B*C, d_model]
   │
   ├─► (3) 先验桥接扩散与条件去噪 (Prior-Bridge Diffusion & HyperbolicConditionedPatchDenoiser):
   │        ├── [训练分支 y_true != None]:
   │        │     • 复用历史 (μ_X, σ_X) 归一化目标: Y_norm = RevIN.normalize_target(Y_true) ──► 切分为 P_0 [B*C, N_fut, P]
   │        │     • 采样时间步 t ~ U[t_min, 1.0]，计算余弦/线性 VP-SDE 系数 (α_t, σ_t)
   │        │     • 构造先验桥接加噪 Patch: P_t = α_t P_0 + (1 - α_t) sg(P_prior) + σ_t ε
   │        │     • 送入 AdaLN-Zero 去噪器 D_θ(P_t, t, H_hist, c_hist, sg(P_prior), c_hyp)
   │        │       产出: 预测干净 Patch P̂_0 = sg(P_prior) + Head_x0(D_θ), 预测噪声 ε̂ = Head_eps(D_θ), 预测未来双曲点 Ẑ_fut_hyp
   │        │     • 正交余弦基冻结投影真实目标: Z_target_hyp = sg(Project_DCT_Hyp(P_0)) ∈ B_c^{d_hyp}
   │        │
   │        └── [推理分支 y_true == None]:
   │              • 从历史先验起点 P_{t=1} = P_prior 出发，沿 t_k = 1 - k/K 迭代 K = diff_steps 步确定性 Bridge-DDIM
   │              • 产出最终去噪未来 Patch P̂_0 与未来双曲表征 Ẑ_fut_hyp
   │
   └─► (4) 序列重构与反归一化:
            P̂_0 [B*C, N_fut, P] ──► 重排并截取有效长度 H [B, H, C] ──► RevIN.denormalize(·) ──► 最终预测 Ŷ [B, H, C]
```

---

## 4. 核心模块数学原理与实现细节 (Detailed Mathematical Formulation)

### 4.1 历史统计量锁定的稳健可逆实例归一化 (`RevIN`)

代码位置：`src/layers/M2Patch_layers.py:15-102`

为防止低方差平稳通道在归一化时因分母趋近于零而将目标残差放大百倍，M2Patch 对 `RevIN` 进行了两项关键加固：

1. **跨通道中位数标准差下界（Median-Anchored Stdev Floor）**：
   仅在历史输入序列 $\mathbf{X} \in \mathbb{R}^{B \times L \times C}$ 上计算每个样本、每个通道的均值 $\mu_{b, c}$ 与原始标准差 $\sigma^{\text{raw}}_{b, c} = \sqrt{\text{Var}_t(\mathbf{X}_{b, :, c}) + \epsilon}$。当 $C > 1$ 时，计算同一批样本内各通道标准差的中位数 $\tilde{\sigma}_b = \text{Median}_c(\sigma^{\text{raw}}_{b, c})$，并施加下界保护（内置常数 `REVIN_STD_FLOOR_RATIO` $\eta_{\text{floor}} = 0.2$）：
   $$
   \sigma_{b, c} = \max\left(\sigma^{\text{raw}}_{b, c},\, \max(\eta_{\text{floor}} \tilde{\sigma}_b, \epsilon)\right)

   $$
2. **仅缓存历史统计量的目标对称裁剪归一化 (`normalize_target`)**：
   前向开始时调用 `self.revin(x, "stats")` 仅计算并缓存 `.detach()` 后的 $(\boldsymbol{\mu}_X, \boldsymbol{\sigma}_X)$。在训练阶段对未来真实序列 $\mathbf{Y}_{\text{true}}$ 归一化时，严格复用历史统计量并进行幅值裁剪（内置常数 `TARGET_CLIP` $\kappa = 10.0$）：
   $$
   \tilde{\mathbf{Y}} = \text{clip}\left(\frac{\mathbf{Y}_{\text{true}} - \boldsymbol{\mu}_X}{\boldsymbol{\sigma}_X},\, -\kappa,\, \kappa\right)

   $$

   这一机制保证了无论在训练还是测试阶段，模型内部永远不会窥探未来窗口的均值或方差。

---

### 4.2 单尺度严格因果分块与逐前缀收缩归一化 (`CausalPatchTokenizer`)

代码位置：`src/layers/M2Patch_layers.py:216-304`

将输入展平为通道独立张量 $\mathbf{x} \in \mathbb{R}^{(B \cdot C) \times L}$，给定单尺度 Patch 长度 $P = \text{patch\_len}$（默认 `16`）与滑动步长 $S = \text{stride}$（默认 `8`）：

1. **左端首值复制填充（Left-Tail Replication Padding）**：
   计算左填充长度：

   $$
   L_{\text{pad}} = \begin{cases} P - L, & \text{if } L < P \\ 0, & \text{if } (L - P) \bmod S = 0 \\ S - ((L - P) \bmod S), & \text{otherwise} \end{cases}

   $$

   在序列最左端（$t=0$ 之前）重复首个观测点 $x_{:, 0}$ 共 $L_{\text{pad}}$ 次得到 $\mathbf{x}_{\text{pad}} \in \mathbb{R}^{(B \cdot C) \times (L + L_{\text{pad}})}$，随后沿时间轴以窗口 $P$、步长 $S$ 展开为 $N_{\text{hist}} = \frac{L + L_{\text{pad}} - P}{S} + 1$ 个历史 Patch $\mathbf{P}^{\text{raw}} \in \mathbb{R}^{(B \cdot C) \times N_{\text{hist}} \times P}$。

   - **严格因果边界性质**：第 $i \in \{0, \dots, N_{\text{hist}}-1\}$ 个 Patch 在原始未填充序列中的有效因果前缀右端点为：
     $$
     e_i = \max\left(1,\, \min\left(L,\, i \cdot S - L_{\text{pad}} + P\right)\right)

     $$

     最后一个 Patch（$i = N_{\text{hist}} - 1$）满足 $e_{N_{\text{hist}}-1} \equiv L$，绝无任何超出 $L$ 的填充伪影。
2. **逐前缀贝叶斯收缩归一化（`_causal_normalize`）**：
   对于第 $i$ 个历史 Patch，仅利用原始序列前 $e_i$ 个历史时间步 $\mathbf{x}_{:, :e_i}$ 的一阶与二阶前缀和（`cumsum`）计算因果前缀均值与方差：

   $$
   \hat{\mu}_i = \frac{1}{e_i}\sum_{t=0}^{e_i-1} x_t, \quad \hat{\sigma}_i^2 = \max\left(0,\, \frac{1}{e_i}\sum_{t=0}^{e_i-1} x_t^2 - \hat{\mu}_i^2\right)

   $$

   为防止前几个 Patch 因 $e_i$ 较小导致方差估计不稳定，引入先验权重 $\tau_0 = 1.0$ 向标准正态分布 $\mathcal{N}(0, 1)$ 进行贝叶斯收缩：

   $$
   \rho_i = \frac{e_i}{e_i + \tau_0}, \quad \bar{\mu}_i = \text{sg}(\rho_i \hat{\mu}_i), \quad \bar{\sigma}_i^2 = \text{sg}\left(\rho_i \hat{\sigma}_i^2 + (1 - \rho_i)\right)

   $$

   $$
   \tilde{\mathbf{P}}_{:, i, :} = \frac{\mathbf{P}^{\text{raw}}_{:, i, :} - \bar{\mu}_i}{\sqrt{\bar{\sigma}_i^2 + \epsilon}}

   $$

   最后通过线性投影 $\mathbf{W}_{\text{emb}} \in \mathbb{R}^{P \times d_{\text{model}}}$ 与可学习位置编码 $\mathbf{E}_{\text{pos}} \in \mathbb{R}^{1 \times N_{\text{hist}} \times d_{\text{model}}}$ 生成历史因果 Token 序列 $\mathbf{T}^{\text{hist}} \in \mathbb{R}^{(B \cdot C) \times N_{\text{hist}} \times d_{\text{model}}}$。

---

### 4.3 因果历史编码器与历史先验生成 (`CausalHistoryEncoder`)

代码位置：`src/layers/M2Patch_layers.py:306-367, 798-816`

1. **下三角因果自注意力编码**：
   `CausalHistoryEncoder` 由 $L_e = \text{e\_layers}$ 层 Pre-LN Transformer 编码块组成。每一层自注意力均强制施加严格上三角负无穷掩码 $\mathbf{M}_{\text{causal}} \in \{0, -\infty\}^{N_{\text{hist}} \times N_{\text{hist}}}$（当 $j > i$ 时 $M_{i, j} = -\infty$）：

   $$
   \mathbf{H}^{\text{hist}} = \text{CausalHistoryEncoder}(\mathbf{T}^{\text{hist}}) \in \mathbb{R}^{(B \cdot C) \times N_{\text{hist}} \times d_{\text{model}}}

   $$

   这保证了任意位置 $i$ 的隐状态 $\mathbf{h}_i^{\text{hist}}$ 完全不受未来位置 $j > i$ 的影响（经数值验证，对后半段历史输入施加任意扰动，前半段 $\mathbf{h}_i^{\text{hist}}$ 的最大绝对误差严格等于 `0.0`）。
2. **历史因果先验序列生成 (`prior_base`)**：
   提取代表完整历史窗口因果总结的末尾隐状态 $\mathbf{h}_{N_{\text{hist}}-1}^{\text{hist}} \in \mathbb{R}^{(B \cdot C) \times d_{\text{model}}}$，通过两层带 GELU 激活的先验 MLP 直接生成未来预测窗口的粗粒度先验序列：

   $$
   \mathbf{y}_{\text{prior\_flat}} = \text{PriorMLP}\left(\text{LayerNorm}(\mathbf{h}_{N_{\text{hist}}-1}^{\text{hist}})\right) \in \mathbb{R}^{(B \cdot C) \times H}

   $$

   将其按未来 Patch 长度 $P$ 切分为 $N_{\text{fut}} = \lceil H / P \rceil$ 个非重叠未来先验 Patch $\mathbf{P}_{\text{prior}} \in \mathbb{R}^{(B \cdot C) \times N_{\text{fut}} \times P}$（尾部不足 $P$ 处补零并由二值有效掩码 $\mathbf{M}_{\text{valid}} \in \{0, 1\}^{(B \cdot C) \times N_{\text{fut}} \times P}$ 精确屏蔽）。

---

### 4.4 常数负曲率庞加莱球双曲流形 (`PoincareBallManifold`)

代码位置：`src/layers/M2Patch_layers.py:104-168, 209-214, 733-756, 786-808`

为避免混合精度（AMP FP16）下反双曲函数在球边界附近发生数值上溢，`PoincareBallManifold` 内部强制转换至 **FP32** 执行全部黎曼几何运算。设曲率标量参数为 $c > 0$（流形截面曲率为 $-c$，默认 $c = 1.0$），开球半径为 $1/\sqrt{c}$：

1. **流形安全边界投影（`project`）**：
   设定安全范数上界 $r_{\max} = \frac{1 - \epsilon}{\sqrt{c}}$（$\epsilon = 10^{-5}$）：

   $$
   \Pi_{\mathbb{B}_c}(\mathbf{z}) = \mathbf{z} \cdot \min\left(1,\, \frac{r_{\max}}{\max(\|\mathbf{z}\|_2, \epsilon)}\right)

   $$
2. **有界切向量原点指数映射（`_bounded_exp_map0` & `exp_map0`）**：
   将欧氏切空间 $\mathcal{T}_{\mathbf{0}}\mathbb{B}_c^{d_{\text{hyp}}} \cong \mathbb{R}^{d_{\text{hyp}}}$ 中的向量 $\mathbf{v}$ 先按最大切范数 $v_{\max} = 2.0$（`HYP_MAX_TANGENT`）进行方向保真缩放 $\tilde{\mathbf{v}} = \mathbf{v} \cdot \min(1, v_{\max} / \|\mathbf{v}\|_2)$，再通过原点指数映射投射至庞加莱球内：

   $$
   \exp_{\mathbf{0}}^c(\tilde{\mathbf{v}}) = \Pi_{\mathbb{B}_c}\!\left(\tanh\left(\sqrt{c}\|\tilde{\mathbf{v}}\|_2\right) \frac{\tilde{\mathbf{v}}}{\sqrt{c}\max(\|\tilde{\mathbf{v}}\|_2, \epsilon)}\right)

   $$
3. **原点对数映射（`log_map0`）**：

   $$
   \log_{\mathbf{0}}^c(\mathbf{z}) = \text{atanh}\!\left(\min(\sqrt{c}\|\mathbf{z}\|_2,\, 1 - \epsilon)\right) \frac{\mathbf{z}}{\sqrt{c}\max(\|\mathbf{z}\|_2, \epsilon)}

   $$
4. **莫比乌斯加法（`mobius_add`）与基点对数映射（`log_map`）**：
   对于流形上任意两点 $\mathbf{x}, \mathbf{y} \in \mathbb{B}_c^{d_{\text{hyp}}}$，其非交换莫比乌斯加法定义为：

   $$
   \mathbf{x} \oplus_c \mathbf{y} = \Pi_{\mathbb{B}_c}\!\left(\frac{\left(1 + 2c\langle \mathbf{x}, \mathbf{y}\rangle + c\|\mathbf{y}\|_2^2\right)\mathbf{x} + \left(1 - c\|\mathbf{x}\|_2^2\right)\mathbf{y}}{1 + 2c\langle \mathbf{x}, \mathbf{y}\rangle + c^2\|\mathbf{x}\|_2^2\|\mathbf{y}\|_2^2}\right)

   $$

   以 $\mathbf{x}$ 为基点将 $\mathbf{y}$ 映射到切空间 $\mathcal{T}_{\mathbf{x}}\mathbb{B}_c^{d_{\text{hyp}}}$ 的对数映射为：

   $$
   \log_{\mathbf{x}}^c(\mathbf{y}) = \log_{\mathbf{0}}^c\left((-\mathbf{x}) \oplus_c \mathbf{y}\right)

   $$
5. **闭式双曲测地线距离（`geodesic_dist`）**：

   $$
   d_{\mathbb{B}}^c(\mathbf{x}, \mathbf{y}) = \frac{1}{\sqrt{c}}\,\text{acosh}\!\left(\max\left(1 + 10^{-7},\, 1 + \frac{2c\|\mathbf{x} - \mathbf{y}\|_2^2}{(1 - c\|\mathbf{x}\|_2^2)(1 - c\|\mathbf{y}\|_2^2)}\right)\right)

   $$
6. **历史流形轨迹、双曲条件注入与正交 DCT 目标流形锚点**：

   - **历史双曲轨迹**：$\mathbf{Z}^{\text{hist}} = \exp_{\mathbf{0}}^c\left(\frac{1}{\sqrt{d_{\text{hyp}}}}\mathbf{W}_{\text{hist\_hyp}}\mathbf{H}^{\text{hist}}\right) \in \mathbb{B}_c^{(B \cdot C) \times N_{\text{hist}} \times d_{\text{hyp}}}$。
   - **双曲条件向量（`hyp_cond`）**：对历史流形轨迹取均值后经原点对数映射与零初始化线性层 $\mathbf{W}_{\text{hyp\_cond}} \in \mathbb{R}^{d_{\text{hyp}} \times d_{\text{model}}}$ 投影为去噪条件：
     $$
     \mathbf{c}_{\text{hyp}} = \mathbf{W}_{\text{hyp\_cond}}\!\left(\log_{\mathbf{0}}^c\left(\frac{1}{N_{\text{hist}}}\sum_{i=1}^{N_{\text{hist}}} \mathbf{Z}_{:, i, :}^{\text{hist}}\right)\right) \in \mathbb{R}^{(B \cdot C) \times d_{\text{model}}}

     $$
   - **冻结正交余弦基（DCT）目标流形锚点（`_project_target_hyp`）**：为防止目标流形分支发生表征坍缩（Representation Collapse），模型在初始化时构造一组经 QR 分解严格正交化的离散余弦变换（DCT）基矩阵 $\mathbf{Q}_{\text{DCT}} \in \mathbb{R}^{d_{\text{hyp}} \times P}$ 并冻结权重（`requires_grad=False`）。训练时，真实未来归一化 Patch $\mathbf{P}_0$ 通过该正交频谱基与双曲指数映射无梯度地投射为稳定的目标流形基准点 $\mathbf{Z}_{\text{target}}^{\text{fut}} \in \mathbb{B}_c^{(B \cdot C) \times N_{\text{fut}} \times d_{\text{hyp}}}$。

---

### 4.5 先验桥接 VP-SDE 与 AdaLN-Zero 条件去噪器 (`BridgeVPSDE` & `HyperbolicConditionedPatchDenoiser`)

代码位置：`src/layers/M2Patch_layers.py:369-532, 818-898`

1. **先验桥接连续时间 VP-SDE (`BridgeVPSDE`)**：
   对于连续扩散时间步 $t \in [t_{\min}, 1.0]$（$t_{\min} = 10^{-3}$），支持余弦调度（`cosine`，偏移 $s=0.008$）与线性调度（`linear`，$\beta_{\min}=0.1, \beta_{\max}=20.0$）：

   $$
   \alpha_t = \frac{\cos\left(\frac{t + s}{1 + s}\cdot \frac{\pi}{2}\right)}{\cos\left(\frac{s}{1 + s}\cdot \frac{\pi}{2}\right)}, \quad \sigma_t = \sqrt{1 - \alpha_t^2}

   $$

   在训练阶段，围绕停止梯度后的历史先验锚点 $\bar{\mathbf{P}}_{\text{prior}} = \text{sg}(\mathbf{P}_{\text{prior}}) \odot \mathbf{M}_{\text{valid}}$ 对真实未来 Patch $\mathbf{P}_0$ 进行前向桥接加噪：

   $$
   \mathbf{P}_t = \left(\alpha_t \mathbf{P}_0 + (1 - \alpha_t)\bar{\mathbf{P}}_{\text{prior}} + \sigma_t \boldsymbol{\epsilon}\right) \odot \mathbf{M}_{\text{valid}}, \quad \boldsymbol{\epsilon} \sim \mathcal{N}(\mathbf{0}, \mathbf{I})

   $$
2. **AdaLN-Zero 条件扩散去噪主干 (`HyperbolicConditionedPatchDenoiser`)**：

   - **输入嵌入与合成条件**：加噪未来 Patch $\mathbf{P}_t$ 通过专属线性层 $\mathbf{W}_{\text{fut}} \in \mathbb{R}^{P \times d_{\text{model}}}$ 与位置编码映射为 $\mathbf{X}^{(0)}$；时间步 $t$ 经正弦频率编码与两层 SiLU MLP 映射后，与历史全局上下文 $\mathbf{c}_{\text{hist}}$ 及双曲几何条件 $\mathbf{c}_{\text{hyp}}$ 相加形成合成条件向量：
     $$
     \mathbf{c}_{\text{total}} = \text{MLP}_t(\text{SinEmb}(t)) + \mathbf{W}_{\text{ctx}}\mathbf{c}_{\text{hist}} + \mathbf{c}_{\text{hyp}} \in \mathbb{R}^{(B \cdot C) \times d_{\text{model}}}

     $$
   - **AdaLN-Zero 调制交互块（`FutureDenoiserBlock` × `d_layers_diff`）**：
     每一层通过零初始化线性层 $\text{AdaLNZero}(\mathbf{c}_{\text{total}})$ 生成 9 组调制向量 $(\boldsymbol{\beta}_k, \boldsymbol{\gamma}_k, \boldsymbol{\alpha}_k)_{k=1}^3$，依次调制 **(1) 未来 Patch 间双向多头自注意力**、**(2) 未来 Patch 对因果历史隐状态 $\mathbf{H}^{\text{hist}}$ 的多头交叉注意力**、以及 **(3) 逐位置前馈网络（FFN）**：
     $$
     \tilde{\mathbf{h}}_k = \text{LayerNorm}_k(\mathbf{X}) \odot (1 + \boldsymbol{\gamma}_k) + \boldsymbol{\beta}_k, \quad \mathbf{X} \leftarrow \mathbf{X} + \boldsymbol{\alpha}_k \odot \text{SubLayer}_k(\tilde{\mathbf{h}}_k)

     $$
   - **三分支解码输出**：
     设末层归一化输出为 $\mathbf{H}_{\text{out}} = \text{LayerNorm}(\mathbf{X}^{(L_{\text{diff}})})$：
     1. **先验锚定残差 $x_0$ 预测头**：$\hat{\mathbf{P}}_0 = \mathbf{P}_{\text{prior}} + \mathbf{W}_{x_0}\mathbf{H}_{\text{out}}$；
     2. **桥接噪声预测头**：$\hat{\boldsymbol{\epsilon}} = \mathbf{W}_{\epsilon}\mathbf{H}_{\text{out}}$（零初始化）；
     3. **未来双曲流形预测头**：$\hat{\mathbf{Z}}^{\text{fut}} = \exp_{\mathbf{0}}^c\left(\frac{1}{\sqrt{d_{\text{hyp}}}}\mathbf{W}_{\text{fut\_hyp}}\mathbf{H}_{\text{out}}\right) \in \mathbb{B}_c^{(B \cdot C) \times N_{\text{fut}} \times d_{\text{hyp}}}$。
3. **确定性 Bridge-DDIM 逆向去噪采样 (`_sample_prior_bridge` & `bridge_ddim_step`)**：
   在验证与测试阶段，无需任何真实未来目标，直接以历史先验作为 $t_0 = 1.0$ 处的确定性初始状态 $\mathbf{P}_{t_0} = \mathbf{P}_{\text{prior}} \odot \mathbf{M}_{\text{valid}}$，沿均匀时间网格 $t_s = 1 - \frac{s}{K} \to t_{s+1} = 1 - \frac{s+1}{K}$（$s = 0, \dots, K-1$，$K = \text{diff\_steps}$）执行 Bridge-DDIM 转移：

   $$
   \mathbf{P}_{t_{s+1}} = \alpha_{t_{s+1}} \hat{\mathbf{P}}_0(\mathbf{P}_{t_s}, t_s) + (1 - \alpha_{t_{s+1}})\mathbf{P}_{\text{prior}} + \sigma_{t_{s+1}}\hat{\boldsymbol{\epsilon}}(\mathbf{P}_{t_s}, t_s)

   $$

   当默认 $K = 1$（且 $\eta = 0.0$）时，$t_0 = 1.0 \to t_1 = 0.0$（$\alpha_0 = 1, \sigma_0 = 0$），模型通过单次去噪器前向计算即可直接输出精炼后的干净未来 Patch $\hat{\mathbf{P}}_0$，兼具扩散去噪表征优势与单步前馈模型的推理速度。

---

### 4.6 样本级尺度不变的三位一体损失函数 (`compute_m2patch_diffusion_loss`)

代码位置：`src/layers/M2Patch_layers.py:551-661`

设 Huber 核函数为 $h_\delta(u) = \frac{1}{2}u^2 \mathbb{I}(|u| \le \delta) + \delta(|u| - \frac{1}{2}\delta)\mathbb{I}(|u| > \delta)$（$\delta = 1.0$）。M2Patch 的总训练目标由四项有机耦合的损失组成：

$$
\mathcal{L}_{\text{total}} = \underbrace{\left(\mathcal{L}_{x_0} + \mathcal{L}_{\text{noise}}\right)}_{\mathcal{L}_{\text{bridge}}} + \lambda_{\text{raw}}\mathcal{L}_{\text{raw}} + \lambda_{\text{hyp}}\underbrace{\left(\mathcal{L}_{\text{geo}} + \mathcal{L}_{\text{trans}}\right)}_{\mathcal{L}_{\text{hyp}}} + \lambda_{\text{prior}}\mathcal{L}_{\text{prior}}

$$

1. **SNR 加权先验桥接去噪损失（$\mathcal{L}_{\text{bridge}} = \mathcal{L}_{x_0} + \mathcal{L}_{\text{noise}}$）**：
   定义信噪比权重 $w_i = \frac{\text{SNR}(t_i)}{1 + \text{SNR}(t_i)} = \alpha_{t_i}^2$，并对每个样本 $i$ 按其目标能量进行尺度归一化：

   $$
   \mathcal{L}_{x_0} = \frac{1}{B \cdot C}\sum_{i=1}^{B \cdot C} w_i \cdot \frac{\frac{1}{V_i}\sum_{m, p} M_{i,m,p}\, h_1\!\left(\hat{P}_{0, i,m,p} - P_{0, i,m,p}\right)}{\frac{1}{V_i}\sum_{m, p} M_{i,m,p}\, P_{0, i,m,p}^2 + 1}

   $$

   $$
   \mathcal{L}_{\text{noise}} = \frac{1}{B \cdot C}\sum_{i=1}^{B \cdot C} \frac{\frac{1}{V_i}\sum_{m, p} M_{i,m,p}\, h_1\!\left(\hat{\epsilon}_{i,m,p} - \epsilon_{i,m,p}\right)}{\frac{1}{V_i}\sum_{m, p} M_{i,m,p}\, \epsilon_{i,m,p}^2 + 1}

   $$

   其中 $V_i = \sum_{m, p} M_{i,m,p}$ 为样本 $i$ 的有效未来时间点数。
2. **原始物理空间尺度不变重构损失（$\mathcal{L}_{\text{raw}}$，$\lambda_{\text{raw}} = 1.0$）**：
   在经 `RevIN.denormalize` 还原后的原始物理空间上，对预测序列 $\hat{\mathbf{Y}}$ 与真实序列 $\mathbf{Y}_{\text{true}}$ 计算样本级能量归一化 Huber 损失：

   $$
   \mathcal{L}_{\text{raw}} = \frac{1}{B}\sum_{b=1}^B \frac{\frac{1}{H \cdot C}\sum_{t, c} h_1\!\left(\hat{Y}_{b, t, c} - Y_{\text{true}, b, t, c}\right)}{\frac{1}{H \cdot C}\sum_{t, c} Y_{\text{true}, b, t, c}^2 + 1}

   $$
3. **庞加莱球双曲测地线对齐与跨界切空间平移损失（$\mathcal{L}_{\text{hyp}} = \mathcal{L}_{\text{geo}} + \mathcal{L}_{\text{trans}}$）**：

   - **有界双曲测地线距离损失（$\mathcal{L}_{\text{geo}}$）**：度量去噪未来流形点 $\hat{\mathbf{Z}}^{\text{fut}}$ 与正交 DCT 目标流形点 $\mathbf{Z}_{\text{target}}^{\text{fut}}$ 之间的黎曼测地线距离，并采用有理函数 $g(d) = \frac{d^2}{1 + d^2} \in [0, 1)$ 进行平滑饱和约束：
     $$
     \mathcal{L}_{\text{geo}} = \frac{1}{\sum_{i, m} M_{i, m}^{\text{patch}}} \sum_{i, m} M_{i, m}^{\text{patch}} \frac{d_{\mathbb{B}}^c\!\left(\hat{\mathbf{Z}}_{i, m}^{\text{fut}},\, \mathbf{Z}_{\text{target}, i, m}^{\text{fut}}\right)^2}{1 + d_{\mathbb{B}}^c\!\left(\hat{\mathbf{Z}}_{i, m}^{\text{fut}},\, \mathbf{Z}_{\text{target}, i, m}^{\text{fut}}\right)^2}

     $$
   - **历史-未来交界处切空间跃迁一致性损失（$\mathcal{L}_{\text{trans}}$）**：以最后一个历史 Patch 的双曲流形点 $\mathbf{z}_{\text{last}}^{\text{hist}} = \mathbf{Z}_{:, -1, :}^{\text{hist}}$ 为局部参考基点，利用基点对数映射 $\log_{\mathbf{z}_{\text{last}}^{\text{hist}}}^c(\cdot)$ 提取从历史末尾跨越到首个未来 Patch 的切空间速度向量，约束预测跃迁方向与真实跃迁方向一致：
     $$
     \Delta_{\text{trans}} = \left\|\log_{\mathbf{z}_{\text{last}}^{\text{hist}}}^c\!\left(\hat{\mathbf{Z}}_{:, 0, :}^{\text{fut}}\right) - \log_{\mathbf{z}_{\text{last}}^{\text{hist}}}^c\!\left(\mathbf{Z}_{\text{target}, :, 0, :}^{\text{fut}}\right)\right\|_2^2, \quad \mathcal{L}_{\text{trans}} = \text{Mean}\!\left(\frac{\Delta_{\text{trans}}}{1 + \Delta_{\text{trans}}}\right)

     $$
4. **历史因果先验锚点监督损失（$\mathcal{L}_{\text{prior}}$）**：
   直接监督历史先验序列 $\mathbf{Y}_{\text{prior}}$ 逼近归一化未来目标 $\tilde{\mathbf{Y}}$，保证先验桥接终点紧贴真实未来趋势：

   $$
   \mathcal{L}_{\text{prior}} = \frac{1}{B}\sum_{b=1}^B \frac{\frac{1}{H \cdot C}\sum_{t, c} h_1\!\left(Y_{\text{prior}, b, t, c} - \tilde{Y}_{b, t, c}\right)}{\frac{1}{H \cdot C}\sum_{t, c} \tilde{Y}_{b, t, c}^2 + 1}

   $$

---

## 5. 工程实现与消融架构 (Engineering & Ablation Architecture)

1. **集中式配置与单变量（OFAT）消融架构 (`src/configs/m2patch_profiles.py`, `src/ablation/registry.py`)**：
   - 全库 14 个基准数据集的元数据与各预测步长超参数统一收口于 `src/configs/m2patch_profiles.py`（通过 `python -m src.configs.m2patch_cli` 发射 CLI 参数）；默认采用 `Adam` 优化器（`weight_decay=0`）与 `OneCycleLR` 调度器（`pct_start=0.2`）。
   - OFAT 目标网格为 6 个数据集（ETTh2、ETTm1、Exchange、Weather、ECL、Illness），每个数据集 4 个预测步长。`none` 基线与全部变体均由 `--from-optuna` 启动，即基线采用各单元格的 Optuna 最优配置；`is_noop_ablation` 会跳过与 Optuna 基线完全重合的单元格。当前 ETTh2、ETTm1、Exchange 已完成 8 变体 × 4 步长的实测，Weather、ECL、Illness 的基线格已由 Optuna 导出填充，变体格标记为 `PENDING`。
   - 在 `src/ablation/registry.py` 中内置了 8 组严格遵循单变量控制（One-Factor-At-a-Time, OFAT）的消融/替换实验组，全面覆盖模型的每一个核心设计环节：


| 消融组标识 (`--ablation`) | 论文展示名称                    | 针对的核心机制                                | 单变量替换/消融行为                                                                                                                |
| :-------------------------- | :-------------------------------- | :---------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------- |
| `none`                    | `Full M2Patch`                  | 完整交付模型                                  | 全部核心组件开启                                                                                                                   |
| `euclid_manifold`         | `w/ Euclidean Manifold`         | 庞加莱球双曲流形 $\mathbb{B}_c^d$             | 将 `PoincareBallManifold` 替换为同维度平坦 `EuclideanManifold`（`use_hyp_manifold=0`）                                             |
| `no_hyp_cond`             | `w/o Hyperbolic Conditioning`   | 双曲历史均值条件注入                          | 仅切断 `hyp_cond_proj` 向去噪器的条件注入（`use_hyp_cond=0`），保留双曲流形与 $\mathcal{L}_{\text{hyp}}$                           |
| `zero_prior_bridge`       | `w/ Zero-Mean Prior Bridge`     | 历史因果先验桥接终点                          | 将 VP-SDE 桥接终点与逆向起点从 $\mathbf{P}_{\text{prior}}$ 替换为零均值先验 $\mathbf{0}$（`use_prior_bridge=0`）                   |
| `no_adaln`                | `w/o AdaLN-Zero Modulation`     | 去噪器 AdaLN-Zero 调制                        | 关闭 `FutureDenoiserBlock` 的 `AdaLNZero` 仿射门控调制，退化为标准 Pre-LN（`use_adaln=0`）                                         |
| `no_denoise_refinement`   | `w/o Diffusion Denoiser`        | 条件扩散去噪精炼主干                          | 旁路 `HyperbolicConditionedPatchDenoiser`，直接输出历史因果先验 $\hat{\mathbf{Y}} = \mathbf{Y}_{\text{prior}}$（`use_denoiser=0`） |
| `no_causal_prefix_norm`   | `w/o Causal Prefix Norm`        | 分块器内逐前缀因果归一化                      | 关闭 `CausalPatchTokenizer` 内的逐前缀贝叶斯收缩归一化（`use_causal_norm=0`），仅保留外层 `RevIN`                                  |
| `no_hyp_loss`             | `w/o Hyperbolic Alignment Loss` | 双曲几何对齐损失 $\mathcal{L}_{\text{hyp}}$   | 仅将 `--lambda_hyp` 置为 `0.0`                                                                                                     |
| `no_prior_loss`           | `w/o Prior Anchor Loss`         | 先验锚点监督损失 $\mathcal{L}_{\text{prior}}$ | 仅将 `--lambda_prior` 置为 `0.0`                                                                                                   |

---

## 6. 模型核心超参数一览表 (Hyperparameter Specification)

定义于 `src/configs/custom_M2Patch.py` 与 `src/configs/m2patch_profiles.py:CONSTANTS`：


| 参数名称          |    默认值    | 所属模块         | 作用与物理含义                                                                     |
| :------------------ | :------------: | :----------------- | :----------------------------------------------------------------------------------- |
| `--patch_len`     |     `16`     | 因果分块器       | 单尺度历史与未来 Patch 的时间窗口长度 $P$                                          |
| `--stride`        |     `8`     | 因果分块器       | 历史因果 Patch 的滑动步长 $S$（仅左端复制填充）                                    |
| `--d_hyp`         |     `64`     | 双曲流形层       | 庞加莱球双曲流形 $\mathbb{B}_c^{d_{\text{hyp}}}$ 的嵌入维度                        |
| `--manifold_c`    |    `1.0`    | 双曲流形层       | 庞加莱球常数负曲率绝对值 $c > 0$（曲率为 $-c$，球半径 $1/\sqrt{c}$）               |
| `--d_layers_diff` |     `2`     | 条件去噪器       | `HyperbolicConditionedPatchDenoiser` 中 `FutureDenoiserBlock` 的堆叠层数           |
| `--diff_steps`    |     `1`     | 先验桥接扩散     | 推理阶段确定性 Bridge-DDIM 的逆向去噪步数 $K \ge 1$                                |
| `--diff_schedule` |  `"cosine"`  | 先验桥接扩散     | 连续时间 VP-SDE 噪声调度策略（`"cosine"` 或 `"linear"`）                           |
| `--diff_eta`      |    `0.0`    | 先验桥接扩散     | Bridge-DDIM 采样随机性系数（`0.0` 为纯确定性推理）                                 |
| `--lambda_hyp`    |    `0.1`    | 三位一体损失     | 庞加莱球双曲测地线对齐与跨界切空间平移损失权重 $\lambda_{\text{hyp}}$              |
| `--lambda_prior`  |    `0.1`    | 三位一体损失     | 历史因果先验锚点监督损失权重 $\lambda_{\text{prior}}$                              |
| `--revin`         |     `1`     | 归一化层         | 是否启用历史统计量锁定的稳健 `RevIN` 归一化（`1`=开启，`0`=关闭）                  |
| `--optim`         |   `"Adam"`   | 优化器与调度     | 默认优化器（配合默认 `weight_decay=0.0`）                                          |
| `--lradj`         | `"onecycle"` | 优化器与调度     | 学习率调度策略（默认 `OneCycleLR`，配合 `--pct_start 0.2`）                        |
| `--ablation`      |   `"none"`   | 消融与机制注册表 | 单变量消融或机制探索变体选择开关（由 `src/ablation/registry.py` 解析）             |

---

## 7. 评测协议与实测产物 (Evaluation Protocol & Measured Artifacts)

### 7.1 基线家族与统一效率口径

效率实验与主表对照使用以下 11 个基线，覆盖五类建模范式：

| 家族 | 模型 | 核心机制 | 本仓库接入方式 |
| --- | --- | --- | --- |
| 扩散 / 生成式 | MMPD (ICLR 2026) | Patch 一致扩散损失、patch-consistent MLP 去噪器、多模态 GMM 推断 | `src/model/MMPD.py`；效率与主表使用确定性锚点预测（`mmpd_sample_expectation=0`） |
| 几何 / 信号分解 | SimpleTM (ICLR 2025) | 平稳小波变换与几何注意力，伪时间 Token 加线性投影 | `src/model/SimpleTM.py`；`AdamW` + `type1` 调度 |
| Mamba / 状态空间 | S-Mamba | 选择性状态空间扫描，线性复杂度长序列建模 | `src/model/S_Mamba.py` |
| 倒置 / 分块 Transformer | iTransformer、PatchTST、Transformer、Informer、Autoformer、Flowformer | 变量 Token、Patch Token 加通道独立、经典/稀疏/自相关/流注意力 | `src/model/*.py` |
| 多尺度 MLP / 分解 | TimeMixer、DLinear | 多尺度可分解混合；趋势-季节分解加线性映射 | `src/model/*.py` |

统一效率协议：M2Patch 与全部基线均为 10 epochs、`batch_size=16`、FP32（`use_amp=0`）、seed 2023，在单张 RTX 4090 D 上顺序测量。`scripts/run.py` 在模型构建后打印 `model_params`，在 `test()` 结束时打印纯前向推理时延（CUDA 同步，前 5 个测试批作为预热剔除）；两项分别写入结果文件的 `params` 与 `inference_time_ms_per_iter`。三个设置为 ETTm1 $H=96$、Weather $H=96$、ECL $H=336$。

| 设置 | M2Patch MSE / MAE | Params | 推理 ms/batch | 训练 ms/iter | 显存 MB | MSE 排名 | 最优基线（MSE 差距） |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ETTm1 $H=96$ | 0.3289 / 0.3566 | 2,655,872 | 4.076 | 19.46 | 124.8 | 3/12 | MMPD 0.3171（+3.73%） |
| Weather $H=96$ | 0.1737 / 0.2128 | 5,259,648 | 4.439 | 20.94 | 422.7 | 4/12 | TimeMixer 0.1626（+6.81%） |
| ECL $H=336$ | 0.2061 / 0.2883 | 1,273,984 | 15.933 | 68.06 | 3129.5 | 6/12 | S-Mamba 0.1782（+15.64%） |

M2Patch 的平均 MSE 排名为 4.33/12，平均 MAE 排名为 3.33/12。参数规模在三个设置中分别为 2.66 M、5.26 M、1.27 M；ECL 的 1.27 M 为 12 个模型中第三小，推理时延 15.93 ms/batch 高于 S-Mamba 的 2.51 ms 与 iTransformer 的 2.72 ms。

### 7.2 OFAT 消融实测（ETTh2 / ETTm1 / Exchange）

8 个单变量变体在 3 个数据集 × 4 个步长上的跨步长均值如下（基线 `none` 使用对应单元格的 Optuna 配置）：

表内 ΔMSE 的聚合口径：对每个变体，取 3 个数据集 × 4 个步长共 12 个单元格的 MSE 之和，除以 `none` 同 12 格的 MSE 之和后减 1；分数据集列为该数据集 4 个步长的 MSE 之和相对 `none` 同 4 格的变化。该口径先汇总 MSE 再取相对差；12 格聚合列与三个分数据集列都不是逐格 ΔMSE 的算术平均。

| 变体 | ETTh2 MSE | ΔMSE | ETTm1 MSE | ΔMSE | Exchange MSE | ΔMSE | 12 格聚合 ΔMSE |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Full M2Patch (`none`) | 0.4028 | — | 0.3862 | — | 0.3838 | — | — |
| w/ Euclidean Manifold | 0.3963 | -1.62% | 0.3879 | +0.46% | 0.3862 | +0.62% | -0.20% |
| w/o Hyperbolic Conditioning | 0.3848 | -4.46% | 0.3868 | +0.16% | 0.3720 | -3.10% | -2.49% |
| w/ Zero-Mean Prior Bridge | 0.4078 | +1.23% | 0.3887 | +0.65% | 0.3811 | -0.71% | +0.40% |
| w/o AdaLN-Zero Modulation | 0.3859 | -4.19% | 0.3984 | +3.17% | 0.3864 | +0.66% | -0.18% |
| w/o Diffusion Denoiser | 0.3770 | -6.40% | 0.3875 | +0.33% | 0.3411 | -11.14% | -5.74% |
| w/o Causal Prefix Norm | 0.4096 | +1.68% | 0.4239 | +9.78% | 0.3487 | -9.16% | +0.80% |
| w/o Hyperbolic Alignment Loss | 0.3833 | -4.83% | 0.3963 | +2.64% | 0.3937 | +2.58% | +0.05% |
| w/o Prior Anchor Loss | 0.3892 | -3.38% | 0.3830 | -0.81% | 0.4002 | +4.26% | -0.03% |

可复核的结论：

- 零均值先验桥接的 12 格聚合 MSE 上升 0.40%，其中 ETTh2 与 ETTm1 分别上升 1.23% 与 0.65%，Exchange 下降 0.71%；平均方向为劣化，单格方向不一致。
- 先验锚点损失的作用依赖数据集：ETTm1 上去掉后 MSE 降低 0.81%，Exchange 上升 4.26%，ETTh2 下降 3.38%；12 格聚合值 -0.03%，方向不一致。
- 因果前缀归一化在 ETTm1 上升 9.78%，在 ETTh2 上升 1.68%，在 Exchange 下降 9.16%；12 格聚合值 +0.80%，跨数据集方向不一致。
- 双曲流形、双曲条件注入、AdaLN-Zero、去噪器与双曲对齐损失的 12 格聚合值落在 -5.74% 到 +0.05% 之间，部分单元格去掉组件后 MSE 反而下降。OFAT 结果显示历史先验桥接与因果前缀归一化的作用随数据集变化，双曲组件在三数据集上没有统一的 MSE 增益。

### 7.3 跨数据集非参数统计检验

`scripts/statistics/nonparametric_tests.py` 以 `(dataset, pred_len)` 为一个问题实例，在 3 个数据集 × 4 个步长共 12 个完整区块上对 8 个模型排名（rank 1 为最低误差），计算 tie-corrected Friedman $\chi_F^2$、Iman-Davenport $F_F$、Nemenyi 临界差、Wilcoxon 符号秩检验（Holm-Bonferroni 校正 7 个基线）与 matched-pairs rank-biserial 效应量 $r=(W_+-W_-)/(W_++W_-)$。

| 指标 | $\chi_F^2$ | $F_F$ | $df_1$ / $df_2$ | $p_F$ | M2Patch 平均秩 | Nemenyi CD |
| --- | --- | --- | --- | --- | --- | --- |
| MSE | 33.4722 | 7.28697 | 7 / 77 | $1.08\times10^{-6}$ | 4.333（5/8） | 3.0309 |
| MAE | 40.1389 | 10.0665 | 7 / 77 | $7.14\times10^{-9}$ | 4.333（5/8） | 3.0309 |

MSE 上 M2Patch 对 PatchTST 的原始 $p=0.0210$，Holm 校正后 $p=0.1470$，$r=-0.7436$（3 胜 0 平 9 负）；对 TimesNet 的原始 $p=0.0640$，Holm $p=0.3838$，$r=+0.6154$（10 胜 0 平 2 负）。MAE 上对 TimesNet 的原始 $p=0.00928$，Holm $p=0.0649$，$r=+0.8205$（10 胜 0 平 2 负）。7 个基线在 $\alpha=0.05$ 下均未通过 Holm 校正；检验结论为 8 个模型整体存在差异，没有单对显著性。

### 7.4 机制分析与定性案例

机制套件在 ETTh2、ETTm1、Exchange 的 $H=96$ 上运行 5 个变体，配置来自 `load_optuna_best_params`，并统一为 `Adam` / `onecycle` / `pct_start=0.2`。三个数据集的满模型 MSE 分别为 0.3019、0.3142、0.0966；去掉先验桥接后上升 4.76%、10.90%、2.08%，去掉先验锚点损失后上升 2.03%、12.94%、6.05%。双曲条件注入的移除在三个数据集上分别降低 MSE 2.13%、0.14%、12.00%，欧氏流形替换为 -1.24%、+0.41%、-14.21%。先验到去噪未来的平均测地距离为 0.997→0.965（ETTh2，-3.21%）、0.402→0.396（ETTm1，-1.60%）、0.592→0.592（Exchange，-0.03%）。去噪校正量 $\mathrm{RMSE}_\Delta$ 为 0.166、0.169、0.338，相对先验误差 1.482、1.427、2.674 的占比为 11.2%、11.9%、12.6%。$K$ 扫描显示，超过部署步数后残差负担上升：ETTh2 从 $K=1$ 的 1.495 升至 $K=4$ 的 1.608，ETTm1 从 1.417 升至 1.481，Exchange 从部署 $K=2$ 的 2.665 升至 $K=4$ 的 2.684。

案例研究覆盖 ETTm2、ETTm1、ECL、Exchange 四个数据集与 M2Patch、MMPD、S-Mamba、iTransformer、PatchTST 五个模型（96→96，原始量纲）。展示窗口按统一规则确定性选取：ETTm2 窗口 872（OT）、ETTm1 窗口 1192（HUFL）、ECL 窗口 676（OT）、Exchange 窗口 168（OT）。展示通道 MSE 上 M2Patch 相对该窗口最优基线分别为 -67.3%、-34.6%、-2.3%、-19.7%；全通道 MSE 分别为 -35.5%、-25.8%、-1.4%、-9.4%。整段测试集 MSE 上，M2Patch 在 ETTm2 取得五模型最优（比 S-Mamba 低 2.95%），ETTm1 比 MMPD 高 3.31%，ECL 比 iTransformer 高 8.09%，Exchange 比 PatchTST 高 16.25%。

### 7.5 图件规范

全部分析图以 600 dpi `.png` 输出：`output/efficiency/exp_2_efficiency.png`、`output/lookback/exp_4_lookback.png`、`output/robustness/exp_3_robustness*.png`、`output/case_study/figures/case_study_comparison_96.png`、`output/hyperparam/{4_sensitivity,4_sensitivity_lines,exp_6_sensitivity}.png`、`output/mechanism/figures/m2patch_mechanism_{Dataset}.png`、`m2patch_mechanism_analysis.png`、`m2patch_mechanism_cross_dataset.png` 与 `output/statistics/critical_difference.png`。配色统一取自 `scripts/color.py` 的 NPG 调色板。
