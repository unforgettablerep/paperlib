工作流（Run ID：`dwfrun-56b546e3-a3e0-47e9-a879-252771918b70`）已完成全部 6 个阶段及独立审计。首先请重点查阅主交付物 **M2Patch TOIS 工作流交付总结**（以及 **M2Patch ACM TOIS 实验补强与杂项重构看板**、**M2Patch 理论与时间序列 Pipeline 架构图**、**M2Patch OFAT 消融实验汇总表 (Optuna 基线)** 和 **跨数据集非参数统计显著性检验报告** 产物卡片）。由于完成通知中的 `findings` 与 `reports` 为节选预览，下面结合 `GetWorkflowRun` 与本地实测文件核查结果，按汇报规范呈现完整结论、逐项发现、验证状态与未覆盖边界。

---

### 1. 总结结论

已按照“先杂项 $\to$ 后基线接入与实验重构 $\to$ 再重跑出图 $\to$ 逐阶段门禁与独立审计 $\to$ 文档回写与分实验提交推送”的流程完成全部任务，并经由 `opencode-go-anthropic/deepseek-v4.1-flash` 审计员逐阶段核验后推送至远端：
1. **杂项与 600 DPI 升级**：彻底移除 `interPDN` 支持及相关脚本/记录，清除 `BiMamba4TS` 对比；将 `assets/plots/MatterGen_architecture.drawio` 重绘为聚焦理论与时间序列 Pipeline 的 `assets/plots/M2Patch_architecture.drawio`（不含命令或指标口径等工程细节）；修复 `output/hyperparam/sensitivity_plot.ipynb` 脏改动，全仓库 14 张导出 `.png` 实测均为 600 DPI（`599.9988 dpi`）。
2. **顶会新基线调研与接入**：拉取 `MMPD` (ICLR 2026) 与 `SimpleTM` (ICLR 2025) 至 `references/`，忠实移植并注册入 `src/model/` 框架，均以确定性测试与前向/梯度数值等价验证通过。
3. **Efficiency 同口径重跑**：将 M2Patch 与 11 个对比基线在 RTX 4090 D 上统一为 `10 epochs, batch_size=16, FP32 (use_amp=0), seed=2023`，补充 `params` 与测试推理延迟 `inference_time_ms_per_iter`，并重绘 600 DPI 气泡图 `output/efficiency/exp_2_efficiency.png`。
4. **TOIS OFAT 消融与非参数统计检验**：去除旧 `profile` 消融兼容，改为全量 `--from-optuna` 同源配置并针对 6 个特征数据集（`ETTh2, ETTm1, Exchange, Weather, ECL, Illness`）重构网格；本机完成 `ETTh2/ETTm1/Exchange` 全部 108 个单元（`none` + 8 OFAT 变体）并生成 `output/ablation/m2p-ablation.xlsx`；同步构建并在该 3 数据集 $\times$ 4 步长（$N=12$ 区块、$k=8$ 模型）上执行 Friedman / Iman-Davenport / Nemenyi CD / Holm-Bonferroni Wilcoxon 检验，其余数据集保留 `PENDING` 占位与 `--include-all` 一键扩展入口。
5. **TOIS 单栏机制图与 Case Study 优化**：对齐 Optuna 配置与 `Adam/OneCycleLR`，重设计为 `5.35 in × 4.60 in` 的 2×2 单栏一联组图并重跑 `ETTh2/ETTm1/Exchange`；Case Study 扩充 `Exchange` 与 `MMPD` 对照，优化为 5×4 TOIS 风格单栏对比网格（600 DPI）。
6. **文档回写与 Git 提交**：同步更新 `README.md`、`AGENTS.md`、`assets/{1_specification.md,2_experimental_report.md,tois_submission_gap_analysis.md}` 及图注，去除过度防御表述与“不是……而是……”句式；通过 30 项 HPO 回归测试，按实验拆分为 Conventional Commits 并已推送至远端（`git rev-list --count @{u}..HEAD == 0`）。

---

### 2. 分项发现、实证证据与核查方式

> 说明：阶段 1 与阶段 2 的详细核验结论由工作流 `findings` 返回；阶段 0、3、4、5 的改动与产物由工作流内对应确定性门禁、`opencode-go-anthropic/deepseek-v4.1-flash` 审计员以及本人在终局对 Git 提交记录、结果文件、600 DPI 图像和 HPO 测试集的复核共同证实。

1. **阶段 0：杂项清理、架构图重绘与 600 DPI 升级（确定性门禁 + 独立审计 + 本会话复核）**
   - **证据**：
     - 提交 `172ee19` 移除 `src/model/interPDN.py`、`src/configs/custom_interPDN.py`、`src/layers/{decomp,dema,ema,network,revin_interpdn}.py`、4 个 `interPDN`/`BiMamba4TS` 脚本，以及 `src/model/__init__.py`、`src/experiments/exp_basic.py`、`src/experiments/exp_long_term_forecasting.py`（移除 `_get_interpdn_ratio` 等 36 行）、`src/configs/{model_parser_dict.py,common.py}` 中的引用；提交 `9207791` 与 `ae9db4c` 清理剩余 `BiMamba4TS` 脚本与废弃的 `assets/idx2.xlsx`。
     - 提交 `faa099a` 写入 `assets/plots/M2Patch_architecture.drawio`（`250` 行 XML，包含板块一理论架构与板块二时序 Pipeline 及理论要点，不含任何 CLI 命令或工程口径）。
     - 实测全库 14 个 `output/**/*.png` 图像（含 `output/hyperparam/{4_sensitivity,4_sensitivity_lines,exp_6_sensitivity}.png`、`output/lookback/exp_4_lookback.png`、`output/robustness/{exp_3_robustness,exp_3_robustness_ETTm1}.png` 等）`PIL.Image.info["dpi"]` 均实测为 `(599.9988, 599.9988)`。

2. **阶段 1：2025/2026 顶会新基线调研与框架接入（`src/model/MMPD.py`, `src/model/SimpleTM.py` — 确定性门禁 + 独立审计实证通过，含 6 项非阻断备注）**
   - **证据**：
     - 拉取 `Thinklab-SJTU/MMPD` (ICLR 2026, commit `8e42bfe0c4156eea920c4dd86eee4f1b8658143e`) 至 `references/MMPD` 与 `vsingh-group/SimpleTM` (ICLR 2025, commit `3c77d820837b726afb03c943235ea95bc924243d`) 至 `references/SimpleTM`（提交 `12ac172`）。
     - 审计员同权重对照验证：`Patch_Consistent_MLP`、`GaussianDiffusion/SpacedDiffusion`、`training_losses`、`p_mean_variance`、`p_sample_loop`、两种 backbone 以及 `SimpleTM` 的 SWT 与几何注意力，前向输出、损失与采样结果 `max|Δ| = 0.0`；参数/缓冲区计数完全一致（`MMPD` 1,996,044 / 271,300；`SimpleTM` 12,856）。
     - 1-epoch 冒烟训练（`ETTh2 96->96`）：`SimpleTM` `mse=0.34980443120002747, mae=0.38631489872932434`；`MMPD` `mse=0.353646844625473, mae=0.38818076252937317`。
   - **审计员记录的非阻断遗留**：
     - `SimpleTM` 接入脚本默认使用 `lr=1e-4 / batch=32 / wv=db1 / type1`，与原仓 ETTh2-96 官方调优配置（实测 10-epoch MSE `0.2825` vs 15-epoch 脚本默认 `0.3135`）不同且 `src/utils/scheduler.py` 未实现 `TST` 调度；`pyproject.toml` 已加入 `PyWavelets`，但环境缺少 `poetry` 未重新锁定 `poetry.lock`；`src/model/MMPD.py:38-45` 使用 `strict=False` 加载；`src/layers/MMPD_layers.py:918` 仅支持整除 `pred_len`；`src/utils/result_io.py` 通用列未单列 `MMPD`/`SimpleTM` 特有超参名（缺省列按 `CONSTANTS` 占位）。

3. **阶段 2：Efficiency 实验同口径改造与重跑（`output/efficiency/exp_2_efficiency.png` — 确定性门禁 + 独立审计复核通过）**
   - **证据**：
     - 提交 `7a1607f` 在 `src/experiments/exp_long_term_forecasting.py:140-144,483-609` 增加全参数量统计与 CUDA 同步前向推理时延测量（剔除前 5 个预热 batch），更新 `scripts/efficiency/{efficiency_store.py,run_efficiency.py,legacy/run_efficiency_legacy.py}`。
     - `output/efficiency/results_by_dataset/{ETTm1,Weather,ECL}.jsonl` 各含 11 个有效对比基线（已剔除 `interPDN`、`BiMamba4TS`，纳入 `MMPD`、`SimpleTM`），共 33 条记录全部满足 `train_epochs=10`、`batch_size=16`、`use_amp=false`；M2Patch 新日志与 JSON（`M2Patch_ETTm1_pl96_20261119_225733.json`、`M2Patch_Weather_pl96_20261119_230514.json`、`M2Patch_ECL_pl336_20261119_231341.json`）实测：
       - `ETTm1 (pl=96)`: M2Patch MSE `0.3289`, Params `2.656M`, 推理 `4.076 ms`, 训练 `19.46 ms/iter`, 显存 `124.8 MB`（对比 MMPD MSE `0.3171`, SimpleTM `0.3475`）。
       - `Weather (pl=96)`: M2Patch MSE `0.1737`, Params `5.260M`, 推理 `4.439 ms`, 训练 `20.94 ms/iter`, 显存 `422.7 MB`（对比 TimeMixer MSE `0.1626`, S-Mamba `0.1662`）。
       - `ECL (pl=336)`: M2Patch MSE `0.2061`, Params `1.274M`, 推理 `15.933 ms`, 训练 `68.06 ms/iter`, 显存 `3129.5 MB`（对比 S-Mamba MSE `0.1782`, MMPD `0.2095`）。
     - 独立重渲染对比确认 `output/efficiency/exp_2_efficiency.png`（`5397×2239`, 600 DPI）无文字重叠、无裁剪、无引导线，散点与数据完全一致。

4. **阶段 3：TOIS OFAT 消融实验重构与跨数据集非参数统计检验（确定性门禁 + 独立审计 + 本会话复核）**
   - **证据**：
     - 提交 `98b0579`、`ed0196c`、`aa11125` 取消旧版 profile 兼容，使 `scripts/ablation/{ablation_common.sh,run_all_ablation.sh,run_baseline.sh}` 全面基于 `--from-optuna --with-meta` 启动，网格涵盖 6 个特征数据集（`ETTh2, ETTm1, Exchange, Weather, ECL, Illness`）；`src/ablation/registry.py` 默认 `is_noop_ablation(..., baseline="optuna")`。
     - 本机完成 `ETTh2`、`ETTm1`、`Exchange` 全部 4 步长 $\times$ (`none` + 8 OFAT 变体) = 108 个实测单元并写入 `output/ablation/{variant}.tsv` 与 `output/ablation/m2p-ablation.xlsx`（12 格聚合 $\Delta\text{MSE}$：`w/o Causal Prefix Norm` `+0.80%`、`w/ Zero-Mean Prior Bridge` `+0.40%`、`w/o Hyperbolic Alignment Loss` `+0.05%`、`w/o Prior Anchor Loss` `-0.03%`、`w/o AdaLN-Zero Modulation` `-0.18%`、`w/ Euclidean Manifold` `-0.20%`、`w/o Hyperbolic Conditioning` `-2.49%`、`w/o Diffusion Denoiser` `-5.74%`——各变体作用方向按数据集显著分化；`Weather/ECL/Illness` 在工作簿中保留 Optuna 基线并将变体列标为 `PENDING`）。
     - 提交 `f3897f2`、`c417492` 新增 `scripts/statistics/nonparametric_tests.py` 与 `output/benchmark/{ETTh2,ETTm1,Exchange}.tsv`，在 12 个实测区块 $\times$ 8 模型上计算得 Friedman 检验均拒绝原假设（MSE: $\chi_F^2 = 33.4722, F_F = 7.28697, df_1=7, df_2=77, p_F = 1.08\times 10^{-6}$；MAE: $\chi_F^2 = 40.1389, F_F = 10.0665, p_F = 7.14\times 10^{-9}$；Nemenyi $\text{CD}=3.0309$），Holm-Bonferroni 校正 Wilcoxon 成对检验尚无对达到 $\alpha=0.05$（最小 $p_{\text{Holm}}$ 为 MSE 对 PatchTST `0.147` 与 MAE 对 TimesNet `0.0649`）。产物含 `output/statistics/{benchmark_matrix.csv,stat_tests_results.csv,m2p_stat_tests.xlsx,stat_tests_summary.md,critical_difference.png}`（600 DPI）。

5. **阶段 4：TOIS 单栏机制实验重构与 Case Study 优化（确定性门禁 + 独立审计 + 本会话直观视觉查图复核）**
   - **证据**：
     - 提交 `bb45c7b` 将 `scripts/mechanism/mechanism_config.py` 对齐 Optuna 配置及 `Adam/OneCycleLR (pct_start=0.2)`，修复 `plot_m2patch_mechanism.py` 缺陷并基于 `ETTh2/ETTm1/Exchange`（`pl=96, 15 epochs`）实测出图。亲眼查看 `output/mechanism/figures/m2patch_mechanism_analysis.png`（`3210×2760`, 600 DPI, `5.35 in × 4.60 in` 单栏排版）：2×2 布局（`(a)` Poincaré 圆盘与测地流、`(b)` 先验骨架与去噪残差 $\Delta Y_{\text{diff}}$、`(c)` 训练四项损失对数收敛与 $K\in\{1,2,4\}$ 残差负担、`(d)` 5 变体干预 MSE/MAE 与对齐度）清晰无遮挡；同步生成 `m2patch_mechanism_{ETTm1,Exchange}.png` 及跨数据集汇总图 `m2patch_mechanism_cross_dataset.png`。
     - 提交 `c4601a8` 将 Case Study 全线对齐 `--from-optuna`，扩展至 4 数据集 $\times$ 5 模型（`ETTm2 OT`, `ETTm1 HUFL`, `ECL OT`, `Exchange OT`，对比 `MMPD, S-Mamba, iTransformer, PatchTST`）。亲眼查看 `output/case_study/figures/case_study_comparison_96.png`（`3300×3600`, 600 DPI）：5×4 网格整洁、稀疏刻度与定量角标（`MSE`, `r`, `Δ`）位于曲线上方空白带不压线。

6. **阶段 5：文档回写、回归测试与分实验 Git 提交推送（终审门禁 + 终审审计 + 本会话复核）**
   - **证据**：
     - 提交 `ae9db4c` 及后续精确校准提交 `9b39580`–`8fcf1e3` 完成 `README.md`、`AGENTS.md`、`assets/{1_specification.md,2_experimental_report.md,tois_submission_gap_analysis.md}` 及图注同步；经检查客观直白表述且无“不是……而是……”模板句。
     - 本会话现场复运行 `/home/ubuntu/miniconda3/envs/m2p/bin/python -B -m unittest discover -s tests/hpo -p 'test_hpo*.py' -v`：**30/30 测试全部 OK**；`git rev-list --count @{u}..HEAD` 为 `0`，本地分支已全部同步推送至远端。

---

### 3. 核验方式划分

- **确定性检查与独立审计双重确认**：阶段 0–5 全部主要交付物均经工作流内 Python 确定性门禁（文件/Schema/DPI/数值/HPO 单测）与独立只读审计员（`opencode-go-anthropic/deepseek-v4.1-flash`）核验；本会话亦在结束后直接抽查复核了全部关键结果文件、4 张核心 600 DPI PNG 图像、30 项 HPO 单元测试及 Git 远端推送状态。
- **仅由外部环境或上游实现判断（未在本机另行全量重测）**：`MMPD`/`SimpleTM` 在全量 14 个基准数据集上的逐格超参调优上界未做独立网格搜索；`lookback`/`robustness`/`hyperparam` 三组旧 TSV 数据本身未重跑（仅将其 Notebook 与导出 PNG 统一升级为 600 DPI 并修复了 `sensitivity_plot.ipynb` 语法 Bug）。

---

### 4. 未覆盖范围与后续扩展说明

- **未覆盖范围**：
  1. 主基准表缺失的 `Solar`、`Traffic`、`PEMS08` 大规模全量训练与 HPO 搜索未在单卡本机长时间强跑。
  2. OFAT 消融中 `Weather`、`ECL`、`Illness` 三数据集的 8 变体（共 $3\times 4\times 8 = 96$ 单元）尚未在单卡执行，工作簿已预留 Optuna 基线与 `PENDING` 占位，可直接在多卡集群运行 `ABLATION_DATASETS="Weather ECL Illness" bash scripts/ablation/run_all_ablation.sh --para ...` 后自动汇总。
  3. 跨数据集统计检验中其余 8 个数据集（`ETTh1, ETTm2, Weather, ECL, Solar, Traffic, PEMS08, Illness`）及 `MMPD`/`SimpleTM` 缺失格在 `output/statistics/benchmark_matrix.csv` 中保持 `PENDING` 占位，后续补全 `output/benchmark/*.tsv` 后可运行 `scripts/statistics/nonparametric_tests.py --include-all` 一键更新全数据集统计显著性结果。
  4. `Efficiency` 新增了 `params` 与纯前向推理时延 `inference_time_ms_per_iter`，但理论 FLOPs/MACs 及 `Lookback`/`Robustness` 的基线横向拓展未纳入本轮执行范围；`poetry.lock` 因本机无 `poetry` 命令尚未随 `pyproject.toml` 中的 `PyWavelets` 重锁。
