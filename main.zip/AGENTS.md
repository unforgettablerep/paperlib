# AGENTS.md

## Language

- Markdown in `assets/`: Simplified Chinese
- OpenCode CLI output (explanations, progress): Simplified Chinese
- Everything else (Python, shell, notebooks, README, plots): English

## Environment

Conda env `m2p` (Python 3.12.12), PyTorch 2.8.0+cu129 (CUDA 12.9, current environment; install scripts pin the 12.8 baseline), remaining deps in `pyproject.toml`. `environment.yml` pins only Python; CUDA and PyTorch are installed separately.

## Data

Datasets are git-ignored under `./data/` (e.g. `./data/ETT-small/`, `./data/weather/`); regenerate them on a fresh clone. Tracked code lives in `src/` (including `src/configs/`) and `scripts/`; `assets/` and selected analysis artifacts under `output/` are also tracked.

`--data` selects the Dataset class (via `src/data_provider/data_factory.py`) and the appended time features. All datasets use `seq_len=96`/`label_len=48` except Illness (`36`/`18`).

| Dataset(s) | `--data` | Dataset class | enc_in | pred_lens |
| --- | --- | --- | --- | --- |
| ETTh1, ETTh2 | `ETTh1`, `ETTh2` | `Dataset_ETT_hour` | 7 | 96,192,336,720 |
| ETTm1, ETTm2 | `ETTm1`, `ETTm2` | `Dataset_ETT_minute` | 7 | 96,192,336,720 |
| Weather / ECL / Exchange / Traffic / Illness | `custom` | `Dataset_Custom` | 21 / 321 / 8 / 862 / 7 | 96,192,336,720 (Illness 24,36,48,60) |
| Solar | `Solar` | `Dataset_Solar` | 137 | 96,192,336,720 |
| PEMS03/04/07/08 | `PEMS` | `Dataset_PEMS` | 358/307/883/170 | 12,24,48,96 |

- Time features: ETTh/ETTm append month/day/weekday[/hour]/[minute//15]; `custom` appends month/day/weekday/hour. For `Solar`/`PEMS`, `_prepare_batch_marks` sets `batch_x_mark=None`, so no time features are appended.
- Dataset metadata and tuned hyperparameters are centralized in `src/configs/m2patch_profiles.py` (`DATASET_META`, `resolve`, `resolve_meta`, `load_optuna_best_params`). `resolve` accepts case-insensitive aliases (`illness`/`ili` → `Illness`, `Solar-Energy` → `Solar`). Do not copy these tables into scripts.

## Quick Start

Use the centralized emitter instead of hand-writing M2Patch flags:

```bash
python -u scripts/run.py --is_training 1 --model M2Patch --des MULTI_PRED \
    $(python -m src.configs.m2patch_cli ETTh1 96 --with-meta)
```

`scripts/run.py` is the only entrypoint. Required arg: `--model`; `--is_training` (1), `--model_id` ("test"), `--data` ("custom") fall back to their defaults, and `--model_id`/`--data` are emitted by `--with-meta`.

Modes:

- `--is_training 1`: train + test; `train()` always saves a numbered checkpoint.
- `--is_training 2`: test only; loads the latest numbered checkpoint, falling back to the legacy `temp/checkpoints/{subdir}/checkpoint.pth`.
- `--checkpoint N`: checked before `is_training`; loads `temp/checkpoints/{dataset_key}/{prefix}_{N}.pth`, then runs continued `train()` + `test()`.

`run.py` seeds all RNGs with `--seed` (default 2023) right after arg parsing. Keep the default unless a different seed is intentional; results and checkpoints are seed-dependent.

Notable defaults: training runs FP32 by default (pass `--use_amp` to enable AMP); `d_model=256`, `d_ff=512`; M2Patch uses `Adam` (weight_decay 0) + `OneCycleLR` (`--lradj onecycle`). `--gpu N` scopes a single device through `CUDA_VISIBLE_DEVICES` (only when the env var is unset).

Other useful flags: `--use_8bit 1`, `--use_cuda_accel 1`, `--explanation {all,manifold,training,attribution}`, `--exp_name partial_train`, `--noise_level N`, `--train_noise_level N`.

## Centralized M2Patch Configuration

`src/configs/m2patch_profiles.py` is the single source of truth for per-(dataset, pred_len) model/data settings; `src/configs/m2patch_cli.py` emits them as CLI flags.

```bash
python -m src.configs.m2patch_cli ETTh1 96                 # profile flags only
python -m src.configs.m2patch_cli ETTh1 96 --with-meta     # + root/data/enc_in/model_id
python -m src.configs.m2patch_cli --list-datasets
python -m src.configs.m2patch_cli ETTh1 --pred-lens
python -m src.configs.m2patch_cli ETTh1 96 --tier          # informational complexity tier
python -m src.configs.m2patch_cli ETTh1 96 --from-optuna   # read output/optuna best params (nearest shorter horizon fallback)
```

M2Patch defaults (`CONSTANTS` in `src/configs/m2patch_profiles.py`, also used by `src/configs/custom_M2Patch.py`):

| Parameter | Default | Purpose |
| --- | --- | --- |
| `--patch_len` | 16 | Causal history patch length |
| `--stride` | 8 | Causal history patch stride (left-tail padding only) |
| `--d_hyp` | 64 | Poincaré-ball manifold dimension |
| `--manifold_c` | 1.0 | Constant negative curvature c > 0 |
| `--d_layers_diff` | 2 | Conditional diffusion denoiser layers |
| `--diff_steps` | 1 | Deterministic Bridge-DDIM steps K ≥ 1 |
| `--diff_schedule` | `cosine` | VP-SDE schedule (`cosine`/`linear`) |
| `--diff_eta` | 0.0 | DDIM stochasticity (0.0 = deterministic) |
| `--lambda_hyp` | 0.1 | Hyperbolic geodesic alignment loss weight |
| `--lambda_prior` | 0.1 | Causal prior anchor loss weight |
| `--revin` | 1 | History-only RevIN normalization |
| `--lradj` | `onecycle` | Learning-rate scheduler |
| `--optim` | `Adam` | Optimizer; `weight_decay` defaults to `0.0` and is not emitted by default |
| `--dropout` | 0.1 | Fixed profile value; Illness uses 0.2 |
| `--pct_start` | 0.2 | Fixed OneCycleLR warm-up fraction |
| `--ablation` | `none` | Registry switch; choices in `src/ablation/registry.py` |

Per-dataset/profile values override these defaults. Experiment scripts call the emitter and append only intentional run-specific overrides (noise, horizon, frozen case-study deltas); never copy the full table into a script. Internal robustness constants in `src/layers/M2Patch_layers.py` are not CLI flags: RevIN stdev floor ratio 0.2, target/sample clip 10.0, max tangent norm 2.0, raw reconstruction weight 1.0. `--ablation` maps to backbone hooks: `euclid_manifold` replaces the Poincaré ball with Euclidean identity maps/distances, `zero_prior_bridge` zeroes the bridge center and reverse start, `no_hyp_cond` skips the hyperbolic conditioning projection. The granular registry switches (`use_hyp_manifold`, `use_prior_bridge`, `use_hyp_cond`, `use_adaln`, `use_denoiser`, `use_causal_norm`, `lambda_hyp`, `lambda_prior`) are read by the backbone via `getattr(configs, ..., 1)`, never passed as CLI flags.

## Multi-GPU Schedulers

- `scripts/multivariate_forecasting/run_all_forecasts.sh [--gpu 0,1 --para 2]` dispatches the 14 `M2Patch*.sh` dataset scripts with least-loaded GPU placement; log `log/multivariate_forecasting/scheduler.log`, lock `temp/forecasts/run.lock`.
- Ablation, sensitivity, mechanism, and lookback runners share `scripts/utils/gpu_queue.sh` (round-robin GPU assignment + per-GPU FIFO slots + standalone `PARALLEL` mode).
- `scripts/ablation/run_all_ablation.sh --para N GPU...` runs the 8 single-variable (OFAT) variants from `DEFAULT_ABLATION_VARIANTS` sequentially (`euclid_manifold`, `no_hyp_cond`, `zero_prior_bridge`, `no_adaln`, `no_denoise_refinement`, `no_causal_prefix_norm`, `no_hyp_loss`, `no_prior_loss`; each changes exactly one component vs `none`), one merged TSV per variant at `output/ablation/{variant}.tsv` with des token `ablation_{variant}`, with per-GPU FIFO limits. The target grid is six datasets (`ABLATION_DATASETS`: ETTh2, ETTm1, Exchange, Weather, ECL, Illness), four horizons each. Every cell, including the `none` baseline, is launched with `--from-optuna`, so the baseline is the Optuna-config model rather than the frozen profile; `is_noop_ablation` skips cells where a variant coincides with the Optuna baseline. `MAIN_ABLATION_LABELS` in `src/ablation/registry.py` holds the paper display names. Env overrides: `ABLATION_DATASETS`, `ABLATION_VARIANTS`, `EPOCHS`. The per-variant TSVs roll up into `output/ablation/m2p-ablation.xlsx` with two worksheets (`Main Table` for the paper table, `Full Detail` for all registered cells), rebuilt by `output/ablation/update_ablation.py`. ETTh2, ETTm1 and Exchange are measured for all 8 variants x 4 horizons; Weather, ECL and Illness keep Optuna-reference baseline cells and `PENDING` variant cells until those runs land.
- Individual dataset scripts call `python -m src.configs.m2patch_cli` and accept `RUN_INDICES` to select horizons.
- `scripts/batch/*.sh` are self-contained Slurm submissions for the 4-GPU RTX 4090 platform (`--gres=gpu:4`): each activates conda `m2p`, exports `PYTHON_BIN`, and keeps the job alive (PID polling / `tail --pid`) until the detached runners or HPO studies finish. Submit with `sbatch scripts/batch/<script>.sh`; per-job logs land in `log/slurm/%x-%j.out`.

## Results and Output

`src/utils/result_io.py` owns the TSV result store: canonical columns, a dot-lock `atomic_append`, header creation, `build_result_row`, `write_test_result`, `read_results`, `compact_results`, `migrate_file`, `upgrade_schema`, and `canonical_dataset`. Use it instead of hand-written TSV I/O. Rows carry the run configuration as one column per M2Patch-relevant parameter: `des` sits right after `timestamp`, followed by model/training columns; there is no `setting` string and M2Patch-irrelevant flags are not stored. The column set is selected by output path (`columns_for_path`): 35-column `RESULT_COLUMNS` (no `noise_level`/`ablation`) for regular/lookback/case-study stores, 36-column `ROBUSTNESS_RESULT_COLUMNS` (adds `noise_level`) for `ROBUSTNESS_OUTPUT_DIR` or `*_robustness.tsv`, and 36-column `ABLATION_RESULT_COLUMNS` (adds `ablation` after `affine`) for `ABLATION_OUTPUT_DIR`/`MECHANISM_OUTPUT_DIR` or paths under `output/ablation` and `output/mechanism/results`. Re-sort/compact or upgrade legacy stores with:

```bash
python -m src.utils.result_io sort output/long_term_forecast/ETTh1.tsv
python -m src.utils.result_io upgrade output/long_term_forecast/ETTh1.tsv  # expand legacy setting strings into config columns
```

`scripts/utils/result_common.sh` exposes `result_done <file.tsv> key=value ...` for shell resume checks; it reads the TSV header and requires `status` starting with `ok` and a finite `mse`.

## Cross-Dataset Statistical Tests

`scripts/statistics/nonparametric_tests.py` implements the Demsar protocol for the paper comparison. A problem instance is one `(dataset, pred_len)` block; models are ranked per block (rank 1 = lowest error). M2Patch cells come from the measured OFAT baseline `output/ablation/none.tsv`, falling back to `output/optuna/*_best_params.json` for datasets not retrained locally. Baseline cells come from `output/benchmark/{dataset}.tsv` when that model was executed under the shared 15-epoch protocol, otherwise from `assets/m2p_eff_results_1.xlsx`; every row records its `source` in `output/statistics/benchmark_matrix.csv`.

The report covers k = 8 models (M2Patch, MMPD, SimpleTM, TimeMixer, iTransformer, PatchTST, DLinear, TimesNet) on the three measured datasets x four horizons (N = 12 complete blocks). It computes the tie-corrected Friedman chi-square, the Iman-Davenport F with `df1 = k-1` and `df2 = (k-1)(N-1)`, the Nemenyi critical difference, pairwise two-sided Wilcoxon signed-rank tests with Holm-Bonferroni correction over the seven baselines, and the matched-pairs rank-biserial effect size `(W+ - W-)/(W+ + W-)`. Outputs: `output/statistics/stat_tests_results.csv`, `stat_tests_summary.md`, `critical_difference.png` (600 dpi), `m2p_stat_tests.xlsx`, and `benchmark_matrix.csv`. Pass `--include-all` after the remaining benchmark cells exist; incomplete blocks never enter a test. The runner `scripts/statistics/run_benchmark_matrix.sh` produces the shared-protocol baseline TSVs (MMPD and SimpleTM over the core datasets).

Output redirection:

| Env var | File |
| --- | --- |
| default | `./output/long_term_forecast/{dataset}.tsv` |
| `ROBUSTNESS_OUTPUT_DIR=dir` | `./{dir}/{dataset}_robustness.tsv` |
| `ABLATION_OUTPUT_DIR=dir` | `{parent(dir)}/{basename(dir)}.tsv` (e.g. `output/ablation/{variant}.tsv`) |
| `MECHANISM_OUTPUT_DIR=dir` | `./{dir}/{dataset}.tsv` |
| `LOOKBACK_OUTPUT_DIR=dir` | `./{dir}/{model}.tsv` |
| `BENCHMARK_OUTPUT_DIR=dir` | `./{dir}/{dataset}.tsv` |
| `REPRODUCIBILITY_OUTPUT_DIR=dir` | `./{dir}/{dataset}.tsv` |
| `CASE_STUDY_MODE=1` | `./output/case_study/case_study.tsv` |

Sensitivity sweeps write `output/hyperparam/sensitivity_results_{dataset}.tsv`. `M2PATCH_SKIP_RESULT_WRITE=1` disables TSV writes. `temp/results/{subdir}/` and `temp/test_results/{subdir}/` hold `.npy` predictions/trues/metrics and visualization PNGs; `temp/checkpoints/{dataset_key}/` holds checkpoints. Notebook-exported analysis figures (efficiency, lookback, robustness, case study, sensitivity), the mechanism figures rendered by `plot_m2patch_mechanism.py`, and `output/statistics/critical_difference.png` are 600 dpi `.png`.

## Architecture: M2Patch

M2Patch combines a strictly causal single-scale patch tokenizer, a constant-negative-curvature Poincaré-ball history manifold, a history-prior bridge diffusion process, and a deterministic Bridge-DDIM forecaster.

| Component | File |
| --- | --- |
| Causal patching, Poincaré manifold, prior-bridge SDE, denoiser, trinity loss | `src/layers/M2Patch_layers.py` |
| Top-level model | `src/model/M2Patch.py` |
| CLI parser | `src/configs/custom_M2Patch.py` |
| Profiles / emitter | `src/configs/m2patch_profiles.py`, `src/configs/m2patch_cli.py` |

New model registration:

1. Add `src/model/YourModel.py` with `class Model(nn.Module)`.
2. Import and register it in `src/experiments/exp_basic.py:Exp_Basic.model_dict`.
3. Add `src/configs/custom_YourModel.py` and register the parser in `src/configs/model_parser_dict.py`.
4. Add dataset scripts under `scripts/multivariate_forecasting/{dataset}/`.

A model needing a custom optimizer can define `build_optimizer(self, lr, weight_decay, optim_type=...)`; `_select_optimizer` picks it up via `hasattr`.

Checkpoints: `temp/checkpoints/{dataset_key}/{prefix}_{seq}.pth`, where `dataset_key` comes from `_get_dataset_name` (PEMS → data_path basename; `custom` → `model_id`, e.g. `weather_96_96`; else `args.data`) and `prefix = {dataset_key}_{model}_sl{seq_len}_pl{pred_len}[_lr{low_rank}][_{des}]` (`src/utils/checkpoint.py`). Sequence numbers auto-increment and `checkpoints_{dataset_key}.txt` logs hyperparameters. The prefix does not include `e_layers`/`label_len`/`class_strategy`; keep those stable across runs so result rows line up.

## Hyperparameter Optimization (Optuna)

Built on Optuna `v5.1.0` (`pyproject.toml`). The search space is code-defined in `src/hpo/search_space.py` as 3 multivariate groups — `backbone_patch` (`d_model`/`e_layers`/`patch_len`/`stride`), `hyperbolic_diffusion` (`d_hyp`/`manifold_c`/`d_layers_diff`/`diff_steps`/`lambda_hyp`/`lambda_prior`), `optimization` (`learning_rate`) — sampled by the official `TPESampler` (`multivariate=True`/`group=True`/`constant_liar=True`; `src/hpo/study_manager.py`). `dropout` and `pct_start` are fixed by `src/configs/m2patch_profiles.py`: all horizons use `pct_start=0.2`; dropout is `0.1` except Illness (`0.2`). Every study stamps an `hpo_config` fingerprint including the effective fixed configuration and derived feed-forward cap; resuming with a mismatched or pre-fingerprint DB is rejected, and stale heartbeat trials are retried via `RetryHeartbeatStaleTrialCallback`. The fingerprint deliberately excludes torch/optuna library versions, so study DBs can be copied between hosts and resumed across differing environments; legacy `torch_version`/`optuna_version` fields in existing DBs are ignored during the check. Constraints use the native `trial.set_constraint()` (GPU memory, `stride <= patch_len`); studies run with `HyperbandPruner(min_resource=4, max_resource=train_epochs, reduction_factor=3)` so the first rung follows the OneCycleLR warm-up peak, and importance is ranked by `PedAnovaImportanceEvaluator`. Per-dataset horizons and metadata in `src/hpo/suggest_overrides.py` derive from `src/configs/m2patch_profiles.py`. Study DBs go to `temp/optuna/`, best-param JSON to `output/optuna/`; `--bg` and batch runs write `log/optuna/{dataset}_{pl}_study_{timestamp}.log`, a new file per launch. `hpo-clean --full` also removes the JSON/CSV exports and study logs.

New studies default to JSON warm start (`--warm_start 1`); Python, poe, parallel, and batch launchers accept `--warm_start 0` to disable it. The matching dataset/horizon JSON contributes only valid parameters in the current search space, with current fixed values applied by the objective. The JSON candidate runs first, followed by a distinct frozen-profile candidate; existing studies are not seeded again. Seed provenance and actual effective parameters are stored in the database, and JSON candidates are trained and tested again rather than reusing historical scores. Exported `best_params` records the best trial's effective configuration. Explicit `--from-optuna` loading continues to use the historical values recorded in JSON. Fresh studies seed `TPESampler` with 2023; resumed studies use a random sampler seed so the random start-up phase does not replay earlier trial parameters, while the training seed remains 2023 in the fingerprint.

Run isolated HPO regression tests with `python -B -m unittest discover -s tests/hpo -p 'test_hpo*.py' -v`; they use temporary stores rather than production results.

```bash
poetry run poe optuna --dataset ETTh1 --pl 96 --trials 50 --gpu 0
poetry run poe optuna --dataset ETTh1 --pl all --trials 50 --bg_mode 1
poetry run poe hpo-list
poetry run poe hpo-stop --dataset ETTh1 --pl 96
poetry run poe hpo-stop-all
poetry run poe dashboard --port 58231
poetry run poe hpo-dump --dataset ETTh1 --pl 96
poetry run poe hpo-clean --dataset ETTh1 --pl 96
poetry run poe hpo-batch --gpus 4 --studies "ETTm1:192:200:7"
bash scripts/hpo/hpo_batch.sh --n_gpus 4 --study "ETTm1:192:200:7" --study "Weather:96:50:7"
```

Refresh `assets/m2p_eff_results_*.xlsx` (sheet `Results`) solely from the Optuna JSON exports under `output/optuna/` — TSV result stores are not a source. The Config block is cleared first and filled only from Optuna JSON best params (no profile fallback); the merged `enc_in` cells are written at their dataset-block anchor, and the SOTA formulas in `V:Y` recompute over `C:T` on open:

```bash
poetry run poe update
poetry run poe update-ablation   # rebuild output/ablation/m2p-ablation.xlsx from output/ablation/{variant}.tsv
```

Sensitivity sweeps live in `scripts/hyperparam/`: `bash scripts/hyperparam/launch_sensitivity.sh --para N GPU...` covers 5 datasets (ETTh1, ETTh2, ETTm1, Weather, Exchange) x 4 parameters (`d_model` 64/128/256/512 with `d_ff=min(2*d_model, 768)` and divisor-aligned `n_heads`, `d_hyp` 16/32/64/128, `d_layers_diff` 1/2/3/4, `learning_rate` 1e-4/2.5e-4/5e-4/1e-3) at `pred_len=96` with 5 seeds (2022-2026) per cell. Non-swept values come from `load_optuna_best_params` when the JSON export exists and fall back to the frozen `src.configs.m2patch_profiles.resolve` profile otherwise; identical full configurations are reused through `temp/hyperparam_sensitivity_cache/`. `run_sensitivity.py --compact` sorts each TSV canonically and dedups retried cells; `--dry_run` prints the resolved configuration. Figures live in `output/hyperparam/sensitivity_plot.ipynb` (`4_sensitivity_lines.png` plus the 2x4 hatched grouped-bar `4_sensitivity.png` / `exp_6_sensitivity.png`, all 600 dpi PNG).

## Mechanism Experiments

`scripts/mechanism/` isolates the Poincaré-ball history geometry and the history causal prior bridge. The suite now covers ETTh2, ETTm1 and Exchange at `pred_len=96` (`--datasets ETTm1 Exchange`); each dataset has its own panel and all three enter the cross-dataset comparison. Variants: `none` (full model), `euclid_manifold`, `zero_prior_bridge`, `no_hyp_cond`, `no_prior_loss`.

```bash
scripts/mechanism/run_m2patch_mechanism.sh --para 2 --epochs 15 --plot 1 --gpu 0
python scripts/mechanism/plot_m2patch_mechanism.py --dataset ETTh2 --pred_len 96
```

- Configuration comes from `load_optuna_best_params(dataset, pred_len)` via `mechanism_config.py` (the same protocol as the paper runs), with `--source profile` as the frozen-profile fallback. It only adds run-control flags, lifts a `lambda_hyp=0` optimum to `MECHANISM_LAMBDA_HYP_FLOOR = 0.1` so the alignment mechanism stays active, and forces `optim=Adam` / `lradj=onecycle` / `pct_start=0.2` from `CONSTANTS`.
- `run_m2patch_mechanism.sh` sources `mechanism_common.sh` (GPU-wave scheduling via `GPU_LIST`/`PARA_PER_GPU`) and skips completed cells with `result_done`. Results: `output/mechanism/results/{Dataset}.tsv` (`MECHANISM_OUTPUT_DIR`).
- `plot_m2patch_mechanism.py` loads the latest checkpoint per variant, extracts `z_hist`, `z_prior`, `z_pred`, `z_target`, `Y_prior`, `y_pred`, and `Delta Y_diff`, merges the rows of the plotted dataset into `output/mechanism/m2patch_mechanism_summary.tsv` (other datasets are preserved), and renders the 2x2 ACM TOIS single-column panel at 600 dpi: `output/mechanism/figures/m2patch_mechanism_{Dataset}.png`, the same panel for `--main_dataset` (default ETTh2) as the paper main figure `output/mechanism/figures/m2patch_mechanism_analysis.png`, and the cross-dataset variant comparison `output/mechanism/figures/m2patch_mechanism_cross_dataset.png` (`--cross_only` rebuilds it from the summary alone).
- Panel (c) reads the per-iteration loss decomposition from `output/mechanism/loss_history_{Dataset}_pl{pred_len}.json` (produced by `scripts/explanation/run_explain_loss_curves.sh` or `run_explain_ETTm1.sh`) and evaluates the deployed model at `K in {1, 2, 4}` diffusion steps as the residual-burden strip.
- Figure colors come from `scripts/color.py` (`purple_dark1/2`, `green_main`, `blue_dark`, `blue_light`; `neutral_dict` for axes/grid/surfaces).

## Case Study

`scripts/case_study/run_case_study.sh` runs 96 -> 96 qualitative comparisons on ETTm2, ETTm1, ECL and Exchange with M2Patch, MMPD, S-Mamba, iTransformer and PatchTST; `output/case_study/collect_results.sh [dataset]` copies the per-run records into `output/case_study/record_{dataset}/`, and `output/case_study/case_study.tsv` holds the full-test metrics. `output/case_study/case_study.ipynb` selects one showcase window per dataset with the deterministic `SHOWCASE_RULE` (dual-scope win on the displayed channel and all channels, optional margin and variation quantile), annotates window MSE and horizon correlation, and exports `output/case_study/figures/case_study_comparison_96.png` at 600 dpi (5.50 in x 6.00 in). M2Patch rows use `src.configs.m2patch_cli <DS> 96 --from-optuna --with-meta`.

## Efficiency Experiments

- Baselines: per-dataset JSONL shards in `output/efficiency/results_by_dataset/{Shard}.jsonl`, schema-rich and sorted by `(model.lower(), timestamp)`. API: `scripts/efficiency/efficiency_store.py` (`build_record`, `append`, `load`, `write_shard`, `config_hash`); shard names use `src.utils.result_io.canonical_dataset`.
- M2Patch: the three final active JSONs stay in `output/efficiency/m2patch_results/`; exploration JSONs and the `efficiency_records.xlsx` tracking workbook are archived under the git-ignored `output/efficiency/m2patch_results/archive/`. The notebook pins one JSON per dataset via `M2PATCH_JSON_MAP`; never written to the JSONL store.
- Unified protocol: M2Patch and all 11 baselines (MMPD, SimpleTM, TimeMixer, PatchTST, iTransformer, S_Mamba, DLinear, Autoformer, Informer, Flowformer, Transformer) use 10 epochs, `batch_size=16`, FP32 (`use_amp=0`) and seed 2023, measured sequentially on one RTX 4090 D. `python scripts/run.py` prints `model_params: total=..., trainable=...` after model construction and `inference_speed: X.XXXXXXs/iter` (pure forward latency, CUDA-synchronised, first 5 test batches excluded as warm-up) at the end of `test()`. Both values are stored as `params` and `inference_time_ms_per_iter` in the JSONL/JSON/XLSX metrics. Every baseline JSONL record stores `train_epochs=10`, `batch_size=16` and `use_amp=false`.
- Configuration is `src.configs.m2patch_profiles.resolve/resolve_meta` with those efficiency-only overrides plus locked `diff_steps`/`lambda_prior` (user-supplied `--diff_steps`/`--lambda_prior` are filtered); there is no separate YAML table. The current M2Patch efficiency JSONs are ETTm1 pl96 (MSE 0.3289, 2.656 M params, 4.076 ms/iter), Weather pl96 (0.1737, 5.260 M, 4.439 ms) and ECL pl336 (0.2061, 1.274 M, 15.933 ms).
- Producers: `scripts/efficiency/legacy/run_efficiency_legacy.py` (baselines), `scripts/efficiency/run_efficiency.py` (M2Patch). Reader: `output/efficiency/efficiency_plot.ipynb`.

## Code Style

- Spaces, 4-space indentation levels, max line 180 (`.editorconfig`). Every indentation level is a multiple of 4; never use 2-space steps or partial alignment to an opening delimiter. For wrapped lines, indent +4 from the statement and refactor instead of nesting deeply.
- Double quotes for strings. Use `getattr(configs, ...)` for optional parameters with defaults.
- No inline comments except tensor-shape annotations or critical notes.
- No file-header comment blocks or multi-line purpose docstrings: start with the shebang (if any), imports, or executable code. A one-line purpose note is allowed.
- No auto-formatter; match the surrounding style.
- Vendored/upstream files keep their license headers and upstream formatting (`src/mamba/**`, `src/utils/timefeatures.py`). SBATCH directive blocks are exempt from the header-comment rule.

## Plotting Colors

Always source colors from `scripts/color.py`; do not hard-code hex values or use library defaults.

- Import `hex_palette`, `purple_palette`, `green_blue_palette`, `color_dict`, `neutral_dict`, `nature_palette`.
- The palette is the Nature Publishing Group (NPG) set. Primary saturated colors: `color_dict["purple_dark1"]` / `npg_red` (`#E64B35`), `purple_dark2` / `npg_brown` (`#7E6148`), `green_main` / `npg_green` (`#00A087`), `blue_dark` / `npg_blue` (`#3C5488`), `blue_light` / `npg_cyan` (`#4DBBD5`); `npg_amber` (`#E18727`), `npg_slate` (`#8491B4`) and `npg_sand` (`#B09C85`) complete the categorical set.
- Light entries (`purple_light1/2`, `green_mint`) are backgrounds/fills only — never lines, markers, bars, or readable text.
- Keep elements vivid: no pastel tints or low-alpha auto-lightening; darken a base color for variants instead of blending toward white.
- Cycle `hex_palette`/`green_blue_palette`/`purple_palette` for multi-series plots. Structural neutrals (axes, grid, hairlines, frames, surfaces) come from `neutral_dict`.
