#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-3}
model_name=${model_name:-TimeMixer}

pred_lens=(12 24 48 96)
e_layers=(3 3 3 3)
d_models=(128 128 128 128)
d_ffs=(256 256 256 256)
down_sampling_layers=(1 1 1 1)
down_sampling_windows=(2 2 2 2)
down_sampling_methods=(avg avg avg avg)
moving_avgs=(25 25 25 25)
learning_rates=(0.005 0.005 0.005 0.005)

run_indices=(0 1 2 3)

for i in "${run_indices[@]}"; do

    python -u scripts/run.py \
        --is_training 1 \
        --des 'MULTI_PRED' \
        --root_path ./data/PEMS/ \
        --data_path PEMS08.npz \
        --model_id PEMS08_96_${pred_lens[$i]} \
        --model $model_name \
        --data PEMS \
        --features M \
        --seq_len 96 \
        --label_len 48 \
        --pred_len ${pred_lens[$i]} \
        --e_layers ${e_layers[$i]} \
        --enc_in 170 \
        --c_out 170 \
        --d_model ${d_models[$i]} \
        --d_ff ${d_ffs[$i]} \
        --channel_independence 0 \
        --down_sampling_layers ${down_sampling_layers[$i]} \
        --down_sampling_window ${down_sampling_windows[$i]} \
        --down_sampling_method ${down_sampling_methods[$i]} \
        --decomp_method moving_avg \
        --moving_avg ${moving_avgs[$i]} \
        --use_norm 0 \
        --use_future_temporal_feature 0 \
        --dropout 0.1 \
        --optim Adam \
        --lradj type1 \
        --learning_rate ${learning_rates[$i]} \
        --weight_decay 0 \
        --patience 5 \
        --train_epochs 15 \
        --batch_size 32

done
