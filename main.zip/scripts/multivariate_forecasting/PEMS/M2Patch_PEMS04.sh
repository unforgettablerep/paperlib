#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-M2Patch}
des=${des:-M2PATCH}
dataset=PEMS04
run_indices=(${RUN_INDICES:-0 1 2 3})

mapfile -t pred_lens < <("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" --pred-lens)

for i in "${run_indices[@]}"; do
    pl=${pred_lens[$i]}
    flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" "$pl" --with-meta)
    "$PYTHON_BIN" -u scripts/run.py \
        --is_training 1 \
        --des "$des" \
        --model "$model_name" \
        $flags
done
