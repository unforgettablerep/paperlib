#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-DisenTS}

pred_lens=(12 24 48 96)

run_indices=(0 1 2 3)

for i in "${run_indices[@]}"; do

    python -u scripts/run.py \
        --is_training 1 \
        --des 'MULTI_PRED' \
        --root_path ./data/PEMS/ \
        --data_path PEMS08.npz \
        --model_id PEMS08_96_${pred_lens[$i]} \
        --model $model_name \
        --data PEMS \
        --features M \
        --seq_len 96 \
        --label_len 48 \
        --pred_len ${pred_lens[$i]} \
        --e_layers 2 \
        --batch_size 16 \
        --enc_in 170 \
        --c_out 170 \
        --d_model 256 \
        --d_ff 512 \
        --disen_backbone PatchTST \
        --disen_times 4 \
        --is_RevIN 1 \
        --similar_weight 0.01 \
        --sample_num 128 \
        --d_gate 64 \
        --individual 0 \
        --revin 1 \
        --optim Adam \
        --lradj type1 \
        --learning_rate 5e-4 \
        --weight_decay 0 \
        --dropout 0.1 \
        --patience 5 \
        --train_epochs 15 \
        --no-use_amp

done
