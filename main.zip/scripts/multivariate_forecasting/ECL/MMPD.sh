#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-MMPD}
des=${des:-MMPD}

pred_lens=(96 192 336 720)
run_indices=(${RUN_INDICES:-0 1 2 3})

for i in "${run_indices[@]}"; do
    pl=${pred_lens[$i]}
    if [ "$pl" -le 192 ]; then
        patch_size=12
    else
        patch_size=24
    fi

    "$PYTHON_BIN" -u scripts/run.py \
        --is_training 1 \
        --des "$des" \
        --root_path ./data/electricity/ \
        --data_path electricity.csv \
        --model_id ecl_96_${pl} \
        --model "$model_name" \
        --data custom \
        --features M \
        --seq_len 96 \
        --label_len 48 \
        --pred_len ${pl} \
        --enc_in 321 \
        --c_out 321 \
        --d_model 256 \
        --d_ff 512 \
        --n_heads 4 \
        --e_layers 2 \
        --d_layers 2 \
        --patch_size ${patch_size} \
        --d_diffusion 256 \
        --diffusion_layers 1 \
        --radius 3 \
        --max_diffusion_steps 1000 \
        --beta_schedule linear \
        --point_weight 0.01 \
        --weighted 1 \
        --sample_num 100 \
        --num_sampling_steps 20 \
        --dropout 0.2 \
        --batch_size 32 \
        --learning_rate 1e-4 \
        --lradj cosine \
        --train_epochs 15 \
        --patience 5 \
        --optim Adam \
        --freq h \
        --no-use_amp

done
