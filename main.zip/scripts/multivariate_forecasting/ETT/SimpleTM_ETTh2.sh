#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-SimpleTM}
des=${des:-SimpleTM}
dataset=ETTh2

pred_lens=(96 192 336 720)
run_indices=(${RUN_INDICES:-0 1 2 3})

for i in "${run_indices[@]}"; do
    pl=${pred_lens[$i]}

    "$PYTHON_BIN" -u scripts/run.py \
        --is_training 1 \
        --des "$des" \
        --root_path ./data/ETT-small/ \
        --data_path ETTh2.csv \
        --model_id ETTh2_96_${pl} \
        --model "$model_name" \
        --data ETTh2 \
        --features M \
        --seq_len 96 \
        --label_len 48 \
        --pred_len ${pl} \
        --enc_in 7 \
        --dec_in 7 \
        --c_out 7 \
        --d_model 32 \
        --d_ff 32 \
        --e_layers 1 \
        --dropout 0.1 \
        --geomattn_dropout 0.5 \
        --wv db1 \
        --wavelet_levels 3 \
        --alpha 1.0 \
        --l1_weight 5e-5 \
        --requires_grad 1 \
        --batch_size 32 \
        --learning_rate 1e-4 \
        --lradj type1 \
        --train_epochs 15 \
        --patience 5 \
        --optim AdamW \
        --weight_decay 0.01 \
        --no-use_amp

done
