#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-TimeMixer}

pred_lens=(24 36 48 60)
batch_sizes=(32 32 32 32)
e_layers=(2 2 2 2)
d_models=(128 128 128 128)
d_ffs=(256 256 256 256)
learning_rates=(0.001 0.001 0.001 0.001)

run_indices=(0 1 2 3)

for i in "${run_indices[@]}"; do

    python -u scripts/run.py \
        --is_training 1 \
        --des 'MULTI_PRED' \
        --root_path ./data/illness/ \
        --data_path national_illness.csv \
        --model_id ili_36_${pred_lens[$i]} \
        --model $model_name \
        --data custom \
        --features M \
        --seq_len 36 \
        --label_len 18 \
        --pred_len ${pred_lens[$i]} \
        --e_layers ${e_layers[$i]} \
        --enc_in 7 \
        --c_out 7 \
        --d_model ${d_models[$i]} \
        --d_ff ${d_ffs[$i]} \
        --channel_independence 1 \
        --down_sampling_layers 2 \
        --down_sampling_window 2 \
        --down_sampling_method avg \
        --decomp_method moving_avg \
        --moving_avg 7 \
        --use_norm 1 \
        --use_future_temporal_feature 0 \
        --dropout 0.2 \
        --optim Adam \
        --lradj type1 \
        --learning_rate ${learning_rates[$i]} \
        --weight_decay 0 \
        --patience 5 \
        --train_epochs 15 \
        --batch_size 32 \
        --freq w

done
