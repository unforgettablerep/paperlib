#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-DisenTS}

pred_lens=(24 36 48 60)

run_indices=(0 1 2 3)

for i in "${run_indices[@]}"; do

    python -u scripts/run.py \
        --is_training 1 \
        --des 'MULTI_PRED' \
        --root_path ./data/illness/ \
        --data_path national_illness.csv \
        --model_id ili_36_${pred_lens[$i]} \
        --model $model_name \
        --data custom \
        --features M \
        --seq_len 36 \
        --label_len 18 \
        --pred_len ${pred_lens[$i]} \
        --e_layers 2 \
        --batch_size 32 \
        --enc_in 7 \
        --c_out 7 \
        --d_model 256 \
        --d_ff 512 \
        --moving_avg 13 \
        --disen_backbone PatchTST \
        --disen_times 4 \
        --is_RevIN 1 \
        --similar_weight 0.01 \
        --sample_num 128 \
        --d_gate 64 \
        --individual 0 \
        --revin 1 \
        --optim Adam \
        --lradj type1 \
        --learning_rate 1e-4 \
        --weight_decay 0 \
        --dropout 0.1 \
        --patience 5 \
        --train_epochs 15 \
        --no-use_amp

done
