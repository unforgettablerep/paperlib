#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-TimeMixer}

# seq_len=96 -> multi-scale lengths (96,48,24,12) all even; safe with down_sampling_window=2
pred_lens=(96 192 336 720)
e_layers=(2 2 2 2)
d_models=(16 16 64 32)
d_ffs=(32 32 128 64)
down_sampling_layers=(3 3 3 3)
down_sampling_windows=(2 2 2 2)
down_sampling_methods=(avg avg avg avg)
learning_rates=(0.01 0.01 0.01 0.01)
batch_sizes=(32 32 32 32)
dropouts=(0.1 0.1 0.1 0.1)

run_indices=(0 1 2 3)

for i in "${run_indices[@]}"; do

    python -u scripts/run.py \
        --is_training 1 \
        --des 'MULTI_PRED' \
        --root_path ./data/exchange_rate/ \
        --data_path exchange_rate.csv \
        --model_id Exchange_96_${pred_lens[$i]} \
        --model $model_name \
        --data custom \
        --features M \
        --seq_len 96 \
        --label_len 48 \
        --pred_len ${pred_lens[$i]} \
        --e_layers ${e_layers[$i]} \
        --enc_in 8 \
        --c_out 8 \
        --d_model ${d_models[$i]} \
        --d_ff ${d_ffs[$i]} \
        --channel_independence 1 \
        --down_sampling_layers ${down_sampling_layers[$i]} \
        --down_sampling_window ${down_sampling_windows[$i]} \
        --down_sampling_method ${down_sampling_methods[$i]} \
        --decomp_method moving_avg \
        --moving_avg 25 \
        --use_norm 1 \
        --use_future_temporal_feature 0 \
        --dropout ${dropouts[$i]} \
        --optim Adam \
        --lradj type1 \
        --learning_rate ${learning_rates[$i]} \
        --weight_decay 0 \
        --patience 5 \
        --train_epochs 15 \
        --batch_size ${batch_sizes[$i]} \
        --freq d

done
