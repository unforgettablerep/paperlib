#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-DisenTS}

pred_lens=(96 192 336 720)
batch_size=(32 32 32 32)
learning_rates=(1e-4 1e-4 1e-4 1e-4)
dropouts=(0.1 0.1 0.1 0.1)

run_indices=(0 1 2 3)

for i in "${run_indices[@]}"; do

    python -u scripts/run.py \
        --is_training 1 \
        --des 'MULTI_PRED' \
        --root_path ./data/exchange_rate/ \
        --data_path exchange_rate.csv \
        --model_id exchange_96_${pred_lens[$i]} \
        --model $model_name \
        --data custom \
        --features M \
        --seq_len 96 \
        --label_len 48 \
        --pred_len ${pred_lens[$i]} \
        --e_layers 2 \
        --batch_size ${batch_size[$i]} \
        --enc_in 8 \
        --c_out 8 \
        --d_model 256 \
        --d_ff 512 \
        --disen_backbone PatchTST \
        --disen_times 4 \
        --is_RevIN 1 \
        --similar_weight 0.01 \
        --sample_num 128 \
        --d_gate 64 \
        --individual 0 \
        --revin 1 \
        --optim Adam \
        --lradj type1 \
        --learning_rate ${learning_rates[$i]} \
        --weight_decay 0 \
        --dropout ${dropouts[$i]} \
        --patience 5 \
        --train_epochs 15 \
        --no-use_amp

done
