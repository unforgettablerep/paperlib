import argparse
import os
import random
import sys

import numpy as np
import torch
import torch.multiprocessing

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(PROJECT_ROOT)

from src.configs.model_parser_dict import model_parser_dict
from src.configs.m2patch_profiles import CONSTANTS
from src.ablation.registry import resolve_ablation
from src.experiments.exp_long_term_forecasting import Exp_Long_Term_Forecast
from src.experiments.exp_long_term_forecasting_partial import (
    Exp_Long_Term_Forecast_Partial,
)


def _build_robustness_str(args):
    parts = []
    if getattr(args, "noise_level", 0.0) > 0:
        parts.append("nl:{}".format(args.noise_level))
    if not parts:
        return ""
    return "|" + "|".join(parts)


def _build_setting(args, robustness_str, ii):
    if args.model == "M2Patch":
        m2patch_str = (
            "|patch:{}|stride:{}|dh:{}|mc:{}|dld:{}|steps:{}|sched:{}|eta:{}|"
            "lh:{}|lp:{}|abl:{}|rc:{}|"
            "do:{}|pct:{}|bs:{}|ep:{}|pat:{}|lrj:{}|opt:{}"
        ).format(
            getattr(args, "patch_len", CONSTANTS["patch_len"]),
            getattr(args, "stride", CONSTANTS["stride"]),
            getattr(args, "d_hyp", CONSTANTS["d_hyp"]),
            getattr(args, "manifold_c", CONSTANTS["manifold_c"]),
            getattr(args, "d_layers_diff", CONSTANTS["d_layers_diff"]),
            getattr(args, "diff_steps", CONSTANTS["diff_steps"]),
            getattr(args, "diff_schedule", CONSTANTS["diff_schedule"]),
            getattr(args, "diff_eta", CONSTANTS["diff_eta"]),
            getattr(args, "lambda_hyp", CONSTANTS["lambda_hyp"]),
            getattr(args, "lambda_prior", CONSTANTS["lambda_prior"]),
            getattr(args, "ablation_group", getattr(args, "ablation", "none")),
            getattr(args, "revin", CONSTANTS["revin"]),
            getattr(args, "dropout", CONSTANTS["dropout"]),
            getattr(args, "pct_start", CONSTANTS["pct_start"]),
            getattr(args, "batch_size", CONSTANTS["batch_size"]),
            getattr(args, "train_epochs", CONSTANTS["train_epochs"]),
            getattr(args, "patience", CONSTANTS["patience"]),
            getattr(args, "lradj", CONSTANTS["lradj"]),
            getattr(args, "optim", CONSTANTS["optim"]),
        )
        setting = "{}_{}|{}|lr:{}|ft:{}|sl:{}|ll:{}|pl:{}|dm:{}|nh:{}|el:{}|df:{}{}{}|itr:{}".format(
            args.model_id,
            args.model,
            args.des,
            args.learning_rate,
            args.features,
            args.seq_len,
            args.label_len,
            args.pred_len,
            args.d_model,
            args.n_heads,
            args.e_layers,
            args.d_ff,
            m2patch_str,
            robustness_str,
            ii,
        )
        return setting
    setting = "{}_{}|{}|lr:{}|ft:{}|sl:{}|ll:{}|pl:{}|dm:{}|nh:{}|el:{}|dl:{}|df:{}|fc:{}|eb:{}|dt:{}|cs:{}{}|itr:{}".format(
        args.model_id,
        args.model,
        args.des,
        args.learning_rate,
        args.features,
        args.seq_len,
        args.label_len,
        args.pred_len,
        args.d_model,
        args.n_heads,
        args.e_layers,
        args.d_layers,
        args.d_ff,
        args.factor,
        args.embed,
        args.distil,
        args.class_strategy,
        robustness_str,
        ii,
    )
    return setting


def _cleanup_last_checkpoint(args, exp):
    if getattr(args, "keep_checkpoint", 0):
        return
    if not getattr(args, "cleanup_checkpoint", 0):
        return
    seq = getattr(exp, "_last_checkpoint_seq", None)
    if seq is None:
        return
    from src.utils.checkpoint import cleanup_checkpoint

    cleanup_checkpoint(args, seq)
    exp._last_checkpoint_seq = None


def _resolve_test_only_checkpoint(args):
    from src.utils.checkpoint import find_latest_checkpoint_seq

    if getattr(args, "checkpoint", 0) > 0:
        return args.checkpoint
    latest = find_latest_checkpoint_seq(args)
    if latest > 0:
        args.checkpoint = latest
        print("is_training=2: loading latest numbered checkpoint {} ".format(latest))
    else:
        print("is_training=2: no numbered checkpoint found, falling back to legacy checkpoint.pth")
    return args.checkpoint


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Time Series Forecasting", conflict_handler="resolve")

    if "__all__" in model_parser_dict:
        for common_parser in model_parser_dict["__all__"]:
            common_parser(parser=parser)

    temp_args, _ = parser.parse_known_args()
    if temp_args.model and temp_args.model in model_parser_dict:
        for model_parser in model_parser_dict[temp_args.model]:
            model_parser(parser=parser)

    args = parser.parse_args()

    if args.model is None:
        parser.error("the following arguments are required: --model")

    fix_seed = args.seed
    random.seed(fix_seed)
    torch.manual_seed(fix_seed)
    np.random.seed(fix_seed)

    args.use_gpu = True if torch.cuda.is_available() and args.use_gpu else False

    resolve_ablation(args)

    if args.use_gpu and args.use_multi_gpu:
        args.devices = args.devices.replace(" ", "")
        device_ids = args.devices.split(",")
        args.device_ids = [int(id_) for id_ in device_ids]
        args.gpu = args.device_ids[0]

    print("Args in experiment:")
    print(args)

    if args.exp_name == "partial_train":
        Exp = Exp_Long_Term_Forecast_Partial
    else:
        Exp = Exp_Long_Term_Forecast

    torch.multiprocessing.set_sharing_strategy("file_system")

    if getattr(args, "checkpoint", 0) > 0:
        from src.utils.checkpoint import checkpoint_exists, _ckpt_prefix, cleanup_checkpoint

        prefix = _ckpt_prefix(args)
        if not checkpoint_exists(args, args.checkpoint):
            print(f"ERROR: Checkpoint {prefix}_{args.checkpoint}.pth not found")
            sys.exit(1)
        setting = "{}_{}|{}|checkpoint:{}|itr:0".format(
            args.model_id, args.model, args.des, args.checkpoint
        )
        exp = Exp(args)
        print(
            ">>>>>>>continued training from checkpoint {}>>>>>>>>>>>>>>>>>>>>>>>>>>".format(
                args.checkpoint
            )
        )
        exp.train(setting)
        print(">>>>>>>testing : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<".format(setting))
        exp.test(setting)
        if args.do_predict:
            print(
                ">>>>>>>predicting : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<".format(
                    setting
                )
            )
            exp.predict(setting, True)

        _lr_seq = getattr(exp, "_lr_checkpoint_to_cleanup", None)
        if _lr_seq is not None:
            cleanup_checkpoint(args, _lr_seq)
            exp._last_checkpoint_seq = None

        _cleanup_last_checkpoint(args, exp)

        torch.cuda.empty_cache()
    elif args.is_training == 1:
        for ii in range(args.itr):
            robustness_str = _build_robustness_str(args)

            setting = _build_setting(args, robustness_str, ii)

            exp = Exp(args)
            print(
                ">>>>>>>start training : {}>>>>>>>>>>>>>>>>>>>>>>>>>>".format(setting)
            )
            exp.train(setting)

            print(
                ">>>>>>>testing : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<".format(setting)
            )
            exp.test(setting)

            if args.do_predict:
                print(
                    ">>>>>>>predicting : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<".format(
                        setting
                    )
                )
                exp.predict(setting, True)

            if getattr(exp, "_lr_checkpoint_to_cleanup", None) is not None:
                from src.utils.checkpoint import cleanup_checkpoint
                cleanup_checkpoint(args, exp._lr_checkpoint_to_cleanup)
                exp._last_checkpoint_seq = None

            _cleanup_last_checkpoint(args, exp)

            torch.cuda.empty_cache()
    elif args.is_training == 2:
        _resolve_test_only_checkpoint(args)
        robustness_str = _build_robustness_str(args)
        setting = _build_setting(args, robustness_str, 0)
        exp = Exp(args)
        print(">>>>>>>testing : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<".format(setting))
        exp.test(setting, test=1)
        torch.cuda.empty_cache()
