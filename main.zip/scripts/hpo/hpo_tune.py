#!/usr/bin/env python
import argparse
import gc
import os
import signal
import subprocess
import sys
import time
import traceback

import numpy as np
import optuna
import torch.multiprocessing

torch.multiprocessing.set_sharing_strategy("file_system")

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from src.configs.m2patch_profiles import D_FF_CAP
from src.hpo.objective import create_objective, resolve_fixed_params
from src.hpo.study_manager import create_study, export_results, make_best_callback
from src.hpo.suggest_overrides import get_dataset_config, PRED_LENS_BY_DATASET
from src.hpo.gpu_budget import MultiGPUBudget, estimate_m2patch_memory_mb, TOTAL_GPU_MEMORY_MB
from src.hpo.search_space import build_search_space, get_fixed_params
from src.hpo.warm_start import initialize_study
from src.utils.result_io import canonical_dataset

_stop_requested = False
_current_study = None


def _handle_sigterm(signum, frame):
    global _stop_requested, _current_study
    _stop_requested = True
    if _current_study is not None:
        _current_study.stop()


signal.signal(signal.SIGTERM, _handle_sigterm)


def _get_max_hyperparams(dataset_name: str, pred_len: int) -> dict:
    space = build_search_space(dataset_name, pred_len)
    fixed = get_fixed_params(dataset_name, pred_len)
    return {
        "d_model": max(space["d_model"]["choices"]),
        "d_ff": min(max(space["d_model"]["choices"]) * 2, D_FF_CAP),
        "e_layers": max(space["e_layers"]["choices"]),
        "patch_len": min(space["patch_len"]["choices"]),
        "stride": min(space["stride"]["choices"]),
        "d_hyp": max(space["d_hyp"]["choices"]),
        "d_layers_diff": max(space["d_layers_diff"]["choices"]),
        "diff_steps": max(space["diff_steps"]["choices"]),
        "batch_size": fixed["batch_size"],
    }


def _detect_physical_gpu(default: int = 0) -> int:
    cvd = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if cvd:
        first = cvd.split(",")[0].strip()
        if first.isdigit():
            return int(first)
    return default


def main():
    parser = argparse.ArgumentParser(description="M2Patch HPO with Optuna")
    parser.add_argument("--dataset", type=str, required=True, help="Dataset name")
    parser.add_argument(
        "--pred_len", type=str, default="all", help="Prediction length, or 'all'"
    )
    parser.add_argument("--n_trials", type=int, default=50, help="Number of trials")
    parser.add_argument(
        "--metric",
        type=str,
        default="mse",
        choices=["mse", "mae"],
        help="Test metric optimized by Optuna (default: mse)",
    )
    parser.add_argument(
        "--resume", action="store_true", default=True, help="Resume from existing Study"
    )
    parser.add_argument(
        "--timeout", type=int, default=None, help="Total timeout (seconds)"
    )
    parser.add_argument("--gpu", type=int, default=0, help="Starting physical GPU index")
    parser.add_argument(
        "--nodes",
        type=int,
        default=1,
        help="Number of GPUs (1=single GPU, >1=multi GPU mode)",
    )
    parser.add_argument(
        "--train_epochs",
        type=int,
        default=0,
        help="Override training epochs (0=use study default 15)",
    )
    parser.add_argument(
        "--patience",
        type=int,
        default=5,
        help="Early stopping patience (default: 5)",
    )
    parser.add_argument(
        "--bg",
        action="store_true",
        default=False,
        help="Redirect output to a fresh unique log/optuna/{dataset}_{pl}_study_{timestamp}_{us}_{pid}.log",
    )
    parser.add_argument(
        "--log_file",
        type=str,
        default=None,
        help="Explicit log file path owned by this process (overrides --bg path generation)",
    )
    parser.add_argument(
        "--save_tmp",
        type=int,
        default=1,
        help="Save temp .npy files (1=yes, 0=no)",
    )
    parser.add_argument(
        "--use_amp",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Enable AMP training inside trials (default: disabled)",
    )
    parser.add_argument(
        "--warm_start",
        type=int,
        default=1,
        choices=[0, 1],
        help="Warm start from exact-horizon best_params JSON (1=enabled, default; 0=disabled)",
    )
    args = parser.parse_args()

    args.dataset = canonical_dataset(args.dataset)
    dataset_name = args.dataset
    dataset_config = get_dataset_config(dataset_name)

    if args.pred_len == "all":
        pred_lens = PRED_LENS_BY_DATASET.get(dataset_name, [96, 192, 336, 720])
    else:
        pred_lens = [int(args.pred_len)]

    os.environ.setdefault("OMP_NUM_THREADS", "4")

    gpu_manager = None
    physical_ids = []

    if args.nodes > 1:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=index", "--format=csv,noheader"],
            capture_output=True, text=True,
        )
        system_gpu_count = len(result.stdout.strip().split("\n"))

        physical_ids = list(range(args.gpu, args.gpu + args.nodes))
        if max(physical_ids) >= system_gpu_count:
            print(f"ERROR: Requested GPUs {physical_ids} but system has {system_gpu_count}")
            sys.exit(1)

        os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(g) for g in physical_ids)

        import torch
        torch.cuda.init()
        for g in range(args.nodes):
            _ = torch.cuda.get_device_name(g)

        gpu_ids = list(range(args.nodes))

        gpu_manager = MultiGPUBudget(gpu_ids)
        print(f"Multi-GPU mode: {args.nodes} GPUs (physical {physical_ids}, runtime {gpu_ids})")
    else:
        if "CUDA_VISIBLE_DEVICES" not in os.environ:
            os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
        gpu_ids = None
        print(f"Single GPU mode: CUDA_VISIBLE_DEVICES={os.environ["CUDA_VISIBLE_DEVICES"]}")

    any_study_error = False
    total_finite_complete = 0

    for pred_len in pred_lens:
        if _stop_requested:
            break

        _log_file = None
        if args.log_file is not None:
            _log_path = args.log_file
            os.makedirs(os.path.dirname(os.path.abspath(_log_path)), exist_ok=True)
            _log_file = open(_log_path, "w", buffering=1)
            print(f"[LOG] {args.dataset}_pl{pred_len}: writing to {_log_path}")
        elif args.bg:
            os.makedirs("log/optuna", exist_ok=True)
            _stamp = time.strftime("%Y%m%d_%H%M%S")
            _us = f"{int(time.time() * 1_000_000) % 1_000_000:06d}"
            _log_path = os.path.join(
                "log", "optuna",
                f"{args.dataset}_{pred_len}_study_{_stamp}_{_us}_{os.getpid()}.log",
            )
            _log_file = open(_log_path, "w", buffering=1)
            print(f"[LOG] {args.dataset}_pl{pred_len}: writing to {_log_path}")
        if _log_file is not None:
            sys.stdout = _log_file
            sys.stderr = _log_file

        reserved_gpu = None
        study_tag = f"{args.dataset}_pl{pred_len}"

        try:
            if gpu_manager is not None:
                max_params = _get_max_hyperparams(args.dataset, pred_len)
                study_mb = estimate_m2patch_memory_mb(
                    enc_in=dataset_config["enc_in"],
                    d_model=max_params["d_model"],
                    d_ff=max_params["d_ff"],
                    seq_len=dataset_config.get("seq_len", 96),
                    pred_len=pred_len,
                    batch_size=max_params["batch_size"],
                    e_layers=max_params["e_layers"],
                    patch_len=max_params["patch_len"],
                    stride=max_params["stride"],
                    d_hyp=max_params["d_hyp"],
                    d_layers_diff=max_params["d_layers_diff"],
                    diff_steps=max_params["diff_steps"],
                )
                study_mb = min(study_mb * 1.1, TOTAL_GPU_MEMORY_MB)
                reserved_gpu = gpu_manager.reserve(study_tag, study_mb, timeout=7200)
                if reserved_gpu is None:
                    print(f"SKIP {study_tag}: GPU reservation timeout")
                    continue
                gpu_for_study = reserved_gpu
                physical_gpu_for_study = physical_ids[reserved_gpu]
            else:
                gpu_for_study = args.gpu
                physical_gpu_for_study = _detect_physical_gpu(args.gpu)

            study_name = f"M2Patch_{args.dataset}_pl{pred_len}"
            print(f"\n{"="*60}")
            print(f"Study: {study_name}")
            print(
                f"Dataset: {args.dataset} | pred_len: {pred_len} | Optimization Target: {args.metric.upper()}"
            )
            print(f"{"="*60}")

            seq_len = dataset_config.get("seq_len", 96)
            label_len = dataset_config.get("label_len", 48)

            train_epochs = args.train_epochs
            if train_epochs <= 0:
                train_epochs = get_fixed_params(args.dataset, pred_len)["train_epochs"]

            fixed_params = {
                **dataset_config,
                "dataset": args.dataset,
                "seq_len": seq_len,
                "label_len": label_len,
                "pred_len": pred_len,
                "model_id": f"{args.dataset}_{seq_len}_{pred_len}",
                "model": "M2Patch",
                "des": "HPO_OPTUNA",
                "gpu": gpu_for_study,
                "train_epochs": train_epochs,
                "patience": args.patience,
                "save_tmp": args.save_tmp,
                "batch_size": get_fixed_params(args.dataset, pred_len)["batch_size"],
                "use_amp": bool(args.use_amp),
                "num_workers": 2,
            }

            fixed_params = resolve_fixed_params(fixed_params)
            search_space = build_search_space(args.dataset, pred_len)
            print(
                f"Initialization config: warm_start={args.warm_start} | profile_anchor=1 | "
                f"dropout={fixed_params['dropout']} (fixed) | pct_start={fixed_params['pct_start']} (fixed)"
            )

            study = create_study(
                study_name=study_name,
                direction="minimize",
                metric=args.metric,
                train_epochs=fixed_params["train_epochs"],
                patience=fixed_params["patience"],
                batch_size=fixed_params["batch_size"],
                use_amp=fixed_params["use_amp"],
                search_space_spec=search_space,
                seed=fixed_params.get("seed", 2023),
                fixed_params=fixed_params,
            )

            initialize_study(
                study,
                args.dataset,
                pred_len,
                search_space,
                fixed_params,
                warm_start=bool(args.warm_start),
            )

            global _current_study
            _current_study = study

            objective = create_objective(
                fixed_params=fixed_params,
                metric=args.metric,
                physical_gpu=physical_gpu_for_study,
                stop_check=lambda: _stop_requested,
            )

            callbacks = [make_best_callback(study_name, args.metric)]

            if args.resume:
                completed = len(
                    [t for t in study.trials if t.state.is_finished()]
                )
                remaining = max(0, args.n_trials - completed)
                print(
                    f"Resuming Study, {completed} trials completed, {remaining} trials remaining"
                )
                if remaining == 0:
                    print("Study target budget reached; summarizing existing results.")
                else:
                    study.optimize(
                        objective,
                        n_trials=remaining,
                        timeout=args.timeout,
                        callbacks=callbacks,
                    )
            else:
                study.optimize(
                    objective,
                    n_trials=args.n_trials,
                    timeout=args.timeout,
                    callbacks=callbacks,
                )

            completed_trials = [
                t for t in study.trials
                if t.state == optuna.trial.TrialState.COMPLETE
            ]
            finite_complete = [
                t for t in completed_trials
                if t.value is not None and np.isfinite(t.value)
            ]
            total_finite_complete += len(finite_complete)
            if completed_trials:
                print(f"\nBest Trial:")
                print(f"  Value ({args.metric}): {study.best_value:.6f}")
                best_params_display = dict(study.best_params)
                user_attrs = dict(study.best_trial.user_attrs)
                for key in ["batch_size", "seed"]:
                    if key in user_attrs:
                        best_params_display[key] = user_attrs[key]
                print(f"  Params:")
                for k, v in best_params_display.items():
                    print(f"    {k}: {v}")

                export_results(study_name)
            else:
                print("\nNo completed trials — skipping best trial summary.")
        except Exception as e:
            any_study_error = True
            print(f"ERROR in {study_tag}: {e}")
            traceback.print_exc()
        finally:
            _current_study = None
            if reserved_gpu is not None and gpu_manager is not None:
                gpu_manager.unreserve(study_tag)
            gc.collect()

            try:
                import torch
                torch.cuda.empty_cache()
            except Exception:
                pass

            if _log_file is not None:
                sys.stdout = sys.__stdout__
                sys.stderr = sys.__stderr__
                _log_file.close()

    print("\nAll Study completed.")

    if any_study_error or total_finite_complete == 0:
        print(
            "ERROR: HPO run produced no usable result "
            f"(study_exceptions={'yes' if any_study_error else 'no'}, "
            f"finite_complete_trials={total_finite_complete})"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
