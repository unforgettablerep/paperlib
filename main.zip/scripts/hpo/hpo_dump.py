#!/usr/bin/env python
import argparse
import glob
import os
import sys

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from src.hpo.study_manager import (
    TEMP_OPTUNA_DIR,
    export_results,
    load_study,
    study_db_exists,
)
from src.hpo.suggest_overrides import PRED_LENS_BY_DATASET
from src.utils.result_io import canonical_dataset


def _resolve_study_names(dataset: str, pl: str) -> list[str]:
    """Build the list of study names to dump.

    When dataset == "all", scan temp/optuna for M2Patch_*.db files on disk
    (optionally filtered by pl) so every existing study is covered without
    depending on PRED_LENS_BY_DATASET.
    """
    if dataset == "all":
        pattern = os.path.join(TEMP_OPTUNA_DIR, "M2Patch_*.db")
        names = [
            os.path.splitext(os.path.basename(f))[0]
            for f in sorted(glob.glob(pattern))
        ]
        if pl != "all":
            suffix = f"_pl{pl}"
            names = [n for n in names if n.endswith(suffix)]
        return names

    if pl == "all":
        pred_lens = PRED_LENS_BY_DATASET.get(canonical_dataset(dataset), [96, 192, 336, 720])
    else:
        pred_lens = [int(pl)]
    return [f"M2Patch_{dataset}_pl{pred_len}" for pred_len in pred_lens]


def _dump_study(study_name: str) -> bool:
    if not study_db_exists(study_name):
        print(f"[SKIP] {study_name}: database file not found")
        return False

    try:
        study = load_study(study_name)
    except Exception as e:
        print(f"[SKIP] {study_name}: study not found ({e})")
        return False

    try:
        best = study.best_trial
    except ValueError:
        print(f"[SKIP] {study_name}: no completed trials yet")
        return False

    df = export_results(study_name)
    print(
        f"[OK]   {study_name}: best_mse={study.best_value:.6f}, "
        f"trial #{best.number}, {len(df)} trials exported"
    )
    return True


def main():
    parser = argparse.ArgumentParser(description="Dump current best Optuna results")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="Dataset name, or 'all' to scan every study on disk",
    )
    parser.add_argument(
        "--pl",
        type=str,
        required=True,
        help="Prediction length, or 'all' for every horizon",
    )
    args = parser.parse_args()

    study_names = _resolve_study_names(args.dataset, args.pl)

    if not study_names:
        print(
            f"[INFO] No studies found to dump "
            f"(dataset={args.dataset}, pl={args.pl})."
        )
        print("\nDone. 0 studies exported.")
        return

    ok_count = 0
    for study_name in study_names:
        if _dump_study(study_name):
            ok_count += 1

    print(f"\nDone. {ok_count}/{len(study_names)} studies exported.")


if __name__ == "__main__":
    main()
