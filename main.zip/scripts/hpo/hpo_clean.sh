#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'EOF'
Usage:
    bash scripts/hpo/hpo_clean.sh --dataset ETTh1 --pl 96
    bash scripts/hpo/hpo_clean.sh --dataset ETTh1 --pl 96 --confirm
    bash scripts/hpo/hpo_clean.sh --dataset ETTh1 --pl 96 --dry-run
    bash scripts/hpo/hpo_clean.sh --dataset ETTh1 --pl 96 --confirm --full

Options:
    --dataset, -d   Dataset name (ETTh1, Weather, ECL, ...)
    --pl, -p        Prediction length (96, 192, 336, 720, ...)
    --confirm, -y   Skip confirmation prompt
    --dry-run       Show what would be deleted without deleting
    --full          Also delete best_params.json, results CSV, and study logs
    --force         Proceed even if m2patch Slurm jobs are running for this user
    --help, -h      Show this help
EOF
}

SQUEUE_BIN="/usr/local/slurm/bin/squeue"

DATASET=""
PL=""
CONFIRM=false
DRY_RUN=false
FULL=false
FORCE=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --dataset|-d)
            DATASET="$2"
            shift 2
            ;;
        --pl|-p)
            PL="$2"
            shift 2
            ;;
        --confirm|-y)
            CONFIRM=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --full)
            FULL=true
            shift
            ;;
        --force)
            FORCE=true
            shift
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

if [[ -z "$DATASET" ]]; then
    echo "Error: --dataset is required"
    echo ""
    usage
    exit 1
fi

if [[ -z "$PL" ]]; then
    echo "Error: --pl is required"
    echo ""
    usage
    exit 1
fi

STUDY="M2Patch_${DATASET}_pl${PL}"
DB_FILE="./temp/optuna/${STUDY}.db"
BEST_PARAMS="./output/optuna/${STUDY}_best_params.json"
RESULTS_CSV="./output/optuna/csv/${STUDY}_results.csv"

TARGETS=()

add_target() {
    [[ -e "$1" ]] && TARGETS+=("$1") || true
}

add_target "$DB_FILE"
if [[ "$FULL" == true ]]; then
    add_target "$BEST_PARAMS"
    add_target "$RESULTS_CSV"
    for log_file in ./log/optuna/"${DATASET}_${PL}"_study_*.log; do
        add_target "$log_file"
    done
fi

if [[ ! -e "$DB_FILE" ]]; then
    echo "No database found for study: $STUDY"
    echo ""
fi
if [[ ${#TARGETS[@]} -eq 0 ]]; then
    exit 0
fi

echo "Study: $STUDY"
echo ""
echo "Files to delete:"
for target in "${TARGETS[@]}"; do
    echo "  - $target"
done
echo ""

if [[ "$DRY_RUN" == true ]]; then
    echo "[dry-run] No files deleted."
    exit 0
fi

if [[ "$FORCE" != true && -x "$SQUEUE_BIN" ]]; then
    running_jobs="$("$SQUEUE_BIN" -u "$USER" -h -o "%j" 2>/dev/null | grep -i "m2patch" || true)"
    if [[ -n "$running_jobs" ]]; then
        echo "Error: user $USER has running Slurm jobs matching 'm2patch':" >&2
        echo "$running_jobs" >&2
        echo "Refusing to delete a study that may still be in use; pass --force to override." >&2
        exit 1
    fi
fi

if [[ "$CONFIRM" == false ]]; then
    read -rp "Delete ${#TARGETS[@]} item(s) for study $STUDY? [y/N] " answer
    if [[ "$answer" != "y" && "$answer" != "Y" ]]; then
        echo "Aborted."
        exit 0
    fi
fi

for target in "${TARGETS[@]}"; do
    rm -rf -- "$target"
    echo "  Deleted: $target"
done

echo ""
if [[ "$FULL" == true ]]; then
    echo "Done. Study $STUDY cleaned (DB plus --full targets above)."
else
    echo "Done. Study $STUDY database cleaned (best_params.json and CSV preserved)."
fi
