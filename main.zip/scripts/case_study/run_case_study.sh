#!/bin/bash
# Case study runner: M2Patch vs MMPD/S_Mamba/iTransformer/PatchTST on ETTm2,
# ETTm1, ECL and Exchange (lookback 96 -> horizon CASE_STUDY_PL, default 96).
# Runs one cell per GPU slot in waves and skips cells already recorded in
# output/case_study/case_study.tsv (result_done).
#
# Usage:
#   scripts/case_study/run_case_study.sh
#   CASE_STUDY_PL=96 CASE_STUDY_GPUS="0" scripts/case_study/run_case_study.sh
#
# Logs: log/case_study/all.log (stdout), log/case_study/{DS}_{MODEL}.log

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$REPO_ROOT" || exit 1

source scripts/utils/result_common.sh

export PYTHON_BIN=${PYTHON_BIN:-/home/ubuntu/miniconda3/envs/m2p/bin/python}

PL=${CASE_STUDY_PL:-96}
read -ra GPUS <<< "${CASE_STUDY_GPUS:-0}"

DATASETS=(ETTm2 ETTm1 ECL Exchange)
MODELS=(M2Patch MMPD S_Mamba iTransformer PatchTST)

mkdir -p log/case_study
for ds in "${DATASETS[@]}"; do
    mkdir -p "output/case_study/record_${ds}"
done

export CASE_STUDY_MODE=1
export CASE_STUDY_PL=$PL

SPECS=()
for ds in "${DATASETS[@]}"; do
    for model in "${MODELS[@]}"; do
        SPECS+=("${ds}:${model}")
    done
done

cell_done() {
    local ds=$1
    local model=$2
    result_done "output/case_study/case_study.tsv" \
        "model=${model}" "dataset=${ds}" "seq_len=96" "pred_len=${PL}" "des=CASESTUDY"
}

echo "==================================================================="
echo "Case study: datasets=(${DATASETS[*]}) pred_len=${PL}"
echo "models=(${MODELS[*]})  GPUs=${GPUS[*]}"
echo "==================================================================="

FAILED=()
i=0
while (( i < ${#SPECS[@]} )); do
    wave=()
    for gpu in "${GPUS[@]}"; do
        (( i < ${#SPECS[@]} )) || break
        wave+=("${SPECS[$i]}:${gpu}")
        i=$((i + 1))
    done

    pids=()
    for cell in "${wave[@]}"; do
        ds=${cell%%:*}
        rest=${cell#*:}
        model=${rest%%:*}
        gpu=${rest##*:}
        name="${ds}/${model}"

        if cell_done "$ds" "$model"; then
            echo "[skip] ${name} already recorded"
            continue
        fi

        echo "[start] ${name} on GPU ${gpu}"
        (
            export CUDA_VISIBLE_DEVICES=$gpu
            bash "scripts/case_study/${ds}/${model}.sh"
        ) > "log/case_study/${ds}_${model}.log" 2>&1 &
        pids+=("$!;${name}")
    done

    for entry in "${pids[@]}"; do
        pid=${entry%%;*}
        name=${entry#*;}
        if wait "$pid"; then
            echo "[done] ${name}"
        else
            echo "[fail] ${name}"
            FAILED+=("$name")
        fi
    done
done

echo "-------------------------------------------------------------------"
for ds in "${DATASETS[@]}"; do
    bash output/case_study/collect_results.sh "$ds"
done
echo "-------------------------------------------------------------------"

echo "All case-study runs finished"
if [[ ${#FAILED[@]} -gt 0 ]]; then
    echo "[summary] failed cells: ${FAILED[*]}"
    exit 1
fi
echo "[summary] all cells completed"
