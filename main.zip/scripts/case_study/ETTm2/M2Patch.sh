#!/bin/bash
# Case study: M2Patch on ETTm2, lookback 96 -> horizon 96.

set -euo pipefail
cd "$(dirname "$0")/../../.." || exit 1
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}

PYTHON_BIN=${PYTHON_BIN:-/home/ubuntu/miniconda3/envs/m2p/bin/python}
flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli ETTm2 96 --from-optuna --with-meta)

"$PYTHON_BIN" -u scripts/run.py $flags \
    --is_training 1 \
    --model M2Patch \
    --des CASESTUDY \
    --inverse \
    --save_tmp 1 \
    --cleanup_checkpoint 1
