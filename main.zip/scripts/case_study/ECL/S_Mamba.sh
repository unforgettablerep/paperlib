#!/bin/bash
# Case study: S_Mamba on ECL, lookback 96 -> horizon 96.

set -euo pipefail
cd "$(dirname "$0")/../../.." || exit 1
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}

PYTHON_BIN=${PYTHON_BIN:-/home/ubuntu/miniconda3/envs/m2p/bin/python}

"$PYTHON_BIN" -u scripts/run.py \
    --is_training 1 \
    --root_path ./data/electricity/ \
    --data_path electricity.csv \
    --model_id ECL_96_96 \
    --model S_Mamba \
    --data custom \
    --features M \
    --freq h \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 96 \
    --enc_in 321 \
    --dec_in 321 \
    --c_out 321 \
    --e_layers 3 \
    --d_model 256 \
    --d_ff 512 \
    --n_heads 8 \
    --d_state 32 \
    --batch_size 16 \
    --learning_rate 5e-4 \
    --train_epochs 15 \
    --patience 5 \
    --des CASESTUDY \
    --itr 1 \
    --inverse \
    --save_tmp 1 \
    --cleanup_checkpoint 1 \
    --use_cuda_accel 0
