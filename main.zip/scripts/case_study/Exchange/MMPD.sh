#!/bin/bash
# Case study: MMPD on Exchange, lookback 96 -> horizon 96.

set -euo pipefail
cd "$(dirname "$0")/../../.." || exit 1
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}

PYTHON_BIN=${PYTHON_BIN:-/home/ubuntu/miniconda3/envs/m2p/bin/python}

"$PYTHON_BIN" -u scripts/run.py \
    --is_training 1 \
    --root_path ./data/exchange_rate/ \
    --data_path exchange_rate.csv \
    --model_id exchange_96_96 \
    --model MMPD \
    --data custom \
    --features M \
    --freq h \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 96 \
    --enc_in 8 \
    --dec_in 8 \
    --c_out 8 \
    --e_layers 2 \
    --d_model 256 \
    --d_ff 512 \
    --n_heads 4 \
    --d_layers 2 \
    --patch_size 12 \
    --d_diffusion 256 \
    --diffusion_layers 1 \
    --radius 3 \
    --max_diffusion_steps 1000 \
    --beta_schedule linear \
    --point_weight 0.01 \
    --weighted 1 \
    --sample_num 100 \
    --num_sampling_steps 20 \
    --dropout 0.2 \
    --batch_size 32 \
    --learning_rate 1e-4 \
    --lradj cosine \
    --optim Adam \
    --no-use_amp \
    --train_epochs 15 \
    --patience 5 \
    --des CASESTUDY \
    --itr 1 \
    --inverse \
    --save_tmp 1 \
    --cleanup_checkpoint 1
