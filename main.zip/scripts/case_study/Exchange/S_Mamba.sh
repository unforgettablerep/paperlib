#!/bin/bash
# Case study: S_Mamba on Exchange, lookback 96 -> horizon 96.

set -euo pipefail
cd "$(dirname "$0")/../../.." || exit 1
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}

PYTHON_BIN=${PYTHON_BIN:-/home/ubuntu/miniconda3/envs/m2p/bin/python}

"$PYTHON_BIN" -u scripts/run.py \
    --is_training 1 \
    --root_path ./data/exchange_rate/ \
    --data_path exchange_rate.csv \
    --model_id exchange_96_96 \
    --model S_Mamba \
    --data custom \
    --features M \
    --freq h \
    --seq_len 96 \
    --label_len 48 \
    --pred_len 96 \
    --enc_in 8 \
    --dec_in 8 \
    --c_out 8 \
    --e_layers 2 \
    --d_model 256 \
    --d_ff 512 \
    --n_heads 8 \
    --d_state 2 \
    --batch_size 32 \
    --learning_rate 5e-5 \
    --train_epochs 15 \
    --patience 5 \
    --des CASESTUDY \
    --itr 1 \
    --inverse \
    --save_tmp 1 \
    --cleanup_checkpoint 1
