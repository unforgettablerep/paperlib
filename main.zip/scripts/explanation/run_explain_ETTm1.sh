#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
set -euo pipefail

export CUDA_VISIBLE_DEVICES=${1:-0}
dataset=ETTm1
pred_len=96
flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" "$pred_len" --from-optuna --with-meta)

echo "=== M2Patch explanation run — ETTm1 (full train+test) ==="

"$PYTHON_BIN" -u scripts/run.py $flags \
    --is_training 1 \
    --model M2Patch \
    --des "EXPLAIN" \
    --explanation all

echo "=== All ETTm1 explanation runs complete. Metrics in ./output/explanation/metrics/ ==="
echo "Run notebooks in output/explanation/ to generate figures."
