#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
set -euo pipefail

export CUDA_VISIBLE_DEVICES=${1:-0}
export METRICS_ROOT="./output/explanation/metrics"
dataset=ETTm1

run_explain() {
    local base_pl=$1
    local pred_len=$2
    shift 2
    local flags
    flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" "$base_pl" --with-meta)

    "$PYTHON_BIN" -u scripts/run.py $flags \
        --is_training 1 \
        --model M2Patch \
        --model_id "${dataset}_96_${pred_len}" \
        --pred_len "$pred_len" \
        "$@"
}

echo "--- Section A: loss-ablation explanation (3 variants, pl=96) ---"
run_explain 96 96 --des "EXPLAIN_LnoIntra" --lambda_hyp 0.0 --lambda_prior 0.1 --explanation manifold
run_explain 96 96 --des "EXPLAIN_LnoInter" --lambda_hyp 0.1 --lambda_prior 0.0 --explanation manifold
run_explain 96 96 --des "EXPLAIN_LpureForecast" --lambda_hyp 0.0 --lambda_prior 0.0 --explanation manifold

echo "--- Section B: longer-horizon explanation (pl=192, pl=384) ---"
run_explain 192 192 --des "EXPLAIN" --explanation all
run_explain 336 384 --des "EXPLAIN" --explanation all

echo "All supplementary explanation runs complete. Metrics in ${METRICS_ROOT}/"
