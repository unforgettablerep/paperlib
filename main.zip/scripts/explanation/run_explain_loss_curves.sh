#!/bin/bash
# Capture the per-iteration training loss decomposition (total / bridge / hyp /
# prior) for the mechanism figure's diffusion-dynamics panel. Runs the Optuna
# best configuration so the loss trajectory matches the mechanism suite, then
# copies loss_history.json into output/mechanism/ where the plot script looks
# first.
#
# Usage:
#   bash scripts/explanation/run_explain_loss_curves.sh [gpu] [datasets...]
#   bash scripts/explanation/run_explain_loss_curves.sh 0 ETTh2 Exchange

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$REPO_ROOT" || exit 1

PYTHON_BIN=${PYTHON_BIN:-/home/ubuntu/miniconda3/envs/m2p/bin/python}
PRED_LEN=${PRED_LEN:-96}
GPU=${1:-0}
shift || true
DATASETS=("$@")
if [[ ${#DATASETS[@]} -eq 0 ]]; then
    DATASETS=(ETTh2 Exchange)
fi

export CUDA_VISIBLE_DEVICES="$GPU"
mkdir -p output/mechanism log/explanation

for dataset in "${DATASETS[@]}"; do
    flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" "$PRED_LEN" --from-optuna --with-meta)
    echo "=== M2Patch loss-curve explanation — ${dataset} pl=${PRED_LEN} ==="
    "$PYTHON_BIN" -u scripts/run.py $flags \
        --is_training 1 \
        --model M2Patch \
        --des EXPLAIN_LOSS \
        --explanation training \
        2>&1 | tee "log/explanation/${dataset}_pl${PRED_LEN}_loss_curve.log"

    model_id=$("$PYTHON_BIN" - "$dataset" "$PRED_LEN" <<'PY'
import sys
from src.configs.m2patch_profiles import resolve_meta

print(resolve_meta(sys.argv[1], int(sys.argv[2]))["model_id"])
PY
)
    latest=$(ls -dt output/explanation/metrics/"${model_id}"_M2Patch_EXPLAIN_LOSS_l*_itr0 2>/dev/null | head -1)
    if [[ -z "$latest" ]]; then
        echo "[error] no explanation metrics dir for ${dataset}" >&2
        exit 1
    fi
    cp "${latest}/loss_history.json" "output/mechanism/loss_history_${dataset}_pl${PRED_LEN}.json"
    echo "[loss-curve] ${dataset} -> output/mechanism/loss_history_${dataset}_pl${PRED_LEN}.json"
done

echo "Loss-curve explanation runs complete."
