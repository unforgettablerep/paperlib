#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=48:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-hpo-b5
#SBATCH --output=log/slurm/%x-%j.out
#
# Submit:   sbatch scripts/batch/batch_5.sh
# Monitor:  squeue -u $USER ; tail -f log/optuna/${Dataset}_${pl}_study_*.log
# Cancel:   scancel <jobid>

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm log/optuna

STUDIES=(
    "Solar:96:200:3"
    "Solar:192:200:2"
    "Solar:336:200:1"
    "Solar:720:200:0"
)

PIDS=()
for line in "${STUDIES[@]}"; do
    ds=$(echo "$line" | cut -d: -f1)
    pl=$(echo "$line" | cut -d: -f2)
    trials=$(echo "$line" | cut -d: -f3)
    gpu=$(echo "$line" | cut -d: -f4)
    log_file="log/optuna/${ds}_${pl}_study_$(date +%Y%m%d_%H%M%S).log"
    CUDA_VISIBLE_DEVICES="$gpu" python scripts/hpo/hpo_tune.py \
        --dataset "$ds" --pred_len "$pl" --n_trials "$trials" \
        --gpu 0 --metric mse --save_tmp 0 \
        >> "$log_file" 2>&1 &
    study_pid=$!
    PIDS+=("$study_pid")
    echo "[$(date +%H:%M:%S)] Launched ${ds} pred_len=${pl} (${trials} trials) on GPU ${gpu} (PID ${study_pid})"
done

FAIL=0
for pid in "${PIDS[@]}"; do
    wait "$pid" || FAIL=$((FAIL + 1))
done

if [ "$FAIL" -gt 0 ]; then
    echo "ERROR: ${FAIL}/${#STUDIES[@]} study/studies failed. Check log/optuna/*_study_*.log"
    exit 1
fi
echo "[$(date +%H:%M:%S)] All ${#STUDIES[@]} HPO studies completed."
