#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=48:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-lookback
#SBATCH --output=log/slurm/%x-%j.out

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm log/lookback

PARA=1
GPUS_STR="0,1,2,3"

LAUNCH_LOG="$(mktemp)"
trap 'rm -f "$LAUNCH_LOG"' EXIT

echo "[$(date +%H:%M:%S)] Launching lookback runner (GPUs: ${GPUS_STR}, slots/GPU: ${PARA})"
bash scripts/increasing_lookback/run-lookback.sh --gpu "${GPUS_STR}" --para "${PARA}" "$@" 2>&1 | tee "$LAUNCH_LOG"

# The runner detaches via nohup + disown, so it is no longer a child of this
# shell and wait(1) cannot track it. Parse the PID it printed and poll
# /proc/$PID with `tail --pid` to keep the SLURM job alive until it finishes.
RUNNER_PID=$(grep -oE 'PID [0-9]+' "$LAUNCH_LOG" | tail -1 | awk '{print $2}' || true)

if [[ -z "${RUNNER_PID:-}" ]]; then
    echo "ERROR: could not parse lookback runner PID from launcher output."
    exit 1
fi

LOG_FILE="log/lookback/scheduler.log"
echo "[$(date +%H:%M:%S)] Lookback runner detached as PID ${RUNNER_PID}; waiting for completion..."
echo "  Log:  tail -f ${LOG_FILE}"

tail --pid="${RUNNER_PID}" -f /dev/null

if grep -qF 'experiment(s) finished' "$LOG_FILE"; then
    echo "[$(date +%H:%M:%S)] All lookback experiments completed."
else
    echo "[$(date +%H:%M:%S)] Lookback runner exited without the completion marker. Check ${LOG_FILE}"
    exit 1
fi
