#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=1-00:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-benchmark
#SBATCH --output=log/slurm/%x-%j.out
#
# Full M2Patch benchmark sweep (14 datasets x all horizons) via the forecast
# scheduler; results land in output/long_term_forecast/{Dataset}.tsv.
#
# Submit:   sbatch scripts/batch/batch_benchmark.sh
# Monitor:  squeue -u $USER ; tail -f log/multivariate_forecasting/scheduler.log
# Cancel:   scancel <jobid>

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm

PARA=1

if [[ -n "${CUDA_VISIBLE_DEVICES:-}" ]]; then
    GPUS_STR="${CUDA_VISIBLE_DEVICES// /,}"
else
    GPUS_STR="0,1,2,3"
fi
echo "[$(date +%H:%M:%S)] CUDA_VISIBLE_DEVICES='${CUDA_VISIBLE_DEVICES:-<unset>}' -> GPU set: ${GPUS_STR}"

LAUNCH_LOG="$(mktemp)"
trap 'rm -f "$LAUNCH_LOG"' EXIT

echo "[$(date +%H:%M:%S)] Launching forecast scheduler (GPUs: ${GPUS_STR}, slots/GPU: ${PARA})"
bash scripts/multivariate_forecasting/run_all_forecasts.sh --gpu "${GPUS_STR}" --para "$PARA" 2>&1 | tee "$LAUNCH_LOG"

RUNNER_PID=$(grep -oE 'PID [0-9]+' "$LAUNCH_LOG" | tail -1 | awk '{print $2}' || true)

if [[ -z "${RUNNER_PID:-}" ]]; then
    echo "ERROR: could not parse forecast scheduler PID from launcher output."
    exit 1
fi

LOG_FILE="log/multivariate_forecasting/scheduler.log"
echo "[$(date +%H:%M:%S)] Forecast scheduler detached as PID ${RUNNER_PID}; waiting for completion..."
echo "  Log:  tail -f ${LOG_FILE}"

tail --pid="${RUNNER_PID}" -f /dev/null

if grep "scheduler finished" "$LOG_FILE" | tail -1 | grep -q "fail=0"; then
    echo "[$(date +%H:%M:%S)] Benchmark sweep completed."
else
    echo "[$(date +%H:%M:%S)] Forecast scheduler exited with failures. Check ${LOG_FILE}"
    exit 1
fi
