#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=48:00:00 --mail-type=ALL
#SBATCH --job-name=hpo-b3
#
# Submit:   sbatch scripts/batch/batch_3.sh
# Monitor:  squeue -u $USER ; tail -f log/optuna/${Dataset}_${pl}_study_*.log
# Cancel:   scancel <jobid>

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm log/optuna temp/optuna

STUDIES=(
    "ETTh1:720:800:0"
    "ETTm1:336:800:2"
    "ETTm1:720:800:1"
    "ETTm2:96:800:0"
    "ETTm2:192:800:1"
    "ETTm2:336:800:2"
    "ETTm2:720:800:3"
    "ETTh2:96:800:0"
    "ETTh2:192:800:1"
    "ETTh2:336:800:2"
    "ETTh2:720:800:3"
)

if [ -n "${CUDA_VISIBLE_DEVICES:-}" ]; then
    IFS=',' read -r -a SLOT <<< "${CUDA_VISIBLE_DEVICES}"
else
    SLOT=(0 1 2 3)
fi
if [ "${#SLOT[@]}" -lt 4 ]; then
    echo "ERROR: expected 4 allocated GPUs, got ${#SLOT[@]} (CUDA_VISIBLE_DEVICES='${CUDA_VISIBLE_DEVICES:-}')"
    exit 1
fi

MANIFEST="temp/optuna/launch_manifest.tsv"
if [ ! -f "$MANIFEST" ]; then
    printf "timestamp\tdataset\tpred_len\tslot\tgpu\tpid\tlog\n" >> "$MANIFEST"
fi

PIDS=()
LABELS=()

on_terminate() {
    echo "[$(date +%H:%M:%S)] Termination signal received; notifying ${#PIDS[@]} study process(es) and waiting..."
    local pid
    for pid in "${PIDS[@]}"; do
        kill -TERM "$pid" 2>/dev/null || true
    done
    for pid in "${PIDS[@]}"; do
        wait "$pid" 2>/dev/null || true
    done
    echo "[$(date +%H:%M:%S)] All study processes exited after termination signal."
    exit 1
}
trap on_terminate TERM INT

for i in "${!STUDIES[@]}"; do
    line="${STUDIES[$i]}"
    ds=$(echo "$line" | cut -d: -f1)
    pl=$(echo "$line" | cut -d: -f2)
    trials=$(echo "$line" | cut -d: -f3)
    slot=$(echo "$line" | cut -d: -f4)
    gpu="${SLOT[$slot]}"
    log_file="log/optuna/${ds}_${pl}_study_$(date +%Y%m%d_%H%M%S).log"
    CUDA_VISIBLE_DEVICES="$gpu" python -u scripts/hpo/hpo_tune.py \
        --dataset "$ds" --pred_len "$pl" --n_trials "$trials" \
        --gpu 0 --metric mse --save_tmp 0 --warm_start 1 \
        >> "$log_file" 2>&1 &
    study_pid=$!
    PIDS+=("$study_pid")
    LABELS+=("${ds}_pl${pl}")
    printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$(date +%Y-%m-%dT%H:%M:%S)" "$ds" "$pl" "$slot" "$gpu" "$study_pid" "$log_file" | tee -a "$MANIFEST"
done

FAIL=0
for i in "${!PIDS[@]}"; do
    if ! wait "${PIDS[$i]}"; then
        echo "ERROR: study ${LABELS[$i]} (PID ${PIDS[$i]}) exited non-zero"
        FAIL=$((FAIL + 1))
    fi
done

if [ "$FAIL" -gt 0 ]; then
    echo "ERROR: ${FAIL}/${#STUDIES[@]} study/studies failed. Check log/optuna/*_study_*.log"
    exit 1
fi
echo "[$(date +%H:%M:%S)] All ${#STUDIES[@]} HPO studies completed."
