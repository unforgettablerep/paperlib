#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=1-00:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-illness
#SBATCH --output=log/slurm/%x-%j.out
# M2Patch Illness training: 4 pred_lens (24/36/48/60) across 4x RTX 4090.
# One pred_len per GPU, launched in parallel; config comes from
# src.configs.m2patch_profiles via the m2patch_cli emitter.
#
# Submit:   sbatch scripts/batch/batch_illness.sh
# Monitor:  squeue -u $USER ; tail -f log/batch_illness_pl*.log
# Cancel:   scancel <jobid>
# Results:  output/long_term_forecast/Illness.tsv
# Per-run:  log/batch_illness_pl{24,36,48,60}_gpu{0,1,2,3}.log

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm output/long_term_forecast

PREDS=(24 36 48 60)
PIDS=()
for i in "${!PREDS[@]}"; do
    pl=${PREDS[$i]}
    gpu=$i
    flags=$($PYTHON_BIN -m src.configs.m2patch_cli Illness "$pl" --with-meta)
    CUDA_VISIBLE_DEVICES="$gpu" $PYTHON_BIN -u scripts/run.py \
        --is_training 1 \
        --des MULTI_PRED \
        --model M2Patch \
        $flags \
        > "log/batch_illness_pl${pl}_gpu${gpu}.log" 2>&1 &
    study_pid=$!
    PIDS+=("$study_pid")
    echo "[$(date +%H:%M:%S)] Launched Illness pred_len=${pl} on GPU ${gpu} (PID ${study_pid})"
done

FAIL=0
for pid in "${PIDS[@]}"; do
    wait "$pid" || FAIL=$((FAIL + 1))
done

if [ "$FAIL" -gt  0 ]; then
    echo "ERROR: ${FAIL}/${#PREDS[@]} job(s) failed. Check log/batch_illness_*.log"
    exit 1
fi
echo "[$(date +%H:%M:%S)] All ${#PREDS[@]} Illness experiments completed."
