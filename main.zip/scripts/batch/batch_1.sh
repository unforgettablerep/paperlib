#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:1 --time=3-00:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-hpo-b1
#SBATCH --output=log/slurm/%x-%j.out

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm

# hpo_batch.sh detaches each study (fire-and-forget): this script returns
# immediately and the studies keep running in the background. Per-study logs:
# log/optuna/; PID files: temp/optuna/pids/; monitor: poe hpo-list.
bash scripts/hpo/hpo_batch.sh --n_gpus 1 --save_tmp 0 \
    --study "PEMS03:24:400:0" \
    --study "PEMS07:24:400:0" \
    --study "PEMS07:48:400:0" \
    --study "PEMS07:96:400:0"

# Experiment menu, single-GPU mode (every study pinned to GPU 0). To enable an
# entry, uncomment it and append it to the hpo_batch.sh call above.
#
# PEMS03 (400 trials)
# --study "PEMS03:48:400:0"  \
# --study "PEMS03:96:400:0"
#
# PEMS04 (200 trials)
# --study "PEMS04:12:200:0"  \
# --study "PEMS04:24:200:0"  \
# --study "PEMS04:48:200:0"  \
# --study "PEMS04:96:200:0"
#
# PEMS07 (200 trials; 24/48/96 already active above at 400 trials)
# --study "PEMS07:12:200:0"
#
# PEMS08 (200 trials)
# --study "PEMS08:12:200:0"  \
# --study "PEMS08:24:200:0"  \
# --study "PEMS08:48:200:0"  \
# --study "PEMS08:96:200:0"
#
# Traffic (200 trials)
# --study "Traffic:336:200:0"  \
# --study "Traffic:720:200:0"
#
# ECL (200 trials)
# --study "ECL:96:200:0"   \
# --study "ECL:192:200:0"  \
# --study "ECL:336:200:0"  \
# --study "ECL:720:200:0"
#
# Weather (200 trials)
# --study "Weather:96:200:0"   \
# --study "Weather:192:200:0"
#
# Solar (200 trials)
# --study "Solar:96:200:0"   \
# --study "Solar:192:200:0"  \
# --study "Solar:336:200:0"  \
# --study "Solar:720:200:0"
#
# ETTm1 (200 trials)
# --study "ETTm1:96:200:0"   \
# --study "ETTm1:192:200:0"  \
# --study "ETTm1:336:200:0"  \
# --study "ETTm1:720:200:0"
#
# ETTm2 (200 trials)
# --study "ETTm2:96:200:0"   \
# --study "ETTm2:192:200:0"  \
# --study "ETTm2:336:200:0"  \
# --study "ETTm2:720:200:0"
