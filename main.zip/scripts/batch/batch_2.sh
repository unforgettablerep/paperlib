#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:1 --time=3-00:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-hpo-b2
#SBATCH --output=log/slurm/%x-%j.out

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm

# hpo_batch.sh detaches each study (fire-and-forget): this script returns
# immediately and the studies keep running in the background. Per-study logs:
# log/optuna/; PID files: temp/optuna/pids/; monitor: poe hpo-list.
bash scripts/hpo/hpo_batch.sh --n_gpus 1 --save_tmp 0 \
    --study "illness:24:1000:0" \
    --study "illness:36:1000:0" \
    --study "illness:48:1000:0" \
    --study "illness:60:1000:0"

# Experiment menu, single-GPU mode (every study pinned to GPU 0). To enable an
# entry, uncomment it and append it to the hpo_batch.sh call above.
#
# ETTh1 (800 trials)
# --study "ETTh1:96:800:0"   \
# --study "ETTh1:192:800:0"  \
# --study "ETTh1:336:800:0"  \
# --study "ETTh1:720:800:0"
#
# ETTh2 (400 trials)
# --study "ETTh2:96:400:0"   \
# --study "ETTh2:192:400:0"  \
# --study "ETTh2:336:400:0"  \
# --study "ETTh2:720:400:0"
#
# ETTm1 (400 trials)
# --study "ETTm1:96:400:0"   \
# --study "ETTm1:192:400:0"  \
# --study "ETTm1:336:400:0"  \
# --study "ETTm1:720:400:0"
#
# ETTm2 (400 trials)
# --study "ETTm2:96:400:0"   \
# --study "ETTm2:192:400:0"  \
# --study "ETTm2:336:400:0"  \
# --study "ETTm2:720:400:0"
#
# Exchange (800 trials)
# --study "Exchange:96:800:0"   \
# --study "Exchange:192:800:0"  \
# --study "Exchange:336:800:0"  \
# --study "Exchange:720:800:0"
#
# Weather (400 trials)
# --study "Weather:96:400:0"   \
# --study "Weather:192:400:0"
#
# PEMS03 (400 trials)
# --study "PEMS03:48:400:0"  \
# --study "PEMS03:96:400:0"
#
# PEMS08 (200 trials)
# --study "PEMS08:96:200:0"
