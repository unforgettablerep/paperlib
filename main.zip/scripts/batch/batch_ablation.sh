#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=48:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-ablation
#SBATCH --output=log/slurm/%x-%j.out

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
mkdir -p log/slurm log/ablation

PARA=2
GPUS=(0 1 2 3)

LAUNCH_LOG="$(mktemp)"
trap 'rm -f "$LAUNCH_LOG"' EXIT

echo "[$(date +%H:%M:%S)] Launching ablation runner (GPUs: ${GPUS[*]}, slots/GPU: ${PARA})"
bash scripts/ablation/run_all_ablation.sh --para "$PARA" "${GPUS[@]}" 2>&1 | tee "$LAUNCH_LOG"

RUNNER_PID=$(grep -oE 'PID [0-9]+' "$LAUNCH_LOG" | tail -1 | awk '{print $2}' || true)

if [[ -z "${RUNNER_PID:-}" ]]; then
    echo "ERROR: could not parse ablation runner PID from launcher output."
    exit 1
fi

LOG_FILE="log/ablation/all.log"
echo "[$(date +%H:%M:%S)] Ablation runner detached as PID ${RUNNER_PID}; waiting for completion..."
echo "  Log:  tail -f ${LOG_FILE}"

tail --pid="${RUNNER_PID}" -f /dev/null

if grep -q "All variants finished" "$LOG_FILE"; then
    echo "[$(date +%H:%M:%S)] All ablation variants completed."
else
    echo "[$(date +%H:%M:%S)] Ablation runner exited without the completion marker. Check ${LOG_FILE}"
    exit 1
fi
