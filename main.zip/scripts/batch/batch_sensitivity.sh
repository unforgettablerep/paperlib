#!/bin/bash
#SBATCH --nodes=1 --gres=gpu:rtx_4090:4 --time=48:00:00 --mail-type=ALL
#SBATCH --job-name=m2patch-sensitivity
#SBATCH --output=log/slurm/%x-%j.out

set -euo pipefail

. "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate m2p
export PYTHON_BIN="$(command -v python)"

REPO_ROOT="${SLURM_SUBMIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
cd "$REPO_ROOT"
source scripts/utils/result_common.sh
mkdir -p log/slurm log/hyperparam

PARA=2
GPUS=(0 1 2 3)
SENSITIVITY_DATASETS="${SENSITIVITY_DATASETS:-ETTh1 ETTh2 ETTm1 Weather Exchange}"
export SENSITIVITY_DATASETS

LAUNCH_LOG="$(mktemp)"
trap 'rm -f "$LAUNCH_LOG"' EXIT

echo "[$(date +%H:%M:%S)] Launching sensitivity runner (GPUs: ${GPUS[*]}, slots/GPU: ${PARA})"
bash scripts/hyperparam/launch_sensitivity.sh --para "$PARA" "${GPUS[@]}" 2>&1 | tee "$LAUNCH_LOG"

RUNNER_PID=$(grep -oE 'PID [0-9]+' "$LAUNCH_LOG" | tail -1 | awk '{print $2}' || true)

if [[ -z "${RUNNER_PID:-}" ]]; then
    echo "ERROR: could not parse sensitivity runner PID from launcher output."
    exit 1
fi

LOG_FILE="log/hyperparam/all.log"
echo "[$(date +%H:%M:%S)] Sensitivity runner detached as PID ${RUNNER_PID}; waiting for completion..."
echo "  Log:  tail -f ${LOG_FILE}"

tail --pid="${RUNNER_PID}" -f /dev/null

if grep -q "All sensitivity cells finished" "$LOG_FILE"; then
    echo "[$(date +%H:%M:%S)] Sensitivity sweep completed."
    read -ra _SENS_DATASETS <<< "$SENSITIVITY_DATASETS"
    SWEEP_CELLS=$(
        python scripts/hyperparam/run_sensitivity.py --list-sweeps |
            awk -F'\t' '{ n += split($2, values, " ") } END { print n+0 }'
    )
    EXPECTED=$(( ${#_SENS_DATASETS[@]} * SWEEP_CELLS * 5 ))
    ACTUAL=0
    for result_file in output/hyperparam/sensitivity_results_*.tsv; do
        [[ -f "$result_file" ]] || continue
        ACTUAL=$((ACTUAL + $(result_count_ok "$result_file")))
    done
    echo "  Result rows (status=ok): ${ACTUAL} / ${EXPECTED}"
else
    echo "[$(date +%H:%M:%S)] Sensitivity runner exited without the completion marker. Check ${LOG_FILE}"
    exit 1
fi
