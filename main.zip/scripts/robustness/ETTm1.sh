#!/bin/bash
DATASET=ETTm1
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/robustness_common.sh"

if [[ "${1:-all}" == "all" ]]; then
    for pl in 96 192 336 720; do
        run_pl "$pl" || exit 1
    done
else
    run_pl "$1" || exit 1
fi
