#!/bin/bash
# Shared zero-shot noise protocol: one clean training run, then test-only passes per noise level.
PYTHON_BIN=${PYTHON_BIN:-python}
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/utils/result_common.sh"

MODEL=${model_name:-M2Patch}
DES=${des:-ROBUSTNESS}
SEED=${seed:-2023}
SEQ_LEN=${seq_len:-96}
PHASE=${phase:-all}
TRAIN_EPOCHS=${train_epochs:-}

FULL_NOISE_LEVELS=(0.1 0.2 0.3 0.5)
if [[ -n "${noise_level:-}" ]]; then
    NOISE_LEVELS=("$noise_level")
else
    read -ra NOISE_LEVELS <<< "${NOISE_LEVELS:-0.1 0.2 0.3 0.5}"
fi

ROBUSTNESS_OUTPUT_DIR=${ROBUSTNESS_OUTPUT_DIR:-./output/robustness}
export ROBUSTNESS_OUTPUT_DIR
RESULT_FILE="${ROBUSTNESS_OUTPUT_DIR}/${DATASET}_robustness.tsv"
CKPT_DIR="./temp/checkpoints/${DATASET}"
STATE_DIR="./temp/robustness"

_result_done() {
    local pl=$1 nl=$2
    result_done "$RESULT_FILE" "dataset=${DATASET}" "seq_len=${SEQ_LEN}" "pred_len=${pl}" "noise_level=${nl}"
}

_ckpt_prefix() {
    echo "${DATASET}_${MODEL}_sl${SEQ_LEN}_pl${1}_${DES}"
}

_latest_seq() {
    local pl=$1 prefix
    prefix=$(_ckpt_prefix "$pl")
    find "$CKPT_DIR" -maxdepth 1 -type f -name "${prefix}_*.pth" -printf '%f\n' 2>/dev/null \
        | sed -n "s/^${prefix}_\([0-9][0-9]*\)\.pth$/\1/p" \
        | sort -n | tail -n 1
}

_seq_file() {
    echo "${STATE_DIR}/${DATASET}_pl${1}.seq"
}

_extra_train_flags() {
    if [[ -n "$TRAIN_EPOCHS" ]]; then
        printf '%s\n' "--train_epochs" "$TRAIN_EPOCHS"
    fi
}

train_clean() {
    local pl=$1 flags
    local -a extra=()
    mapfile -t extra < <(_extra_train_flags)
    flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$DATASET" "$pl" --with-meta)

    "$PYTHON_BIN" -u scripts/run.py $flags \
        --is_training 1 \
        --model "$MODEL" \
        --des "$DES" \
        --seed "$SEED" \
        --itr 1 \
        --noise_level 0.0 \
        --keep_checkpoint 1 \
        --save_tmp 0 \
        "${extra[@]}"

    local seq
    seq=$(_latest_seq "$pl")
    if [[ -z "$seq" ]]; then
        echo "ERROR: no clean checkpoint found after training ${DATASET} pl=${pl}" >&2
        return 1
    fi
    mkdir -p "$STATE_DIR"
    printf '%s\n' "$seq" > "$(_seq_file "$pl")"
    echo "[${DATASET} pl=${pl}] clean checkpoint seq=${seq}"
}

test_noise() {
    local pl=$1 nl=$2 flags
    flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$DATASET" "$pl" --with-meta)

    "$PYTHON_BIN" -u scripts/run.py $flags \
        --is_training 2 \
        --model "$MODEL" \
        --des "$DES" \
        --seed "$SEED" \
        --noise_level "$nl" \
        --save_tmp 0
}

cleanup_clean_checkpoint() {
    local pl=$1 seq_file prefix seq
    seq_file=$(_seq_file "$pl")
    [[ -f "$seq_file" ]] || return 0
    seq=$(cat "$seq_file")
    prefix=$(_ckpt_prefix "$pl")
    rm -f "${CKPT_DIR}/${prefix}_${seq}.pth"
    rm -f "$seq_file"
    echo "[${DATASET} pl=${pl}] cleaned checkpoint seq=${seq}"
}

_all_noise_done() {
    local pl=$1 nl
    _result_done "$pl" "0.0" || return 1
    for nl in "${FULL_NOISE_LEVELS[@]}"; do
        _result_done "$pl" "$nl" || return 1
    done
    return 0
}

run_pl() {
    local pl=$1 nl skipped=1
    local -a pending=()
    for nl in "${NOISE_LEVELS[@]}"; do
        if ! _result_done "$pl" "$nl"; then
            pending+=("$nl")
        fi
    done

    if [[ "$PHASE" != "test" ]]; then
        if ! _result_done "$pl" "0.0" || { [[ ${#pending[@]} -gt 0 ]] && [[ -z "$(_latest_seq "$pl")" ]]; }; then
            train_clean "$pl" || return 1
        fi
    fi

    if [[ "$PHASE" == "train" ]]; then
        echo "[${DATASET} pl=${pl}] phase=train only, checkpoint kept for test phase"
        return 0
    fi

    if [[ ${#pending[@]} -gt 0 ]] && [[ -z "$(_latest_seq "$pl")" ]]; then
        echo "ERROR: no checkpoint available for ${DATASET} pl=${pl}; run PHASE=train first" >&2
        return 1
    fi

    for nl in "${NOISE_LEVELS[@]}"; do
        if _result_done "$pl" "$nl"; then
            echo "[skip] ${DATASET} pl=${pl} nl=${nl} already in ${RESULT_FILE}"
            continue
        fi
        skipped=0
        test_noise "$pl" "$nl" || return 1
    done

    if [[ "$PHASE" == "all" ]] && _all_noise_done "$pl"; then
        cleanup_clean_checkpoint "$pl"
    elif [[ $skipped -eq 1 ]]; then
        echo "[skip] ${DATASET} pl=${pl} all requested noise levels already complete"
    fi
}
