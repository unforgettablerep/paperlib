#!/bin/bash
# Robustness testing runner: one clean training run per (dataset, pred_len), then zero-shot noise tests.

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$REPO_ROOT" || exit 1

export ROBUSTNESS_OUTPUT_DIR="${ROBUSTNESS_OUTPUT_DIR:-./output/robustness}"

PARA=1
GPU_IDS=("0")
DATASETS=("ETTm1" "ETTm2")
PRED_LENS=("96" "192" "336" "720")
NOISE_LEVELS_STR="0.1 0.2 0.3 0.5"
PHASE="all"

dataset_arg="all"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --para)
            PARA="$2"
            shift 2
            ;;
        --gpu)
            IFS=',' read -ra GPU_IDS <<< "$2"
            shift 2
            ;;
        --phase)
            PHASE="$2"
            shift 2
            ;;
        --noise_levels|--noise-levels)
            NOISE_LEVELS_STR="$2"
            shift 2
            ;;
        --noise_level|--noise-level)
            NOISE_LEVELS_STR="$2"
            shift 2
            ;;
        -h|--help|help)
            echo "Usage: $0 [--para N] [--gpu ID[,ID...]] [--phase {all,train,test}] [--noise_levels \"L ...\"] [dataset]"
            echo ""
            echo "Options:"
            echo "  --para N          Max concurrent experiments per GPU (default: 1)"
            echo "  --gpu IDs         CUDA devices, comma-separated (default: 0)"
            echo "  --phase MODE      all = train + all noise tests + cleanup (default)"
            echo "                    train = clean training only, keep checkpoint"
            echo "                    test  = noise tests only, reuse existing checkpoint"
            echo "  --noise_levels S  Space-separated test noise levels (default: 0.1 0.2 0.3 0.5)"
            echo "  dataset           Dataset to test: ${DATASETS[*]}, or 'all' (default: all)"
            echo ""
            echo "Examples:"
            echo "  $0                                  # Full protocol, sequential"
            echo "  $0 --para 4                         # 4 pred_lens in parallel"
            echo "  $0 --para 2 --gpu 0,1 ETTm2         # 2 per GPU across GPU 0,1"
            echo "  $0 --noise_levels \"0.2\"            # Single noise level"
            exit 0
            ;;
        *)
            dataset_arg="$1"
            shift
            ;;
    esac
done

unset noise_level

echo -e "${BLUE}M2Patch Robustness Testing Runner (zero-shot noise)${NC}"
echo "Repository root: $REPO_ROOT"
echo "Output directory: $ROBUSTNESS_OUTPUT_DIR"
echo "Parallel slots:   ${PARA} per GPU"
echo "GPUs:             ${GPU_IDS[*]}"
echo "Phase:            ${PHASE}"
echo ""

validate_dataset() {
    local dataset=$1
    for d in "${DATASETS[@]}"; do
        if [[ "$d" == "$dataset" ]]; then return 0; fi
    done
    echo -e "${RED}Error: Unknown dataset: $dataset${NC}"
    echo "Available datasets: ${DATASETS[*]}"
    exit 1
}

datasets_to_run=()
if [[ "$dataset_arg" == "all" ]]; then
    datasets_to_run=("${DATASETS[@]}")
else
    validate_dataset "$dataset_arg"
    datasets_to_run=("$dataset_arg")
fi

echo -e "${YELLOW}Datasets:     ${datasets_to_run[*]}${NC}"
echo -e "${YELLOW}Pred lens:    ${PRED_LENS[*]}${NC}"
echo -e "${YELLOW}Noise levels: ${NOISE_LEVELS_STR}${NC}"
echo ""

JOBS=()
for dataset in "${datasets_to_run[@]}"; do
    for pl in "${PRED_LENS[@]}"; do
        JOBS+=("$dataset $pl")
    done
done

total_jobs=${#JOBS[@]}
echo -e "${CYAN}Total experiments: ${total_jobs}${NC}"
echo ""

active_pids=()
active_gpus=()

_reap() {
    local new_pids=()
    local new_gpus=()
    for i in "${!active_pids[@]}"; do
        if kill -0 "${active_pids[$i]}" 2>/dev/null; then
            new_pids+=("${active_pids[$i]}")
            new_gpus+=("${active_gpus[$i]}")
        fi
    done
    active_pids=("${new_pids[@]}")
    active_gpus=("${new_gpus[@]}")
}

_gpu_active_count() {
    local gpu=$1
    local count=0
    for g in "${active_gpus[@]}"; do
        if [[ "$g" == "$gpu" ]]; then
            count=$((count + 1))
        fi
    done
    echo $count
}

_wait_for_slot() {
    while true; do
        _reap
        for gpu in "${GPU_IDS[@]}"; do
            local cnt
            cnt=$(_gpu_active_count "$gpu")
            if [[ $cnt -lt $PARA ]]; then
                echo "$gpu"
                return
            fi
        done
        sleep 2
    done
}

completed=0
failed=0
declare -A job_status

for i in "${!JOBS[@]}"; do
    read -r dataset pl <<< "${JOBS[$i]}"
    job_num=$((i + 1))

    gpu=$(_wait_for_slot)

    echo -e "${BLUE}[$job_num/$total_jobs] ${dataset} pl=${pl} → GPU ${gpu}${NC}"

    log_dir="${LOG_DIR:-${REPO_ROOT}/log/robustness}"
    mkdir -p "$log_dir"
    log_file="${log_dir}/${dataset}_pl${pl}.log"

    (
        {
            echo "===== $(date '+%F %T') phase=${PHASE} noise=[${NOISE_LEVELS_STR}] ====="
            CUDA_VISIBLE_DEVICES="$gpu" \
            PHASE="$PHASE" \
            NOISE_LEVELS="$NOISE_LEVELS_STR" \
            bash "./scripts/robustness/${dataset}.sh" "$pl"
        } >> "$log_file" 2>&1
    ) &

    active_pids+=($!)
    active_gpus+=("$gpu")
    job_status[$!]="$dataset pl=$pl"
done

echo -e "${YELLOW}Waiting for ${#active_pids[@]} active experiments...${NC}"

for pid in "${active_pids[@]}"; do
    if wait "$pid"; then
        completed=$((completed + 1))
    else
        failed=$((failed + 1))
        echo -e "${RED}FAILED: ${job_status[$pid]} (log: ${REPO_ROOT}/log/robustness/)${NC}"
    fi
done

echo -e "\n${BLUE}=================================================================${NC}"
echo -e "${BLUE}Robustness Testing Summary${NC}"
echo -e "${BLUE}=================================================================${NC}"
echo -e "Total:     ${total_jobs}"
echo -e "Completed: ${GREEN}${completed}${NC}"
echo -e "Failed:    ${RED}${failed}${NC}"
echo -e "Results:   ${ROBUSTNESS_OUTPUT_DIR}/"
echo -e "Logs:      ${REPO_ROOT}/log/robustness/"

if [[ $failed -eq 0 ]]; then
    echo -e "\n${GREEN}All tests completed successfully!${NC}"
    exit 0
else
    echo -e "\n${YELLOW}${failed} experiment(s) failed${NC}"
    exit 1
fi
