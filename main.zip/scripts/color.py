nature_palette = [
    "#E64B35",
    "#3C5488",
    "#00A087",
    "#4DBBD5",
    "#8491B4",
    "#E18727",
    "#7E6148",
    "#B09C85",
]

hex_palette = [
    "#E64B35",
    "#3C5488",
    "#F9D5D0",
    "#D9E2EC",
    "#00A087",
    "#CCECE6",
    "#4DBBD5",
    "#E18727",
]

purple_palette = ["#E64B35", "#3C5488", "#F9D5D0", "#D9E2EC"]
green_blue_palette = ["#00A087", "#CCECE6", "#4DBBD5", "#3C5488"]

color_dict = {
    "purple_dark1": "#E64B35",
    "purple_dark2": "#7E6148",
    "purple_light1": "#F9D5D0",
    "purple_light2": "#D9E2EC",
    "green_main": "#00A087",
    "green_mint": "#CCECE6",
    "blue_light": "#4DBBD5",
    "blue_dark": "#3C5488",
    "npg_red": "#E64B35",
    "npg_blue": "#3C5488",
    "npg_green": "#00A087",
    "npg_cyan": "#4DBBD5",
    "npg_slate": "#8491B4",
    "npg_amber": "#E18727",
    "npg_brown": "#7E6148",
    "npg_sand": "#B09C85",
}

neutral_dict = {
    "ink": "#262626",
    "grid": "#b8b8b8",
    "hairline": "#d0d0d0",
    "frame": "#3f3f3f",
    "surface": "#ffffff",
}
