import os
import json
import time
import numpy as np
import pandas as pd
import torch

OUT_DIR = "./output/channel_correlation"

DATASETS = [
    ("ETTh1", "./data/ETT-small/ETTh1.pt", None),
    ("ETTh2", "./data/ETT-small/ETTh2.pt", None),
    ("ETTm1", "./data/ETT-small/ETTm1.pt", None),
    ("ETTm2", "./data/ETT-small/ETTm2.pt", None),
    ("Weather", "./data/weather/weather.pt", -9999.0),
    ("ECL", "./data/electricity/electricity.pt", None),
    ("Exchange", "./data/exchange_rate/exchange_rate.pt", None),
    ("Traffic", "./data/traffic/traffic.pt", None),
    ("Illness", "./data/illness/national_illness.pt", None),
    ("Solar", "./data/Solar/solar_AL.pt", None),
    ("PEMS03", "./data/PEMS/PEMS03.pt", None),
    ("PEMS04", "./data/PEMS/PEMS04.pt", None),
    ("PEMS07", "./data/PEMS/PEMS07.pt", None),
    ("PEMS08", "./data/PEMS/PEMS08.pt", None),
]


def load_values(pt_path):
    cached = torch.load(pt_path, weights_only=False)
    values = cached["values"].astype(np.float64)              # [T, C]
    columns = cached.get("columns")
    if columns is not None:
        cols = [c for c in columns if c != "date"]
    else:
        cols = [f"ch{i}" for i in range(values.shape[1])]      # Solar/PEMS: unnamed
    return values, cols


def mask_sentinel(values, sentinel):
    if sentinel is None:
        return values, 0
    mask = values == sentinel
    n_bad = int(mask.sum())
    if n_bad == 0:
        return values, 0
    out = values.copy()
    out[mask] = np.nan
    return out, n_bad


def pearson_matrix(values, has_nan):
    if has_nan:
        return pd.DataFrame(values).corr().values              # pairwise complete
    return np.corrcoef(values, rowvar=False)                   # [C, C], fast path


def upper_tri_values(R):
    C = R.shape[0]
    iu = np.triu_indices(C, k=1)
    r = R[iu]
    return r[~np.isnan(r)]


def summarize(r_vals):
    if r_vals.size == 0:
        keys = (
            "mean_abs", "median_abs", "std", "frac_gt_05", "frac_gt_08",
            "frac_lt_02", "mean_pos", "mean_neg", "max", "min",
        )
        return {key: float("nan") for key in keys}
    abs_r = np.abs(r_vals)
    pos = r_vals[r_vals > 0]
    neg = r_vals[r_vals < 0]
    return {
        "mean_abs": float(abs_r.mean()),
        "median_abs": float(np.median(abs_r)),
        "std": float(r_vals.std()),
        "frac_gt_05": float((abs_r > 0.5).mean()),
        "frac_gt_08": float((abs_r > 0.8).mean()),
        "frac_lt_02": float((abs_r < 0.2).mean()),
        "mean_pos": float(pos.mean()) if pos.size else float("nan"),
        "mean_neg": float(neg.mean()) if neg.size else float("nan"),
        "max": float(r_vals.max()),
        "min": float(r_vals.min()),
    }


def top_pairs(R, cols, k=5):
    C = R.shape[0]
    iu0, iu1 = np.triu_indices(C, k=1)
    r_flat = R[iu0, iu1]
    valid = ~np.isnan(r_flat)
    iu0, iu1, r_flat = iu0[valid], iu1[valid], r_flat[valid]
    order = np.argsort(r_flat)
    top_pos = [(cols[iu0[i]], cols[iu1[i]], float(r_flat[i])) for i in order[-k:][::-1]]
    top_neg = [(cols[iu0[i]], cols[iu1[i]], float(r_flat[i])) for i in order[:k]]
    return {"top_positive": top_pos, "top_negative": top_neg}


def process(name, pt_path, sentinel):
    t0 = time.time()
    values, cols = load_values(pt_path)
    T, C = values.shape
    values, n_bad = mask_sentinel(values, sentinel)
    has_nan = bool(np.isnan(values).any())

    R_raw = pearson_matrix(values, has_nan)
    diff = np.diff(values, axis=0)                             # [T-1, C], NaN propagates
    has_nan_diff = bool(np.isnan(diff).any())
    R_diff = pearson_matrix(diff, has_nan_diff)

    r_raw = upper_tri_values(R_raw)
    r_diff = upper_tri_values(R_diff)
    s_raw = summarize(r_raw)
    s_diff = summarize(r_diff)
    pairs_raw = top_pairs(R_raw, cols)
    pairs_diff = top_pairs(R_diff, cols)

    elapsed = time.time() - t0
    print(
        f"{name:9s} T={T:6d} C={C:4d} bad={n_bad:8d}  "
        f"mean|r| raw={s_raw["mean_abs"]:.3f} diff={s_diff["mean_abs"]:.3f}  "
        f"%>0.5 raw={s_raw["frac_gt_05"]*100:5.1f}% "
        f"diff={s_diff["frac_gt_05"]*100:5.1f}%  "
        f"({elapsed:.1f}s)"
    )

    return {
        "name": name,
        "n_rows": int(T),
        "n_channels": int(C),
        "n_masked_sentinel": int(n_bad),
        "has_nan": has_nan,
        "raw": s_raw,
        "diff": s_diff,
        "pairs_raw": pairs_raw,
        "pairs_diff": pairs_diff,
    }


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    print("=" * 110)
    print(f"Channel correlation analysis (raw + first-difference Pearson). Out -> {OUT_DIR}")
    print("=" * 110)
    results = [process(n, p, s) for n, p, s in DATASETS]
    print("=" * 110)

    csv_path = os.path.join(OUT_DIR, "summary.csv")
    rows = []
    for r in results:
        rows.append({
            "dataset": r["name"],
            "channels": r["n_channels"],
            "rows": r["n_rows"],
            "raw_mean_abs_r": round(r["raw"]["mean_abs"], 4),
            "raw_median_abs_r": round(r["raw"]["median_abs"], 4),
            "raw_std_r": round(r["raw"]["std"], 4),
            "raw_frac_gt_0.5": round(r["raw"]["frac_gt_05"], 4),
            "raw_frac_gt_0.8": round(r["raw"]["frac_gt_08"], 4),
            "raw_frac_lt_0.2": round(r["raw"]["frac_lt_02"], 4),
            "raw_mean_pos_r": round(r["raw"]["mean_pos"], 4),
            "raw_mean_neg_r": round(r["raw"]["mean_neg"], 4),
            "raw_max_r": round(r["raw"]["max"], 4),
            "raw_min_r": round(r["raw"]["min"], 4),
            "diff_mean_abs_r": round(r["diff"]["mean_abs"], 4),
            "diff_median_abs_r": round(r["diff"]["median_abs"], 4),
            "diff_frac_gt_0.5": round(r["diff"]["frac_gt_05"], 4),
            "diff_frac_gt_0.8": round(r["diff"]["frac_gt_08"], 4),
            "diff_frac_lt_0.2": round(r["diff"]["frac_lt_02"], 4),
        })
    df = pd.DataFrame(rows)
    df.to_csv(csv_path, index=False)
    print(f"\nWrote {csv_path} ({len(df)} rows)")

    json_path = os.path.join(OUT_DIR, "summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"Wrote {json_path}")

    print("\n" + df.to_string(index=False))


if __name__ == "__main__":
    main()
