"""Cross-dataset Friedman, Nemenyi and Wilcoxon tests for M2Patch."""

import argparse
import csv
import json
import math
import os
import sys

import numpy as np

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from scipy.stats import chi2 as chi2_dist
from scipy.stats import f as f_dist
from scipy.stats import friedmanchisquare, rankdata, studentized_range, wilcoxon

from scripts.color import color_dict, neutral_dict
from src.utils.result_io import canonical_dataset, is_valid_result, read_results

M2PATCH = "M2Patch"
MODELS = [
    "M2Patch",
    "MMPD",
    "SimpleTM",
    "TimeMixer",
    "iTransformer",
    "PatchTST",
    "DLinear",
    "TimesNet",
]
CORE_DATASETS = ["ETTh2", "ETTm1", "Exchange"]
PENDING_DATASETS = [
    "ETTh1",
    "ETTm2",
    "Weather",
    "ECL",
    "Solar",
    "Traffic",
    "PEMS08",
    "Illness",
]
ALL_DATASETS = CORE_DATASETS + PENDING_DATASETS

STANDARD_PRED_LENS = [96, 192, 336, 720]
PRED_LENS = {ds: list(STANDARD_PRED_LENS) for ds in ALL_DATASETS}
PRED_LENS["Illness"] = [24, 36, 48, 60]
PRED_LENS["PEMS08"] = [12, 24, 48, 96]

ASSET_MODEL_COLUMNS = {
    "M2Patch": "M2Patch",
    "TimeMixer": "TimeMixer",
    "iTransformer": "iTransformer",
    "PatchTST": "PatchTST",
    "TimesNet": "TimesNet",
    "DLinear": "DLinear",
}

OPTUNA_DIR_DEFAULT = os.path.join(REPO_ROOT, "output", "optuna")
NONE_TSV_DEFAULT = os.path.join(REPO_ROOT, "output", "ablation", "none.tsv")
BENCHMARK_DIR_DEFAULT = os.path.join(REPO_ROOT, "output", "benchmark")
ASSETS_DEFAULT = os.path.join(REPO_ROOT, "assets", "m2p_eff_results_1.xlsx")

CSV_FIELDS = [
    "metric",
    "test",
    "model",
    "comparison",
    "n_blocks",
    "k",
    "statistic",
    "statistic_name",
    "f_iman_davenport",
    "df1",
    "df2",
    "p_value",
    "p_holm",
    "effect_size_r",
    "avg_rank",
    "cd",
    "q_alpha",
    "win",
    "tie",
    "loss",
    "n_pairs",
    "wilcoxon_method",
    "significant",
    "notes",
]

METRICS = ("mse", "mae")


def _fmt(value, digits=6):
    if value is None:
        return ""
    if isinstance(value, float):
        if not math.isfinite(value):
            return str(value)
        return f"{value:.{digits}g}"
    return str(value)


def _finite(value):
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def _read_tsv_cells(path, dataset, models):
    cells = {}
    if not os.path.isfile(path):
        return cells
    wanted = set(models)
    for row in read_results(path):
        if not is_valid_result(row):
            continue
        if canonical_dataset(row.get("dataset", "")) != dataset:
            continue
        model = str(row.get("model", ""))
        if model == "" and "M2Patch" in wanted:
            model = "M2Patch"
        if model not in wanted:
            continue
        des = str(row.get("des", ""))
        if model == "M2Patch" and des.startswith("ablation_") and des != "ablation_none":
            continue
        try:
            pred_len = int(float(row.get("pred_len", "")))
            cells.setdefault(model, {})[pred_len] = {
                "mse": float(row.get("mse", "")),
                "mae": float(row.get("mae", "")),
                "source": os.path.relpath(path, REPO_ROOT),
            }
        except (TypeError, ValueError):
            continue
    return cells


def _read_optuna_cell(dataset, pred_len, optuna_dir):
    candidates = PRED_LENS[dataset]
    shorter = [p for p in candidates if p <= pred_len]
    actual_pl = pred_len if pred_len in candidates else max(shorter or [min(candidates)])
    path = os.path.join(optuna_dir, f"M2Patch_{dataset}_pl{actual_pl}_best_params.json")
    if not os.path.isfile(path):
        path = os.path.join(optuna_dir, f"M2Patch_{dataset.lower()}_pl{actual_pl}_best_params.json")
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None
    attrs = data.get("best_trial_user_attrs") or {}
    mse = attrs.get("mse", attrs.get("test_mse", data.get("best_value")))
    mae = attrs.get("mae", attrs.get("test_mae"))
    if not (_finite(mse) and _finite(mae)):
        return None
    return {
        "mse": float(mse),
        "mae": float(mae),
        "source": "optuna:" + os.path.relpath(path, REPO_ROOT),
    }


def _asset_column_map(header):
    lookup = {name.lower(): model for model, name in ASSET_MODEL_COLUMNS.items()}
    mapping = {}
    for idx, label in enumerate(header):
        if not isinstance(label, str):
            continue
        base = label.split("(")[0].strip().lower()
        model = lookup.get(base)
        if model is not None:
            mapping[model] = idx
    if header[0] == "Models" and "M2Patch" in mapping:
        return mapping
    return {}


def _load_assets(path):
    """Return {(dataset, pred_len): {model: {mse, mae}}} from the curated main table."""
    if not os.path.isfile(path):
        return {}
    try:
        from openpyxl import load_workbook
    except ImportError:
        print(f"[WARN] openpyxl unavailable; cannot read {path}")
        return {}

    workbook = load_workbook(path, read_only=True, data_only=True)
    if "Results" not in workbook.sheetnames:
        return {}
    rows = list(workbook["Results"].iter_rows(min_row=1, values_only=True))
    header_idx = None
    for idx, row in enumerate(rows):
        if row and row[0] == "Models":
            header_idx = idx
            break
    if header_idx is None:
        return {}
    columns = _asset_column_map(rows[header_idx])
    if not columns:
        return {}

    data = {}
    current_dataset = None
    known = set(ALL_DATASETS)
    for row in rows[header_idx + 1 :]:
        if not row:
            continue
        first = row[0]
        if isinstance(first, str):
            if first == "Metric":
                continue
            candidate = canonical_dataset(first)
            if candidate in known:
                current_dataset = candidate
            else:
                break
        if current_dataset is None:
            continue
        second = row[1]
        if second in ("Avg", None) or isinstance(second, str):
            continue
        try:
            pred_len = int(second)
        except (TypeError, ValueError):
            continue
        if pred_len not in PRED_LENS[current_dataset]:
            continue
        for model, col in columns.items():
            try:
                mse = float(row[col])
                mae = float(row[col + 1])
            except (TypeError, ValueError, IndexError):
                continue
            if _finite(mse) and _finite(mae):
                data.setdefault((current_dataset, pred_len), {})[model] = {
                    "mse": mse,
                    "mae": mae,
                    "source": os.path.relpath(path, REPO_ROOT),
                }
    return data


def build_matrix(args):
    assets = {} if args.no_assets else _load_assets(args.assets)
    matrix = {}
    missing = []

    for dataset in ALL_DATASETS:
        benchmark_path = os.path.join(args.benchmark_dir, f"{dataset}.tsv")
        benchmark = _read_tsv_cells(benchmark_path, dataset, [m for m in MODELS if m != M2PATCH])
        m2p = _read_tsv_cells(args.none_tsv, dataset, [M2PATCH]).get(M2PATCH, {})
        for pred_len in PRED_LENS[dataset]:
            block = {}
            if pred_len in m2p:
                block[M2PATCH] = m2p[pred_len]
            else:
                fallback = _read_optuna_cell(dataset, pred_len, args.optuna_dir)
                if fallback is not None:
                    block[M2PATCH] = fallback
            for model in MODELS:
                if model == M2PATCH:
                    continue
                cell = benchmark.get(model, {}).get(pred_len)
                if cell is None:
                    cell = assets.get((dataset, pred_len), {}).get(model)
                if cell is not None:
                    block[model] = cell
            matrix[(dataset, pred_len)] = block
            for model in MODELS:
                if model not in block:
                    missing.append((dataset, pred_len, model))
    return matrix, missing, assets


def _scope_datasets(include_all):
    return list(ALL_DATASETS) if include_all else list(CORE_DATASETS)


def _write_matrix_csv(path, matrix, test_datasets):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "dataset",
                "pred_len",
                "model",
                "mse",
                "mae",
                "source",
                "status",
                "note",
            ],
        )
        writer.writeheader()
        for dataset in ALL_DATASETS:
            for pred_len in PRED_LENS[dataset]:
                block = matrix.get((dataset, pred_len), {})
                for model in MODELS:
                    cell = block.get(model)
                    in_scope = dataset in test_datasets
                    if cell is None:
                        status = "PENDING"
                        note = "not executed"
                    elif not in_scope:
                        status = "PENDING"
                        note = "outside default scope; pass --include-all after filling all datasets"
                    else:
                        status = "OK"
                        note = ""
                    writer.writerow(
                        {
                            "dataset": dataset,
                            "pred_len": pred_len,
                            "model": model,
                            "mse": _fmt(cell["mse"]) if cell else "",
                            "mae": _fmt(cell["mae"]) if cell else "",
                            "source": cell["source"] if cell else "",
                            "status": status,
                            "note": note,
                        }
                    )


def _complete_blocks(matrix, datasets):
    blocks = []
    missing = []
    for dataset in datasets:
        for pred_len in PRED_LENS[dataset]:
            block = matrix.get((dataset, pred_len), {})
            absent = [m for m in MODELS if m not in block]
            if absent:
                missing.append((dataset, pred_len, absent))
            else:
                blocks.append((dataset, pred_len))
    return blocks, missing


def _rank_data(matrix, blocks, metric):
    values = np.array(
        [[matrix[block][model][metric] for model in MODELS] for block in blocks],
        dtype=float,
    )
    ranks = np.apply_along_axis(rankdata, 1, values)
    return values, ranks


def _friedman(values, ranks):
    n_blocks, k = values.shape
    rank_sums = ranks.sum(axis=0)
    base = 12.0 / (n_blocks * k * (k + 1)) * float((rank_sums**2).sum()) - 3.0 * n_blocks * (k + 1)
    tie_sum = 0.0
    for row in values:
        _, counts = np.unique(row, return_counts=True)
        tie_sum += float((counts**3 - counts).sum())
    correction = 1.0 - tie_sum / (n_blocks * (k**3 - k))
    chi2 = base / correction if correction > 0 else base
    df1 = k - 1
    df2 = (k - 1) * (n_blocks - 1)
    f_value = (n_blocks - 1) * chi2 / (n_blocks * df1 - chi2)
    return {
        "chi2": chi2,
        "chi2_uncorrected": base,
        "tie_correction": correction,
        "f": f_value,
        "df1": df1,
        "df2": df2,
        "p_chi2": float(chi2_dist.sf(chi2, df1)),
        "p_f": float(f_dist.sf(f_value, df1, df2)),
        "avg_ranks": rank_sums / n_blocks,
    }


def _nemenyi_cd(k, n_blocks, alpha):
    q_alpha = float(studentized_range.ppf(1.0 - alpha, k, np.inf)) / math.sqrt(2.0)
    cd = q_alpha * math.sqrt(k * (k + 1) / (6.0 * n_blocks))
    return q_alpha, cd


def _wilcoxon_vs_m2patch(matrix, blocks, metric, baseline, alpha):
    m2p = np.array([matrix[b][M2PATCH][metric] for b in blocks], dtype=float)
    base = np.array([matrix[b][baseline][metric] for b in blocks], dtype=float)
    diff = base - m2p
    wins = int((diff > 0).sum())
    losses = int((diff < 0).sum())
    ties = int((diff == 0).sum())
    nonzero = diff[diff != 0]

    if nonzero.size == 0:
        return {
            "w": 0.0,
            "p": 1.0,
            "method": "none",
            "r": 0.0,
            "win": wins,
            "tie": ties,
            "loss": losses,
            "n_pairs": 0,
        }

    method = "exact"
    try:
        result = wilcoxon(
            nonzero,
            alternative="two-sided",
            zero_method="wilcox",
            correction=False,
            method="exact",
        )
    except ValueError:
        method = "asymptotic"
        result = wilcoxon(
            nonzero,
            alternative="two-sided",
            zero_method="wilcox",
            correction=False,
            method="asymptotic",
        )

    abs_ranks = rankdata(np.abs(nonzero))
    w_pos = float(abs_ranks[nonzero > 0].sum())
    w_neg = float(abs_ranks[nonzero < 0].sum())
    total = w_pos + w_neg
    effect = (w_pos - w_neg) / total if total > 0 else 0.0
    return {
        "w": float(result.statistic),
        "p": float(result.pvalue),
        "method": method,
        "r": effect,
        "win": wins,
        "tie": ties,
        "loss": losses,
        "n_pairs": int(nonzero.size),
    }


def _holm(pvalues):
    order = sorted(range(len(pvalues)), key=lambda i: pvalues[i])
    adjusted = [1.0] * len(pvalues)
    running = 0.0
    for rank, idx in enumerate(order):
        value = (len(pvalues) - rank) * pvalues[idx]
        running = max(running, min(1.0, value))
        adjusted[idx] = running
    return adjusted


def run_tests(matrix, blocks, alpha):
    rows = []
    friedman = {}
    for metric in METRICS:
        values, ranks = _rank_data(matrix, blocks, metric)
        stats = _friedman(values, ranks)
        q_alpha, cd = _nemenyi_cd(values.shape[1], values.shape[0], alpha)
        friedman[metric] = {"stats": stats, "cd": cd, "q_alpha": q_alpha}

        try:
            scipy_chi2, scipy_p = friedmanchisquare(*[values[:, j] for j in range(values.shape[1])])
        except ValueError:
            scipy_chi2, scipy_p = float("nan"), float("nan")

        rows.append(
            {
                "metric": metric,
                "test": "friedman",
                "model": "all",
                "comparison": f"k={len(MODELS)}",
                "n_blocks": values.shape[0],
                "k": values.shape[1],
                "statistic": stats["chi2"],
                "statistic_name": "Friedman chi2_F (tie-corrected)",
                "f_iman_davenport": stats["f"],
                "df1": stats["df1"],
                "df2": stats["df2"],
                "p_value": stats["p_f"],
                "significant": str(stats["p_f"] < alpha),
                "notes": (
                    f"p_chi2={_fmt(stats['p_chi2'])}; uncorrected chi2={_fmt(stats['chi2_uncorrected'])}; "
                    f"tie correction={_fmt(stats['tie_correction'])}; "
                    f"scipy friedmanchisquare chi2={_fmt(scipy_chi2)} p={_fmt(scipy_p)}"
                ),
            }
        )
        for idx, model in enumerate(MODELS):
            rows.append(
                {
                    "metric": metric,
                    "test": "average_rank",
                    "model": model,
                    "n_blocks": values.shape[0],
                    "k": values.shape[1],
                    "statistic": float(stats["avg_ranks"][idx]),
                    "statistic_name": "average rank (1=best)",
                    "cd": cd,
                    "q_alpha": q_alpha,
                }
            )

        pvalues = []
        baselines = [m for m in MODELS if m != M2PATCH]
        for baseline in baselines:
            pvalues.append(_wilcoxon_vs_m2patch(matrix, blocks, metric, baseline, alpha)["p"])
        holm = _holm(pvalues)
        for baseline, p_holm in zip(baselines, holm):
            result = _wilcoxon_vs_m2patch(matrix, blocks, metric, baseline, alpha)
            rows.append(
                {
                    "metric": metric,
                    "test": "wilcoxon",
                    "model": baseline,
                    "comparison": f"{M2PATCH} vs {baseline}",
                    "n_blocks": values.shape[0],
                    "k": values.shape[1],
                    "statistic": result["w"],
                    "statistic_name": "Wilcoxon W (min rank sum)",
                    "p_value": result["p"],
                    "p_holm": p_holm,
                    "effect_size_r": result["r"],
                    "win": result["win"],
                    "tie": result["tie"],
                    "loss": result["loss"],
                    "n_pairs": result["n_pairs"],
                    "wilcoxon_method": result["method"],
                    "significant": str(p_holm < alpha),
                    "notes": "positive r = M2Patch lower error",
                }
            )
    return rows, friedman


def _write_results_csv(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _fmt(row.get(key)) for key in CSV_FIELDS})


def _plot_critical_difference(path, rows, friedman, alpha):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    fig, axes = plt.subplots(1, 2, figsize=(14.0, 5.6), dpi=600)
    bar_color = color_dict["blue_dark"]
    point_color = color_dict["purple_dark1"]
    text_color = neutral_dict["ink"]
    grid_color = neutral_dict["hairline"]

    for ax, metric in zip(axes, METRICS):
        entry = friedman[metric]
        stats = entry["stats"]
        cd = entry["cd"]
        avg = stats["avg_ranks"]
        order = np.argsort(avg)
        names = [MODELS[i] for i in order]
        values = avg[order]
        k = len(MODELS)
        n_blocks = int(round(stats["df2"] / max(stats["df1"], 1) + 1))

        y_positions = np.arange(k)[::-1]
        ax.set_xlim(0.5, max(k + 0.5, float(values.max()) + cd + 0.4))
        ax.set_yticks(y_positions)
        ax.set_yticklabels(names, fontsize=10, color=text_color)
        ax.set_ylim(-0.9, k + 0.35)
        ax.set_xlabel("Average rank (1 = best)", fontsize=11, color=text_color)
        ax.set_title(
            f"{metric.upper()}: Friedman $p_F$={stats['p_f']:.3g}, N={n_blocks}, CD={cd:.3f}",
            fontsize=10,
            color=text_color,
        )
        ax.grid(axis="x", color=grid_color, linewidth=0.6, alpha=0.8)
        ax.set_axisbelow(True)
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)
        ax.spines["left"].set_color(neutral_dict["frame"])
        ax.spines["bottom"].set_color(neutral_dict["frame"])

        for y, name, value in zip(y_positions, names, values):
            ax.plot([0.5, value], [y, y], color=grid_color, linewidth=0.8, zorder=1)
            ax.scatter([value], [y], s=46, color=point_color, zorder=3, edgecolor="white", linewidth=0.6)
            ax.text(value + 0.05, y, f"{value:.2f}", va="center", fontsize=9, color=text_color)

        intervals = []
        for i in range(k):
            j = i
            while j + 1 < k and values[j + 1] - values[i] <= cd + 1e-12:
                j += 1
            if j > i:
                intervals.append((i, j))
        cliques = [
            interval
            for interval in intervals
            if not any(
                other != interval and other[0] <= interval[0] and interval[1] <= other[1]
                for other in intervals
            )
        ]
        for level, (i, j) in enumerate(cliques):
            y = -0.55 - 0.28 * level
            ax.plot([values[i], values[j]], [y, y], color=bar_color, linewidth=3.0, solid_capstyle="butt")
        if cliques:
            ax.set_ylim(-0.75 - 0.28 * len(cliques), k + 0.35)

        x0 = ax.get_xlim()[1] - cd - 0.15
        ax.plot([x0, x0 + cd], [k + 0.02, k + 0.02], color=bar_color, linewidth=2.6)
        ax.text(x0 + cd / 2.0, k + 0.12, f"CD = {cd:.2f}", ha="center", va="bottom", fontsize=9, color=text_color)

    fig.legend(
        handles=[
            Line2D([0], [0], color=bar_color, linewidth=2.6, label="Non-significant clique (Nemenyi)"),
            Line2D([0], [0], color=point_color, marker="o", linestyle="", label="Average rank"),
        ],
        loc="upper center",
        bbox_to_anchor=(0.5, 0.94),
        ncol=2,
        fontsize=8,
        frameon=False,
    )
    fig.suptitle(
        f"Critical Difference diagram (Nemenyi post-hoc, alpha={alpha:.2f})",
        fontsize=12,
        color=text_color,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.88))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=600, bbox_inches="tight")
    plt.close(fig)


def _write_xlsx(path, matrix, test_datasets, rows, friedman, alpha):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    header_font = Font(bold=True)
    pending_fill = PatternFill(fill_type="solid", fgColor="FFF2F2F2")
    ok_fill = PatternFill(fill_type="solid", fgColor="FFE2EFDA")

    ws = wb.active
    ws.title = "Benchmark Matrix"
    headers = ["Dataset", "Pred Len", "Model", "MSE", "MAE", "Source", "Status", "Note"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = header_font
    for dataset in ALL_DATASETS:
        for pred_len in PRED_LENS[dataset]:
            block = matrix.get((dataset, pred_len), {})
            for model in MODELS:
                cell = block.get(model)
                in_scope = dataset in test_datasets
                status = "OK" if (cell is not None and in_scope) else "PENDING"
                note = ""
                if cell is None:
                    note = "not executed"
                elif not in_scope:
                    note = "outside default scope; pass --include-all"
                ws.append(
                    [
                        dataset,
                        pred_len,
                        model,
                        cell["mse"] if cell else None,
                        cell["mae"] if cell else None,
                        cell["source"] if cell else "",
                        status,
                        note,
                    ]
                )
                row_idx = ws.max_row
                fill = ok_fill if status == "OK" else pending_fill
                ws.cell(row=row_idx, column=7).fill = fill
                if status != "OK":
                    for col in range(1, 9):
                        ws.cell(row=row_idx, column=col).fill = pending_fill
    ws.freeze_panes = "A2"
    for col, width in enumerate([12, 10, 14, 12, 12, 34, 10, 52], start=1):
        ws.column_dimensions[get_column_letter(col)].width = width

    ws = wb.create_sheet("Friedman")
    ws.append(["Metric", "chi2_F", "F (Iman-Davenport)", "df1", "df2", "p (chi2)", "p (F)", "N blocks", "k", "CD (Nemenyi)", "q_alpha"])
    for cell in ws[1]:
        cell.font = header_font
    for metric in METRICS:
        entry = friedman[metric]
        stats = entry["stats"]
        ws.append(
            [
                metric.upper(),
                stats["chi2"],
                stats["f"],
                stats["df1"],
                stats["df2"],
                stats["p_chi2"],
                stats["p_f"],
                int(round(stats["df2"] / max(stats["df1"], 1) + 1)),
                len(MODELS),
                entry["cd"],
                entry["q_alpha"],
            ]
        )
        for col in (2, 3, 6, 7, 10, 11):
            ws.cell(row=ws.max_row, column=col).number_format = "0.000000E+00"
    ws.freeze_panes = "A2"

    ws = wb.create_sheet("Average Ranks")
    ws.append(["Metric", "Model", "Average Rank", "Position"])
    for cell in ws[1]:
        cell.font = header_font
    for metric in METRICS:
        avg = friedman[metric]["stats"]["avg_ranks"]
        order = np.argsort(avg)
        for position, idx in enumerate(order, start=1):
            ws.append([metric.upper(), MODELS[idx], float(avg[idx]), position])
    ws.freeze_panes = "A2"

    ws = wb.create_sheet("Wilcoxon")
    ws.append(
        [
            "Metric",
            "Comparison",
            "N pairs",
            "W",
            "p value",
            "p Holm",
            "Rank-biserial r",
            "Win",
            "Tie",
            "Loss",
            "Method",
            "Significant (Holm 0.05)",
        ]
    )
    for cell in ws[1]:
        cell.font = header_font
    for row in rows:
        if row.get("test") != "wilcoxon":
            continue
        ws.append(
            [
                row["metric"].upper(),
                row["comparison"],
                row["n_pairs"],
                row["statistic"],
                row["p_value"],
                row["p_holm"],
                row["effect_size_r"],
                row["win"],
                row["tie"],
                row["loss"],
                row["wilcoxon_method"],
                row["significant"],
            ]
        )
        for col in (5, 6, 7):
            ws.cell(row=ws.max_row, column=col).number_format = "0.0000E+00"
    ws.freeze_panes = "A2"

    ws = wb.create_sheet("Summary")
    ws.append(["Item", "Value"])
    for cell in ws[1]:
        cell.font = header_font
    ws.append(["Models", ", ".join(MODELS)])
    ws.append(["Default test datasets", ", ".join(CORE_DATASETS)])
    ws.append(["Datasets in matrix", ", ".join(ALL_DATASETS)])
    ws.append(["Blocks (default)", sum(len(PRED_LENS[d]) for d in CORE_DATASETS)])
    ws.append(["Alpha", alpha])
    for metric in METRICS:
        entry = friedman[metric]
        ws.append([f"{metric.upper()} Friedman p (F)", entry["stats"]["p_f"]])
        ws.append([f"{metric.upper()} CD", entry["cd"]])
    ws.append(["PENDING", "Grey cells are placeholders (dataset/model not executed under this protocol)"])
    ws.append(["M2Patch source", "output/ablation/none.tsv (measured); Optuna JSON fallback"])
    ws.append(["Baseline source", "output/benchmark/{dataset}.tsv or assets/m2p_eff_results_1.xlsx"])
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 100

    os.makedirs(os.path.dirname(path), exist_ok=True)
    wb.save(path)


def _md_table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        lines.append("| " + " | ".join(str(v) for v in row) + " |")
    return "\n".join(lines)


def _write_summary_md(path, matrix, blocks, rows, friedman, alpha, missing, include_all):
    lines = []
    lines.append("# Cross-dataset nonparametric tests (M2Patch vs baselines)")
    lines.append("")
    lines.append("## Protocol")
    lines.append("")
    lines.append("- Problem instances: one block per `(dataset, pred_len)` pair; rank 1 = lowest error.")
    lines.append(f"- Models (k = {len(MODELS)}): {', '.join(MODELS)}.")
    lines.append(f"- Complete blocks used (N = {len(blocks)}): " + ", ".join(f"{d}@{p}" for d, p in blocks))
    lines.append(f"- Significance level alpha = {alpha}; Holm-Bonferroni correction across {len(MODELS) - 1} pairwise comparisons per metric.")
    lines.append("- Friedman chi-square is tie-corrected; Iman-Davenport F uses df1 = k-1, df2 = (k-1)(N-1).")
    lines.append("- Nemenyi CD = q_alpha * sqrt(k(k+1)/(6N)), two-tailed Studentized range over infinite df.")
    lines.append("- Wilcoxon signed-rank: two-sided, zero differences discarded (`wilcox`), exact when possible, asymptotic otherwise.")
    lines.append("- Effect size: matched-pairs rank-biserial r = (W+ - W-) / (W+ + W-); positive r favours M2Patch.")
    if not include_all:
        lines.append("- Scope: core datasets only. Pass `--include-all` after filling every dataset to recompute a global test.")
    lines.append("")

    lines.append("## Data coverage")
    lines.append("")
    coverage_rows = []
    for dataset in ALL_DATASETS:
        per_model = []
        for model in MODELS:
            count = sum(1 for pl in PRED_LENS[dataset] if model in matrix.get((dataset, pl), {}))
            per_model.append(str(count))
        status = "OK" if all(v == str(len(PRED_LENS[dataset])) for v in per_model) else "PENDING"
        coverage_rows.append([dataset, len(PRED_LENS[dataset]), status, ", ".join(per_model)])
    lines.append(_md_table(["Dataset", "Horizons", "Status", "Models with data (order: " + ", ".join(MODELS) + ")"], coverage_rows))
    lines.append("")
    if missing:
        lines.append("Missing cells (first 40): " + "; ".join(
            f"{d}@{pl}:{models}" for d, pl, models in missing[:40]
        ))
        lines.append("")

    for metric in METRICS:
        entry = friedman[metric]
        stats = entry["stats"]
        lines.append(f"## {metric.upper()}")
        lines.append("")
        lines.append(
            f"Friedman: chi2_F = {stats['chi2']:.6g}, Iman-Davenport F = {stats['f']:.6g} "
            f"(df1 = {stats['df1']}, df2 = {stats['df2']}), p_F = {stats['p_f']:.6g}, "
            f"p_chi2 = {stats['p_chi2']:.6g}."
        )
        lines.append("")
        rank_rows = []
        avg = stats["avg_ranks"]
        for position, idx in enumerate(np.argsort(avg), start=1):
            rank_rows.append([position, MODELS[idx], f"{avg[idx]:.4f}"])
        lines.append(_md_table(["Position", "Model", "Average rank"], rank_rows))
        lines.append("")
        lines.append(f"Nemenyi CD = {entry['cd']:.4f} (q_alpha = {entry['q_alpha']:.4f}). Models whose average ranks differ by less than the CD are not significantly different.")
        lines.append("")
        wilcoxon_rows = []
        for row in rows:
            if row.get("test") != "wilcoxon" or row["metric"] != metric:
                continue
            wilcoxon_rows.append(
                [
                    row["comparison"].split(" vs ")[1],
                    row["n_pairs"],
                    f"{row['statistic']:.4g}",
                    f"{row['p_value']:.4g}",
                    f"{row['p_holm']:.4g}",
                    f"{row['effect_size_r']:+.4f}",
                    f"{row['win']}/{row['tie']}/{row['loss']}",
                    row["wilcoxon_method"],
                    "yes" if row["significant"] == "True" else "no",
                ]
            )
        lines.append(
            _md_table(
                ["Baseline", "N pairs", "W", "p", "p_Holm", "r", "Win/Tie/Loss", "Method", "Significant"],
                wilcoxon_rows,
            )
        )
        lines.append("")

    lines.append("## Notes")
    lines.append("")
    lines.append("- M2Patch cells are the measured Optuna-config baseline (`output/ablation/none.tsv`); missing datasets fall back to the exported HPO best-trial JSON and are labelled `optuna:` in the matrix CSV.")
    lines.append("- Baseline cells are measured under the shared protocol (`output/benchmark/{dataset}.tsv`) when present; otherwise they come from the curated main table `assets/m2p_eff_results_1.xlsx` and are labelled with that source.")
    lines.append("- `PENDING` rows in `benchmark_matrix.csv` are placeholders for datasets not yet executed; they never enter a test.")
    lines.append("- Rows with `status=PENDING` and `note=outside default scope` can be activated with `--include-all` once their benchmark TSVs exist.")
    lines.append("")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as handle:
        handle.write("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description="Cross-dataset nonparametric tests for M2Patch")
    parser.add_argument("--output-dir", default=os.path.join(REPO_ROOT, "output", "statistics"))
    parser.add_argument("--benchmark-dir", default=BENCHMARK_DIR_DEFAULT)
    parser.add_argument("--optuna-dir", default=OPTUNA_DIR_DEFAULT)
    parser.add_argument("--none-tsv", default=NONE_TSV_DEFAULT)
    parser.add_argument("--assets", default=ASSETS_DEFAULT)
    parser.add_argument("--no-assets", action="store_true", help="do not read assets/m2p_eff_results_1.xlsx")
    parser.add_argument("--include-all", action="store_true", help="include all datasets instead of the 3 core ones")
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--allow-partial", action="store_true", help="run on complete blocks when some cells are missing")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    matrix, missing, _ = build_matrix(args)
    test_datasets = _scope_datasets(args.include_all)
    blocks, missing_blocks = _complete_blocks(matrix, test_datasets)

    if missing_blocks:
        message = "; ".join(f"{d}@{pl}: {', '.join(models)}" for d, pl, models in missing_blocks)
        print(f"[ERROR] incomplete benchmark matrix for {len(missing_blocks)} block(s): {message}")
        if not args.allow_partial:
            sys.exit(2)
        print("[WARN] --allow-partial: tests are restricted to fully populated blocks")
    if not blocks:
        print("[ERROR] no complete blocks to test")
        sys.exit(2)

    _write_matrix_csv(os.path.join(args.output_dir, "benchmark_matrix.csv"), matrix, test_datasets)

    rows, friedman = run_tests(matrix, blocks, args.alpha)
    _write_results_csv(os.path.join(args.output_dir, "stat_tests_results.csv"), rows)
    _write_xlsx(
        os.path.join(args.output_dir, "m2p_stat_tests.xlsx"),
        matrix,
        test_datasets,
        rows,
        friedman,
        args.alpha,
    )
    _write_summary_md(
        os.path.join(args.output_dir, "stat_tests_summary.md"),
        matrix,
        blocks,
        rows,
        friedman,
        args.alpha,
        missing,
        args.include_all,
    )
    _plot_critical_difference(
        os.path.join(args.output_dir, "critical_difference.png"),
        rows,
        friedman,
        args.alpha,
    )

    for metric in METRICS:
        stats = friedman[metric]["stats"]
        print(
            f"[{metric.upper()}] N={len(blocks)} k={len(MODELS)} "
            f"chi2_F={stats['chi2']:.6g} F={stats['f']:.6g} df=({stats['df1']},{stats['df2']}) "
            f"p_F={stats['p_f']:.6g} CD={friedman[metric]['cd']:.4f}"
        )
    print(f"Saved statistics outputs to {args.output_dir}")


if __name__ == "__main__":
    main()
