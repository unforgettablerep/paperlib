#!/bin/bash
# Benchmark matrix runner for the nonparametric statistics: same protocol as M2Patch
# (seq_len=96, label_len=48, 15 epochs, patience 5, batch 32, FP32, seed 2023),
# one merged TSV per dataset under BENCHMARK_OUTPUT_DIR (default output/benchmark).
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
cd "$REPO_ROOT" || exit 1

PYTHON_BIN=${PYTHON_BIN:-python}
export PYTHON_BIN
source "${REPO_ROOT}/scripts/utils/result_common.sh"
source "${REPO_ROOT}/scripts/utils/gpu_queue.sh"

DATASETS=(ETTh2 ETTm1 Exchange)
MODELS=(MMPD SimpleTM)
EPOCHS=${EPOCHS:-15}
PARALLEL=${PARALLEL:-2}
GPUS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --para) PARA="$2"; shift 2 ;;
        --datasets) read -ra DATASETS <<< "$2"; shift 2 ;;
        --models) read -ra MODELS <<< "$2"; shift 2 ;;
        --gpus) read -ra GPUS <<< "${2//,/ }"; shift 2 ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

GPU_LIST=${GPU_LIST:-${GPUS[*]:-0}}
PARA_PER_GPU=${PARA_PER_GPU:-${PARA:-${PARALLEL}}}
export GPU_LIST PARA_PER_GPU
export BENCHMARK_OUTPUT_DIR=${BENCHMARK_OUTPUT_DIR:-output/benchmark}

gpu_queue_init
mkdir -p "$BENCHMARK_OUTPUT_DIR" log/benchmark

_dataset_meta() {
    local ds=$1
    case "$ds" in
        ETTh2) DS_ROOT="./data/ETT-small/"; DS_FILE="ETTh2.csv"; DS_DATA="ETTh2"; DS_FREQ="h"; DS_ENC=7 ;;
        ETTm1) DS_ROOT="./data/ETT-small/"; DS_FILE="ETTm1.csv"; DS_DATA="ETTm1"; DS_FREQ="t"; DS_ENC=7 ;;
        Exchange) DS_ROOT="./data/exchange_rate/"; DS_FILE="exchange_rate.csv"; DS_DATA="custom"; DS_FREQ="d"; DS_ENC=8 ;;
        *) echo "Unsupported dataset: $ds" >&2; return 1 ;;
    esac
    DS_CPP_OUT=$DS_ENC
}

_model_flags() {
    local model=$1 pl=$2
    MODEL_FLAGS=()
    case "$model" in
        MMPD)
            local patch_size=12
            [[ "$pl" -gt 192 ]] && patch_size=24
            MODEL_FLAGS=(
                --d_model 256 --d_ff 512 --n_heads 4 --e_layers 2 --d_layers 2
                --patch_size "$patch_size" --d_diffusion 256 --diffusion_layers 1
                --radius 3 --max_diffusion_steps 1000 --beta_schedule linear
                --point_weight 0.01 --weighted 1 --sample_num 100 --num_sampling_steps 20
                --dropout 0.2 --batch_size 32 --learning_rate 1e-4 --lradj cosine
                --optim Adam
            )
            ;;
        SimpleTM)
            MODEL_FLAGS=(
                --d_model 32 --d_ff 32 --e_layers 1 --dropout 0.1 --geomattn_dropout 0.5
                --wv db1 --wavelet_levels 3 --alpha 1.0 --l1_weight 5e-5 --requires_grad 1
                --batch_size 32 --learning_rate 1e-4 --lradj type1 --optim AdamW
                --weight_decay 0.01
            )
            ;;
        DLinear)
            MODEL_FLAGS=(--d_model 512 --d_ff 2048 --e_layers 2 --n_heads 8 --moving_avg 25 --dropout 0.1 --batch_size 32 --learning_rate 1e-3 --lradj type1 --optim Adam)
            ;;
        PatchTST)
            MODEL_FLAGS=(--d_model 128 --d_ff 256 --e_layers 3 --n_heads 16 --patch_len 16 --stride 8 --dropout 0.2 --fc_dropout 0.2 --head_dropout 0.0 --batch_size 32 --learning_rate 1e-4 --lradj onecycle --pct_start 0.3 --optim Adam)
            ;;
        iTransformer)
            MODEL_FLAGS=(--d_model 256 --d_ff 512 --e_layers 2 --n_heads 8 --dropout 0.1 --batch_size 32 --learning_rate 1e-4 --lradj type1 --optim Adam)
            ;;
        TimeMixer)
            local d_model=16 d_ff=32
            [[ "$pl" -ge 336 ]] && { d_model=64; d_ff=128; }
            MODEL_FLAGS=(--d_model "$d_model" --d_ff "$d_ff" --e_layers 2 --n_heads 8 --channel_independence 1 --down_sampling_layers 3 --down_sampling_window 2 --down_sampling_method avg --decomp_method moving_avg --moving_avg 25 --use_norm 1 --use_future_temporal_feature 0 --dropout 0.1 --batch_size 32 --learning_rate 0.01 --lradj type1 --optim Adam)
            ;;
        TimesNet)
            MODEL_FLAGS=(--d_model 32 --d_ff 32 --e_layers 2 --n_heads 8 --top_k 5 --num_kernels 6 --dropout 0.1 --batch_size 32 --learning_rate 1e-4 --lradj type1 --optim Adam)
            ;;
        *)
            echo "Unsupported model: $model" >&2
            return 1
            ;;
    esac
}

_run_cell() {
    local ds=$1 pl=$2 model=$3
    local out="${BENCHMARK_OUTPUT_DIR}/${ds}.tsv"
    if result_done "$out" "dataset=${ds}" "pred_len=${pl}" "model=${model}"; then
        echo "[skip] ${ds} pl=${pl} ${model} already recorded"
        return 0
    fi
    _dataset_meta "$ds" || return 1
    _model_flags "$model" "$pl" || return 1
    local cmd=(
        "${PYTHON_BIN}" -u scripts/run.py
        --is_training 1
        --model "$model"
        --des "$model"
        --root_path "$DS_ROOT"
        --data_path "$DS_FILE"
        --data "$DS_DATA"
        --model_id "${ds}_96_${pl}"
        --features M
        --freq "$DS_FREQ"
        --seq_len 96
        --label_len 48
        --pred_len "$pl"
        --enc_in "$DS_ENC"
        --dec_in "$DS_ENC"
        --c_out "$DS_CPP_OUT"
        "${MODEL_FLAGS[@]}"
        --train_epochs "$EPOCHS"
        --patience 5
        --no-use_amp
    )
    if [[ "${DRY_RUN:-0}" == "1" ]]; then
        echo "${cmd[*]}"
        return 0
    fi
    gpu_queue_next
    local log="${BENCHMARK_LOG_DIR:-log/benchmark}/${model}.log"
    mkdir -p "$(dirname "$log")"
    gpu_queue_dispatch "$log" "${cmd[@]}"
}

for ds in "${DATASETS[@]}"; do
    for pl in 96 192 336 720; do
        for model in "${MODELS[@]}"; do
            _run_cell "$ds" "$pl" "$model"
        done
    done
done
gpu_queue_wait

for ds in "${DATASETS[@]}"; do
    out="${BENCHMARK_OUTPUT_DIR}/${ds}.tsv"
    [[ -f "$out" ]] && "${PYTHON_BIN}" -m src.utils.result_io sort "$out"
done
echo "[$(date '+%F %T')] benchmark matrix finished: ${BENCHMARK_OUTPUT_DIR}"
