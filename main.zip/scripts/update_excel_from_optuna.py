#!/usr/bin/env python3
import argparse
import json
import math
import re
import sys
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import openpyxl
from openpyxl.cell.cell import MergedCell

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.configs.m2patch_profiles import (
    OPTUNA_SKIP_KEYS,
    finalize_config,
    resolve,
    resolve_meta,
)
from src.utils.result_io import canonical_dataset

ASSETS_DIR = PROJECT_ROOT / "assets"
OPTUNA_DIR = PROJECT_ROOT / "output" / "optuna"
ARCHIVE_DIR = OPTUNA_DIR / "archive"

METRIC_NUM_FMT = "0.000"

SHEET_NAME = "Results"

RESULTS_HEADER_ROW = 3
CONFIG_HEADER_ROW = 62
RESULTS_DATA_START = 4
RESULTS_DATA_END = 58
CONFIG_DATA_START = 63
CONFIG_DATA_END = 106

PARAM_COL_MAP = {
    "enc_in": "C",
    "e_layers": "D",
    "batch_size": "E",
    "d_model": "F",
    "d_ff": "G",
    "patch_len": "H",
    "stride": "I",
    "d_hyp": "J",
    "manifold_c": "K",
    "d_layers_diff": "L",
    "diff_steps": "M",
    "diff_schedule": "N",
    "lambda_hyp": "O",
    "lambda_prior": "P",
    "dropout": "Q",
    "seed": "R",
    "lradj": "S",
    "optim": "T",
    "pct_start": "U",
    "train_epochs": "V",
    "patience": "W",
    "learning_rate": "X",
}

PARAM_NUM_FMT = {
    "C": "0",
    "D": "0",
    "E": "0",
    "F": "0",
    "G": "0",
    "H": "0",
    "I": "0",
    "J": "0",
    "K": "0.0",
    "L": "0",
    "M": "0",
    "N": "General",
    "O": "0.00",
    "P": "0.00",
    "Q": "0.00",
    "R": "0",
    "S": "General",
    "T": "General",
    "U": "0.0",
    "V": "0",
    "W": "0",
    "X": "0.00E+00",
}

WORKBOOK_DATASET_ALIASES = {
    "Solar": "Solar-Energy",
}

LOCKED_CONFIG_KEYS = {
    "diff_steps",
    "diff_schedule",
    "seed",
    "lradj",
    "optim",
    "train_epochs",
    "patience",
}


def round_metric(value):
    quantized = Decimal(str(value)).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
    return float(quantized)


def col_to_idx(col: str) -> int:
    result = 0
    for ch in col.upper():
        result = result * 26 + (ord(ch) - ord("A") + 1)
    return result


def build_row_map(ws, start_row, end_row):
    row_map = {}
    current_dataset = None
    for row in range(start_row, end_row + 1):
        a_val = ws.cell(row=row, column=1).value
        b_val = ws.cell(row=row, column=2).value
        if a_val is not None:
            current_dataset = a_val
        if current_dataset and b_val is not None and isinstance(b_val, (int, float)):
            key = (current_dataset, int(b_val))
            row_map[key] = row
    return row_map


def parse_json_filename(fname: str):
    stem = Path(fname).stem
    m = re.match(r"M2Patch_(.+)_pl(\d+)_best_params", stem)
    if not m:
        return None, None
    dataset = m.group(1)
    pred_len = int(m.group(2))
    return dataset, pred_len


def find_json_files(optuna_dir: Path) -> list[Path]:
    files = []
    if not optuna_dir.exists():
        return files
    for f in sorted(optuna_dir.glob("M2Patch_*_best_params.json")):
        if ARCHIVE_DIR in f.parents:
            continue
        files.append(f)
    return files


def latest_json_by_key(files: list[Path]) -> dict:
    latest = {}
    for path in files:
        dataset, pred_len = parse_json_filename(path.name)
        if dataset is None:
            continue
        key = (dataset, pred_len)
        mtime = path.stat().st_mtime
        if key not in latest or mtime > latest[key][0]:
            latest[key] = (mtime, path)
    return {key: item[1] for key, item in latest.items()}


def normalize_json_params(params: dict) -> dict:
    result = {}
    for key, value in params.items():
        if key in OPTUNA_SKIP_KEYS:
            continue
        result[key] = value
    return result


def results_dataset_name(dataset: str) -> str:
    return canonical_dataset(dataset)


def build_config(dataset: str, pred_len: int, params: dict) -> dict:
    cfg = resolve(dataset, pred_len)
    meta = resolve_meta(dataset, pred_len)
    base_locked = {key: cfg[key] for key in LOCKED_CONFIG_KEYS if key in cfg}

    cfg.update(normalize_json_params(params))
    cfg.update(base_locked)
    cfg["enc_in"] = meta["enc_in"]
    cfg["seed"] = 2023
    return finalize_config(cfg)


def extract_json_metrics(data: dict):
    attrs = data.get("best_trial_user_attrs", {}) or {}
    candidates = [
        ("test_attr", attrs.get("mse"), attrs.get("mae")),
        ("test", data.get("test_mse"), data.get("test_mae")),
    ]
    for label, mse, mae in candidates:
        if mse is None or mae is None:
            continue
        mse_value = float(mse)
        mae_value = float(mae)
        if math.isfinite(mse_value) and math.isfinite(mae_value):
            return mse_value, mae_value, label
    return None


def collect_json_entries(json_by_key: dict):
    metrics = {}
    configs = {}
    for (dataset, pred_len), path in sorted(json_by_key.items()):
        with open(path) as f:
            data = json.load(f)
        params = data.get("best_params", {})
        canonical = results_dataset_name(dataset)
        key = (canonical, pred_len)
        config_dataset = WORKBOOK_DATASET_ALIASES.get(canonical, canonical)
        configs[(config_dataset, pred_len)] = build_config(
            config_dataset, pred_len, params
        )

        extracted = extract_json_metrics(data)
        if extracted is not None:
            mse, mae, source = extracted
            metrics[key] = (mse, mae, f"{path.name}:{source}")
        print(f"  JSON: {path.name} -> {canonical} pl={pred_len}")
    return metrics, configs


def find_excel_files(assets_dir: Path) -> list[Path]:
    return sorted(assets_dir.glob("m2p_eff_results_*.xlsx"))


def fill_averages(ws, metrics: dict, dry_run: bool = False) -> int:
    dataset_rows = {}
    current_dataset = None
    for row in range(RESULTS_DATA_START, RESULTS_DATA_END + 1):
        a_val = ws.cell(row=row, column=1).value
        b_val = ws.cell(row=row, column=2).value
        if a_val is not None:
            current_dataset = a_val
        if current_dataset is None or b_val is None:
            continue
        if b_val == "Avg":
            dataset_rows.setdefault(current_dataset, {})["avg"] = row
        elif isinstance(b_val, (int, float)):
            dataset_rows.setdefault(current_dataset, {})[int(b_val)] = row

    filled = 0
    for dataset, rows in dataset_rows.items():
        avg_row = rows.get("avg")
        if avg_row is None:
            continue
        pred_rows = [(pl, r) for pl, r in rows.items() if isinstance(pl, int)]
        if len(pred_rows) != 4:
            continue
        keys = [(dataset, pl) for pl, _ in pred_rows]
        if not all(key in metrics for key in keys):
            continue
        for col, pos in ((3, 0), (4, 1)):
            metric_label = ws.cell(row=RESULTS_HEADER_ROW, column=col).value
            if metric_label not in ("MSE", "MAE"):
                continue
            raw = [float(metrics[key][pos]) for key in keys]
            avg = round_metric(sum(raw) / len(raw))
            if not dry_run:
                cell = ws.cell(row=avg_row, column=col)
                cell.value = avg
                cell.number_format = METRIC_NUM_FMT
            filled += 1
        print(f"  Avg row {avg_row} ({dataset}): C={ws.cell(row=avg_row, column=3).value}")
    return filled


def write_metrics(ws, results_map: dict, metrics: dict, dry_run: bool) -> int:
    updated = 0
    for (dataset, pred_len), (mse, mae, source) in sorted(metrics.items()):
        key = (dataset, pred_len)
        if key not in results_map:
            print(f"  WARNING: no results row for ({dataset}, {pred_len}) [{source}]")
            continue
        row = results_map[key]
        old_mse = ws.cell(row=row, column=3).value
        old_mae = ws.cell(row=row, column=4).value
        print(
            f"  Results row {row}: {dataset} pl={pred_len} "
            f"MSE {old_mse} -> {round_metric(mse):.3f}, "
            f"MAE {old_mae} -> {round_metric(mae):.3f} [{source}]"
        )
        if not dry_run:
            c = ws.cell(row=row, column=3)
            c.value = round_metric(mse)
            c.number_format = METRIC_NUM_FMT
            d = ws.cell(row=row, column=4)
            d.value = round_metric(mae)
            d.number_format = METRIC_NUM_FMT
        updated += 1
    return updated


def write_configs(ws, config_map: dict, configs: dict, dry_run: bool) -> int:
    if ws.cell(row=CONFIG_HEADER_ROW, column=3).value != "enc_in":
        print(
            "  SKIP config update: workbook does not use the current M2Patch "
            "config header (enc_in at C62)"
        )
        return 0

    updated = 0
    rows = sorted(config_map.items(), key=lambda item: item[1])
    for (dataset, pred_len), row in rows:
        cfg = configs.get((dataset, pred_len))
        written = 0
        cleared = 0
        for param_name, col_letter in PARAM_COL_MAP.items():
            col_idx = col_to_idx(col_letter)
            cell = ws.cell(row=row, column=col_idx)
            if isinstance(cell, MergedCell):
                continue
            had_value = cell.value is not None
            value = None
            num_fmt = None
            if cfg is not None and param_name in cfg:
                value = cfg[param_name]
                num_fmt = PARAM_NUM_FMT[col_letter]
            if not dry_run:
                cell.value = value
                if num_fmt is not None:
                    cell.number_format = num_fmt
            if value is not None:
                written += 1
            elif had_value:
                cleared += 1
        source = f"{written} JSON params" if cfg is not None else "no JSON, cleared"
        print(f"  Config row {row}: {dataset} pl={pred_len} ({source})")
        updated += written + cleared
    for (dataset, pred_len) in sorted(configs):
        if (dataset, pred_len) not in config_map:
            print(f"  WARNING: no config row for ({dataset}, {pred_len})")
    return updated


def update_single_excel(
    excel_path: Path,
    json_by_key: dict,
    dry_run: bool = False,
) -> int:
    wb = openpyxl.load_workbook(excel_path)
    ws = wb[SHEET_NAME]

    results_map = build_row_map(ws, RESULTS_DATA_START, RESULTS_DATA_END)
    config_map = build_row_map(ws, CONFIG_DATA_START, CONFIG_DATA_END)

    json_metrics, json_configs = collect_json_entries(json_by_key)
    metrics = dict(json_metrics)

    updated = write_metrics(ws, results_map, metrics, dry_run)
    updated += write_configs(ws, config_map, json_configs, dry_run)

    if not dry_run and updated > 0:
        print("\n--- Filling averages ---")
        avg_filled = fill_averages(ws, metrics, dry_run=dry_run)
        print(f"  Avg rows filled: {avg_filled}")
        wb.save(excel_path)
        print(f"\nExcel saved: {excel_path}")
    elif dry_run:
        print(f"\n[DRY RUN] {updated} cells would be updated. No changes saved.")
    else:
        print("  No matching entries to update.")

    wb.close()
    return updated


def update_excel(dry_run: bool = False):
    excel_files = find_excel_files(ASSETS_DIR)
    if not excel_files:
        print(
            f"ERROR: No Excel files matching 'm2p_eff_results_*.xlsx' found in {ASSETS_DIR}"
        )
        return

    json_files = find_json_files(OPTUNA_DIR)
    json_by_key = latest_json_by_key(json_files)
    print(f"Optuna JSON files: {len(json_files)} (latest keys: {len(json_by_key)})")
    if not json_by_key:
        print("No Optuna JSON results found.")
        return

    total_updated = 0
    for excel_path in excel_files:
        print(f"\n{"=" * 60}")
        print(f"Processing: {excel_path.name}")
        print(f"{"=" * 60}")
        total_updated += update_single_excel(
            excel_path, json_by_key, dry_run=dry_run
        )

    print(f"\nAll Excel files processed. Total updates: {total_updated}")


def main():
    parser = argparse.ArgumentParser(
        description="Update experiment Excel solely from Optuna JSON exports"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Preview changes without saving"
    )
    args = parser.parse_args()
    update_excel(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
