import argparse
import glob
import json
import math
import os
import subprocess
import sys
import time

import numpy as np
import torch
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.patches import Circle
from matplotlib.text import Annotation, Text
from sklearn.decomposition import PCA

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from scripts.color import color_dict, neutral_dict
from scripts.mechanism.mechanism_config import (
    VARIANT_LABELS,
    VARIANTS,
    build_args,
    config_source,
    experiment_flags,
    get_config,
    variant_des,
)
from src.data_provider.data_factory import data_provider
from src.layers.M2Patch_layers import _split_future_patches
from src.model.M2Patch import Model
from src.utils.checkpoint import _ckpt_prefix, _get_checkpoint_dir, find_latest_checkpoint_seq
from src.utils.metrics import metric
from src.utils.result_io import append_result, read_results

# Compact row labels for the single-column panels; the full names stay in the
# result store and in the caption.
SHORT_LABELS = {
    "none": "Full",
    "euclid_manifold": "Euclid",
    "zero_prior_bridge": "Zero prior",
    "no_hyp_cond": "No hyp.",
    "no_prior_loss": "No prior",
}

SUMMARY_COLUMNS = [
    "dataset",
    "pred_len",
    "variant",
    "des",
    "mse",
    "mae",
    "geo_dist_prior",
    "geo_dist_pred",
    "geo_align",
    "geo_align_rel",
    "geo_gain",
    "hist_step_geo",
    "prior_rmse",
    "diff_rmse",
    "final_rmse_norm",
    "geometry",
    "config_source",
    "checkpoint",
    "status",
    "timestamp",
]

SUMMARY_KEY = ("dataset", "pred_len", "variant")

GRID_GRAY = neutral_dict["grid"]
TEXT_GRAY = neutral_dict["ink"]
HAIRLINE = neutral_dict["hairline"]
FRAME_COLOR = neutral_dict["frame"]
SURFACE = neutral_dict["surface"]

HIST_COLOR = color_dict["purple_dark1"]
PRIOR_COLOR = color_dict["purple_dark2"]
PRED_COLOR = color_dict["green_main"]
TARGET_COLOR = color_dict["blue_dark"]
DELTA_COLOR = color_dict["blue_light"]
ALIGN_COLOR = color_dict["green_main"]
MSE_COLOR = color_dict["purple_dark1"]
MAE_COLOR = color_dict["blue_dark"]

FIGURE_SIZE = (5.35, 4.6)
PANEL_FONTSIZE = 7.5
TICK_FONTSIZE = 6.5
LEGEND_FONTSIZE = 6.5
LABEL_FONTSIZE = 6.5
MIN_FONTSIZE = 6.5


def _serif_family():
    installed = {entry.name for entry in fm.fontManager.ttflist}
    for name in ("Times New Roman", "Nimbus Roman", "Nimbus Roman No9 L", "DejaVu Serif"):
        if name in installed:
            return name
    return "DejaVu Serif"


def _apply_style():
    family = _serif_family()
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": [family],
        "mathtext.fontset": "stix",
        "font.size": PANEL_FONTSIZE,
        "axes.titlesize": PANEL_FONTSIZE,
        "axes.labelsize": LABEL_FONTSIZE,
        "legend.fontsize": LEGEND_FONTSIZE,
        "xtick.labelsize": TICK_FONTSIZE,
        "ytick.labelsize": TICK_FONTSIZE,
        "axes.linewidth": 0.45,
        "xtick.major.width": 0.45,
        "ytick.major.width": 0.45,
        "xtick.major.size": 1.6,
        "ytick.major.size": 1.6,
        "axes.labelcolor": TEXT_GRAY,
        "text.color": TEXT_GRAY,
        "xtick.color": TEXT_GRAY,
        "ytick.color": TEXT_GRAY,
        "savefig.dpi": 600,
        "figure.dpi": 150,
        "path.simplify": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    return family


def _checkpoint_path(args):
    seq = int(getattr(args, "checkpoint", 0) or 0)
    if seq <= 0:
        seq = find_latest_checkpoint_seq(args)
    if seq <= 0:
        return 0, None
    path = os.path.join(_get_checkpoint_dir(args), "{}_{}.pth".format(_ckpt_prefix(args), seq))
    return seq, path


def _train_variant(args):
    flags = experiment_flags(
        args.dataset_name,
        args.pred_len,
        args.ablation_name,
        args.des,
        training=True,
        train_epochs=args.train_epochs,
        source=args.config_source,
    )
    env = os.environ.copy()
    env["MECHANISM_OUTPUT_DIR"] = args.mechanism_output_dir
    cmd = [sys.executable, "-u", "scripts/run.py"] + flags
    print("[train] {}".format(" ".join(cmd)))
    subprocess.run(cmd, cwd=REPO_ROOT, env=env, check=True)


def _load_model(args, dataset, pred_len, variant, device):
    source = config_source(dataset, pred_len, args.config_source)
    run_args = build_args(
        dataset, pred_len, variant, variant_des(variant, pred_len), device=str(device), source=source
    )
    run_args.dataset_name = dataset
    run_args.num_workers = 0
    run_args.ablation_name = variant
    run_args.train_epochs = int(args.train_epochs)
    run_args.mechanism_output_dir = args.mechanism_output_dir
    run_args.config_source = source
    seq, path = _checkpoint_path(run_args)
    if path is None or not os.path.isfile(path):
        if args.train_missing:
            _train_variant(run_args)
            seq, path = _checkpoint_path(run_args)
        if path is None or not os.path.isfile(path):
            raise FileNotFoundError(
                "Missing checkpoint for {} {} (expected prefix {}). Run scripts/mechanism/run_m2patch_mechanism.sh first.".format(
                    dataset, variant, _ckpt_prefix(run_args)
                )
            )
    model = Model(run_args).float().to(device)
    state = torch.load(path, map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    model.eval()
    print("[load ] {} {} <- {}".format(dataset, variant, path))
    return run_args, model, seq, source


def _k_sweep(backbone, run_args, loader, device, pred_len, steps):
    saved_steps = int(backbone.diff_steps)
    rows = []
    try:
        for k in steps:
            backbone.diff_steps = int(k)
            prior_sq = 0.0
            final_sq = 0.0
            n_elem = 0.0
            with torch.no_grad():
                for batch_x, batch_y, _, _ in loader:
                    batch_x = batch_x.float().to(device)
                    batch_y = batch_y.float().to(device)
                    outputs, aux = backbone(batch_x, None)
                    target_norm = (
                        backbone.revin.normalize_target(batch_y[:, -pred_len:, :])
                        if backbone.use_revin
                        else batch_y[:, -pred_len:, :]
                    )
                    prior_sq += float((aux["y_prior"] - target_norm).pow(2).sum().item())
                    final_sq += float((aux["output_norm"] - target_norm).pow(2).sum().item())
                    n_elem += float(target_norm.numel())
                    del outputs
            rows.append({
                "K": int(k),
                "prior_rmse": math.sqrt(prior_sq / max(n_elem, 1.0)),
                "final_rmse": math.sqrt(final_sq / max(n_elem, 1.0)),
            })
    finally:
        backbone.diff_steps = saved_steps
    return rows


def _collect_variant(args, dataset, pred_len, variant, device):
    run_args, model, seq, source = _load_model(args, dataset, pred_len, variant, device)
    test_data, test_loader = data_provider(run_args, "test")
    backbone = model.backbone
    config = get_config(dataset, pred_len, source=source)
    pred_len_eff = int(config["pred_len"])
    patch_len = int(backbone.patch_len)
    num_patches = int(backbone.num_future_patches)
    is_hyperbolic = hasattr(backbone.manifold, "c")
    geometry = "poincare" if is_hyperbolic else "euclidean"
    curvature = float(getattr(backbone.manifold, "c", 1.0))
    print("[eval ] {} {} ({} geometry, config={})".format(dataset, variant, geometry, source))

    preds = []
    trues = []
    sums = {
        "geo_prior": 0.0,
        "geo_pred": 0.0,
        "geo_gain": 0.0,
        "hist": 0.0,
        "hist_n": 0.0,
        "prior_sq": 0.0,
        "diff_sq": 0.0,
        "final_sq": 0.0,
        "n_elem": 0.0,
        "n_patch": 0.0,
    }
    sample = None
    with torch.no_grad():
        for batch_idx, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
            batch_x = batch_x.float().to(device)
            batch_y = batch_y.float().to(device)
            outputs, aux = backbone(batch_x, None)
            f_dim = -1 if run_args.features == "MS" else 0
            out = outputs[:, -pred_len_eff:, f_dim:]
            target = batch_y[:, -pred_len_eff:, f_dim:]
            preds.append(out.detach().cpu().numpy())
            trues.append(target.detach().cpu().numpy())

            batch, _, channels = batch_x.shape
            target_raw = batch_y[:, -pred_len_eff:, :]
            if backbone.use_revin:
                target_norm = backbone.revin.normalize_target(target_raw)
            else:
                target_norm = target_raw
            valid = backbone._future_mask(batch * channels, device, target_norm.dtype)
            patch_mask = valid.any(dim=-1)
            patch_float = patch_mask.float()
            target_flat = _split_future_patches(target_norm, patch_len).reshape(batch * channels, num_patches, patch_len) * valid
            y_prior = aux["y_prior"]
            prior_flat = _split_future_patches(y_prior, patch_len).reshape(batch * channels, num_patches, patch_len) * valid
            z_target = backbone._project_target_hyp(target_flat)
            z_prior = backbone._project_target_hyp(prior_flat)
            z_pred = aux["z_fut_hyp"]
            z_hist = aux["z_hist_hyp"]
            manifold = backbone.manifold

            d_prior = manifold.geodesic_dist(z_prior, z_target)
            d_pred = manifold.geodesic_dist(z_pred, z_target)
            n_patch = float(patch_float.sum().item())
            sums["geo_prior"] += float((d_prior * patch_float).sum().item())
            sums["geo_pred"] += float((d_pred * patch_float).sum().item())
            gain = 1.0 - d_pred / (d_prior + 1e-6)
            sums["geo_gain"] += float((gain * patch_float).sum().item())
            sums["n_patch"] += n_patch

            if z_hist.shape[1] > 1:
                hist_dist = manifold.geodesic_dist(z_hist[:, :-1, :], z_hist[:, 1:, :])
                sums["hist"] += float(hist_dist.mean().item())
                sums["hist_n"] += 1.0

            out_norm = aux["output_norm"]
            sums["prior_sq"] += float((y_prior - target_norm).pow(2).sum().item())
            sums["diff_sq"] += float((out_norm - y_prior).pow(2).sum().item())
            sums["final_sq"] += float((out_norm - target_norm).pow(2).sum().item())
            sums["n_elem"] += float(target_norm.numel())

            if sample is None and batch_idx == args.sample_batch:
                n_tokens = z_hist.shape[1]
                z_hist_bc = z_hist.reshape(batch, channels, n_tokens, -1)
                if args.sample_channel >= 0:
                    hist_channel = args.sample_channel
                    series_channel = args.sample_channel
                else:
                    history_steps = manifold.geodesic_dist(z_hist_bc[0, :, :-1, :], z_hist_bc[0, :, 1:, :]).mean(dim=1)
                    hist_channel = int(history_steps.argmax().item())
                    prior_err = (y_prior[0] - target_norm[0]).pow(2).mean(dim=0)
                    final_err = (out_norm[0] - target_norm[0]).pow(2).mean(dim=0)
                    gain = (prior_err - final_err).detach().cpu().numpy()
                    series_channel = int(np.argmax(gain))
                prior_denorm = backbone.revin.denormalize(y_prior) if backbone.use_revin else y_prior
                sample = {
                    "history_channel": hist_channel,
                    "series_channel": series_channel,
                    "y_prior_std": prior_denorm[0, :, series_channel].float().cpu().numpy(),
                    "y_pred_std": outputs[0, :, series_channel].float().cpu().numpy(),
                    "y_target_std": batch_y[0, -pred_len_eff:, series_channel].float().cpu().numpy(),
                    "z_hist": z_hist_bc[0, hist_channel].float().cpu().numpy(),
                    "z_prior": z_prior.reshape(batch, channels, num_patches, -1)[0, hist_channel].float().cpu().numpy(),
                    "z_pred": z_pred.reshape(batch, channels, num_patches, -1)[0, hist_channel].float().cpu().numpy(),
                    "z_target": z_target.reshape(batch, channels, num_patches, -1)[0, hist_channel].float().cpu().numpy(),
                    "curvature": curvature,
                    "hyperbolic": is_hyperbolic,
                    "patch_len": patch_len,
                }

    pred = np.concatenate(preds, axis=0)
    true = np.concatenate(trues, axis=0)
    mae, mse, rmse, mape, mspe = metric(pred, true)
    if sample is not None:
        print(
            "[sample] batch={} history_channel={} series_channel={} tokens={}".format(
                args.sample_batch, sample["history_channel"], sample["series_channel"], len(sample["z_hist"])
            )
        )
    n_patch = max(sums["n_patch"], 1.0)
    n_elem = max(sums["n_elem"], 1.0)
    geo_prior = sums["geo_prior"] / n_patch
    geo_pred = sums["geo_pred"] / n_patch
    result = {
        "dataset": dataset,
        "pred_len": pred_len,
        "variant": variant,
        "des": variant_des(variant, pred_len),
        "mse": float(mse),
        "mae": float(mae),
        "geo_dist_prior": geo_prior,
        "geo_dist_pred": geo_pred,
        "geo_align": 1.0 / (1.0 + geo_pred),
        "geo_align_rel": 1.0 - geo_pred / max(geo_prior, 1e-8),
        "geo_gain": sums["geo_gain"] / n_patch,
        "hist_step_geo": sums["hist"] / max(sums["hist_n"], 1.0),
        "prior_rmse": math.sqrt(sums["prior_sq"] / n_elem),
        "diff_rmse": math.sqrt(sums["diff_sq"] / n_elem),
        "final_rmse_norm": math.sqrt(sums["final_sq"] / n_elem),
        "geometry": geometry,
        "config_source": source,
        "checkpoint": seq,
        "status": "ok",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    k_rows = []
    if args.k_sweep and variant == "none":
        steps = [int(part) for part in str(args.k_sweep).split(",") if part.strip()]
        print("[k-sweep] {} diffusion steps={}".format(dataset, steps))
        k_rows = _k_sweep(backbone, run_args, test_loader, device, pred_len_eff, steps)
    return result, sample, k_rows


def _log_map_2d(points, curvature, hyperbolic):
    if not hyperbolic:
        return points.astype(np.float64)
    norm = np.linalg.norm(points, axis=1, keepdims=True)
    sqrt_c = math.sqrt(curvature)
    ratio = np.clip(sqrt_c * norm, None, 1.0 - 1e-6)
    factor = np.arctanh(ratio) / (sqrt_c * np.clip(norm, 1e-8, None))
    return points * factor


def _exp_map_2d(tangent, curvature, hyperbolic, scale):
    scaled = tangent * scale
    if not hyperbolic:
        return scaled
    norm = np.linalg.norm(scaled, axis=1, keepdims=True)
    sqrt_c = math.sqrt(curvature)
    factor = np.tanh(sqrt_c * norm) / (sqrt_c * np.clip(norm, 1e-8, None))
    return scaled * factor


def _fit_disk_scale(tangent, curvature, hyperbolic, target_radius=0.93):
    radius = 1.0 / math.sqrt(curvature) if hyperbolic else 1.0
    aim = target_radius * radius
    low, high = 1e-3, 1.0
    for _ in range(60):
        mid = 0.5 * (low + high)
        probe = _exp_map_2d(tangent, curvature, hyperbolic, mid)
        if np.linalg.norm(probe, axis=1).max() < aim:
            low = mid
        else:
            high = mid
    return low


def _project_to_disk(sample):
    groups = [sample["z_hist"], sample["z_prior"], sample["z_pred"], sample["z_target"]]
    tangent = _log_map_2d(np.concatenate(groups, axis=0), sample["curvature"], sample["hyperbolic"])
    try:
        pca = PCA(n_components=2, random_state=0)
        uv = pca.fit_transform(tangent)
    except ValueError:
        uv = tangent[:, :2]
    for axis in range(2):
        if uv[:, axis].mean() < 0:
            uv[:, axis] *= -1.0
    max_norm = float(np.linalg.norm(uv, axis=1).max())
    if max_norm > 0:
        uv = uv / max_norm
    # One far patch would otherwise squash every other point into the centre;
    # clipping at the 95th percentile keeps the bulk spread across the disk
    # while the few extremes saturate near the boundary.
    norms = np.linalg.norm(uv, axis=1, keepdims=True)
    cap = float(np.quantile(norms, 0.95))
    if cap > 0:
        uv = uv / cap
        norms = np.linalg.norm(uv, axis=1, keepdims=True)
        uv = uv * np.clip(1.0 / np.clip(norms, 1e-8, None), None, 1.0)
    scale = _fit_disk_scale(uv, sample["curvature"], sample["hyperbolic"], target_radius=0.90)
    disk = _exp_map_2d(uv, sample["curvature"], sample["hyperbolic"], scale)
    splits = []
    offset = 0
    for group in groups:
        splits.append(disk[offset:offset + len(group)])
        offset += len(group)
    return splits


def _style_axis(axis, spine_color=HAIRLINE):
    axis.tick_params(labelsize=TICK_FONTSIZE, colors=TEXT_GRAY, length=1.6, pad=1.6)
    for spine in axis.spines.values():
        spine.set_color(spine_color)
        spine.set_linewidth(0.45)


def _plot_panel_disk(axis, sample, result):
    hist_xy, prior_xy, pred_xy, target_xy = _project_to_disk(sample)
    radius = 1.0 / math.sqrt(sample["curvature"]) if sample["hyperbolic"] else 1.0
    axis.add_patch(Circle((0.0, 0.0), radius, fill=False, color=FRAME_COLOR, lw=0.6, zorder=2))
    for fraction in (0.4, 0.7, 0.9):
        axis.add_patch(Circle((0.0, 0.0), radius * fraction, fill=False, color=GRID_GRAY,
                              lw=0.3, ls=(0, (1.4, 2.0)), zorder=1))
    axis.axhline(0.0, color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)), zorder=0)
    axis.axvline(0.0, color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)), zorder=0)

    axis.plot(prior_xy[:, 0], prior_xy[:, 1], color=PRIOR_COLOR, lw=0.8, ls=(0, (3.0, 1.6)),
              marker="s", ms=2.4, mfc="none", mec=PRIOR_COLOR, mew=0.6, zorder=4)
    axis.plot(pred_xy[:, 0], pred_xy[:, 1], color=PRED_COLOR, lw=0.9, marker="D", ms=2.6,
              mec=SURFACE, mew=0.3, zorder=6)
    axis.plot(target_xy[:, 0], target_xy[:, 1], color=TARGET_COLOR, lw=0.0, marker="*",
              ms=5.2, zorder=5)
    pred_center = pred_xy.mean(axis=0)
    target_center = target_xy.mean(axis=0)
    axis.annotate(
        "", xy=target_center, xytext=pred_center,
        arrowprops=dict(arrowstyle="-|>", color=TARGET_COLOR, lw=0.45, ls=(0, (1.0, 1.6)),
                        shrinkA=2.0, shrinkB=2.0, mutation_scale=4.5),
        zorder=3,
    )
    if len(hist_xy) > 1:
        axis.plot(hist_xy[:, 0], hist_xy[:, 1], color=HIST_COLOR, lw=0.95, zorder=5)
    axis.plot(hist_xy[:, 0], hist_xy[:, 1], color=HIST_COLOR, lw=0.0, marker="o", ms=1.9,
              mec=SURFACE, mew=0.3, zorder=6)
    for step in range(0, max(len(hist_xy) - 1, 0), 2):
        axis.annotate(
            "", xy=hist_xy[step + 1], xytext=hist_xy[step],
            arrowprops=dict(arrowstyle="-|>", color=HIST_COLOR, lw=0.55,
                            shrinkA=0.4, shrinkB=0.4, mutation_scale=4.5),
            zorder=5,
        )

    axis.set_xlim(-radius * 1.02, radius * 1.02)
    axis.set_ylim(-radius * 1.30, radius * 1.04)
    axis.set_aspect("equal", adjustable="datalim")
    axis.set_anchor("N")
    axis.set_xticks([])
    axis.set_yticks([])
    for spine in axis.spines.values():
        spine.set_visible(False)

    # Endpoint labels are pushed radially outward from the disk centre so the
    # four trajectories stay readable even when their last patches coincide.
    annotations = (
        (hist_xy[-1], "$z^{\\mathrm{hist}}$", HIST_COLOR, 180.0, 20.0),
        (prior_xy[-1], "$z^{\\mathrm{prior}}$", PRIOR_COLOR, 152.0, 20.0),
        (pred_xy[-1], "$\\hat{z}^{\\mathrm{fut}}$", PRED_COLOR, 35.0, 20.0),
        (target_xy[-1], "$z^{\\mathrm{fut}}_{\\mathrm{tgt}}$", TARGET_COLOR, -142.0, 26.0),
    )
    for point, label, color, angle, radius in annotations:
        rad = math.radians(angle)
        offset = (radius * math.cos(rad), radius * math.sin(rad))
        axis.annotate(
            label, xy=point, textcoords="offset points", xytext=offset,
            fontsize=MIN_FONTSIZE, color=color, ha="center", va="center", zorder=9,
            bbox=dict(boxstyle="square,pad=0.12", facecolor=SURFACE, edgecolor="none",
                      alpha=0.92),
            arrowprops=dict(arrowstyle="-", color=color, lw=0.3,
                            shrinkA=0.0, shrinkB=1.5, alpha=0.85),
        )

    axis.text(
        0.5, -0.015,
        "$c=%.2f$, $d_{\\mathrm{hyp}}=%d$, %d patches\n" % (
            sample["curvature"], sample["z_hist"].shape[1], len(sample["z_hist"])
        )
        + "$\\bar{d}_{\\mathrm{prior}}=%.3f \\rightarrow \\bar{d}_{\\mathrm{fut}}=%.3f$ (distance %+.2f%%)" % (
            result["geo_dist_prior"], result["geo_dist_pred"], -100.0 * result["geo_align_rel"]
        ),
        transform=axis.transAxes, ha="center", va="top",
        fontsize=MIN_FONTSIZE, color=TEXT_GRAY, linespacing=1.35,
    )
    axis.set_title("(a) Poincaré disk and geodesic flow",
                   fontsize=PANEL_FONTSIZE, color=TEXT_GRAY, pad=2.5, loc="left")


def _plot_panel_prior(axis_top, axis_bottom, sample):
    y_target = sample["y_target_std"]
    y_prior = sample["y_prior_std"]
    y_pred = sample["y_pred_std"]
    horizon = len(y_prior)
    steps = np.arange(horizon)
    delta = y_pred - y_prior
    values = np.concatenate([y_target, y_prior, y_pred])
    lo = float(values.min())
    hi = float(values.max())
    span = hi - lo if hi > lo else 1.0
    axis_top.set_ylim(lo - 0.08 * span, hi + 0.55 * span)

    axis_top.plot(steps, y_target, color=TARGET_COLOR, lw=0.8, ls=(0, (3.2, 1.6)))
    axis_top.plot(steps, y_prior, color=PRIOR_COLOR, lw=1.0)
    axis_top.plot(steps, y_pred, color=PRED_COLOR, lw=1.0)
    axis_top.set_ylabel("Standardized value", fontsize=LABEL_FONTSIZE, labelpad=1.2)
    axis_top.set_title("(b) Prior-bridge denoising (variate %d)" % sample["series_channel"],
                       fontsize=PANEL_FONTSIZE, color=TEXT_GRAY, pad=2.5, loc="left")
    axis_top.grid(axis="y", color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)))
    axis_top.set_axisbelow(True)
    axis_top.tick_params(axis="x", labelbottom=False, length=1.6, pad=1.2)
    _style_axis(axis_top)
    for xpos, token, token_color in (
        (0.025, "$Y$", TARGET_COLOR),
        (0.115, "$Y_{\\mathrm{prior}}$", PRIOR_COLOR),
        (0.290, "$\\hat{Y}_0$", PRED_COLOR),
    ):
        axis_top.text(xpos, 0.965, token, transform=axis_top.transAxes, ha="left",
                      va="top", fontsize=MIN_FONTSIZE, color=token_color)

    # The pointwise RMSE is nearly neutral at K=1; the correlation gain is what
    # the high-frequency correction buys, so both are reported.
    prior_rmse = float(np.sqrt(np.mean((y_prior - y_target) ** 2)))
    final_rmse = float(np.sqrt(np.mean((y_pred - y_target) ** 2)))
    prior_r = float(np.corrcoef(y_prior, y_target)[0, 1])
    final_r = float(np.corrcoef(y_pred, y_target)[0, 1])
    axis_top.text(
        0.985, 0.965,
        "$r$ %.3f$\\rightarrow$%.3f\nRMSE %.3f$\\rightarrow$%.3f" % (
            prior_r, final_r, prior_rmse, final_rmse
        ),
        transform=axis_top.transAxes, ha="right", va="top",
        fontsize=MIN_FONTSIZE, color=TEXT_GRAY, linespacing=1.3,
    )

    axis_bottom.bar(steps, delta, width=0.8, color=DELTA_COLOR, edgecolor="none", zorder=1)
    axis_bottom.plot(steps, delta, color=TARGET_COLOR, lw=0.55, zorder=2)
    axis_bottom.axhline(0.0, color=TEXT_GRAY, lw=0.4, ls=(0, (1.4, 2.0)))
    axis_bottom.set_ylabel("$\\Delta Y_{\\mathrm{diff}}$", fontsize=LABEL_FONTSIZE, labelpad=1.2)
    axis_bottom.set_xlabel("Forecast step", fontsize=LABEL_FONTSIZE, labelpad=1.2)
    axis_bottom.grid(axis="y", color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)))
    axis_bottom.set_axisbelow(True)
    axis_bottom.set_xticks([0, 48, 96])
    _style_axis(axis_bottom)


def _ema(values, weight=0.06):
    if not values:
        return np.empty(0)
    out = np.empty(len(values), dtype=np.float64)
    acc = float(values[0])
    for idx, value in enumerate(values):
        acc = (1.0 - weight) * acc + weight * float(value)
        out[idx] = acc
    return out


def _loss_history_candidates(dataset, pred_len):
    model_id = get_config(dataset, pred_len)["model_id"]
    candidates = [
        os.path.join(REPO_ROOT, "output", "mechanism", "loss_history_{}_pl{}.json".format(dataset, int(pred_len))),
    ]
    pattern = os.path.join(REPO_ROOT, "output", "explanation", "metrics", "{}_M2Patch_*_itr0".format(model_id), "loss_history.json")
    candidates.extend(sorted(glob.glob(pattern), key=os.path.getmtime, reverse=True))
    return candidates


def _load_loss_history(dataset, pred_len):
    for path in _loss_history_candidates(dataset, pred_len):
        if os.path.isfile(path):
            with open(path) as handle:
                data = json.load(handle)
            print("[loss-curve] {} <- {}".format(dataset, path))
            return data, path
    print("[loss-curve] {} has no loss_history.json; panel (c) falls back to the K sweep".format(dataset))
    return None, None


def _plot_panel_diffusion(axis, axis_k, loss_history, k_rows, config, deployed_k):
    axis.set_title("(c) Denoising dynamics", fontsize=PANEL_FONTSIZE, color=TEXT_GRAY,
                   pad=2.5, loc="left")
    axis.grid(axis="y", color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)))
    axis.set_axisbelow(True)
    _style_axis(axis)

    if loss_history is not None and loss_history.get("total"):
        episodes = np.arange(1, len(loss_history["total"]) + 1)
        total = _ema(loss_history["total"])
        bridge = _ema(loss_history["bridge_dsm"])
        hyp = _ema(loss_history["hyp_align"]) * float(config.get("lambda_hyp", 0.0))
        prior = _ema(loss_history["prior"]) * float(config.get("lambda_prior", 0.0))
        axis.plot(episodes, total, color=TEXT_GRAY, lw=0.65, ls=(0, (2.4, 1.4)))
        axis.plot(episodes, bridge, color=TARGET_COLOR, lw=0.9)
        axis.plot(episodes, prior, color=PRIOR_COLOR, lw=0.9)
        axis.plot(episodes, hyp, color=HIST_COLOR, lw=0.9)
        axis.set_yscale("log")
        axis.tick_params(axis="x", labelbottom=False)
        axis.set_ylabel("Loss term", fontsize=LABEL_FONTSIZE, labelpad=1.2)
        # Direct labels above the data keep the trace area free of a legend box.
        stacked = np.concatenate([total, bridge, prior, hyp])
        stacked = stacked[np.isfinite(stacked) & (stacked > 0)]
        if stacked.size:
            axis.set_ylim(float(stacked.min()) * 0.7, float(stacked.max()) * 40.0)
        for xpos, ypos, token, token_color in (
            (0.02, 0.985, "$\\mathcal{L}_{\\mathrm{total}}$", TEXT_GRAY),
            (0.42, 0.985, "$\\mathcal{L}_{\\mathrm{bridge}}$", TARGET_COLOR),
            (0.02, 0.845, "$\\lambda_{p}\\mathcal{L}_{\\mathrm{prior}}$", PRIOR_COLOR),
            (0.44, 0.845, "$\\lambda_{h}\\mathcal{L}_{\\mathrm{hyp}}$", HIST_COLOR),
        ):
            axis.text(xpos, ypos, token, transform=axis.transAxes, ha="left", va="top",
                      fontsize=MIN_FONTSIZE, color=token_color)
    else:
        axis.tick_params(axis="x", labelbottom=False)
        axis.set_ylabel("Loss term", fontsize=LABEL_FONTSIZE, labelpad=1.2)
        axis.text(0.5, 0.5, "training trace unavailable", transform=axis.transAxes,
                  ha="center", va="center", fontsize=MIN_FONTSIZE, color=TEXT_GRAY)

    axis_k.grid(axis="y", color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)))
    axis_k.set_axisbelow(True)
    _style_axis(axis_k)
    if k_rows:
        _plot_k_sweep(axis_k, k_rows, deployed_k)
    else:
        axis_k.set_visible(False)


def _plot_k_sweep(axis, k_rows, deployed_k):
    steps = [row["K"] for row in k_rows]
    prior_level = k_rows[0]["prior_rmse"]
    residual = [row["final_rmse"] for row in k_rows]
    low = min(residual + [prior_level])
    high = max(residual + [prior_level])
    pad = max((high - low) * 0.30, 0.005)
    y_low = low - pad
    y_high = high + pad * 1.15
    axis.set_ylim(y_low, y_high)

    axis.plot(steps, residual, color=PRED_COLOR, lw=0.9, marker="o", ms=2.6,
              mec=SURFACE, mew=0.3, zorder=3)
    axis.axhline(prior_level, color=PRIOR_COLOR, lw=0.7, ls=(0, (2.4, 1.4)), zorder=2)
    for step, value in zip(steps, residual):
        frac = (value - y_low) / max(y_high - y_low, 1e-9)
        below = frac > 0.85
        offset = (0.0, -7.0) if below else (0.0, 8.0)
        axis.annotate("%.3f" % value, (step, value), textcoords="offset points",
                      xytext=offset, ha="center", va="top" if below else "bottom",
                      fontsize=MIN_FONTSIZE, color=PRED_COLOR,
                      bbox=dict(boxstyle="square,pad=0.12", facecolor=SURFACE,
                                edgecolor="none", alpha=0.92), zorder=6)
    if deployed_k in steps:
        index = steps.index(deployed_k)
        axis.plot([deployed_k], [residual[index]], color=PRED_COLOR, lw=0.0, marker="o",
                  ms=7.5, mfc="none", mec=PRED_COLOR, mew=0.8, zorder=4)
    axis.set_title("$K$ sweep (ring = deployed $K{=}%d$)" % deployed_k, loc="left",
                   fontsize=MIN_FONTSIZE, color=TEXT_GRAY, pad=2.5)
    axis.annotate("prior %.3f" % prior_level, xy=(max(steps), prior_level),
                  textcoords="offset points", xytext=(-1.0, -2.5), ha="right", va="top",
                  fontsize=MIN_FONTSIZE, color=PRIOR_COLOR, zorder=6,
                  bbox=dict(boxstyle="square,pad=0.10", facecolor=SURFACE,
                            edgecolor="none", alpha=0.92))
    axis.set_xticks(steps)
    axis.set_xticklabels(["$K{=}%d$" % step for step in steps], fontsize=MIN_FONTSIZE)
    axis.set_xlim(min(steps) - 0.35, max(steps) + 0.35)
    axis.yaxis.set_major_locator(plt.MaxNLocator(nbins=3))
    axis.set_ylabel("RMSE$_{\\Delta}$", fontsize=LABEL_FONTSIZE, labelpad=1.2)
    axis.set_xlabel("Diffusion steps", fontsize=LABEL_FONTSIZE, labelpad=1.2)


def _plot_panel_interventions(axis, results):
    variants = [result["variant"] for result in results]
    mse_values = np.array([result["mse"] for result in results])
    mae_values = np.array([result["mae"] for result in results])
    alignment = np.array([result["geo_align"] for result in results])
    positions = np.arange(len(variants))
    height = 0.32

    axis.barh(positions - height / 2.0, mse_values, height, color=MSE_COLOR, zorder=3)
    axis.barh(positions + height / 2.0, mae_values, height, color=MAE_COLOR, zorder=3)
    span = float(max(mse_values.max(), mae_values.max()))
    for position, value in zip(positions, mse_values):
        axis.text(value + span * 0.012, position - height / 2.0, "%.4f" % value,
                  ha="left", va="center", fontsize=MIN_FONTSIZE, color=TEXT_GRAY)
    for position, value in zip(positions, mae_values):
        axis.text(value + span * 0.012, position + height / 2.0, "%.4f" % value,
                  ha="left", va="center", fontsize=MIN_FONTSIZE, color=TEXT_GRAY)
    axis.text(span * 0.02, positions[0] - height / 2.0, "MSE", ha="left", va="center",
              fontsize=MIN_FONTSIZE, color=SURFACE, zorder=5)
    axis.text(span * 0.02, positions[0] + height / 2.0, "MAE", ha="left", va="center",
              fontsize=MIN_FONTSIZE, color=SURFACE, zorder=5)

    axis.set_yticks(positions)
    axis.set_yticklabels([SHORT_LABELS.get(variant, variant) for variant in variants],
                         fontsize=TICK_FONTSIZE)
    axis.invert_yaxis()
    axis.set_xlabel("Error in standardized space", fontsize=LABEL_FONTSIZE, labelpad=1.2)
    axis.set_xlim(0.0, span * 1.26)
    axis.set_ylim(len(variants) - 0.45, -0.55)
    axis.grid(axis="x", color=GRID_GRAY, lw=0.3, ls=(0, (1.4, 2.0)))
    axis.set_axisbelow(True)
    _style_axis(axis)
    axis.spines["right"].set_visible(False)
    axis.set_title("(d) Mechanism interventions", fontsize=PANEL_FONTSIZE,
                   color=TEXT_GRAY, pad=2.5, loc="left")

    axis.set_title("(d) Mechanism interventions", fontsize=PANEL_FONTSIZE,
                   color=TEXT_GRAY, pad=2.5, loc="left")


def _plot_alignment_strip(axis, results):
    variants = [result["variant"] for result in results]
    alignment = np.array([result["geo_align"] for result in results])
    positions = np.arange(len(variants))
    euclid = [str(result.get("geometry", "poincare")) != "poincare" for result in results]

    low = float(alignment.min())
    high = float(alignment.max())
    span = max(high - low, 0.01)
    axis.set_xlim(low - 0.12 * span, high + 0.95 * span)
    axis.set_ylim(len(variants) - 0.45, -0.80)

    for position, value, is_euclid in zip(positions, alignment, euclid):
        # Marker-only display: no connecting line can imply that the Euclidean
        # point lies on the same scale as the geodesic ones.
        axis.plot([value], [position], color=ALIGN_COLOR, lw=0.0, marker="D", ms=3.4,
                  mfc=SURFACE if is_euclid else ALIGN_COLOR, mec=ALIGN_COLOR, mew=0.7, zorder=6)
        if not is_euclid:
            axis.annotate(
                "%.3f" % value, (value, position), textcoords="offset points",
                xytext=(5.0, 0.0), ha="left", va="center",
                fontsize=MIN_FONTSIZE, color=ALIGN_COLOR, zorder=7,
                bbox=dict(boxstyle="square,pad=0.10", facecolor=SURFACE,
                          edgecolor="none", alpha=0.92),
            )

    axis.set_yticks(positions)
    axis.set_yticklabels([])
    axis.set_xticks([])
    axis.tick_params(axis="y", length=0.0)
    axis.set_title("$1/(1+\\bar{d})$\nopen: Euclid", fontsize=MIN_FONTSIZE,
                   color=ALIGN_COLOR, pad=3.5, linespacing=1.15)
    for side in ("bottom", "left", "right", "top"):
        axis.spines[side].set_visible(False)


def _write_summary(path, rows):
    merged = {}
    order = []
    for row in read_results(path) if os.path.exists(path) else []:
        key = tuple(str(row[name]) for name in SUMMARY_KEY)
        if key not in merged:
            order.append(key)
        merged[key] = row
    for row in rows:
        key = tuple(str(row[name]) for name in SUMMARY_KEY)
        if key not in merged:
            order.append(key)
        merged[key] = row
    variant_rank = {variant: idx for idx, variant in enumerate(VARIANTS)}
    ordered = sorted(
        order,
        key=lambda key: (key[0], int(key[1]), variant_rank.get(key[2], len(variant_rank))),
    )
    if os.path.exists(path):
        os.remove(path)
    for key in ordered:
        row = merged[key]
        payload = {name: row.get(name, "") for name in SUMMARY_COLUMNS}
        append_result(path, payload, columns=SUMMARY_COLUMNS)


def _print_summary(results):
    header = "{:<18} {:>9} {:>9} {:>9} {:>9} {:>8} {:>9} {:>9} {:>9}".format(
        "variant", "MSE", "MAE", "d_prior", "d_pred", "align", "align_rel", "prior_rmse", "final_rmse"
    )
    print(header)
    print("-" * len(header))
    for result in results:
        print(
            "{:<18} {:>9.5f} {:>9.5f} {:>9.4f} {:>9.4f} {:>8.4f} {:>9.4f} {:>9.4f} {:>9.4f}".format(
                result["variant"],
                result["mse"],
                result["mae"],
                result["geo_dist_prior"],
                result["geo_dist_pred"],
                result["geo_align"],
                result["geo_align_rel"],
                result["prior_rmse"],
                result["final_rmse_norm"],
            )
        )


def _report_overlaps(figure, label):
    # Prints text-text and text-over-curve collisions in display space so the
    # single-column layout can be checked without eyeballing the PNG.
    figure.canvas.draw()
    renderer = figure.canvas.get_renderer()
    boxes = []
    candidates = []
    for axis in figure.axes:
        candidates.extend([item for item in axis.texts if item.get_text().strip()])
        candidates.extend([axis.title, axis.xaxis.label, axis.yaxis.label])
    candidates.extend([item for item in figure.texts if item.get_text().strip()])
    for item in candidates:
        if not item.get_text().strip():
            continue
        try:
            if isinstance(item, Annotation):
                # Annotation.get_window_extent unions the text with its arrow,
                # which would report false collisions between leader lines.
                box = Text.get_window_extent(item, renderer)
            else:
                box = item.get_window_extent(renderer)
        except Exception:
            continue
        if box.width <= 0 or box.height <= 0:
            continue
        boxes.append((item.get_text().replace("\n", "|")[:22], box, item))
    text_hits = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            first, second = boxes[i][1], boxes[j][1]
            overlap_w = min(first.x1, second.x1) - max(first.x0, second.x0)
            overlap_h = min(first.y1, second.y1) - max(first.y0, second.y0)
            if overlap_w > 0.5 and overlap_h > 0.5:
                text_hits.append((boxes[i][0], boxes[j][0]))
    curve_hits = []
    for axis in figure.axes:
        lines = [line for line in axis.lines if len(line.get_xydata()) >= 8]
        if not lines:
            continue
        for text, box, item in boxes:
            if item.axes is not axis:
                continue
            covered = 0
            for line in lines:
                points = line.get_transform().transform(line.get_xydata())
                inside = ((points[:, 0] > box.x0) & (points[:, 0] < box.x1)
                          & (points[:, 1] > box.y0) & (points[:, 1] < box.y1))
                covered += int(inside.sum())
            if covered >= 2:
                curve_hits.append((text, covered))
    print("[overlap] {}: {} text-text, {} text-over-curve".format(
        label, len(text_hits), len(curve_hits)))
    for pair in text_hits[:8]:
        print("           text-text: {!r} x {!r}".format(*pair))
    for pair in curve_hits[:8]:
        print("           text-over-curve: {!r} ({} pts)".format(*pair))


def _render_dataset_figure(figure_paths, sample, results, loss_history, k_rows, config, dataset_label, deployed_k):
    figure = plt.figure(figsize=FIGURE_SIZE)
    grid = figure.add_gridspec(
        2, 2,
        width_ratios=[1.0, 1.10], height_ratios=[1.0, 0.96],
        left=0.072, right=0.985, top=0.935, bottom=0.095,
        wspace=0.30, hspace=0.40,
    )
    axis_disk = figure.add_subplot(grid[0, 0])
    prior_grid = grid[0, 1].subgridspec(2, 1, height_ratios=[1.5, 1.0], hspace=0.08)
    axis_prior = figure.add_subplot(prior_grid[0])
    axis_delta = figure.add_subplot(prior_grid[1])
    diffusion_grid = grid[1, 0].subgridspec(2, 1, height_ratios=[1.75, 1.0], hspace=0.20)
    axis_diffusion = figure.add_subplot(diffusion_grid[0])
    axis_k = figure.add_subplot(diffusion_grid[1])
    lower_right = grid[1, 1].subgridspec(1, 2, width_ratios=[3.0, 1.55], wspace=0.05)
    axis_intervention = figure.add_subplot(lower_right[0])
    axis_alignment = figure.add_subplot(lower_right[1])

    _plot_panel_disk(axis_disk, sample, results[0])
    _plot_panel_prior(axis_prior, axis_delta, sample)
    _plot_panel_diffusion(axis_diffusion, axis_k, loss_history, k_rows, config, deployed_k)
    _plot_panel_interventions(axis_intervention, results)
    _plot_alignment_strip(axis_alignment, results)

    figure.suptitle("{} (pl = {}): hyperbolic manifold and prior-bridge diffusion".format(
        dataset_label, results[0]["pred_len"]),
        fontsize=PANEL_FONTSIZE, color=TEXT_GRAY, y=0.995)

    _report_overlaps(figure, dataset_label)
    for figure_path in figure_paths:
        figure.savefig(figure_path, dpi=600, facecolor=SURFACE)
        print("[figure] {}".format(figure_path))
    plt.close(figure)


def _read_summary(path):
    if not os.path.exists(path):
        return []
    return read_results(path)


def _render_cross_dataset_figure(path, rows):
    datasets = []
    for row in rows:
        if row["dataset"] not in datasets:
            datasets.append(row["dataset"])
    datasets.sort()
    variants = [variant for variant in VARIANTS if any(row["variant"] == variant for row in rows)]
    lookup = {(row["dataset"], row["variant"]): row for row in rows}
    if not datasets or not variants:
        print("[cross] summary is empty; cross-dataset figure skipped")
        return

    figure = plt.figure(figsize=(5.35, 4.35))
    grid = figure.add_gridspec(
        2, 1, height_ratios=[1.0, 1.0], left=0.185, right=0.965, top=0.905, bottom=0.10, hspace=0.34,
    )
    axis_mse = figure.add_subplot(grid[0])
    axis_align = figure.add_subplot(grid[1])

    group_height = 0.80
    slot = group_height / max(len(datasets), 1)
    variant_positions = np.arange(len(variants))
    palette = [TARGET_COLOR, HIST_COLOR, PRIOR_COLOR, PRED_COLOR, color_dict["npg_amber"]]

    for order, dataset in enumerate(datasets):
        offsets = variant_positions - group_height / 2.0 + slot * (order + 0.5)
        reference = lookup.get((dataset, "none"))
        base_mse = float(reference["mse"]) if reference is not None else None
        base_align = float(reference["geo_align"]) if reference is not None else None
        delta = []
        align_rel = []
        for variant in variants:
            row = lookup.get((dataset, variant))
            if row is None or base_mse is None:
                delta.append(np.nan)
                align_rel.append(np.nan)
                continue
            delta.append(100.0 * (float(row["mse"]) - base_mse) / base_mse)
            align_rel.append(float(row["geo_align"]) - base_align)
        axis_mse.barh(offsets, delta, slot * 0.86, color=palette[order % len(palette)],
                      label=dataset, zorder=3)
        axis_align.hlines(offsets, 0.0, align_rel, color=palette[order % len(palette)],
                          lw=0.75, zorder=3)
        for offset, value, variant in zip(offsets, align_rel, variants):
            row = lookup.get((dataset, variant))
            hollow = row is not None and str(row.get("geometry", "poincare")) != "poincare"
            axis_align.plot([value], [offset], color=palette[order % len(palette)], lw=0.0,
                            marker="o", ms=2.9, mec=palette[order % len(palette)],
                            mfc=SURFACE if hollow else palette[order % len(palette)],
                            mew=0.7, zorder=4)

    axis_mse.axvline(0.0, color=TEXT_GRAY, lw=0.55, zorder=4)
    axis_mse.set_yticks(variant_positions)
    axis_mse.set_yticklabels([VARIANT_LABELS.get(variant, variant) for variant in variants],
                             fontsize=TICK_FONTSIZE)
    axis_mse.invert_yaxis()
    axis_mse.set_xlabel("$\\Delta$MSE vs. full model (%)", fontsize=LABEL_FONTSIZE, labelpad=1.5)
    axis_mse.grid(axis="x", color=GRID_GRAY, lw=0.35, ls=(0, (1.4, 2.0)))
    axis_mse.set_axisbelow(True)
    _style_axis(axis_mse)
    axis_mse.spines["right"].set_visible(False)
    axis_mse.set_title("(a) Error change under mechanism interventions",
                       fontsize=PANEL_FONTSIZE, color=TEXT_GRAY, pad=15.0, loc="left")
    axis_mse.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), fontsize=LEGEND_FONTSIZE,
                    frameon=False, ncol=3, handlelength=1.2, handletextpad=0.35,
                    columnspacing=1.0, borderpad=0.05, borderaxespad=0.1)

    axis_align.axvline(0.0, color=TEXT_GRAY, lw=0.55, zorder=4)
    axis_align.set_yticks(variant_positions)
    axis_align.set_yticklabels([VARIANT_LABELS.get(variant, variant) for variant in variants],
                               fontsize=TICK_FONTSIZE)
    axis_align.invert_yaxis()
    axis_align.set_xlabel("$\\Delta$ geodesic alignment vs. full model", fontsize=LABEL_FONTSIZE, labelpad=1.5)
    axis_align.grid(axis="x", color=GRID_GRAY, lw=0.35, ls=(0, (1.4, 2.0)))
    axis_align.set_axisbelow(True)
    _style_axis(axis_align)
    axis_align.spines["right"].set_visible(False)
    axis_align.set_title("(b) Change in Poincaré geodesic alignment",
                         fontsize=PANEL_FONTSIZE, color=TEXT_GRAY, pad=3.0)

    _report_overlaps(figure, "cross-dataset")
    figure.savefig(path, dpi=600, facecolor=SURFACE)
    plt.close(figure)
    print("[figure] {}".format(path))


def main():
    parser = argparse.ArgumentParser(description="Plot the M2Patch hyperbolic / prior-bridge mechanism suite")
    parser.add_argument("--dataset", default="ETTh2")
    parser.add_argument("--pred_len", type=int, default=96)
    parser.add_argument("--variants", nargs="+", default=VARIANTS, choices=VARIANTS)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--sample_batch", type=int, default=0)
    parser.add_argument("--sample_channel", type=int, default=-1)
    parser.add_argument("--train_missing", action="store_true")
    parser.add_argument("--train_epochs", type=int, default=15)
    parser.add_argument("--config_source", default="optuna", choices=("optuna", "profile"))
    parser.add_argument("--k_sweep", default="1,2,4",
                        help="comma-separated diffusion steps evaluated on the full model (empty disables)")
    parser.add_argument("--loss_history", default=None,
                        help="explicit loss_history.json; defaults to output/mechanism then output/explanation")
    parser.add_argument("--figure_dir", default="./output/mechanism/figures")
    parser.add_argument("--figure_name", default=None,
                        help="per-dataset figure name; defaults to m2patch_mechanism_{dataset}.png")
    parser.add_argument("--summary_path", default="./output/mechanism/m2patch_mechanism_summary.tsv")
    parser.add_argument("--mechanism_output_dir", default="./output/mechanism/results")
    parser.add_argument("--main_dataset", default="ETTh2",
                        help="dataset whose 2x2 panel is also written as m2patch_mechanism_analysis.png")
    parser.add_argument("--cross_only", "--main_only", dest="cross_only", action="store_true",
                        help="rebuild only the cross-dataset panel from the summary TSV (no model loading)")
    args = parser.parse_args()

    _apply_style()
    figure_dir = os.path.join(REPO_ROOT, args.figure_dir)
    os.makedirs(figure_dir, exist_ok=True)
    summary_path = os.path.join(REPO_ROOT, args.summary_path)
    main_path = os.path.join(figure_dir, "m2patch_mechanism_analysis.png")
    cross_path = os.path.join(figure_dir, "m2patch_mechanism_cross_dataset.png")

    if args.cross_only:
        _render_cross_dataset_figure(cross_path, _read_summary(summary_path))
        return

    device = torch.device(args.device if torch.cuda.is_available() and args.device.startswith("cuda") else "cpu")
    print("[device] {}".format(device))
    os.makedirs(os.path.join(REPO_ROOT, args.mechanism_output_dir), exist_ok=True)

    results = []
    sample = None
    k_rows = []
    for variant in args.variants:
        result, variant_sample, variant_k = _collect_variant(args, args.dataset, args.pred_len, variant, device)
        results.append(result)
        if variant == "none":
            sample = variant_sample
            k_rows = variant_k
        print(
            "[metric] {:<18} mse={:.5f} mae={:.5f} geo_prior={:.4f} geo_pred={:.4f} align={:.4f}".format(
                variant, result["mse"], result["mae"], result["geo_dist_prior"], result["geo_dist_pred"], result["geo_align"]
            )
        )
        del variant_sample
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    if sample is None:
        raise RuntimeError("Full-model sample was not captured")

    _write_summary(summary_path, results)
    _print_summary(results)

    if args.loss_history:
        candidate = args.loss_history if os.path.isabs(args.loss_history) else os.path.join(REPO_ROOT, args.loss_history)
        loss_history, loss_path = (json.load(open(candidate)), candidate) if os.path.isfile(candidate) else (None, None)
        if loss_path is not None:
            print("[loss-curve] {} <- {}".format(args.dataset, loss_path))
    else:
        loss_history, _ = _load_loss_history(args.dataset, args.pred_len)
    config = get_config(args.dataset, args.pred_len, source=config_source(args.dataset, args.pred_len, args.config_source))

    figure_name = args.figure_name or "m2patch_mechanism_{}.png".format(args.dataset)
    figure_paths = [os.path.join(figure_dir, figure_name)]
    if args.dataset == args.main_dataset:
        figure_paths.append(main_path)
    _render_dataset_figure(
        figure_paths, sample, results, loss_history, k_rows, config,
        args.dataset, int(config.get("diff_steps", 1)),
    )
    _render_cross_dataset_figure(cross_path, _read_summary(summary_path))
    print("[summary] {}".format(summary_path))


if __name__ == "__main__":
    main()
