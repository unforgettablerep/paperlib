import argparse
import os
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from src.configs.m2patch_profiles import (
    CONSTANTS,
    META_ORDER,
    emit_cli_args,
    load_optuna_best_params,
    resolve,
    resolve_meta,
)
from src.ablation.registry import MECHANISM_VARIANTS, resolve_ablation

VARIANTS = MECHANISM_VARIANTS

VARIANT_LABELS = {
    "none": "Full M2Patch",
    "euclid_manifold": "Euclid manifold",
    "zero_prior_bridge": "Zero prior bridge",
    "no_hyp_cond": "No hyp. cond.",
    "no_prior_loss": "No prior loss",
}

# A profile optimum may set lambda_hyp=0 (legacy ETTh2 pl=96), which would disable
# the geometric alignment mechanism under study; lift only that disabled case.
MECHANISM_LAMBDA_HYP_FLOOR = 0.1

# The mechanism suite must share one optimizer protocol with the paper runs:
# Adam + OneCycleLR pct_start=0.2. Legacy ETTh2 sweeps left AdamW/pct_start=0.3
# in the result store, which made the mechanism deltas incomparable.
_ALIGNED_OPTIM_KEYS = ("optim", "lradj", "pct_start")

CONFIG_SOURCES = ("optuna", "profile")

_RUN_DEFAULTS = {
    "features": "M",
    "freq": "h",
    "target": "OT",
    "n_heads": 8,
    "seed": 2023,
}


def optuna_params_path(dataset, pred_len):
    return os.path.join(
        REPO_ROOT,
        "output",
        "optuna",
        "M2Patch_{}_pl{}_best_params.json".format(dataset, int(pred_len)),
    )


def config_source(dataset, pred_len, preferred="optuna"):
    if preferred == "optuna" and os.path.isfile(optuna_params_path(dataset, pred_len)):
        return "optuna"
    return "profile"


def _source_config(dataset, pred_len, source):
    if source not in CONFIG_SOURCES:
        raise ValueError("source must be one of {}, got {!r}".format(CONFIG_SOURCES, source))
    if source == "optuna":
        try:
            return load_optuna_best_params(dataset, pred_len)
        except FileNotFoundError as exc:
            print("[mechanism_config] {} — falling back to the frozen profile".format(exc))
    return resolve(dataset, pred_len)


def get_config(dataset, pred_len, source="optuna"):
    config = dict(_RUN_DEFAULTS)
    config.update(_source_config(dataset, pred_len, source))
    if float(config.get("lambda_hyp", 0.0)) == 0.0:
        config["lambda_hyp"] = MECHANISM_LAMBDA_HYP_FLOOR
    for key in _ALIGNED_OPTIM_KEYS:
        config[key] = CONSTANTS[key]
    config.update(resolve_meta(dataset, pred_len))
    config["pred_len"] = int(pred_len)
    config.setdefault("dec_in", config["enc_in"])
    return config


def variant_des(variant, pred_len):
    return "MECH_{}_pl{}".format(variant, int(pred_len))


def experiment_flags(dataset, pred_len, ablation, des, training=True, train_epochs=None, source="optuna"):
    config = get_config(dataset, pred_len, source=source)
    meta = {
        key: config[key]
        for key in META_ORDER
        if key in config and key != "model_id"
    }
    flags = [
        "--is_training", "1" if training else "2",
        "--model", "M2Patch",
        "--model_id", str(config["model_id"]),
        "--des", des,
    ]
    emit_cfg = dict(config)
    emit_cfg.pop("train_epochs", None)
    flags.extend(emit_cli_args(emit_cfg, meta))
    flags.extend([
        "--dec_in", str(config["dec_in"]),
        "--target", str(config["target"]),
        "--n_heads", str(config["n_heads"]),
        "--seed", str(config["seed"]),
        "--train_epochs", str(train_epochs if train_epochs is not None else config["train_epochs"]),
        "--save_tmp", "0",
        "--keep_checkpoint", "1",
        "--ablation", ablation,
    ])
    return flags


def build_args(dataset, pred_len, ablation, des, device="cuda:0", source="optuna"):
    from src.configs.model_parser_dict import model_parser_dict

    parser = argparse.ArgumentParser(conflict_handler="resolve")
    for common_parser in model_parser_dict["__all__"]:
        common_parser(parser=parser)
    for model_parser in model_parser_dict["M2Patch"]:
        model_parser(parser=parser)
    args = parser.parse_args(
        experiment_flags(dataset, pred_len, ablation, des, training=False, source=source)
    )
    args.device = device
    args.use_gpu = device.startswith("cuda")
    resolve_ablation(args)
    return args


def main():
    parser = argparse.ArgumentParser(description="Emit M2Patch mechanism-suite run flags")
    parser.add_argument("--dataset", default="ETTh2")
    parser.add_argument("--pred_len", type=int, default=96)
    parser.add_argument("--ablation", default="none", choices=VARIANTS)
    parser.add_argument("--des", default=None)
    parser.add_argument("--train_epochs", type=int, default=None)
    parser.add_argument("--source", default="optuna", choices=CONFIG_SOURCES)
    parser.add_argument("--emit-flags", action="store_true")
    parser.add_argument("--list-variants", action="store_true")
    args = parser.parse_args()

    if args.list_variants:
        for variant in VARIANTS:
            print("{}\t{}".format(variant, VARIANT_LABELS.get(variant, variant)))
        return

    des = args.des or variant_des(args.ablation, args.pred_len)
    flags = experiment_flags(
        args.dataset, args.pred_len, args.ablation, des,
        training=True, train_epochs=args.train_epochs, source=args.source,
    )
    print(" ".join(flags))


if __name__ == "__main__":
    main()
