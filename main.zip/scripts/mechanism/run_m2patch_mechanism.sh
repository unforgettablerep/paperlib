#!/bin/bash
# Train the five hyperbolic / prior-bridge intervention variants and dispatch them across GPUs.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$REPO_ROOT" || exit 1

PYTHON_BIN="${PYTHON_BIN:-python}"
PARA=1
GPU_IDS=()
GPU_POS=()
DATASETS=("ETTh2")
PRED_LENS=("96")
VARIANTS=()
EPOCHS="${MECH_EPOCHS:-15}"
PLOT="${MECH_PLOT:-1}"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --para) PARA="$2"; shift 2 ;;
        --gpu) IFS=',' read -ra GPU_IDS <<< "$2"; shift 2 ;;
        --datasets) read -ra DATASETS <<< "$2"; shift 2 ;;
        --pred-lens) read -ra PRED_LENS <<< "$2"; shift 2 ;;
        --variants) read -ra VARIANTS <<< "$2"; shift 2 ;;
        --epochs) EPOCHS="$2"; shift 2 ;;
        --plot) PLOT="$2"; shift 2 ;;
        *) GPU_POS+=("$1"); shift ;;
    esac
done
if [[ ${#GPU_POS[@]} -gt 0 ]]; then
    GPU_IDS=()
    for tok in "${GPU_POS[@]}"; do
        IFS=',' read -ra parts <<< "$tok"
        GPU_IDS+=("${parts[@]}")
    done
fi
if [[ ${#GPU_IDS[@]} -eq 0 ]]; then
    GPU_IDS=("0")
fi
if [[ ${#VARIANTS[@]} -eq 0 ]]; then
    mapfile -t VARIANTS < <("$PYTHON_BIN" scripts/mechanism/mechanism_config.py --list-variants | cut -f1)
fi
if [[ ${#VARIANTS[@]} -eq 0 ]]; then
    echo "ERROR: no mechanism variants resolved from src.ablation.registry" >&2
    exit 1
fi

export GPU_LIST="${GPU_IDS[*]}"
export PARA_PER_GPU="$PARA"
export MECHANISM_ROOT="${MECHANISM_ROOT:-./output/mechanism}"
export MECHANISM_OUTPUT_DIR="${MECHANISM_OUTPUT_DIR:-${MECHANISM_ROOT}/results}"
export PYTHONUNBUFFERED=1
export MECHANISM_SESSION="$(mktemp -d /tmp/_m2patch_mechanism_XXXXXX)"
trap 'rm -rf "${MECHANISM_SESSION:-}"' EXIT

source "$SCRIPT_DIR/mechanism_common.sh"
mkdir -p log/mechanism "$MECHANISM_OUTPUT_DIR" "${MECHANISM_ROOT}/figures"
echo "[mechanism] GPUs=${GPU_LIST} slots=${_SLOTS} para=${PARA_PER_GPU} datasets=${DATASETS[*]} pred_lens=${PRED_LENS[*]}"

_run_cell() {
    local dataset=$1 pred_len=$2 variant=$3
    local des="MECH_${variant}_pl${pred_len}"
    local out_tsv="${MECHANISM_OUTPUT_DIR}/${dataset}.tsv"
    if mechanism_done "$out_tsv" "$dataset" "$pred_len" "$des"; then
        echo "[skip] ${dataset} pl${pred_len} ${variant}"
        return
    fi
    local flags
    flags=$("$PYTHON_BIN" scripts/mechanism/mechanism_config.py \
        --dataset "$dataset" --pred_len "$pred_len" --ablation "$variant" \
        --des "$des" --train_epochs "$EPOCHS" --emit-flags)
    local flag_arr
    read -ra flag_arr <<< "$flags"
    local args=("$PYTHON_BIN" -u scripts/run.py "${flag_arr[@]}")
    _rotate_gpu
    _DISPATCH_LOG="log/mechanism/${dataset}_pl${pred_len}_${variant}.log"
    echo "[run ] ${dataset} pl${pred_len} ${variant} -> ${_DISPATCH_LOG}"
    _dispatch "${args[@]}"
}

for dataset in "${DATASETS[@]}"; do
    for pred_len in "${PRED_LENS[@]}"; do
        for variant in "${VARIANTS[@]}"; do
            _run_cell "$dataset" "$pred_len" "$variant"
        done
        _wait_all
    done
done

echo "[mechanism] training cells finished"
if [[ "$PLOT" == "1" ]]; then
    for dataset in "${DATASETS[@]}"; do
        for pred_len in "${PRED_LENS[@]}"; do
            echo "[plot ] ${dataset} pl${pred_len}"
            CUDA_VISIBLE_DEVICES="${_GPU_ARR[0]:-0}" "$PYTHON_BIN" scripts/mechanism/plot_m2patch_mechanism.py \
                --dataset "$dataset" --pred_len "$pred_len" --device cuda:0
        done
    done
fi
