#!/bin/bash
# Shared GPU-wave scheduler and TSV resume helpers for the M2Patch mechanism suite.

_UTILS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../utils" && pwd)"
source "${_UTILS_DIR}/result_common.sh"
source "${_UTILS_DIR}/gpu_queue.sh"

GPU_QUEUE_SESSION="${MECHANISM_SESSION:-/tmp}"
gpu_queue_init
_SLOTS=$_GPU_SLOTS

_rotate_gpu() {
    gpu_queue_next
}

_dispatch() {
    gpu_queue_dispatch "${_DISPATCH_LOG:-}" "$@"
}

_wait_all() {
    gpu_queue_wait
}

mechanism_done() {
    local out_tsv=$1 dataset=$2 pred_len=$3 des=$4
    result_done "$out_tsv" "dataset=${dataset}" "pred_len=${pred_len}" "des=${des}"
}
