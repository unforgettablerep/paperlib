#!/bin/bash
# M2Patch ablation suite: sequential variants, one merged TSV per variant, FIFO GPU dispatch.
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
cd "$REPO_ROOT" || exit 1

SELECTED_DATASETS=(
    ETTh2
    ETTm1
    Exchange
    Weather
    ECL
    Illness
)

PYTHON_BIN=${PYTHON_BIN:-python}

mapfile -t VARIANTS < <(
    "${PYTHON_BIN}" -c 'from src.ablation.registry import DEFAULT_ABLATION_VARIANTS; print("\n".join(DEFAULT_ABLATION_VARIANTS))'
)
if [[ ${#VARIANTS[@]} -eq 0 ]]; then
    echo "ERROR: no ablation variants resolved from src.ablation.registry" >&2
    exit 1
fi

if [[ -n "${ABLATION_DATASETS:-}" ]]; then
    read -ra SELECTED_DATASETS <<< "${ABLATION_DATASETS}"
fi
if [[ -n "${ABLATION_VARIANTS:-}" ]]; then
    read -ra VARIANTS <<< "${ABLATION_VARIANTS}"
fi

if [[ " ${VARIANTS[*]} " != *" none "* ]]; then
    VARIANTS=(none "${VARIANTS[@]}")
fi

PARA=1
GPUS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --para) PARA="$2"; shift 2 ;;
        *)      GPUS+=("$1"); shift ;;
    esac
done

if [[ ${#GPUS[@]} -eq 0 ]]; then
    GPUS=(0)
fi

export ABLATION_DATASETS="${SELECTED_DATASETS[*]}"
export ABLATION_VARIANTS="${VARIANTS[*]}"
export EPOCHS="${EPOCHS:-15}"

mkdir -p log/ablation output/ablation

LOG_FILE="log/ablation/all.log"

nohup bash -c '
set -u
SCRIPT_DIR="'"${SCRIPT_DIR}"'"

exec 200>/tmp/_m2patch_ablation.lock
if ! flock -n 200; then
    echo "[$(date "+%H:%M:%S")] ERROR: Another ablation run is in progress" >&2
    exit 1
fi

export _ABLATION_SESSION="/tmp/_m2patch_ablation_$$"
mkdir -p "$_ABLATION_SESSION"
trap '"'"'rm -rf "${_ABLATION_SESSION:-}"'"'"' EXIT

export GPU_LIST="'"${GPUS[*]}"'"
export PARA_PER_GPU="'"${PARA}"'"
export PYTHON_BIN="'"${PYTHON_BIN}"'"
export _GPU_COUNTER_FILE="${_ABLATION_SESSION}/counter"
echo 0 > "$_GPU_COUNTER_FILE"

source "${SCRIPT_DIR}/ablation_common.sh"

run_variant() {
    local variant="$1"
    export ABLATION_OUTPUT_DIR="./output/ablation/${variant}"
    export ABLATION_LOG_DIR="./log/ablation/${variant}"
    mkdir -p "$ABLATION_LOG_DIR"
    echo "[$(date "+%H:%M:%S")] START ${variant} (GPUs: ${GPU_LIST})"
    run_all_datasets "$variant" --des "ablation_${variant}"
    local ec=$?
    _compact_variant_tsv "$variant" >> "${ABLATION_LOG_DIR}/compact.log" 2>&1 || true
    if [[ $ec -eq 0 ]]; then
        echo "[$(date "+%H:%M:%S")] DONE  ${variant}"
    else
        echo "[$(date "+%H:%M:%S")] FAIL  ${variant} (exit $ec)"
    fi
}

read -ra VARIANTS <<< "${ABLATION_VARIANTS:-}"
for _v in "${VARIANTS[@]}"; do
    run_variant "$_v"
done

wait
echo "[$(date "+%H:%M:%S")] All variants finished"
rm -rf "${_ABLATION_SESSION:-}"
if [[ -f output/ablation/update_ablation.py ]]; then
    ${PYTHON_BIN:-python} output/ablation/update_ablation.py || true
fi
' >> "$LOG_FILE" 2>&1 &

DISOWN_PID=$!
disown $DISOWN_PID 2>/dev/null || true
echo "[$(date '+%H:%M:%S')] Launched ablation runner as PID $DISOWN_PID"
echo "  GPUs: ${GPUS[*]}  slots/GPU: ${PARA}  datasets: ${SELECTED_DATASETS[*]}"
echo "  Variants (sequential): ${VARIANTS[*]}"
echo "  Results: output/ablation/{variant}.tsv  Logs: log/ablation/{variant}/{dataset}.log"
echo "  Progress: tail -f ${LOG_FILE}"
