#!/bin/bash
# Full M2Patch reference group for the OFAT suite: one Optuna-config baseline per
# (dataset, pred_len), merged into output/ablation/none.tsv with des=ablation_none.
set -e
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/ablation_common.sh"

DEFAULT_VARIANTS=(none)
VARIANTS=("${@:-${DEFAULT_VARIANTS[@]}}")

for VARIANT in "${VARIANTS[@]}"; do
    case $VARIANT in
        none|baseline)
            export ABLATION_OUTPUT_DIR="./output/ablation/none"
            run_all_datasets none --des "ablation_none"
            ;;
        *)
            export ABLATION_OUTPUT_DIR="./output/ablation/${VARIANT}"
            run_all_datasets "${VARIANT}" --des "ablation_${VARIANT}"
            ;;
    esac
done
