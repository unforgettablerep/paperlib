#!/bin/bash
# Shared ablation plumbing: GPU queue, merged variant TSVs, result_done breakpoints.
PYTHON_BIN=${PYTHON_BIN:-python}
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/utils/result_common.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/utils/gpu_queue.sh"

EPOCHS=${EPOCHS:-15}
PARALLEL=${PARALLEL:-2}
GPU_QUEUE_SESSION="${_ABLATION_SESSION:-/tmp}"
gpu_queue_init

_rotate_gpu() {
    gpu_queue_next
}

_dispatch() {
    gpu_queue_dispatch "${ABLATION_CELL_LOG:-}" "$@"
}

_wait_all() {
    gpu_queue_wait
}

_ablation_result_file() {
    local dir="${ABLATION_OUTPUT_DIR:-./output/ablation/${1:-full}}"
    printf '%s/%s.tsv' "$(dirname "$dir")" "$(basename "${dir%/}")"
}

_compact_variant_tsv() {
    ${PYTHON_BIN} -m src.utils.result_io sort "$(_ablation_result_file "$1")"
}

_result_done() {
    local ds=$1 pl=$2
    result_done "$(_ablation_result_file)" "dataset=${ds}" "pred_len=${pl}"
}

_run() {
    _dispatch "$@"
}

DATASETS=(ETTh2 ETTm1 Exchange Weather ECL Illness)

if [[ -n "${ABLATION_DATASETS:-}" ]]; then
    DATASETS=(${ABLATION_DATASETS})
fi

_is_noop_cell() {
    local ds=$1 pl=$2 variant=$3
    [[ -z "$variant" || "$variant" == "none" ]] && return 1
    ${PYTHON_BIN} -c '
import sys
from src.ablation.registry import is_noop_ablation
sys.exit(0 if is_noop_ablation(sys.argv[1], int(sys.argv[2]), sys.argv[3], baseline="optuna") else 1)
' "$ds" "$pl" "$variant"
}

_run_config() {
    local ds=$1 pl=$2; shift 2
    local flags
    flags=$(${PYTHON_BIN} -m src.configs.m2patch_cli "$ds" "$pl" --from-optuna --with-meta)

    _run ${PYTHON_BIN} -u scripts/run.py \
        $flags \
        --is_training 1 \
        --model M2Patch \
        --save_tmp 0 \
        --cleanup_checkpoint 1 \
        --train_epochs ${EPOCHS} \
        "$@"
}

run_all_datasets() {
    local name=$1; shift
    local ds pl
    local -a abl=()

    if [[ -n "$name" && "$name" != "none" ]]; then
        abl=(--ablation "$name")
    fi

    for ds in "${DATASETS[@]}"; do
        for pl in $(${PYTHON_BIN} -m src.configs.m2patch_cli "$ds" --pred-lens); do
            if _result_done "$ds" "$pl"; then
                echo "[skip] ${ds} pl=${pl} already has result in ${ABLATION_OUTPUT_DIR:-./output/ablation}"
                continue
            fi
            if _is_noop_cell "$ds" "$pl" "$name"; then
                echo "[skip] ${ds} pl=${pl} variant=${name} is a config no-op against the Optuna baseline"
                continue
            fi
            _rotate_gpu
            if [[ -n "${ABLATION_LOG_DIR:-}" ]]; then
                ABLATION_CELL_LOG="${ABLATION_LOG_DIR}/${ds}.log"
                echo "=== $(date '+%F %T') ${ds} pl=${pl} variant=${name} ===" >> "${ABLATION_CELL_LOG}"
            else
                ABLATION_CELL_LOG=""
            fi
            _run_config "$ds" "$pl" "${abl[@]}" "$@"
        done
    done
    _wait_all
}
