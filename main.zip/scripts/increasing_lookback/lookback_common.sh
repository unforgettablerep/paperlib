#!/bin/bash
# Shared lookback configuration and dispatcher.

ETTM1_SEQ_LENS=(48 96 192 336 720)
WEATHER_SEQ_LENS=(48 96 192 336 720)
PEMS08_SEQ_LENS=(48 96 144 192)
ECL_SEQ_LENS=(48 96 192 336 720)

# Mapping from dataset name (as in DATASETS array) to seq_len array variable
get_seq_lens() {
    local dataset=$1
    case "$dataset" in
        ETTm1)   echo "${ETTM1_SEQ_LENS[*]}" ;;
        Weather) echo "${WEATHER_SEQ_LENS[*]}" ;;
        PEMS08)  echo "${PEMS08_SEQ_LENS[*]}" ;;
        ECL)     echo "${ECL_SEQ_LENS[*]}" ;;
    esac
}

# ============================================================
# Unified per-experiment dispatcher.
# Delegates to scripts/increasing_lookback/${dataset}/${model}.sh, which each
# support single-seq_len dispatch via the LOOKBACK_SEQ_LEN env var. Model
# hyperparameters come from src.configs.m2patch_profiles; these scripts only choose
# the horizon, sequence length, batch size, and model-specific runtime flags.
# ============================================================

# Lookback script root, relative to repo root (cwd is repo root when invoked
# from run-lookback.sh; allow override for sourced use).
LOOKBACK_SCRIPT_DIR="${LOOKBACK_SCRIPT_DIR:-scripts/increasing_lookback}"

run_dataset_lookback() {
    local model=$1 dataset=$2 seq_len=$3
    local script="${LOOKBACK_SCRIPT_DIR}/${dataset}/${model}.sh"
    if [[ -f "$script" ]]; then
        LOOKBACK_SEQ_LEN=$seq_len bash "$script"
    else
        echo "Lookback script not found: $script" >&2
        echo "  Create it to add ${model} support for ${dataset}." >&2
        return 1
    fi
}

# ============================================================
# Part B: GPU queue
# Activates only when GPU_LIST is set (by run-lookback.sh).
# ============================================================

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/utils/gpu_queue.sh"
GPU_QUEUE_SESSION="${LOOKBACK_SESSION:-/tmp}"
gpu_queue_init

_rotate_gpu() {
    gpu_queue_next
}
