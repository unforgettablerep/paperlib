#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
export LOOKBACK_OUTPUT_DIR=${LOOKBACK_OUTPUT_DIR:-./output/lookback}
model_name=${model_name:-M2Patch}
dataset=ETTm1
pred_len=96
des_tag="LOOKBACK_M2PATCH"

# One fixed configuration at every lookback window; only seq_len varies, so the
# MSE trend is attributable to the history length alone. The frozen profile is
# used instead of an Optuna pl96 checkpoint because the Optuna objective is the
# test MSE, which would make the sl=96 point a test-tuned rather than held-out
# comparison.
# Base = frozen profile at pred_len 96 (src/configs/m2patch_profiles.py), fetched
# via m2patch_cli --with-meta:
#   d_model 128, d_ff 256, d_hyp 64, patch_len 16, stride 8,
#   lr 4.5240e-4, lambda_hyp 0.2, lambda_prior 0.05, batch_size 32, 15 epochs.
seq_lens=(48 96 192 336 720)

_run_for_index() {
    local seq_len=$1
    local base_flags
    base_flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" "$pred_len" --with-meta)

    "$PYTHON_BIN" -u scripts/run.py $base_flags \
        --is_training 1 \
        --model "$model_name" \
        --des "$des_tag" \
        --model_id "${dataset}_${seq_len}_${pred_len}" \
        --seq_len "$seq_len" \
        --save_tmp 0 \
        --cleanup_checkpoint 1
}

if [[ -n "${LOOKBACK_SEQ_LEN:-}" ]]; then
    for seq_len in "${seq_lens[@]}"; do
        if [[ ${seq_len} -eq ${LOOKBACK_SEQ_LEN} ]]; then
            _run_for_index "$seq_len"
            exit $?
        fi
    done
    echo "Unknown LOOKBACK_SEQ_LEN for ${dataset}: ${LOOKBACK_SEQ_LEN}" >&2
    exit 1
else
    for seq_len in "${seq_lens[@]}"; do
        _run_for_index "$seq_len"
    done
fi
