#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-TimeMixer}

seq_lens=(48 96 192 336 720)
batch_sizes=(128 128 128 32 32)
learning_rate=(0.01 0.01 0.01 0.005 0.005)
pred_len=96

e_layers=3
d_model=16
d_ff=32
down_sampling_layers=3
down_sampling_window=2
down_sampling_method=avg
channel_independence=1
use_norm=1
decomp_method=moving_avg
moving_avg=25
use_future_temporal_feature=0
dropout=0.1
weight_decay=0
train_epochs=15
patience=5

_run_for_index() {
    local i=$1
    seq_len=${seq_lens[$i]}
    bs=${batch_sizes[$i]}

    python -u scripts/run.py \
        --is_training 1 \
        --model $model_name \
        --root_path ./data/weather/ \
        --data_path weather.csv \
        --model_id Weather_${seq_len}_${pred_len} \
        --data custom \
        --features M \
        --seq_len $seq_len \
        --pred_len $pred_len \
        --e_layers $e_layers \
        --enc_in 21 \
        --c_out 21 \
        --des 'LOOKBACK_TIMEMIXER' \
        --d_model $d_model \
        --d_ff $d_ff \
        --channel_independence $channel_independence \
        --down_sampling_layers $down_sampling_layers \
        --down_sampling_window $down_sampling_window \
        --down_sampling_method $down_sampling_method \
        --decomp_method $decomp_method \
        --moving_avg $moving_avg \
        --use_norm $use_norm \
        --use_future_temporal_feature $use_future_temporal_feature \
        --dropout $dropout \
        --optim Adam \
        --lradj type1 \
        --learning_rate ${learning_rate[$i]} \
        --weight_decay $weight_decay \
        --train_epochs $train_epochs \
        --patience $patience \
        --freq t \
        --batch_size $bs
}

if [[ -n "${LOOKBACK_SEQ_LEN:-}" ]]; then
    for i in "${!seq_lens[@]}"; do
        if [[ ${seq_lens[$i]} -eq $LOOKBACK_SEQ_LEN ]]; then
            _run_for_index $i
            exit $?
        fi
    done
    echo "Unknown LOOKBACK_SEQ_LEN for Weather: $LOOKBACK_SEQ_LEN" >&2
    exit 1
else
    for i in "${!seq_lens[@]}"; do
        _run_for_index $i
    done
fi
