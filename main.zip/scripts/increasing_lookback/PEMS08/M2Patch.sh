#!/bin/bash
PYTHON_BIN=${PYTHON_BIN:-python}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-M2Patch}
dataset=PEMS08
pred_len=96
seq_lens=(48 96 144 192)
batch_sizes=(32 32 16 16)

_run_for_index() {
    local i=$1
    local seq_len=${seq_lens[$i]}
    local bs=${batch_sizes[$i]}
    local flags
    flags=$("$PYTHON_BIN" -m src.configs.m2patch_cli "$dataset" "$pred_len" --with-meta)

    "$PYTHON_BIN" -u scripts/run.py $flags \
        --is_training 1 \
        --model "$model_name" \
        --model_id "${dataset}_${seq_len}_${pred_len}" \
        --seq_len "$seq_len" \
        --des "LOOKBACK_M2PATCH" \
        --batch_size "$bs"
}

if [[ -n "${LOOKBACK_SEQ_LEN:-}" ]]; then
    for i in "${!seq_lens[@]}"; do
        if [[ ${seq_lens[$i]} -eq ${LOOKBACK_SEQ_LEN} ]]; then
            _run_for_index "$i"
            exit $?
        fi
    done
    echo "Unknown LOOKBACK_SEQ_LEN for ${dataset}: ${LOOKBACK_SEQ_LEN}" >&2
    exit 1
else
    for i in "${!seq_lens[@]}"; do
        _run_for_index "$i"
    done
fi
