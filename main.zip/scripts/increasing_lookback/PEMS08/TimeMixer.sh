#!/bin/bash
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
model_name=${model_name:-TimeMixer}

seq_lens=(48 96 144 192)
batch_sizes=(32 32 16 16)
pred_len=12

e_layers=3
d_model=128
d_ff=256
down_sampling_layers=1
down_sampling_window=2
down_sampling_method=avg
channel_independence=0
use_norm=0
decomp_method=moving_avg
moving_avg=25
use_future_temporal_feature=0
dropout=0.1
learning_rate=0.003
weight_decay=0
train_epochs=15
patience=5

_run_for_index() {
    local i=$1
    seq_len=${seq_lens[$i]}
    bs=${batch_sizes[$i]}

    python -u scripts/run.py \
        --is_training 1 \
        --model $model_name \
        --root_path ./data/PEMS/ \
        --data_path PEMS08.npz \
        --model_id PEMS08_${seq_len}_${pred_len} \
        --data PEMS \
        --features M \
        --seq_len $seq_len \
        --pred_len $pred_len \
        --e_layers $e_layers \
        --enc_in 170 \
        --c_out 170 \
        --des 'LOOKBACK_TIMEMIXER' \
        --d_model $d_model \
        --d_ff $d_ff \
        --channel_independence $channel_independence \
        --down_sampling_layers $down_sampling_layers \
        --down_sampling_window $down_sampling_window \
        --down_sampling_method $down_sampling_method \
        --decomp_method $decomp_method \
        --moving_avg $moving_avg \
        --use_norm $use_norm \
        --use_future_temporal_feature $use_future_temporal_feature \
        --dropout $dropout \
        --optim Adam \
        --lradj type1 \
        --learning_rate $learning_rate \
        --weight_decay $weight_decay \
        --train_epochs $train_epochs \
        --patience $patience \
        --batch_size $bs
}

if [[ -n "${LOOKBACK_SEQ_LEN:-}" ]]; then
    for i in "${!seq_lens[@]}"; do
        if [[ ${seq_lens[$i]} -eq $LOOKBACK_SEQ_LEN ]]; then
            _run_for_index $i
            exit $?
        fi
    done
    echo "Unknown LOOKBACK_SEQ_LEN for PEMS08: $LOOKBACK_SEQ_LEN" >&2
    exit 1
else
    for i in "${!seq_lens[@]}"; do
        _run_for_index $i
    done
fi
