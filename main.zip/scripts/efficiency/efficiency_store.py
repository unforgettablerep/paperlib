#!/usr/bin/env python3
"""JSONL store for baseline efficiency experiment results."""

import hashlib
import json
import os
import sys

try:
    import pandas as _pd
except Exception:
    _pd = None

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(os.path.dirname(SCRIPT_DIR))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.utils.result_io import canonical_dataset

EFFICIENCY_DIR = os.path.join(PROJECT_ROOT, "output", "efficiency")
SHARD_DIR = os.path.join(EFFICIENCY_DIR, "results_by_dataset")

FIELD_ORDER = [
    "timestamp",
    "model",
    "dataset",
    "model_id",
    "seq_len",
    "pred_len",
    "enc_in",
    "e_layers",
    "d_model",
    "d_ff",
    "batch_size",
    "learning_rate",
    "weight_decay",
    "dropout",
    "train_epochs",
    "patience",
    "use_amp",
    "gpu",
    "optim",
    "lradj",
    "low_rank",
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "revin",
    "extra",
    "metrics",
]

METRIC_KEYS = [
    "mse",
    "mae",
    "params",
    "inference_time_ms_per_iter",
    "train_time_ms_per_iter",
    "avg_gpu_mem_allocated_mb",
]

M2PATCH_ONLY_KEYS = {
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "revin",
}

CONFIG_HASH_KEYS = [
    "model",
    "dataset",
    "seq_len",
    "pred_len",
    "enc_in",
    "e_layers",
    "d_model",
    "d_ff",
    "batch_size",
    "learning_rate",
    "weight_decay",
    "low_rank",
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "extra",
]


def shard_name(dataset):
    """Resolve a raw dataset label to its canonical shard name."""
    return canonical_dataset(dataset)


def shard_path(dataset):
    """Return the absolute path of the JSONL shard for ``dataset``."""
    return os.path.join(SHARD_DIR, shard_name(dataset) + ".jsonl")


def _ordered(record):
    """Re-order a record dict to follow FIELD_ORDER (extra keys appended)."""
    out = {}
    for key in FIELD_ORDER:
        if key in record:
            out[key] = record[key]
    for key in record:
        if key not in out:
            out[key] = record[key]
    return out


def _strip_nulls(obj):
    """Recursively drop keys/elements whose value is ``None``."""
    if isinstance(obj, dict):
        return {k: _strip_nulls(v) for k, v in obj.items() if v is not None}
    if isinstance(obj, list):
        return [_strip_nulls(v) for v in obj if v is not None]
    return obj


def _normalize(record):
    """Order fields, drop empty ``extra``, and strip null-valued properties."""
    rec = _ordered(record)
    extra = rec.get("extra")
    if isinstance(extra, dict) and not extra:
        rec.pop("extra", None)
    return _strip_nulls(rec)


def build_record(
    model,
    dataset,
    model_id,
    config,
    metrics,
    timestamp,
    extra=None,
):
    """Assemble a canonical efficiency record dict.

    ``config`` may contain both common keys and model-specific keys; the
    M2Patch-only keys (patch_len, d_hyp, ...) are hoisted to top level and any
    unknown keys are funneled into ``extra``.  ``metrics`` must contain the four
    metric keys (missing values become ``None``).
    """
    cfg = dict(config or {})
    rec = {
        "timestamp": timestamp,
        "model": model,
        "dataset": cfg.get("dataset", dataset),
        "model_id": model_id,
    }
    common_keys = [
        "seq_len", "pred_len", "enc_in", "e_layers", "d_model", "d_ff",
        "batch_size", "learning_rate", "weight_decay", "dropout",
        "train_epochs", "patience", "use_amp", "gpu", "optim", "lradj",
        "low_rank",
    ]
    for key in common_keys:
        rec[key] = cfg.get(key)

    for key in M2PATCH_ONLY_KEYS:
        rec[key] = cfg.get(key)

    extra_out = dict(extra) if extra else {}
    known = set(common_keys) | M2PATCH_ONLY_KEYS | {"dataset", "model", "model_id"}
    for key, val in cfg.items():
        if key not in known and not key.startswith("_") and key not in extra_out:
            extra_out[key] = val
    rec["extra"] = extra_out

    metrics_out = {}
    src_metrics = metrics or {}
    for key in METRIC_KEYS:
        metrics_out[key] = src_metrics.get(key)
    rec["metrics"] = metrics_out

    return _ordered(rec)


def _sort_key(record):
    """Sort by model name (case-insensitive) then timestamp."""
    return (str(record.get("model", "")).lower(), str(record.get("timestamp", "")))


def _read_shard(path):
    """Read all records from a JSONL shard (missing file -> empty list)."""
    records = []
    if not os.path.isfile(path):
        return records
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("//") or line.startswith("#"):
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                print("WARN: skipping malformed line {} in {}".format(lineno, path))
    return records


def _write_shard(path, records):
    """Atomically write records (sorted + null-stripped) to ``path``."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    normalized = sorted((_normalize(r) for r in records), key=_sort_key)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        for rec in normalized:
            f.write(json.dumps(rec, ensure_ascii=False))
            f.write("\n")
    os.replace(tmp, path)
    return len(normalized)


def append(dataset, record):
    """Append ``record`` to the dataset's shard and re-sort the file.

    Returns the path written.
    """
    path = shard_path(dataset)
    records = _read_shard(path)
    records.append(_ordered(record))
    _write_shard(path, records)
    return path


def append_many(dataset, new_records):
    """Append multiple records at once and re-sort."""
    path = shard_path(dataset)
    records = _read_shard(path)
    records.extend(_ordered(r) for r in new_records)
    _write_shard(path, records)
    return path


def write_shard(dataset, records):
    """Overwrite the shard with ``records`` (sorted).  Used by migration."""
    return _write_shard(shard_path(dataset), list(records))


def resort_file(dataset):
    """Re-format an existing shard in place: sort + strip nulls (no-op if absent)."""
    path = shard_path(dataset)
    if not os.path.isfile(path):
        return path
    records = _read_shard(path)
    _write_shard(path, records)
    return path


def format_all_shards():
    """Re-format every ``*.jsonl`` shard in SHARD_DIR (sort + strip nulls).

    Returns a list of ``(path, record_count)`` tuples.
    """
    results = []
    if not os.path.isdir(SHARD_DIR):
        return results
    for name in sorted(os.listdir(SHARD_DIR)):
        if not name.endswith(".jsonl"):
            continue
        path = os.path.join(SHARD_DIR, name)
        records = _read_shard(path)
        count = _write_shard(path, records)
        results.append((path, count))
    return results


def config_hash(record):
    """Stable hash of the config-defining fields (ignores timestamp/metrics)."""
    payload = {}
    for key in CONFIG_HASH_KEYS:
        if key in record:
            val = record[key]
            payload[key] = val
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.md5(blob.encode("utf-8")).hexdigest()


def load(
    dataset=None,
    model=None,
    pred_len=None,
    best_only=False,
    as_dataframe=True,
    dedupe_key="latest",
):
    """Load records from one or all shards with optional filtering.

    Parameters
    ----------
    dataset : str | None
        Dataset label.  ``None`` (or ``"all"``) merges every shard.
    model : str | None
        Keep only records whose ``model`` matches.
    pred_len : int | None
        Keep only records with this ``pred_len``.
    best_only : bool
        If True, collapse duplicate ``(model, pred_len)`` groups to one record.
    as_dataframe : bool
        Return a ``pandas.DataFrame`` when True (and pandas is available),
        else a list of dicts.  Metrics are flattened to ``mse``/``mae``/...
    dedupe_key : str
        ``"latest"`` (default) keeps the newest timestamp per group;
        ``"best_mse"`` keeps the lowest MSE per group.
    """
    if dataset in (None, "all", "ALL"):
        paths = []
        if os.path.isdir(SHARD_DIR):
            for name in sorted(os.listdir(SHARD_DIR)):
                if name.endswith(".jsonl"):
                    paths.append(os.path.join(SHARD_DIR, name))
    else:
        paths = [shard_path(dataset)]

    records = []
    for path in paths:
        records.extend(_read_shard(path))

    if model is not None:
        records = [r for r in records if r.get("model") == model]
    if pred_len is not None:
        records = [r for r in records if r.get("pred_len") == pred_len]

    records = sorted(records, key=_sort_key)

    if best_only:
        records = _dedupe(records, dedupe_key)

    flat = [_flatten(r) for r in records]
    if as_dataframe and _pd is not None and flat:
        return _pd.DataFrame(flat)
    if as_dataframe and _pd is not None and not flat:
        return _pd.DataFrame(columns=_flat_columns())
    return flat


def _dedupe(records, dedupe_key):
    """Keep one record per ``(model, pred_len)`` group."""
    chosen = {}
    for rec in records:
        gkey = (rec.get("model"), rec.get("pred_len"))
        cur = chosen.get(gkey)
        if cur is None:
            chosen[gkey] = rec
            continue
        if dedupe_key == "best_mse":
            cur_mse = _safe_mse(cur)
            new_mse = _safe_mse(rec)
            if new_mse < cur_mse:
                chosen[gkey] = rec
        else:
            if str(rec.get("timestamp", "")) > str(cur.get("timestamp", "")):
                chosen[gkey] = rec
    return sorted(chosen.values(), key=_sort_key)


def _safe_mse(rec):
    try:
        return float(rec.get("metrics", {}).get("mse", float("inf")))
    except (TypeError, ValueError):
        return float("inf")


def _flat_columns():
    cols = [k for k in FIELD_ORDER if k not in ("metrics", "extra")]
    cols.extend(METRIC_KEYS)
    return cols


def _flatten(record):
    """Flatten metrics to top level for tabular consumption."""
    out = {}
    for key in FIELD_ORDER:
        if key in ("metrics", "extra"):
            continue
        out[key] = record.get(key)
    metrics = record.get("metrics", {}) or {}
    for key in METRIC_KEYS:
        out[key] = metrics.get(key)
    return out


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Efficiency JSONL store utility")
    parser.add_argument("--dataset", default=None, help="dataset label (default: all)")
    parser.add_argument(
        "--format",
        action="store_true",
        help="re-format shard(s) in place: sort + strip null properties",
    )
    parser.add_argument(
        "--resort",
        action="store_true",
        help="alias of --format (kept for backward compatibility)",
    )
    parser.add_argument("--count", action="store_true", help="print record count")
    args = parser.parse_args()

    do_format = args.format or args.resort
    if do_format:
        if args.dataset:
            path = resort_file(args.dataset)
            print("Formatted: {}".format(path))
        else:
            for path, count in format_all_shards():
                print("Formatted {} ({} records)".format(path, count))
    if args.count or not do_format:
        df = load(args.dataset, as_dataframe=True)
        if _pd is not None and isinstance(df, _pd.DataFrame):
            print("Records: {}".format(len(df)))
            if args.dataset and not df.empty:
                print(df[["timestamp", "model", "dataset", "pred_len", "mse"]].to_string(index=False))
