#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/../.."

python scripts/efficiency/run_efficiency.py \
    --dataset Weather \
    --pred_len 96 \
    --train_epochs 10 \
    --gpu 0 \
    --d_model 256 \
    --d_hyp 128 \
    --e_layers 3 \
    --d_layers_diff 2 \
    --learning_rate 4.5e-4 \
    --lambda_hyp 0.2 \
    --batch_size 16
