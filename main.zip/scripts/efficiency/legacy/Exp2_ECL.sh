#!/bin/bash
# Unified efficiency protocol: 10 epochs, batch_size=16, FP32, seed=2023 (RTX 4090 D).
set -euo pipefail

cd "$(dirname "$0")/../../.."

PYTHON_BIN=${PYTHON_BIN:-python}
COMMON="--dataset ECL --train_epochs 10 --batch_size 16 --patience 10"

# TimeMixer (lr 0.005 = official 0.01 scaled from batch 32 to batch 16)
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model TimeMixer $COMMON \
    --e_layers 3 --d_model 16 --d_ff 32 --learning_rate 0.005 \
    --channel_independence 1 --down_sampling_layers 3 --down_sampling_window 2 \
    --down_sampling_method avg --decomp_method moving_avg --moving_avg 25 \
    --use_norm 1 --use_future_temporal_feature 0 --lradj type1 --optim Adam

# PatchTST
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model PatchTST $COMMON \
    --patch_len 16 --stride 8 --padding_patch end --fc_dropout 0.2 --head_dropout 0 \
    --pct_start 0.4 --learning_rate 0.0005

# iTransformer
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model iTransformer $COMMON \
    --learning_rate 0.0005

# S_Mamba
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model S_Mamba $COMMON \
    --d_state 2 --learning_rate 0.0005

# DLinear
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model DLinear $COMMON \
    --individual --learning_rate 0.0005

# Autoformer
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model Autoformer $COMMON \
    --learning_rate 0.0005

# Informer
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model Informer $COMMON \
    --learning_rate 0.0005

# Flowformer
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model Flowformer $COMMON \
    --learning_rate 0.0005

# Transformer
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model Transformer $COMMON \
    --learning_rate 0.0005

# MMPD (deterministic anchor inference: mmpd_sample_expectation=0)
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model MMPD $COMMON \
    --d_model 256 --d_ff 512 --n_heads 4 --e_layers 2 --d_layers 2 --patch_size 24 \
    --d_diffusion 256 --diffusion_layers 1 --radius 3 --max_diffusion_steps 1000 \
    --beta_schedule linear --point_weight 0.01 --weighted 1 --sample_num 100 \
    --num_sampling_steps 20 --temperature 1.0 --mmpd_sample_expectation 0 \
    --gmm_components 10 --prior_pi_decay 0.5 --prior_precision_shape 100 \
    --gmm_iterations 10 --dropout 0.2 --learning_rate 0.0001 --lradj cosine \
    --optim Adam

# SimpleTM
"$PYTHON_BIN" scripts/efficiency/legacy/run_efficiency_legacy.py --model SimpleTM $COMMON \
    --d_model 32 --d_ff 32 --e_layers 1 --dropout 0.1 --geomattn_dropout 0.5 \
    --wv db1 --wavelet_levels 3 --alpha 1.0 --l1_weight 0.00005 --requires_grad 1 \
    --learning_rate 0.0001 --lradj type1 --optim AdamW --weight_decay 0.01
