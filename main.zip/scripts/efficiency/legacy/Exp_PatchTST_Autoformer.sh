#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/../../.."

# ------------------------------------------------------------------------------
# PatchTST on ETTm1 (pred_len=96, batch_size=16)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model PatchTST \
    --dataset ETTm1 \
    --patch_len 16 \
    --stride 8 \
    --padding_patch end \
    --fc_dropout 0.2 \
    --head_dropout 0 \
    --pct_start 0.4 \
    --learning_rate 0.0001 \
    --batch_size 16 \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# PatchTST on Weather (pred_len=96, batch_size=16)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model PatchTST \
    --dataset weather \
    --patch_len 16 \
    --stride 8 \
    --padding_patch end \
    --fc_dropout 0.2 \
    --head_dropout 0 \
    --pct_start 0.4 \
    --learning_rate 0.0001 \
    --batch_size 16 \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# PatchTST on PEMS04 (pred_len=12, batch_size=16)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model PatchTST \
    --dataset PEMS04 \
    --patch_len 16 \
    --stride 8 \
    --padding_patch end \
    --fc_dropout 0.2 \
    --head_dropout 0 \
    --pct_start 0.4 \
    --learning_rate 0.001 \
    --batch_size 16 \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# PatchTST on ECL (pred_len=336, batch_size=16)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model PatchTST \
    --dataset ECL \
    --patch_len 16 \
    --stride 8 \
    --padding_patch end \
    --fc_dropout 0.2 \
    --head_dropout 0 \
    --pct_start 0.4 \
    --learning_rate 0.0001 \
    --batch_size 16 \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# Autoformer on ECL (pred_len=336, batch_size=16)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model Autoformer \
    --dataset ECL \
    --learning_rate 0.0001 \
    --batch_size 16 \
    --train_epochs 10 \
    --patience 10
