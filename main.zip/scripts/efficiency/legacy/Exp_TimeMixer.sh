#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/../../.."

# ------------------------------------------------------------------------------
# ETTm1 (pred_len=96)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model TimeMixer \
    --dataset ETTm1 \
    --e_layers 2 \
    --d_model 16 \
    --d_ff 32 \
    --batch_size 16 \
    --learning_rate 0.01 \
    --channel_independence 1 \
    --down_sampling_layers 3 \
    --down_sampling_window 2 \
    --down_sampling_method avg \
    --decomp_method moving_avg \
    --moving_avg 25 \
    --use_norm 1 \
    --use_future_temporal_feature 0 \
    --lradj type1 \
    --optim Adam \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# Weather (pred_len=96)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model TimeMixer \
    --dataset weather \
    --e_layers 3 \
    --d_model 16 \
    --d_ff 32 \
    --batch_size 16 \
    --learning_rate 0.001 \
    --channel_independence 1 \
    --down_sampling_layers 3 \
    --down_sampling_window 2 \
    --down_sampling_method avg \
    --decomp_method moving_avg \
    --moving_avg 25 \
    --use_norm 1 \
    --use_future_temporal_feature 0 \
    --lradj type1 \
    --optim Adam \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# PEMS04 (pred_len=12)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model TimeMixer \
    --dataset PEMS04 \
    --e_layers 5 \
    --d_model 128 \
    --d_ff 256 \
    --batch_size 16 \
    --learning_rate 0.003 \
    --channel_independence 0 \
    --down_sampling_layers 1 \
    --down_sampling_window 2 \
    --down_sampling_method avg \
    --decomp_method moving_avg \
    --moving_avg 25 \
    --use_norm 0 \
    --use_future_temporal_feature 0 \
    --lradj type1 \
    --optim Adam \
    --train_epochs 10 \
    --patience 10

# ------------------------------------------------------------------------------
# ECL (pred_len=336)
# ------------------------------------------------------------------------------
python scripts/efficiency/legacy/run_efficiency_legacy.py \
    --model TimeMixer \
    --dataset ECL \
    --e_layers 3 \
    --d_model 16 \
    --d_ff 32 \
    --batch_size 16 \
    --learning_rate 0.005 \
    --channel_independence 1 \
    --down_sampling_layers 3 \
    --down_sampling_window 2 \
    --down_sampling_method avg \
    --decomp_method moving_avg \
    --moving_avg 25 \
    --use_norm 1 \
    --use_future_temporal_feature 0 \
    --lradj type1 \
    --optim Adam \
    --train_epochs 10 \
    --patience 10
