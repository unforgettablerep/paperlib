#!/usr/bin/env python3
"""Legacy efficiency runner for baseline models."""

import argparse
import os
import re
import subprocess
import sys
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
EFFICIENCY_SCRIPT_DIR = os.path.dirname(SCRIPT_DIR)
if EFFICIENCY_SCRIPT_DIR not in sys.path:
    sys.path.insert(0, EFFICIENCY_SCRIPT_DIR)
import efficiency_store

PROJECT_ROOT = os.path.dirname(os.path.dirname(EFFICIENCY_SCRIPT_DIR))

DATASET_CONFIGS = {
    "ETTm1": {
        "root_path": "./data/ETT-small/",
        "data_path": "ETTm1.csv",
        "data": "ETTm1",
        "freq": "t",
        "enc_in": 7,
        "dec_in": 7,
        "c_out": 7,
        "seq_len": 96,
        "pred_len": 96,
        "e_layers": 2,
        "d_model": 256,
        "d_ff": 256,
        "learning_rate": 7e-5,
        "d_state": 8,
    },
    "ECL": {
        "root_path": "./data/electricity/",
        "data_path": "electricity.csv",
        "data": "custom",
        "freq": "h",
        "enc_in": 321,
        "dec_in": 321,
        "c_out": 321,
        "seq_len": 96,
        "pred_len": 336,
        "e_layers": 2,
        "d_model": 512,
        "d_ff": 512,
        "learning_rate": 1e-4,
        "d_state": 8,
    },
    "Weather": {
        "root_path": "./data/weather/",
        "data_path": "weather.csv",
        "data": "custom",
        "freq": "h",
        "enc_in": 21,
        "dec_in": 21,
        "c_out": 21,
        "seq_len": 96,
        "pred_len": 96,
        "e_layers": 2,
        "d_model": 512,
        "d_ff": 512,
        "learning_rate": 5e-5,
        "d_state": 8,
    },
    "PEMS04": {
        "root_path": "./data/PEMS/",
        "data_path": "PEMS04.npz",
        "data": "PEMS",
        "freq": "h",
        "enc_in": 307,
        "dec_in": 307,
        "c_out": 307,
        "seq_len": 96,
        "pred_len": 12,
        "e_layers": 2,
        "d_model": 256,
        "d_ff": 512,
        "learning_rate": 1e-4,
        "d_state": 8,
    },
    "PEMS08": {
        "root_path": "./data/PEMS/",
        "data_path": "PEMS08.npz",
        "data": "PEMS",
        "freq": "h",
        "enc_in": 170,
        "dec_in": 170,
        "c_out": 170,
        "seq_len": 96,
        "pred_len": 12,
        "e_layers": 2,
        "d_model": 256,
        "d_ff": 512,
        "learning_rate": 1e-3,
        "d_state": 8,
    },
}

MAMBA_MODELS = {
    "S_Mamba",
    "Autoformer_M",
    "Flowformer_M",
    "Flashformer_M",
}


def parse_training_output(log_content):
    """Parse training log and extract MSE, MAE, params, speed, GPU memory.

    Mirrors ``scripts/efficiency/run_efficiency.py``: the first ``speed`` line of
    every epoch is dropped because it absorbs CUDA/data-loader warm-up, and the
    validation MSE, model parameter count, and pure inference latency are read
    from the harness markers.
    """
    metrics = {
        "mse": 0.0,
        "mae": 0.0,
        "val_mse": None,
        "params": None,
        "inference_time_ms_per_iter": 0.0,
        "train_time_ms_per_iter": 0.0,
        "avg_gpu_mem_allocated_mb": 0.0,
    }

    m = re.search(r"mse:([0-9\.e\-]+),\s*mae:([0-9\.e\-]+)", log_content)
    if m:
        metrics["mse"] = float(m.group(1))
        metrics["mae"] = float(m.group(2))

    val_matches = re.findall(r"Vali MSE:\s*([0-9\.eE\+\-]+)", log_content)
    if val_matches:
        metrics["val_mse"] = float(val_matches[-1])

    param_matches = re.findall(
        r"model_params: total=(\d+), trainable=(\d+)", log_content
    )
    if param_matches:
        metrics["params"] = int(param_matches[-1][0])

    infer_matches = re.findall(r"inference_speed: ([0-9\.]+)s/iter", log_content)
    if infer_matches:
        metrics["inference_time_ms_per_iter"] = float(infer_matches[-1]) * 1000

    all_speeds = re.findall(r"speed: ([0-9\.]+)s/iter", log_content)
    speeds = []
    seen_speed = False
    for line in log_content.splitlines():
        if re.match(r"^\s*Epoch \d+ : LR", line) or re.match(r"^\s*Epoch: \d+ cost time", line):
            seen_speed = False
        speed_match = re.search(r"speed: ([0-9\.]+)s/iter", line)
        if speed_match:
            if seen_speed:
                speeds.append(speed_match.group(1))
            else:
                seen_speed = True
    if not speeds:
        speeds = all_speeds
    if speeds:
        times_ms = [float(t) * 1000 for t in speeds]
        metrics["train_time_ms_per_iter"] = sum(times_ms) / len(times_ms)

    gpu_matches = re.findall(r"allocated_memory: ([0-9\.]+)", log_content)
    if gpu_matches:
        vals = [float(g) * 1024 for g in gpu_matches]
        metrics["avg_gpu_mem_allocated_mb"] = sum(vals) / len(vals)

    return metrics


def build_command(args, ds_config):
    """Build the subprocess command list for ``scripts/run.py``."""
    model_name = args.model
    dataset = args.dataset

    learning_rate = (
        args.learning_rate
        if args.learning_rate is not None
        else ds_config["learning_rate"]
    )
    d_model = args.d_model if args.d_model is not None else ds_config["d_model"]
    d_ff = args.d_ff if args.d_ff is not None else ds_config["d_ff"]
    e_layers = args.e_layers if args.e_layers is not None else ds_config["e_layers"]
    d_state = args.d_state if args.d_state is not None else ds_config.get("d_state")

    train_epochs = args.train_epochs
    batch_size = args.batch_size
    n_heads = args.n_heads if args.n_heads is not None else 8
    patience = args.patience if args.patience is not None else 3

    model_id = "{}_{}_{}".format(dataset, ds_config["seq_len"], ds_config["pred_len"])

    cmd = [
        sys.executable,
        "-u",
        os.path.join(PROJECT_ROOT, "scripts", "run.py"),
        "--is_training",
        "1",
        "--root_path",
        ds_config["root_path"],
        "--data_path",
        ds_config["data_path"],
        "--model_id",
        model_id,
        "--model",
        model_name,
        "--data",
        ds_config["data"],
        "--freq",
        ds_config.get("freq", "h"),
        "--features",
        "M",
        "--seq_len",
        str(ds_config["seq_len"]),
        "--label_len",
        "48",
        "--pred_len",
        str(ds_config["pred_len"]),
        "--e_layers",
        str(e_layers),
        "--enc_in",
        str(ds_config["enc_in"]),
        "--dec_in",
        str(ds_config["dec_in"]),
        "--c_out",
        str(ds_config["c_out"]),
        "--des",
        "Efficiency-Exp",
        "--batch_size",
        str(batch_size),
        "--train_epochs",
        str(train_epochs),
        "--learning_rate",
        str(learning_rate),
        "--d_model",
        str(d_model),
        "--d_ff",
        str(d_ff),
        "--n_heads",
        str(n_heads),
        "--itr",
        "1",
        "--patience",
        str(patience),
        "--save_tmp",
        "0",
        "--cleanup_checkpoint",
        "1",
    ]

    if args.use_amp:
        cmd.append("--use_amp")

    if args.use_8bit:
        cmd.extend(["--use_8bit", str(args.use_8bit)])

    if d_state is not None and model_name in MAMBA_MODELS:
        cmd.extend(["--d_state", str(d_state)])

    if args.individual:
        cmd.append("--individual")

    if model_name == "TimeMixer":
        if args.channel_independence is not None:
            cmd.extend(["--channel_independence", str(args.channel_independence)])
        if args.down_sampling_layers is not None:
            cmd.extend(["--down_sampling_layers", str(args.down_sampling_layers)])
        if args.down_sampling_window is not None:
            cmd.extend(["--down_sampling_window", str(args.down_sampling_window)])
        if args.down_sampling_method is not None:
            cmd.extend(["--down_sampling_method", args.down_sampling_method])
        if args.decomp_method is not None:
            cmd.extend(["--decomp_method", args.decomp_method])
        if args.moving_avg is not None:
            cmd.extend(["--moving_avg", str(args.moving_avg)])
        if args.top_k is not None:
            cmd.extend(["--top_k", str(args.top_k)])
        if args.use_norm is not None:
            cmd.extend(["--use_norm", str(args.use_norm)])
        if args.use_future_temporal_feature is not None:
            cmd.extend(
                ["--use_future_temporal_feature", str(args.use_future_temporal_feature)]
            )

    if model_name == "MMPD":
        for key in (
            "mmpd_backbone",
            "patch_size",
            "d_diffusion",
            "diffusion_layers",
            "max_diffusion_steps",
            "beta_schedule",
            "radius",
            "point_weight",
            "weighted",
            "sample_num",
            "num_sampling_steps",
            "temperature",
            "mmpd_sample_expectation",
            "gmm_components",
            "prior_pi_decay",
            "prior_precision_shape",
            "gmm_iterations",
        ):
            val = getattr(args, key, None)
            if val is not None:
                cmd.extend(["--" + key, str(val)])
        if args.d_layers is not None:
            cmd.extend(["--d_layers", str(args.d_layers)])

    if model_name == "SimpleTM":
        for key in (
            "geomattn_dropout",
            "wv",
            "wavelet_levels",
            "kernel_size",
            "alpha",
            "l1_weight",
            "requires_grad",
        ):
            val = getattr(args, key, None)
            if val is not None:
                cmd.extend(["--" + key, str(val)])
        if args.d_layers is not None:
            cmd.extend(["--d_layers", str(args.d_layers)])

    if args.patch_len is not None:
        cmd.extend(["--patch_len", str(args.patch_len)])
    if args.stride is not None:
        cmd.extend(["--stride", str(args.stride)])
    if args.padding_patch is not None:
        cmd.extend(["--padding_patch", args.padding_patch])

    if args.fc_dropout is not None:
        cmd.extend(["--fc_dropout", str(args.fc_dropout)])
    if args.head_dropout is not None:
        cmd.extend(["--head_dropout", str(args.head_dropout)])
    if args.pct_start is not None:
        cmd.extend(["--pct_start", str(args.pct_start)])
    if args.lradj is not None:
        cmd.extend(["--lradj", args.lradj])
    if args.optim is not None:
        cmd.extend(["--optim", args.optim])
    if args.weight_decay is not None:
        cmd.extend(["--weight_decay", str(args.weight_decay)])
    if args.dropout is not None:
        cmd.extend(["--dropout", str(args.dropout)])
    if args.use_norm is not None:
        cmd.extend(["--use_norm", str(args.use_norm)])

    cmd.extend(args.extra)

    run_config = {
        "model": model_name,
        "dataset": dataset,
        "model_id": model_id,
        "batch_size": batch_size,
        "train_epochs": train_epochs,
        "learning_rate": learning_rate,
        "d_model": d_model,
        "d_ff": d_ff,
        "e_layers": e_layers,
        "seq_len": ds_config["seq_len"],
        "pred_len": ds_config["pred_len"],
        "enc_in": ds_config["enc_in"],
        "d_state": d_state,
        "low_rank": args.low_rank if args.low_rank is not None else 0,
        "dropout": (
            args.dropout
            if args.dropout is not None
            else (0.2 if model_name == "MMPD" else 0.1)
        ),
        "patience": patience,
        "optim": args.optim or ("AdamW" if model_name == "SimpleTM" else "Adam"),
        "lradj": args.lradj or "type1",
        "weight_decay": args.weight_decay,
    }
    if model_name == "MMPD":
        for key in (
            "mmpd_backbone",
            "patch_size",
            "d_diffusion",
            "diffusion_layers",
            "max_diffusion_steps",
            "beta_schedule",
            "radius",
            "point_weight",
            "weighted",
            "sample_num",
            "num_sampling_steps",
            "temperature",
            "mmpd_sample_expectation",
            "gmm_components",
            "gmm_iterations",
        ):
            val = getattr(args, key, None)
            if val is not None:
                run_config[key] = val
    if model_name == "SimpleTM":
        for key in (
            "geomattn_dropout",
            "wv",
            "wavelet_levels",
            "alpha",
            "l1_weight",
            "requires_grad",
        ):
            val = getattr(args, key, None)
            if val is not None:
                run_config[key] = val

    return cmd, model_id, run_config


def main():
    parser = argparse.ArgumentParser(
        description="Legacy efficiency experiment runner for non-Hi-Mamba models",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python scripts/efficiency/legacy/run_efficiency_legacy.py --model S_Mamba --dataset ETTm1 --d_state 8\n"
            "  python scripts/efficiency/legacy/run_efficiency_legacy.py --model PatchTST --dataset ECL --patch_len 16 --stride 8\n"
        ),
    )

    parser.add_argument("--model", type=str, required=True, help="Model name")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="Dataset: ETTm1, ECL, weather, PEMS04",
    )
    parser.add_argument("--learning_rate", type=float, default=None)
    parser.add_argument("--d_state", type=int, default=None)
    parser.add_argument("--d_model", type=int, default=None)
    parser.add_argument("--d_ff", type=int, default=None)
    parser.add_argument("--e_layers", type=int, default=None)
    parser.add_argument("--n_heads", type=int, default=None)
    parser.add_argument("--d_layers", type=int, default=None)
    parser.add_argument("--use_amp", action="store_true", default=False)
    parser.add_argument("--train_epochs", type=int, default=10)
    parser.add_argument("--patience", type=int, default=None)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--use_8bit", type=int, default=0)

    parser.add_argument("--tcn_kernel_size", type=int, default=None)
    parser.add_argument("--tcn_dropout", type=float, default=None)
    parser.add_argument("--st_attention_dim", type=int, default=None)
    parser.add_argument("--st_dropout", type=float, default=None)
    parser.add_argument("--low_rank", type=int, default=None)

    parser.add_argument("--patch_len", type=int, default=None)
    parser.add_argument("--stride", type=int, default=None)
    parser.add_argument("--padding_patch", type=str, default=None)

    parser.add_argument("--individual", action="store_true", default=False)

    parser.add_argument("--fc_dropout", type=float, default=None)
    parser.add_argument("--head_dropout", type=float, default=None)
    parser.add_argument("--pct_start", type=float, default=None)
    parser.add_argument("--lradj", type=str, default=None)
    parser.add_argument("--optim", type=str, default=None)
    parser.add_argument("--weight_decay", type=float, default=None)
    parser.add_argument("--dropout", type=float, default=None)
    parser.add_argument("--use_norm", type=int, default=None)

    # ---- TimeMixer-specific parameters (defaults mirror configs/custom_TimeMixer.py) ----
    parser.add_argument(
        "--channel_independence",
        type=int,
        default=None,
        help="TimeMixer: channel independence (1/0)",
    )
    parser.add_argument(
        "--down_sampling_layers",
        type=int,
        default=None,
        help="TimeMixer: num of down sampling layers",
    )
    parser.add_argument(
        "--down_sampling_window",
        type=int,
        default=None,
        help="TimeMixer: down sampling window size",
    )
    parser.add_argument(
        "--down_sampling_method",
        type=str,
        default=None,
        help="TimeMixer: down sampling method (avg/max/conv)",
    )
    parser.add_argument(
        "--decomp_method",
        type=str,
        default=None,
        help="TimeMixer: series decomposition (moving_avg/dft_decomp)",
    )
    parser.add_argument(
        "--moving_avg",
        type=int,
        default=None,
        help="TimeMixer: moving average window for decomposition",
    )
    parser.add_argument(
        "--top_k", type=int, default=None, help="TimeMixer: top-k freq for dft_decomp"
    )
    parser.add_argument(
        "--use_future_temporal_feature",
        type=int,
        default=None,
        help="TimeMixer: whether to use future temporal features",
    )

    # ---- MMPD-specific parameters (defaults mirror configs/custom_MMPD.py) ----
    parser.add_argument(
        "--mmpd_backbone",
        type=str,
        default=None,
        help="MMPD: Decoder or EncoderDecoder backbone",
    )
    parser.add_argument("--patch_size", type=int, default=None, help="MMPD: future patch size")
    parser.add_argument("--d_diffusion", type=int, default=None, help="MMPD: diffusion MLP width")
    parser.add_argument(
        "--diffusion_layers", type=int, default=None, help="MMPD: denoiser MLP layers"
    )
    parser.add_argument(
        "--max_diffusion_steps", type=int, default=None, help="MMPD: training diffusion steps"
    )
    parser.add_argument(
        "--beta_schedule", type=str, default=None, help="MMPD: linear or cosine noise schedule"
    )
    parser.add_argument("--radius", type=int, default=None, help="MMPD: adjacent patch radius")
    parser.add_argument(
        "--point_weight", type=float, default=None, help="MMPD: point-prediction regularizer weight"
    )
    parser.add_argument("--weighted", type=int, default=None, help="MMPD: variance-weighted loss")
    parser.add_argument(
        "--sample_num", type=int, default=None, help="MMPD: diffusion samples per inference"
    )
    parser.add_argument(
        "--num_sampling_steps",
        type=str,
        default=None,
        help="MMPD: reverse-diffusion steps used by the sampling path",
    )
    parser.add_argument("--temperature", type=float, default=None, help="MMPD: sampling temperature")
    parser.add_argument(
        "--mmpd_sample_expectation",
        type=int,
        default=None,
        help="MMPD: 1 uses multi-sample expectation, 0 uses the deterministic anchor",
    )
    parser.add_argument("--gmm_components", type=int, default=None, help="MMPD: GMM components")
    parser.add_argument("--prior_pi_decay", type=float, default=None, help="MMPD: mixture prior decay")
    parser.add_argument(
        "--prior_precision_shape", type=float, default=None, help="MMPD: precision prior shape"
    )
    parser.add_argument("--gmm_iterations", type=int, default=None, help="MMPD: EM iterations per step")

    # ---- SimpleTM-specific parameters (defaults mirror configs/custom_SimpleTM.py) ----
    parser.add_argument(
        "--geomattn_dropout", type=float, default=None, help="SimpleTM: geometric attention dropout"
    )
    parser.add_argument("--wv", type=str, default=None, help="SimpleTM: wavelet filter")
    parser.add_argument(
        "--wavelet_levels", type=int, default=None, help="SimpleTM: stationary wavelet levels"
    )
    parser.add_argument("--kernel_size", type=int, default=None, help="SimpleTM: wavelet kernel size")
    parser.add_argument("--alpha", type=float, default=None, help="SimpleTM: wedge-product weight")
    parser.add_argument("--l1_weight", type=float, default=None, help="SimpleTM: L1 regularization")
    parser.add_argument(
        "--requires_grad", type=int, default=None, help="SimpleTM: learnable wavelet filters"
    )

    args, extra = parser.parse_known_args()
    args.extra = extra

    dataset = args.dataset
    dataset_key = efficiency_store.shard_name(dataset)
    if dataset_key not in DATASET_CONFIGS:
        print("ERROR: Unknown dataset '{}'".format(dataset))
        print("  Available: {}".format(list(DATASET_CONFIGS.keys())))
        sys.exit(1)

    ds_config = DATASET_CONFIGS[dataset_key]
    cmd, model_id, run_config = build_command(args, ds_config)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    print(
        "Parameters: Batch {}, Epochs {}, LR {}".format(
            run_config["batch_size"],
            run_config["train_epochs"],
            run_config["learning_rate"],
        )
    )
    print("Model ID: {}".format(model_id))
    print("=" * 80)
    print()
    print("Starting training...")
    print()

    child_env = os.environ.copy()
    child_env["M2PATCH_SKIP_RESULT_WRITE"] = "1"

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        cwd=PROJECT_ROOT,
        env=child_env,
    )

    output_lines = []
    for line in iter(proc.stdout.readline, b""):
        decoded = line.decode("utf-8", errors="replace")
        print(decoded, end="")
        output_lines.append(decoded)

    proc.wait()

    if proc.returncode != 0:
        print("\nERROR: Training failed for {} on {}".format(args.model, dataset))
        sys.exit(1)

    log_content = "".join(output_lines)
    print("\nParsing metrics...")

    metrics = parse_training_output(log_content)

    run_config["use_amp"] = bool(args.use_amp)
    run_config["gpu"] = None
    record = efficiency_store.build_record(
        model=args.model,
        dataset=dataset,
        model_id=model_id,
        config=run_config,
        metrics=metrics,
        timestamp=timestamp,
    )
    jsonl_path = efficiency_store.append(dataset, record)

    print("Successfully parsed metrics for {} on {}".format(args.model, dataset))
    print("  Model ID: {}".format(model_id))
    print("  MSE: {:.8f}".format(metrics["mse"]))
    print("  MAE: {:.8f}".format(metrics["mae"]))
    if metrics.get("val_mse") is not None:
        print("  Val MSE: {}".format(metrics["val_mse"]))
    print("  Params: {}".format(metrics.get("params")))
    print(
        "  Inference Time: {:.4f} ms/iter".format(
            metrics.get("inference_time_ms_per_iter", 0.0)
        )
    )
    print("  Training Time: {:.2f} ms/iter".format(metrics["train_time_ms_per_iter"]))
    print(
        "  Avg Allocated GPU Memory: {:.2f} MB".format(
            metrics["avg_gpu_mem_allocated_mb"]
        )
    )
    print("JSONL updated: {}".format(jsonl_path))
    print("=" * 80)


if __name__ == "__main__":
    main()
