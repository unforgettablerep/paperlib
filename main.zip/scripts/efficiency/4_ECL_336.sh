#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/../.."

python scripts/efficiency/run_efficiency.py \
    --dataset ECL \
    --pred_len 336 \
    --train_epochs 10 \
    --gpu 0 \
    --d_model 128 \
    --d_hyp 64 \
    --e_layers 2 \
    --d_layers_diff 2 \
    --patch_len 24 \
    --stride 12 \
    --learning_rate 1.2e-3 \
    --lambda_hyp 0.1 \
    --batch_size 16
