#!/usr/bin/env python3
import argparse
import glob
import json
import os
import re
import subprocess
import sys
from datetime import datetime

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(os.path.dirname(SCRIPT_DIR))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.configs.m2patch_profiles import CONSTANTS, get_pred_lens, resolve, resolve_meta
from src.utils.result_io import canonical_dataset

DEFAULT_OUTPUT_DIR = os.path.join(
    PROJECT_ROOT, "output", "efficiency", "m2patch_results"
)
XLSX_PATH = os.path.join(DEFAULT_OUTPUT_DIR, "archive", "efficiency_records.xlsx")
LOG_DIR = os.path.join(PROJECT_ROOT, "output", "efficiency", "m2patch_logs")

EFFICIENCY_TRAIN_EPOCHS = 10

EFFICIENCY_OVERRIDES = {
    "use_amp": 0,
    "train_epochs": EFFICIENCY_TRAIN_EPOCHS,
}

XLSX_HEADERS = [
    "Timestamp",
    "Dataset",
    "Model",
    "Model ID",
    "seq_len",
    "pred_len",
    "enc_in",
    "e_layers",
    "d_model",
    "d_ff",
    "patch_len",
    "stride",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "ablation",
    "revin",
    "lradj",
    "dropout",
    "learning_rate",
    "weight_decay",
    "batch_size",
    "optim",
    "train_epochs",
    "pct_start",
    "patience",
    "use_amp",
    "gpu",
    "seed",
    "MSE",
    "MAE",
    "Val MSE",
    "Params",
    "Inference Time (ms/iter)",
    "Train Time (ms/iter)",
    "ms/sample",
    "GPU Memory (MB)",
    "MB/sample",
]

HEADER_FONT = Font(bold=True)
HEADER_FILL = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")

LOCKED_CONFIG = {
    "diff_steps": CONSTANTS["diff_steps"],
    "lambda_prior": CONSTANTS["lambda_prior"],
}

LOCKED_CLI_KEYS = ("--diff_steps", "--lambda_prior")


def strip_locked_run_args(tokens):
    filtered = []
    skip_next = False
    prefixes = tuple(key + "=" for key in LOCKED_CLI_KEYS)
    for token in tokens:
        if skip_next:
            skip_next = False
            continue
        if token in LOCKED_CLI_KEYS:
            skip_next = True
            continue
        if token.startswith(prefixes):
            continue
        filtered.append(token)
    return filtered


def load_defaults(dataset, pred_len=None):
    """Resolve the tuned M2Patch profile for a dataset/horizon."""
    dataset = canonical_dataset(dataset)
    if pred_len is None:
        print("ERROR: --pred_len is required for dataset '{}'".format(dataset))
        print("  Available pred_lens: {}".format(list_pred_lens(dataset)))
        sys.exit(1)
    try:
        config = resolve(dataset, pred_len)
        config.update(resolve_meta(dataset, pred_len))
    except KeyError as exc:
        print("ERROR: {}".format(exc))
        sys.exit(1)
    config["dataset"] = dataset
    config["dec_in"] = config["enc_in"]
    config.update(EFFICIENCY_OVERRIDES)
    return config


def list_pred_lens(dataset):
    return get_pred_lens(canonical_dataset(dataset))


def apply_overrides(config, args):
    """Override profile values with non-None CLI arguments."""
    override_keys = [
        "seq_len",
        "pred_len",
        "e_layers",
        "d_model",
        "d_ff",
        "patch_len",
        "stride",
        "d_hyp",
        "manifold_c",
        "d_layers_diff",
        "diff_schedule",
        "diff_eta",
        "lambda_hyp",
        "ablation",
        "revin",
        "batch_size",
        "learning_rate",
        "weight_decay",
        "dropout",
        "patience",
        "pct_start",
        "lradj",
        "optim",
        "use_amp",
        "gpu",
        "seed",
    ]
    for key in override_keys:
        val = getattr(args, key, None)
        if val is not None:
            config[key] = val
    if args.d_model is not None and args.d_ff is None:
        config["d_ff"] = min(config["d_model"] * 2, 768)
    config.update(LOCKED_CONFIG)
    return config


def build_run_command(config, train_epochs, extra_args):
    """Build the subprocess command list for ``scripts/run.py``."""
    model_id = "{}_{}_{}".format(
        config["dataset"], config["seq_len"], config["pred_len"]
    )

    cmd = [
        sys.executable,
        "-u",
        os.path.join(PROJECT_ROOT, "scripts", "run.py"),
        "--is_training",
        "1",
        "--model",
        "M2Patch",
        "--model_id",
        model_id,
        "--root_path",
        config["root_path"],
        "--data_path",
        config["data_path"],
        "--data",
        config["data"],
        "--freq",
        config.get("freq", "h"),
        "--features",
        "M",
        "--seq_len",
        str(config["seq_len"]),
        "--label_len",
        str(config.get("label_len", 48)),
        "--pred_len",
        str(config["pred_len"]),
        "--enc_in",
        str(config["enc_in"]),
        "--dec_in",
        str(config["dec_in"]),
        "--c_out",
        str(config["c_out"]),
        "--e_layers",
        str(config["e_layers"]),
        "--d_model",
        str(config["d_model"]),
        "--d_ff",
        str(config["d_ff"]),
        "--des",
        "Efficiency-Exp",
        "--itr",
        "1",
        "--batch_size",
        str(config["batch_size"]),
        "--train_epochs",
        str(train_epochs),
        "--learning_rate",
        str(config["learning_rate"]),
        "--dropout",
        str(config.get("dropout", CONSTANTS["dropout"])),
        "--patience",
        str(config.get("patience", CONSTANTS["patience"])),
        "--use_amp" if config.get("use_amp", 0) else "--no-use_amp",
        "--optim",
        config.get("optim", CONSTANTS["optim"]),
        "--lradj",
        config.get("lradj", CONSTANTS["lradj"]),
        "--pct_start",
        str(config.get("pct_start", CONSTANTS["pct_start"])),
        "--gpu",
        str(config.get("gpu", 0)),
        "--seed",
        str(config.get("seed", 2023)),
        "--patch_len",
        str(config.get("patch_len", CONSTANTS["patch_len"])),
        "--stride",
        str(config.get("stride", CONSTANTS["stride"])),
        "--d_hyp",
        str(config.get("d_hyp", CONSTANTS["d_hyp"])),
        "--manifold_c",
        str(config.get("manifold_c", CONSTANTS["manifold_c"])),
        "--d_layers_diff",
        str(config.get("d_layers_diff", CONSTANTS["d_layers_diff"])),
        "--diff_steps",
        str(config.get("diff_steps", CONSTANTS["diff_steps"])),
        "--diff_schedule",
        str(config.get("diff_schedule", CONSTANTS["diff_schedule"])),
        "--diff_eta",
        str(config.get("diff_eta", CONSTANTS["diff_eta"])),
        "--lambda_hyp",
        str(config.get("lambda_hyp", CONSTANTS["lambda_hyp"])),
        "--lambda_prior",
        str(config.get("lambda_prior", CONSTANTS["lambda_prior"])),
        "--ablation",
        config.get("ablation", "none"),
        "--revin",
        str(config.get("revin", CONSTANTS["revin"])),
        "--save_tmp",
        "0",
        "--cleanup_checkpoint",
        "1",
    ]

    cmd.extend(extra_args)
    return cmd, model_id


def parse_training_output(log_content):
    """Parse training log and extract MSE, MAE, training speed, GPU memory."""
    metrics = {
        "mse": 0.0,
        "mae": 0.0,
        "val_mse": None,
        "params": None,
        "inference_time_ms_per_iter": 0.0,
        "train_time_ms_per_iter": 0.0,
        "avg_gpu_mem_allocated_mb": 0.0,
    }

    m = re.search(r"mse:([0-9\.e\-]+),\s*mae:([0-9\.e\-]+)", log_content)
    if m:
        metrics["mse"] = float(m.group(1))
        metrics["mae"] = float(m.group(2))

    val_matches = re.findall(r"Vali MSE:\s*([0-9\.eE\+\-]+)", log_content)
    if val_matches:
        metrics["val_mse"] = float(val_matches[-1])

    param_matches = re.findall(
        r"model_params: total=(\d+), trainable=(\d+)", log_content
    )
    if param_matches:
        metrics["params"] = int(param_matches[-1][0])

    infer_matches = re.findall(r"inference_speed: ([0-9\.]+)s/iter", log_content)
    if infer_matches:
        metrics["inference_time_ms_per_iter"] = float(infer_matches[-1]) * 1000

    all_speeds = re.findall(r"speed: ([0-9\.]+)s/iter", log_content)
    speeds = []
    seen_speed = False
    for line in log_content.splitlines():
        if re.match(r"^\s*Epoch \d+ : LR", line) or re.match(r"^\s*Epoch: \d+ cost time", line):
            seen_speed = False
        speed_match = re.search(r"speed: ([0-9\.]+)s/iter", line)
        if speed_match:
            if seen_speed:
                speeds.append(speed_match.group(1))
            else:
                seen_speed = True
    if not speeds:
        speeds = all_speeds
    if speeds:
        times_ms = [float(t) * 1000 for t in speeds]
        metrics["train_time_ms_per_iter"] = sum(times_ms) / len(times_ms)

    gpu_matches = re.findall(r"allocated_memory: ([0-9\.]+)", log_content)
    if gpu_matches:
        vals = [float(g) * 1024 for g in gpu_matches]
        metrics["avg_gpu_mem_allocated_mb"] = sum(vals) / len(vals)

    return metrics


def build_result_json(model_id, timestamp, config, metrics):
    """Build the JSON-serializable result dict."""
    ds = config.get("dataset", "unknown")
    result = {
        "model": "M2Patch",
        "dataset": ds,
        "model_id": model_id,
        "timestamp": timestamp,
    }
    result["metrics"] = {
        "mse": metrics["mse"],
        "mae": metrics["mae"],
        "val_mse": metrics.get("val_mse"),
        "params": metrics.get("params"),
        "inference_time_ms_per_iter": round(
            metrics.get("inference_time_ms_per_iter", 0.0), 4
        ),
        "train_time_ms_per_iter": round(metrics["train_time_ms_per_iter"], 4),
        "avg_gpu_mem_allocated_mb": round(metrics["avg_gpu_mem_allocated_mb"], 4),
    }
    result["config"] = {
        "seq_len": config.get("seq_len"),
        "pred_len": config.get("pred_len"),
        "enc_in": config.get("enc_in"),
        "e_layers": config.get("e_layers"),
        "d_model": config.get("d_model"),
        "d_ff": config.get("d_ff"),
        "patch_len": config.get("patch_len"),
        "stride": config.get("stride"),
        "d_hyp": config.get("d_hyp"),
        "manifold_c": config.get("manifold_c"),
        "d_layers_diff": config.get("d_layers_diff"),
        "diff_steps": config.get("diff_steps"),
        "diff_schedule": config.get("diff_schedule"),
        "diff_eta": config.get("diff_eta"),
        "lambda_hyp": config.get("lambda_hyp"),
        "lambda_prior": config.get("lambda_prior"),
        "ablation": config.get("ablation", "none"),
        "revin": config.get("revin"),
        "lradj": config.get("lradj", "onecycle"),
        "dropout": config.get("dropout"),
        "learning_rate": config.get("learning_rate"),
        "weight_decay": config.get("weight_decay"),
        "batch_size": config.get("batch_size"),
        "optim": config.get("optim"),
        "train_epochs": config.get("_train_epochs"),
        "pct_start": config.get("pct_start"),
        "patience": config.get("patience"),
        "use_amp": config.get("use_amp"),
        "gpu": config.get("gpu", 0),
        "seed": config.get("seed", 2023),
    }
    return result


def write_json(output_dir, result):
    """Write result as a JSON file to output_dir."""
    ds = result["dataset"]
    pl = result["config"]["pred_len"]
    ts = result["timestamp"]
    json_path = os.path.join(output_dir, "M2Patch_{}_pl{}_{}.json".format(ds, pl, ts))
    with open(json_path, "w") as f:
        json.dump(result, f, indent=4)
    return json_path


def _row_values_from_result(result):
    """Extract ordered row values matching XLSX_HEADERS."""
    c = result["config"]
    m = result["metrics"]
    batch_size = c.get("batch_size") or 1
    ms_per_iter = m["train_time_ms_per_iter"]
    infer_ms = m.get("inference_time_ms_per_iter") or 0.0
    mem_mb = m["avg_gpu_mem_allocated_mb"]
    return [
        result["timestamp"],
        result["dataset"],
        result["model"],
        result["model_id"],
        c.get("seq_len"),
        c.get("pred_len"),
        c.get("enc_in"),
        c.get("e_layers"),
        c.get("d_model"),
        c.get("d_ff"),
        c.get("patch_len"),
        c.get("stride"),
        c.get("d_hyp"),
        c.get("manifold_c"),
        c.get("d_layers_diff"),
        c.get("diff_steps"),
        c.get("diff_schedule"),
        c.get("diff_eta"),
        c.get("lambda_hyp"),
        c.get("lambda_prior"),
        c.get("ablation", "none"),
        c.get("revin"),
        c.get("lradj"),
        c.get("dropout"),
        c.get("learning_rate"),
        c.get("weight_decay"),
        c.get("batch_size"),
        c.get("optim"),
        c.get("train_epochs"),
        c.get("pct_start"),
        c.get("patience"),
        c.get("use_amp"),
        c.get("gpu"),
        c.get("seed"),
        m["mse"],
        m["mae"],
        m.get("val_mse"),
        m.get("params"),
        infer_ms,
        ms_per_iter,
        round(ms_per_iter / batch_size, 6),
        mem_mb,
        round(mem_mb / batch_size, 6),
    ]


def append_to_xlsx(result, xlsx_path=None):
    """Append a result row to the efficiency_records.xlsx tracking file.

    Creates the file with headers if it does not exist and rejects unknown
    workbook schemas instead of silently migrating them.
    """
    target_path = xlsx_path or XLSX_PATH
    parent = os.path.dirname(target_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    if os.path.exists(target_path):
        wb = openpyxl.load_workbook(target_path)
        ws = wb.active
        headers = [cell.value for cell in ws[1]]
        if headers != XLSX_HEADERS:
            raise ValueError(
                "efficiency_records.xlsx has an unsupported schema; delete or regenerate it"
            )
        start_row = ws.max_row + 1
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "M2Patch Efficiency"
        for col_idx, header in enumerate(XLSX_HEADERS, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = Alignment(horizontal="center")
        start_row = 2

    values = _row_values_from_result(result)
    for col_idx, val in enumerate(values, 1):
        ws.cell(row=start_row, column=col_idx, value=val)

    ws.auto_filter.ref = ws.dimensions
    wb.save(target_path)
    wb.close()


def rebuild_xlsx(output_dir=None, xlsx_path=None):
    """Rebuild efficiency_records.xlsx from every result JSON in output_dir."""
    source_dir = output_dir or DEFAULT_OUTPUT_DIR
    default_target = XLSX_PATH if source_dir == DEFAULT_OUTPUT_DIR else os.path.join(source_dir, "efficiency_records.xlsx")
    target_path = xlsx_path or default_target
    records = []
    for path in sorted(glob.glob(os.path.join(source_dir, "M2Patch_*.json"))):
        with open(path, "r") as f:
            records.append(json.load(f))
    records.sort(
        key=lambda r: (
            r.get("dataset", ""),
            r.get("config", {}).get("pred_len", 0),
            r.get("timestamp", ""),
        )
    )

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "M2Patch Efficiency"
    for col_idx, header in enumerate(XLSX_HEADERS, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")
    for row_idx, result in enumerate(records, 2):
        for col_idx, val in enumerate(_row_values_from_result(result), 1):
            ws.cell(row=row_idx, column=col_idx, value=val)
    ws.auto_filter.ref = ws.dimensions

    notes = wb.create_sheet("Protocol Notes")
    note_lines = [
        "Every row is one raw training run; batch_size is recorded per row.",
        "Unified efficiency protocol: 10 epochs, batch_size=16, FP32, seed=2023, one RTX 4090 D.",
        "ms/sample = Train Time (ms/iter) / batch_size; MB/sample = GPU Memory (MB) / batch_size.",
        "inference_time_ms_per_iter is the pure forward latency measured in test() with CUDA synchronisation.",
        "params counts every model parameter (total, not trainable-only).",
        "Final M2Patch recipes are pinned in output/efficiency/efficiency_plot.ipynb (M2PATCH_JSON_MAP)",
        "and were selected by validation MSE among the batch=16 rounds; test MSE is reported once.",
        "Per-run stdout logs exist for runs launched after the logging change (files with a CMD: header);",
        "earlier rounds are evidenced by their JSON records only (no reconstructed logs are shipped).",
    ]
    for row_idx, line in enumerate(note_lines, 1):
        notes.cell(row=row_idx, column=1, value=line)

    wb.save(target_path)
    wb.close()
    return target_path, len(records)


def main():
    parser = argparse.ArgumentParser(
        description="Run M2Patch efficiency experiments",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Any additional unrecognized args are passed through to scripts/run.py.\n"
            "Examples:\n"
            "  python scripts/efficiency/run_efficiency.py --dataset ECL\n"
            "  python scripts/efficiency/run_efficiency.py --dataset ETTh2 --pred_len 96\n"
            "  python scripts/efficiency/run_efficiency.py --dataset ETTm1 --pred_len 96\n"
            "  python scripts/efficiency/run_efficiency.py --dataset Weather --train_epochs 10\n"
        ),
    )

    parser.add_argument(
        "--dataset",
        type=str,
        required=False,
        help="Dataset name: ECL, ETTh2, ETTm1, PEMS04, Weather",
    )
    parser.add_argument(
        "--pred_len",
        type=int,
        default=None,
        help="Prediction length (required unless --all_pred_lens)",
    )
    parser.add_argument(
        "--all_pred_lens",
        "--all-pred-lens",
        action="store_true",
        dest="all_pred_lens",
        help="Run every pred_len preset defined for the dataset",
    )
    parser.add_argument(
        "--train_epochs",
        type=int,
        default=None,
        help="Number of training epochs (default: profile train_epochs)",
    )
    parser.add_argument("--gpu", type=int, default=None, help="GPU device id")
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed passed to scripts/run.py (default: 2023)",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help="Output directory for results (default: output/efficiency/m2patch_results/)",
    )
    parser.add_argument(
        "--log_dir",
        type=str,
        default=None,
        help="Directory for per-run stdout logs (default: log/efficiency/)",
    )
    parser.add_argument(
        "--rebuild_xlsx",
        action="store_true",
        help="Rebuild efficiency_records.xlsx from the result JSONs and exit",
    )

    parser.add_argument("--seq_len", type=int, default=None)
    parser.add_argument("--e_layers", type=int, default=None)
    parser.add_argument("--d_model", type=int, default=None)
    parser.add_argument("--d_ff", type=int, default=None)
    parser.add_argument("--batch_size", type=int, default=None)
    parser.add_argument("--learning_rate", type=float, default=None)
    parser.add_argument("--weight_decay", type=float, default=None)
    parser.add_argument("--dropout", type=float, default=None)
    parser.add_argument("--patience", type=int, default=None)
    parser.add_argument("--pct_start", type=float, default=None)
    parser.add_argument("--lradj", type=str, default=None)
    parser.add_argument("--optim", type=str, default=None)
    parser.add_argument("--use_amp", type=int, default=None)

    parser.add_argument("--patch_len", type=int, default=None)
    parser.add_argument("--stride", type=int, default=None)
    parser.add_argument("--d_hyp", type=int, default=None)
    parser.add_argument("--manifold_c", type=float, default=None)
    parser.add_argument("--d_layers_diff", type=int, default=None)
    parser.add_argument("--diff_schedule", type=str, default=None)
    parser.add_argument("--diff_eta", type=float, default=None)
    parser.add_argument("--lambda_hyp", type=float, default=None)
    parser.add_argument("--ablation", type=str, default=None)
    parser.add_argument("--revin", type=int, default=None)

    args, extra_run_args = parser.parse_known_args()
    extra_run_args = strip_locked_run_args(extra_run_args)

    if args.rebuild_xlsx:
        target, count = rebuild_xlsx(args.output_dir, None if args.output_dir is None else os.path.join(args.output_dir, "efficiency_records.xlsx"))
        print("Rebuilt {} from {} JSON records".format(target, count))
        return

    if not args.dataset:
        parser.error("--dataset is required unless --rebuild_xlsx is given")

    if args.all_pred_lens:
        pred_lens = list_pred_lens(args.dataset)
        if not pred_lens:
            print("ERROR: no pred_len presets found for {}".format(args.dataset))
            sys.exit(1)
        filtered = []
        skip_next = False
        for token in sys.argv[1:]:
            if skip_next:
                skip_next = False
                continue
            if token in ("--all_pred_lens", "--all-pred-lens"):
                continue
            if token == "--pred_len":
                skip_next = True
                continue
            if token.startswith("--pred_len="):
                continue
            filtered.append(token)
        for pred_len in pred_lens:
            cmd = [sys.executable, os.path.abspath(__file__)] + filtered + ["--pred_len", str(pred_len)]
            print("Running efficiency for {} pred_len={}".format(args.dataset, pred_len))
            subprocess.run(cmd, cwd=PROJECT_ROOT, check=True)
        return

    config = load_defaults(args.dataset, args.pred_len)
    config = apply_overrides(config, args)
    train_epochs = (
        args.train_epochs
        if args.train_epochs is not None
        else config.get("train_epochs", EFFICIENCY_TRAIN_EPOCHS)
    )
    config["_train_epochs"] = train_epochs

    output_dir = args.output_dir or DEFAULT_OUTPUT_DIR
    cmd, model_id = build_run_command(config, train_epochs, extra_run_args)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    print(
        "Config: batch={}, epochs={}, lr={}, dm={}, df={}, el={}, patch={}, "
        "stride={}, d_hyp={}, c={}, dld={}, steps={}, sched={}, eta={}, "
        "lh={}, lp={}, abl={}, revin={}".format(
            config["batch_size"],
            train_epochs,
            config["learning_rate"],
            config["d_model"],
            config["d_ff"],
            config["e_layers"],
            config.get("patch_len", 16),
            config.get("stride", 8),
            config.get("d_hyp", 64),
            config.get("manifold_c", 1.0),
            config.get("d_layers_diff", 2),
            config.get("diff_steps", 1),
            config.get("diff_schedule", "cosine"),
            config.get("diff_eta", 0.0),
            config.get("lambda_hyp", 0.1),
            config.get("lambda_prior", 0.1),
            config.get("ablation", "none"),
            config.get("revin", 1),
        )
    )
    print("Model ID: {}".format(model_id))
    print("=" * 80)
    print()
    print("Starting training...")
    print()

    log_dir = args.log_dir or LOG_DIR
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(
        log_dir,
        "M2Patch_{}_pl{}_{}.txt".format(config["dataset"], config["pred_len"], timestamp),
    )

    child_env = os.environ.copy()
    child_env["M2PATCH_SKIP_RESULT_WRITE"] = "1"

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        cwd=PROJECT_ROOT,
        env=child_env,
    )

    output_lines = []
    for line in iter(proc.stdout.readline, b""):
        decoded = line.decode("utf-8", errors="replace")
        print(decoded, end="")
        output_lines.append(decoded)

    proc.wait()

    if proc.returncode != 0:
        print("\nERROR: Training failed for M2Patch on {}".format(args.dataset))
        sys.exit(1)

    log_content = "".join(output_lines)
    print("\nParsing metrics...")

    metrics = parse_training_output(log_content)

    with open(log_path, "w") as f:
        f.write("CMD: {}\n".format(" ".join(cmd)))
        f.write("EPOCHS: {}\n".format(train_epochs))
        f.write(log_content)

    dataset_name = config.get("dataset", args.dataset)
    os.makedirs(output_dir, exist_ok=True)

    result = build_result_json(model_id, timestamp, config, metrics)

    json_path = write_json(output_dir, result)
    xlsx_path = XLSX_PATH if output_dir == DEFAULT_OUTPUT_DIR else os.path.join(output_dir, "efficiency_records.xlsx")
    append_to_xlsx(result, xlsx_path)

    print("Successfully parsed metrics for M2Patch on {}".format(dataset_name))
    print("  Model ID: {}".format(model_id))
    print("  MSE: {:.8f}".format(metrics["mse"]))
    print("  MAE: {:.8f}".format(metrics["mae"]))
    print("  Val MSE: {}".format(metrics.get("val_mse")))
    print("  Params: {}".format(metrics.get("params")))
    print(
        "  Inference Time: {:.4f} ms/iter".format(
            metrics.get("inference_time_ms_per_iter", 0.0)
        )
    )
    print("  Training Time: {:.2f} ms/iter".format(metrics["train_time_ms_per_iter"]))
    print(
        "  Avg Allocated GPU Memory: {:.2f} MB".format(
            metrics["avg_gpu_mem_allocated_mb"]
        )
    )
    print(
        "  Per-sample: {:.3f} ms, {:.3f} MB (batch={})".format(
            metrics["train_time_ms_per_iter"] / max(config["batch_size"], 1),
            metrics["avg_gpu_mem_allocated_mb"] / max(config["batch_size"], 1),
            config["batch_size"],
        )
    )
    print("JSON saved to: {}".format(json_path))
    print("XLSX updated: {}".format(xlsx_path))
    print("Log saved to: {}".format(log_path))
    print("=" * 80)


if __name__ == "__main__":
    main()
