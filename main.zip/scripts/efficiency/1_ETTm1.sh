#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/../.."

python scripts/efficiency/run_efficiency.py \
    --dataset ETTm1 \
    --pred_len 96 \
    --train_epochs 10 \
    --gpu 0 \
    --d_model 192 \
    --d_hyp 64 \
    --e_layers 2 \
    --d_layers_diff 2 \
    --learning_rate 5.5e-4 \
    --lambda_hyp 0.1 \
    --batch_size 16
