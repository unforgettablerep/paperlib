#!/bin/bash
# Shared GPU-wave scheduler and TSV resume helpers for M2Patch sensitivity runs.

PYTHON_BIN=${PYTHON_BIN:-python}
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/utils/result_common.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/utils/gpu_queue.sh"

PARALLEL=${PARALLEL:-2}
GPU_QUEUE_SESSION="${_SENSITIVITY_SESSION:-/tmp}"
gpu_queue_init

declare -A RANGES
PARAMS=()
while IFS=$'\t' read -r _param _values; do
    [[ -z "$_param" ]] && continue
    PARAMS+=("$_param")
    RANGES[$_param]="$_values"
done < <("$PYTHON_BIN" scripts/hyperparam/run_sensitivity.py --list-sweeps)

SEEDS=(2022 2023 2024 2025 2026)

_rotate_gpu() {
    gpu_queue_next
}

_dispatch() {
    local logfile=""
    if [[ -n "${_SENSITIVITY_LOG_DIR:-}" && -d "${_SENSITIVITY_LOG_DIR}" ]]; then
        if [[ -n "${GPU_LIST:-}" ]]; then
            logfile="${_SENSITIVITY_LOG_DIR}/worker_gpu${_CURRENT_GPU}_$$.log"
        else
            logfile="${_SENSITIVITY_LOG_DIR}/worker_standalone_$$.log"
        fi
    fi
    gpu_queue_dispatch "$logfile" "$@"
}

_wait_all() {
    gpu_queue_wait
}

# Numeric-tolerant resume check: `1e-4`, `0.0001` and `1e-04` all match.
_sensitivity_done() {
    local ds=$1 param=$2 val=$3 pl=$4 seed=$5
    local tsv="${RESULTS_DIR:-./output/hyperparam}/sensitivity_results_${ds}.tsv"
    [[ -f "$tsv" ]] || return 1
    awk -F'\t' -v p="$param" -v v="$val" -v pl="$pl" -v sd="$seed" '
        NR == 1 {
            for (c = 1; c <= NF; c++) idx[$c] = c
            next
        }
        !($idx["status"] ~ /^ok/) { next }
        $idx["sweep_param"] == p && $idx["pred_len"] == pl && $idx["seed"] == sd \
            && ($idx["sweep_value"] == v || ($idx["sweep_value"] + 0) == (v + 0)) { found = 1; exit }
        END { exit !found }
    ' "$tsv"
}

_run_sensitivity_cell() {
    local ds=$1 pl=$2 param=$3 val=$4 seed=$5
    _dispatch "$PYTHON_BIN" -u scripts/hyperparam/run_sensitivity.py \
        --dataset "$ds" \
        --sweep_param "$param" \
        --sweep_value "$val" \
        --pred_len "$pl" \
        --seed "$seed" \
        --gpu 0
}

run_all_cells() {
    local pl=$1
    local ds param val seed
    for ds in "${DATASETS[@]}"; do
        for param in "${PARAMS[@]}"; do
            for val in ${RANGES[$param]}; do
                for seed in "${SEEDS[@]}"; do
                    if _sensitivity_done "$ds" "$param" "$val" "$pl" "$seed"; then
                        echo "[skip] ${ds} pl=${pl} ${param}=${val} seed=${seed} already done"
                        continue
                    fi
                    _rotate_gpu
                    _run_sensitivity_cell "$ds" "$pl" "$param" "$val" "$seed"
                done
            done
        done
    done
    _wait_all
}

compact_results() {
    "$PYTHON_BIN" scripts/hyperparam/run_sensitivity.py --compact
}
