#!/bin/bash
# M2Patch hyperparameter sensitivity runner (multi-GPU, detached).

set -u

PYTHON_BIN=${PYTHON_BIN:-python}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$PROJECT_ROOT"

if [[ -n "${SENSITIVITY_DATASETS:-}" ]]; then
    read -ra DATASETS <<< "${SENSITIVITY_DATASETS}"
else
    DATASETS=(ETTh1 ETTh2 ETTm1 Weather Exchange)
fi
PRED_LEN=96

PARA=2
GPUS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --para) PARA="$2"; shift 2 ;;
        *)      GPUS+=("$1"); shift ;;
    esac
done

if [[ ${#GPUS[@]} -eq 0 ]]; then
    GPUS=(0)
fi

export SENSITIVITY_DATASETS="${DATASETS[*]}"
export SENSITIVITY_PRED_LEN="$PRED_LEN"
export M2PATCH_SKIP_RESULT_WRITE=1

mkdir -p log/hyperparam output/hyperparam

SWEEP_VALUES=$(
    "$PYTHON_BIN" scripts/hyperparam/run_sensitivity.py --list-sweeps |
        awk -F'\t' '{ n += split($2, values, " ") } END { print n+0 }'
)
SWEEP_VALUES=${SWEEP_VALUES:-0}
TOTAL_CELLS=$(( ${#DATASETS[@]} * SWEEP_VALUES * 5 ))

RESULTS_DIR="$PROJECT_ROOT/output/hyperparam"
export RESULTS_DIR

# GPU precheck — refuse to dispatch if any requested GPU is not visible to
# torch. Without this, every cell fails in <1s with RuntimeError at
# model.to(device) and the result TSV fills with error rows.
for _g in "${GPUS[@]}"; do
    if ! CUDA_VISIBLE_DEVICES="$_g" "$PYTHON_BIN" -c "
import sys, torch
try:
    assert torch.cuda.is_available() and torch.cuda.device_count() > 0
except AssertionError:
    print('ERROR: GPU $_g not visible to torch (cuda.is_available()=False or device_count=0)', file=sys.stderr)
    sys.exit(1)
" 2>&1; then
        echo "[$(date '+%H:%M:%S')] GPU precheck failed for GPU $_g. Aborting." >&2
        exit 1
    fi
done

LOG_FILE="$PROJECT_ROOT/log/hyperparam/all.log"

nohup bash -c '
set -u
PROJECT_ROOT="'"${PROJECT_ROOT}"'"
SCRIPT_DIR="'"${SCRIPT_DIR}"'"
PYTHON_BIN="'"${PYTHON_BIN}"'"
DATASETS_STR="'"${SENSITIVITY_DATASETS}"'"
PRED_LEN="'"${SENSITIVITY_PRED_LEN}"'"
PARA="'"${PARA}"'"
GPUS_STR="'"${GPUS[*]}"'"

cd "$PROJECT_ROOT"

# PID lock to prevent concurrent sensitivity runs
exec 200>/tmp/_m2patch_sensitivity.lock
if ! flock -n 200; then
    echo "[$(date "+%H:%M:%S")] ERROR: Another sensitivity run is in progress" >&2
    exit 1
fi

# Session directory for global FIFO semaphores + counter
export _SENSITIVITY_SESSION="/tmp/_m2patch_sensitivity_$$"
mkdir -p "$_SENSITIVITY_SESSION"
trap '"'"'rm -rf "${_SENSITIVITY_SESSION:-}"'"'"' EXIT

export GPU_LIST="$GPUS_STR"
export PARA_PER_GPU="$PARA"
export _GPU_COUNTER_FILE="${_SENSITIVITY_SESSION}/counter"
echo 0 > "$_GPU_COUNTER_FILE"

export RESULTS_DIR="$PROJECT_ROOT/output/hyperparam"
export M2PATCH_SKIP_RESULT_WRITE=1

# Per-run log directory
LOG_DIR="$PROJECT_ROOT/log/hyperparam/sensitivity_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$LOG_DIR"
export _SENSITIVITY_LOG_DIR="$LOG_DIR"

read -ra DATASETS <<< "$DATASETS_STR"

source "${SCRIPT_DIR}/sensitivity_common.sh"

TOTAL_CELLS=0
for ds in "${DATASETS[@]}"; do
    for param in "${PARAMS[@]}"; do
        TOTAL_CELLS=$((TOTAL_CELLS + $(echo ${RANGES[$param]} | wc -w)))
    done
done
TOTAL_CELLS=$((TOTAL_CELLS * ${#SEEDS[@]}))
TOTAL_WORKERS=$((${#_GPU_ARR[@]} * _PARA_PER_GPU))

echo "============================================================"
echo "[$(date "+%H:%M:%S")] Hyperparameter Sensitivity — M2Patch"
echo "  Datasets:    ${DATASETS[*]}"
echo "  Pred len:    $PRED_LEN"
echo "  Params:      ${PARAMS[*]}"
echo "  Seeds:       ${SEEDS[*]}"
echo "  Total cells: $TOTAL_CELLS"
echo "  GPUs:        ${#_GPU_ARR[@]} x ${_PARA_PER_GPU} parallel = $TOTAL_WORKERS workers"
echo "  Baseline:    Optuna best params, profile fallback (per dataset)"
echo "  Output:      $RESULTS_DIR/sensitivity_results_*.tsv"
echo "  Logs:        $LOG_DIR/"
echo "============================================================"

run_all_cells "$PRED_LEN" > "$LOG_DIR/run.log" 2>&1
EC=$?

# Compact each per-dataset TSV into canonical sweep order (serial, after all
# workers finished, so no locking is needed).
compact_results >> "$LOG_DIR/run.log" 2>&1

# Summary -- per-dataset TSV files are created lazily by result_io.
DONE=0
for ds in "${DATASETS[@]}"; do
    f="$RESULTS_DIR/sensitivity_results_${ds}.tsv"
    if [[ -f "$f" ]]; then
        rows=$(wc -l < "$f")
        DONE=$((DONE + rows - 1))
    fi
done
echo "" >> "$LOG_DIR/summary.log"
echo "============================================================" >> "$LOG_DIR/summary.log"
echo "[$(date "+%H:%M:%S")] All cells dispatched. Exit code: $EC" >> "$LOG_DIR/summary.log"
echo "  Result rows in TSV: $DONE / $TOTAL_CELLS" >> "$LOG_DIR/summary.log"
echo "  Results: $RESULTS_DIR/sensitivity_results_*.tsv" >> "$LOG_DIR/summary.log"
echo "  Logs:    $LOG_DIR/" >> "$LOG_DIR/summary.log"
echo "============================================================" >> "$LOG_DIR/summary.log"

echo "[$(date "+%H:%M:%S")] All sensitivity cells finished. Exit=$EC rows=$DONE/$TOTAL_CELLS"

rm -rf "${_SENSITIVITY_SESSION:-}"
' >> "$LOG_FILE" 2>&1 &

DISOWN_PID=$!
disown $DISOWN_PID 2>/dev/null || true
echo "[$(date '+%H:%M:%S')] Launched sensitivity runner as PID $DISOWN_PID"
echo "  Datasets: ${DATASETS[*]}  pred_len: $PRED_LEN"
echo "  GPUs: ${GPUS[*]}  slots/GPU: $PARA  total cells: $TOTAL_CELLS"
echo "  Log:  tail -f ${LOG_FILE}"
echo "  Results: output/hyperparam/sensitivity_results_*.tsv"
