import argparse
import fcntl
import gc
import hashlib
import json
import os
import random
import sys
import time
import traceback

import numpy as np

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from src.configs.m2patch_profiles import (
    D_FF_CAP,
    load_optuna_best_params,
    resolve,
    resolve_meta,
)
from src.configs.model_parser_dict import model_parser_dict
from src.utils.checkpoint import cleanup_checkpoint
from src.utils.result_io import DATASET_ORDER, append_result, canonical_dataset

SENSITIVITY_DATASETS = ("ETTh1", "ETTh2", "ETTm1", "Weather", "Exchange")
SENSITIVITY_PRED_LEN = 96

OUTPUT_DIR = os.path.join(REPO_ROOT, "output", "hyperparam")
CACHE_DIR = os.environ.get(
    "SENSITIVITY_CACHE_DIR",
    os.path.join(REPO_ROOT, "temp", "hyperparam_sensitivity_cache"),
)

SWEEP_RANGES = {
    "d_model": [64, 128, 256, 512],
    "d_hyp": [16, 32, 64, 128],
    "d_layers_diff": [1, 2, 3, 4],
    "learning_rate": [1e-4, 2.5e-4, 5e-4, 1e-3],
}

RESULT_COLUMNS = [
    "dataset",
    "pred_len",
    "sweep_param",
    "sweep_value",
    "seed",
    "mse",
    "mae",
    "status",
    "elapsed_s",
    "timestamp",
]

FINGERPRINT_KEYS = (
    "dataset",
    "model",
    "data",
    "root_path",
    "data_path",
    "model_id",
    "features",
    "freq",
    "seq_len",
    "label_len",
    "pred_len",
    "enc_in",
    "dec_in",
    "c_out",
    "e_layers",
    "d_layers",
    "d_model",
    "d_ff",
    "n_heads",
    "d_hyp",
    "manifold_c",
    "d_layers_diff",
    "diff_steps",
    "diff_schedule",
    "diff_eta",
    "lambda_hyp",
    "lambda_prior",
    "patch_len",
    "stride",
    "dropout",
    "learning_rate",
    "batch_size",
    "train_epochs",
    "patience",
    "pct_start",
    "lradj",
    "optim",
    "revin",
    "affine",
    "use_norm",
    "ablation",
    "use_amp",
    "num_workers",
    "itr",
    "seed",
)


def _build_default_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(conflict_handler="resolve")
    for common_parser in model_parser_dict["__all__"]:
        common_parser(parser=parser)
    for model_parser in model_parser_dict["M2Patch"]:
        model_parser(parser=parser)
    return parser.parse_args(
        [
            "--is_training",
            "1",
            "--model_id",
            "test",
            "--model",
            "M2Patch",
            "--data",
            "custom",
        ]
    )


def _build_setting(args) -> str:
    return (
        "{}_{}|{}|batch:{}|epochs:{}|el:{}|dm:{}|nh:{}|df:{}|patch:{}|stride:{}|"
        "dh:{}|dld:{}|steps:{}|sched:{}|lh:{}|lp:{}|lr:{}|itr:0"
    ).format(
        args.model_id,
        args.model,
        args.des,
        args.batch_size,
        args.train_epochs,
        args.e_layers,
        args.d_model,
        args.n_heads,
        args.d_ff,
        args.patch_len,
        args.stride,
        args.d_hyp,
        args.d_layers_diff,
        args.diff_steps,
        args.diff_schedule,
        args.lambda_hyp,
        args.lambda_prior,
        args.learning_rate,
    )


def _apply_params(args: argparse.Namespace, params: dict) -> None:
    for key, value in params.items():
        setattr(args, key, type(value)(value))


def _finalize_model_dims(args: argparse.Namespace) -> None:
    args.d_model = int(args.d_model)
    args.d_ff = min(args.d_model * 2, D_FF_CAP)
    n_heads = int(getattr(args, "n_heads", 8) or 8)
    while n_heads > 1 and args.d_model % n_heads != 0:
        n_heads -= 1
    args.n_heads = n_heads


def _parse_sweep_value(raw: str):
    try:
        return int(raw) if "." not in raw and "e" not in raw.lower() else float(raw)
    except ValueError:
        return raw


def _format_sweep_value(value) -> str:
    if isinstance(value, float):
        return "{:.6g}".format(value)
    return str(value)


def _result_path(dataset: str) -> str:
    return os.path.join(OUTPUT_DIR, f"sensitivity_results_{dataset}.tsv")


def _baseline_params(dataset: str, pred_len: int):
    try:
        return load_optuna_best_params(dataset, pred_len), "optuna"
    except FileNotFoundError:
        return resolve(dataset, pred_len), "profile"


def _fingerprint(dataset: str, args: argparse.Namespace) -> str:
    payload = {"dataset": dataset}
    for key in FINGERPRINT_KEYS:
        payload[key] = getattr(args, key, None)
    encoded = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha1(encoded.encode("utf-8")).hexdigest()[:16]


def _cache_path(dataset: str, fingerprint: str) -> str:
    return os.path.join(CACHE_DIR, dataset, f"{fingerprint}.json")


class _CacheLock:
    def __init__(self, dataset: str, fingerprint: str):
        self.path = _cache_path(dataset, fingerprint) + ".lock"
        self.handle = None

    def __enter__(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.handle = open(self.path, "a+")
        fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX)
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.handle is not None:
            fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None


def _read_cache(dataset: str, fingerprint: str):
    path = _cache_path(dataset, fingerprint)
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return None
    if data.get("status") != "ok" or data.get("mse") is None or data.get("mae") is None:
        return None
    return data


def _write_cache(dataset: str, fingerprint: str, payload: dict) -> None:
    path = _cache_path(dataset, fingerprint)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp_path = "{}.tmp.{}".format(path, os.getpid())
    with open(tmp_path, "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp_path, path)


def _sweep_sort_key(row: dict):
    dataset = str(row.get("dataset", ""))
    known = dataset in DATASET_ORDER
    try:
        pred_len = float(row.get("pred_len") or "inf")
    except ValueError:
        pred_len = float("inf")
    param = str(row.get("sweep_param", ""))
    param_rank = (
        list(SWEEP_RANGES).index(param) if param in SWEEP_RANGES else len(SWEEP_RANGES)
    )
    try:
        value = float(row.get("sweep_value") or "inf")
    except ValueError:
        value = float("inf")
    try:
        seed = int(float(row.get("seed") or 0))
    except ValueError:
        seed = 0
    return (
        len(DATASET_ORDER) if not known else DATASET_ORDER.index(dataset),
        "" if known else dataset,
        pred_len,
        param_rank,
        param,
        value,
        seed,
    )


def _dedup_rows(header: list, rows: list) -> list:
    cell_index = {name: header.index(name) for name in ("dataset", "pred_len", "sweep_param", "sweep_value", "seed")}
    status_index = header.index("status")
    chosen = {}
    order = []
    for position, row in enumerate(rows):
        try:
            value_key = float(row[cell_index["sweep_value"]])
        except (TypeError, ValueError):
            value_key = row[cell_index["sweep_value"]]
        key = (
            row[cell_index["dataset"]],
            row[cell_index["pred_len"]],
            row[cell_index["sweep_param"]],
            value_key,
            row[cell_index["seed"]],
        )
        is_ok = str(row[status_index]).startswith("ok")
        if key not in chosen:
            chosen[key] = (position, is_ok, row)
            order.append(key)
            continue
        prev_position, prev_ok, _ = chosen[key]
        if is_ok and not prev_ok:
            chosen[key] = (position, is_ok, row)
        elif is_ok == prev_ok:
            chosen[key] = (position, is_ok, row)
    return [chosen[key][2] for key in order]


def compact_sensitivity_tsv(path: str) -> int:
    if not os.path.exists(path):
        return 0
    with open(path) as handle:
        header = handle.readline().rstrip("\n").split("\t")
        rows = [line.rstrip("\n").split("\t") for line in handle if line.strip()]
    if header != RESULT_COLUMNS:
        raise ValueError(f"Unexpected header in {path}: {header}")
    rows = _dedup_rows(header, rows)
    keyed = [
        (_sweep_sort_key(dict(zip(header, row))), position, row)
        for position, row in enumerate(rows)
    ]
    keyed.sort(key=lambda item: (item[0], item[1]))
    tmp_path = path + ".tmp.{}".format(os.getpid())
    with open(tmp_path, "w") as handle:
        handle.write("\t".join(header) + "\n")
        for _, _, row in keyed:
            handle.write("\t".join(row) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp_path, path)
    return len(keyed)


def _compact_all(datasets: list) -> None:
    for dataset in datasets:
        path = _result_path(dataset)
        count = compact_sensitivity_tsv(path)
        if count:
            print(f"compacted {path} ({count} rows)")
        else:
            print(f"no result file yet: {path}")


def _run_training(args, dataset: str, setting: str):
    import torch

    from src.experiments.exp_long_term_forecasting import Exp_Long_Term_Forecast

    os.environ["M2PATCH_SKIP_RESULT_WRITE"] = "1"
    exp = Exp_Long_Term_Forecast(args)
    try:
        exp.train(setting)
        test_result = exp.test(setting)
        mse_val = mae_val = None
        if test_result is not None:
            mse_val, mae_val = test_result.get("mse"), test_result.get("mae")
        elif hasattr(exp, "_last_test_result") and exp._last_test_result:
            mse_val = exp._last_test_result.get("mse")
            mae_val = exp._last_test_result.get("mae")
        return exp, mse_val, mae_val
    finally:
        cleanup_seq = getattr(exp, "_lr_checkpoint_to_cleanup", None) or getattr(
            exp, "_active_ckpt_seq", None
        )
        if cleanup_seq is not None:
            try:
                cleanup_checkpoint(args, cleanup_seq)
            except OSError as exc:
                print(f"checkpoint cleanup failed: {exc}")


def main():
    cli = argparse.ArgumentParser(description="Single-experiment hyperparameter sweep")
    cli.add_argument("--dataset", type=str, choices=list(SENSITIVITY_DATASETS))
    cli.add_argument("--sweep_param", type=str)
    cli.add_argument("--sweep_value", type=str)
    cli.add_argument("--pred_len", type=int)
    cli.add_argument("--gpu", type=int, default=0)
    cli.add_argument("--seed", type=int, default=2023)
    cli.add_argument("--dry_run", action="store_true")
    cli.add_argument("--compact", action="store_true")
    cli.add_argument("--list-sweeps", action="store_true")
    opts = cli.parse_args()

    if opts.list_sweeps:
        for param, values in SWEEP_RANGES.items():
            print("{}\t{}".format(param, " ".join(_format_sweep_value(v) for v in values)))
        return

    if opts.compact:
        _compact_all([opts.dataset] if opts.dataset else list(SENSITIVITY_DATASETS))
        return

    if opts.dataset is None or opts.sweep_param is None or opts.sweep_value is None or opts.pred_len is None:
        cli.error("--dataset, --sweep_param, --sweep_value and --pred_len are required")

    dataset = canonical_dataset(opts.dataset)
    if dataset not in SENSITIVITY_DATASETS:
        cli.error("Unsupported dataset: {}".format(opts.dataset))
    if opts.pred_len != SENSITIVITY_PRED_LEN:
        cli.error("Sensitivity sweep is fixed at pred_len={}".format(SENSITIVITY_PRED_LEN))

    param = opts.sweep_param
    if param not in SWEEP_RANGES:
        print("ERROR: Unknown sweep_param '{}'. Valid: {}".format(param, list(SWEEP_RANGES)))
        sys.exit(1)

    value = _parse_sweep_value(opts.sweep_value)
    sweep_values = SWEEP_RANGES[param]
    if not any(float(value) == float(candidate) for candidate in sweep_values):
        print("WARNING: {}={} is outside the declared sweep {}".format(param, value, sweep_values))

    import torch

    meta = resolve_meta(dataset, opts.pred_len)
    defaults, baseline_source = _baseline_params(dataset, opts.pred_len)

    args = _build_default_args()
    args.is_training = 1
    args.model = "M2Patch"
    args.model_id = meta["model_id"]
    args.data = meta["data"]
    args.root_path = meta["root_path"]
    args.data_path = meta["data_path"]
    args.enc_in = meta["enc_in"]
    args.dec_in = meta["enc_in"]
    args.c_out = meta["enc_in"]
    args.features = meta.get("features", "M")
    if meta.get("freq") is not None:
        args.freq = meta["freq"]
    args.seq_len = meta["seq_len"]
    args.label_len = meta["label_len"]
    args.pred_len = opts.pred_len
    args.des = "HPARAM_SENSITIVITY_{}_{}_s{}".format(
        param, _format_sweep_value(value), opts.seed
    )
    args.use_gpu = True
    args.gpu = opts.gpu
    args.use_multi_gpu = False
    args.devices = str(opts.gpu)
    args.itr = 1
    args.output_attention = False
    args.do_predict = False
    args.save_tmp = 0
    args.exp_name = "MTSF"
    args.use_norm = True

    _apply_params(args, defaults)
    setattr(args, param, type(defaults[param])(value))
    _finalize_model_dims(args)
    args.seed = opts.seed

    setting = _build_setting(args)
    fingerprint = _fingerprint(dataset, args)
    cached = _read_cache(dataset, fingerprint)

    if opts.dry_run:
        print(f"[dry-run] dataset={dataset} pl={opts.pred_len} {param}={_format_sweep_value(value)} seed={opts.seed}")
        print(f"[dry-run] baseline source: {baseline_source}")
        print(f"[dry-run] baseline params: {defaults}")
        print(
            "[dry-run] applied d_model={} d_ff={} n_heads={} d_hyp={} d_layers_diff={} lr={}".format(
                args.d_model,
                args.d_ff,
                args.n_heads,
                args.d_hyp,
                args.d_layers_diff,
                args.learning_rate,
            )
        )
        print(f"[dry-run] setting: {setting}")
        print(f"[dry-run] fingerprint: {fingerprint} (cache hit: {cached is not None})")
        print(f"[dry-run] output tsv: {_result_path(dataset)}")
        return

    seed = int(getattr(args, "seed", 2023))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    tag = f"[{dataset} pl={opts.pred_len} {param}={_format_sweep_value(value)} s{seed}]"
    row = {
        "dataset": dataset,
        "pred_len": opts.pred_len,
        "sweep_param": param,
        "sweep_value": _format_sweep_value(value),
        "seed": opts.seed,
        "mse": "",
        "mae": "",
        "status": "running",
        "elapsed_s": "",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    if cached is not None:
        row["mse"] = f"{float(cached['mse']):.8f}"
        row["mae"] = f"{float(cached['mae']):.8f}"
        row["status"] = "ok"
        row["elapsed_s"] = f"{float(cached.get('elapsed_s', 0.0)):.1f}"
        print(f"{tag} Reused identical configuration from {_cache_path(dataset, fingerprint)}")
        append_result(_result_path(dataset), row, columns=RESULT_COLUMNS)
        return

    print(f"{tag} Starting training (baseline={baseline_source}) ...")
    t0 = time.time()
    exp = None
    with _CacheLock(dataset, fingerprint):
        cached = _read_cache(dataset, fingerprint)
        if cached is not None:
            row["mse"] = f"{float(cached['mse']):.8f}"
            row["mae"] = f"{float(cached['mae']):.8f}"
            row["status"] = "ok"
            row["elapsed_s"] = f"{float(cached.get('elapsed_s', 0.0)):.1f}"
            print(f"{tag} Reused identical configuration after lock wait")
            append_result(_result_path(dataset), row, columns=RESULT_COLUMNS)
            return
        try:
            exp, mse_val, mae_val = _run_training(args, dataset, setting)
            if (
                mse_val is not None
                and mae_val is not None
                and np.isfinite(mse_val)
                and np.isfinite(mae_val)
            ):
                row["mse"] = f"{float(mse_val):.8f}"
                row["mae"] = f"{float(mae_val):.8f}"
                row["status"] = "ok"
            else:
                row["status"] = "no_metrics"
        except RuntimeError as exc:
            if "out of memory" in str(exc).lower():
                row["status"] = "oom"
                print(f"{tag} OOM")
            else:
                message = str(exc).replace("\n", " ")[:160]
                row["status"] = f"error:RuntimeError:{message}"
                print(f"{tag} RuntimeError: {exc}")
        except Exception as exc:
            message = str(exc).replace("\n", " ")[:160]
            row["status"] = f"error:{type(exc).__name__}:{message}"
            print(f"{tag} Exception: {exc}")
            traceback.print_exc()
        finally:
            row["elapsed_s"] = f"{time.time() - t0:.1f}"
            if exp is not None:
                del exp
            gc.collect()
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
        if row["status"] == "ok":
            try:
                _write_cache(
                    dataset,
                    fingerprint,
                    {
                        "status": "ok",
                        "mse": float(row["mse"]),
                        "mae": float(row["mae"]),
                        "elapsed_s": float(row["elapsed_s"]),
                        "timestamp": row["timestamp"],
                        "fingerprint": fingerprint,
                        "sweep_param": param,
                        "sweep_value": _format_sweep_value(value),
                        "dataset": dataset,
                        "pred_len": opts.pred_len,
                        "seed": opts.seed,
                    },
                )
            except OSError as exc:
                print(f"cache write failed: {exc}")

    print(
        f"{tag} Done: status={row['status']}, mse={row.get('mse', 'N/A')}, "
        f"mae={row.get('mae', 'N/A')}, elapsed={row['elapsed_s']}s"
    )

    append_result(_result_path(dataset), row, columns=RESULT_COLUMNS)


if __name__ == "__main__":
    main()
